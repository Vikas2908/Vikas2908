sap.ui.define([
	'sap/ui/core/UIComponent',
	'com/upm/maint/dev/devapp',
	'com/upm/maint/controller/Application'
], function(UIComponent, devapp, Application) {
	'use strict';

	return UIComponent.extend('com.upm.maint.Component', {
		metadata: {
			manifest: 'json'
		},

		init: function() {
			// general applications initiate different OData models
			var navigatedToGeneralApplication = !(devapp && devapp.smpInfo && devapp.smpInfo.appID) && this.getNavigationIntent() === 'Approvals';
			new Application(this).init(navigatedToGeneralApplication);

			UIComponent.prototype.init.apply(this, arguments);

			this.initializeRouter();
		},

		initializeRouter: function() {
			var router = this.getRouter();
			router.initialize();
			if (!(devapp && devapp.smpInfo && devapp.smpInfo.appID) && this.containsNoNavigationPath()) {
				this.handleNavigationFromLaunchpad();
			}
		},

		handleNavigationFromLaunchpad: function() {
			var router = this.getRouter();
			var navigationIntent = this.getNavigationIntent();

			if (navigationIntent === 'CreateNotification') {
				router.navTo('CreateNotification', {
					Purpose: 'Create'
				}, true);
			} else if (navigationIntent === 'UserParameters') {
				router.navTo('UserParameters', {}, true);
			} else if (navigationIntent === 'ListNotifications') {
				router.navTo('Notifications', {}, true);
			} else if (navigationIntent === 'CreateOrder') {
				router.navTo('CreateOrder', {
					Purpose: 'Create',
					query: {
						Tab: 'Header'
					}
				}, true);
			} else if (navigationIntent === 'ListOrders') {
				router.navTo('Orders', {}, true);
			} else if (navigationIntent === 'RouteExcecution') {
				router.navTo('Routes', {}, true);
			} else if (navigationIntent === 'MyWork') {
				router.navTo('MyWorks', {}, true);
			} else if (navigationIntent === 'EquipmentDismantling') {
				router.navTo('EquipmentDismantling', {}, true);
			} else if (navigationIntent === 'Approvals') {
				router.navTo('WorkFlowApprovals', {}, true);
			} else if (navigationIntent === 'ObjectInfo') {
				router.navTo('TechnicalObjectSelection', {}, true);
			} else if (navigationIntent === 'MaterialSearch') {
				router.navTo('MaterialSearch', {}, true);
			} else if (navigationIntent === 'MaterialDetails') {
				router.navTo('MaterialDetails', {}, true);
			}
		},

		getNavigationIntent: function() {
			var urlParser = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService('URLParsing');
			return urlParser && urlParser.parseShellHash(urlParser.getHash(window.location.href)).action;
		},

		containsNoNavigationPath: function() {
			return window.location && window.location.hash && window.location.hash.indexOf('&/') === -1;
		}

	});
});