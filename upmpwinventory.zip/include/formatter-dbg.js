sap.ui.define([
    "sap/ui/core/format/DateFormat"
], function (DateFormat) {
   return {
        deliveryDate: function (value) {
            try {
                if (value) {
                    value = new Date(parseFloat(value.split("(")[1]));
                    var date = value.getDate();
                    var month = value.getMonth() + 1;
                    var year = value.getFullYear();
                    var fullDate = date + "." + month + '.' + year;
                }
                return fullDate;
            } catch (e) {
                console.log(e);
            }
        },

        getTime: function () {
            try {
                var date = new Date();
                var hour = date.getHours();
                var minutes = date.getMinutes();
                if (minutes < 10)
                    minutes = '0' + minutes;

                var time = hour + ':' + minutes;
                return time;
            } catch (e) {
                console.log(e);
            }
        },

        toShortDate: function (sDate) {
            if (sDate) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy"
                });
                return oDateFormat.format(new Date(sDate));
            }
            return sDate;
        },

        toDateTime: function (datetime) {
            if (datetime) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy HH:mm"
                });
                return oDateFormat.format(new Date(datetime));
            }
            return datetime;
        },
        getPlant: function(value) {
        	var plants = App.getModel("plants") ? App.getModel("plants").getData() : [];
        	var plant = plants.find(function(item, i) {
        		return item.Plant == value;
        	});
        	return (plant ? plant.Name : "");
        },
        getBtnVisible: function(item) {
        	if (item.zeroStock || item.confirm)
        		return false;
        	return true;
        },
        getCheckBoxEditable: function(item) {
        	return (item.confirm ? false : true);
        },
        getEditable: function(item) {
        	if (item.confirm || item.zeroStock)
				return false;
			return true;
        },
        getStatusText: function(item) {
        	return App.getTran(item.confirm ? "counted" : "open");
        },
        getStatusState: function(item) {
        	return item.confirm ? "Success" : "Warning";
        },
        getStatusVisible: function(item) {
        	if (item.confirm)
				return true;
			if (item.zeroStock || item.Quantity)
				return false;
			return true;
        },
        getConfirmVisible: function(item) {
        	if (item.confirm)
				return false;
			if (item.zeroStock || item.Quantity) 
				return true;
			return false;
        },
        checkValtype: function(valtypes) {
        	if (!valtypes || valtypes.length)
        		return false;
        	if (valtypes.length == 1 && valtypes[0].ValType == "")
        		return false;
        	return true;
        },
        checkItemsForVal: function(items) {
        	if (!items.length)
        		return true;
        	return items.filter(function(item, i) {
				return item.valTypes.length > 0;
			}).length > 0;
        },
        checkPI: function(pi) {
        	return !$.isEmptyObject(pi) ? true : false;
        },
        checkCameraAvailability: function(settings) {
        	return (settings.barcodeScanEnabled ? true : false);
        },
        startCountingVisible: function(settings) {
        	return !settings.countingStarted;
        },
        countingStartedVisible: function(settings) {
        	return settings.countingStarted;
        },
        createMode: function(arg) {
        	return !arg ? true : false;
        },
        getPIDoc: function(pi) {
        	return pi ? true : false;
        },
        isStorBinSelected: function(storBin) {
        	var selected = false;
        	if (!storBin) return selected;
        	
        	return App.getModel('selectedStorbins').getProperty('/').find(function(item) {
        		return item.StorBin == storBin;
        	}) ? true : false;
        }
    };
});