/* global App:true */
sap.ui.define([
	'sap/ui/core/BusyIndicator',
	'sap/ui/model/odata/v2/ODataModel',
	'sap/m/Dialog',
	'sap/ui/model/Filter',
], function(BusyIndicator, ODataModel, Dialog, Filter) {
	return {
		base_url: "/odata/SAP/ZWH_EQ_PI_SRV/",

		getBaseModel: function() {
			if (!this.baseServiceModel)
				this.baseServiceModel = new ODataModel(this.base_url, {
					json: true,
					useBatch: true
				});
			return this.baseServiceModel;
		},

		getUserId: function() {
			return sap.ushell ? sap.ushell.Container.getUser().getId() : null;
		},
		checkHostReachableASync: function() {
			var deferred = $.Deferred();
			var xhr = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
			xhr.open("HEAD", "?rand=" + Math.floor((1 + Math.random()) * 0x10000), true);
			xhr.onload = function () {
				return (xhr.status>= 200 && xhr.status < 300 || xhr.status === 304) ? deferred.resolve(true) : deferred.reject();
			};
			xhr.onerror = function () {
			  deferred.reject();
			};
			xhr.send();
			return deferred;	
		},
		checkHostReachable: function() {
			var xhr = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
			xhr.open("HEAD", "?rand=" + Math.floor((1 + Math.random()) * 0x10000), false);

			try{
				xhr.send();
				return (xhr.status>= 200 && xhr.status < 300 || xhr.status === 304);
			}	
			catch(e) {
				return false;
			}
		},
		showMessageDialog: function(state, title, message) {
			var dialog = new Dialog({
				state: state,
				title: title,
				content: new sap.m.Text({text: message})
			}).addStyleClass("oMsgDialog");
			dialog.open();
		},

		_odataRead: function(model, path, filters, sorters, params) {
			var self = this;
			var def = $.Deferred();
		
			model.read(path, {
				filters: (filters || []),
				sorters: (sorters || []),
				urlParameters: (params || ''),
				success: function(data) {
					def.resolve(data);
				},
				error: function(error) {
					def.reject(self._handleError(error));
				}
			});		
		
			return def;
		},
		_odataCreate: function(model, path, data) {
			var self = this;
			var def = $.Deferred();
			
			model.create(path, data, {
				context: null,
				success: function(data) {
					def.resolve(data);
				},
				error: function(error) {
					def.reject(self._handleError(error));
				},
				async:true
			});	
		
			return def;
		},
		_odataUpdate: function(model, path, data) {
			var self = this;
			var def = $.Deferred();
		
			model.update(path, data, {
				context: null,
				success: function(data) {
					def.resolve(data);
				},
				error: function(error) {
					def.reject(self._handleError(error));
				},
				async:true
			});
		
			return def;
		},
		_odataRemove: function(model, path) {
			var self = this;
			var def = $.Deferred();
		
			model.remove(path, {
				success: function(data) {
					def.resolve(data);
				},
				error: function(error) {
					def.reject(self._handleError(error));
				}
			});
			
			return def;
		},

		_handleError: function(error) {
			var message = "";
			var title = App.getTran('error');

			try{
				error = (error.response && error.response.body || error.responseText || error);
				error = JSON.parse(error);
				var innerError = error.error.innererror.errordetails;
				for (var i in innerError) {
					var errorMsg = innerError[i];

					if (errorMsg.code.indexOf('/IWBEP') == -1)
						message += errorMsg.message + '\n';
				}
			}
			catch(err) {
				message = error.error ? error.error.message.value : error.message;
			}
			if (!message)
				message = error.error ? error.error.message.value : error.message;
			
			return {title: title, message: message}; 
		},

		_baseDataRead: function(path, filter, sorter, urlParams) {
			return this._odataRead(this.getBaseModel(), path, filter, sorter, urlParams);
		},
		_baseDataCreate: function(path, data, base) {
			return this._odataCreate(this.getBaseModel(), path, data);
		},
		_baseDataUpdate: function(path, data) {
			return this._odataUpdate(this.getBaseModel(), path, data);
		},
		_baseDataRemove: function(path, data) {
			return this._odataRemove(this.getBaseModel(), path, data);
		},
		getPI: function(filters, pi, plant, storloc) {
			var path = "/PiHeaderSet";
			if (!filters.length) {
				path += "(PiDoc='" + window.encodeURIComponent(pi) + "',Plant='" + plant + "',Storloc='" + storloc + "')";
			}
			return this._baseDataRead(path, filters, [], '$expand=NavPiHeaderToItem');
		},
		getMaterial: function(value) {
			var path = "/MaterialSet('" + value +"')";
			return this._baseDataRead(path, [], [], '$expand=NavMaterialToUom,NavMaterialToSloc,NavMaterialToValType,NavMaterialToPiDoc');
		},
		getMaterialLimited: function(filters) {
			var path = "/MaterialSet";
			return this._baseDataRead(path, filters, [], '$expand=NavMaterialToUom,NavMaterialToValType');
		},
		getUserPlant: function() {
			var path = "/UserPlantSet";
			return this._baseDataRead(path);
		},
		postPI: function(data) {
			var path = "/PiHeaderSet";
			return this._baseDataCreate(path, data);
		},
		getPlantStorLocs: function(value) {
			var path = "/PlantStorLocSet";
			return this._baseDataRead(path);
		},
		getStorageBins: function(plant, stgloc) {
			var path = "/StorageBinSet";
			var filters = [
				new Filter('Plant', 'EQ', plant),
				new Filter('StorLoc', 'EQ', stgloc)
			];
			return this._baseDataRead(path, filters);
		}
		
	};
});