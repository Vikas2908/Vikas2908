sap.ui.jsview("com.upm.pw.z_wh_postpi.view.App", {
	getControllerName: function() {
		return "com.upm.pw.z_wh_postpi.controller.App";
	},
	createContent: function(oController) {
		var self = this;
		
		this.setDisplayBlock(true);
		this.storbinSelectDialog = this.getStorbinSelectDialog(oController);
		
		var oPage = new sap.m.Page({
			title: "{i18n>appTitle}",
			showHeader: false,
			content: [
				self.getHeader(oController),
				self.getToolbar(oController),
				self.getTable(oController)
				],
			footer: self.getFooter(oController)
		});

		this.app = new sap.m.App(this.createId("app"), {
			pages: [oPage]
		}).addStyleClass("whpostpi");
		return this.app;
	},
	getHeader: function(oController) {
		return new sap.ui.layout.HorizontalLayout({
			allowWrapping: true,
			content: [
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Label({
							text: "{i18n>plant}:"
						}),
						new sap.m.Select(this.createId("plantSelect"), {
							enabled: "{settings>/editEnabled}",
							selectedKey: "{settings>/plant}",
							change: [oController.plantChange, oController]
						}).bindAggregation("items", "plants>/", new sap.ui.core.Item({
							text: "{plants>Name}",
							key: "{plants>Plant}"
						}))
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Label({
							text: "{i18n>storageLocation}:"
						}),
						new sap.m.Input(this.createId("stgInput"), {
							enabled: "{settings>/editEnabled}",
							value: "{settings>/stglocText}",
							showValueHelp: true,
							valueHelpRequest: [oController.showStorageLocations, oController]
						})
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Label({
							text: "{i18n>storageBin}:"
						}),
						new sap.ui.layout.HorizontalLayout({
							content: [
								new sap.m.Switch({
									enabled: "{settings>/editEnabled}",
									customTextOn: " ",
									customTextOff: " ",
									state: '{settings>/storageBinVisible}'
								}).addStyleClass("marginRight5px"),
								new sap.m.MultiInput(this.createId('storbinInput'), {
									visible: '{settings>/storageBinVisible}',
									width: "192px",
									enabled: "{settings>/editEnabled}",
									change: [oController.storbinChange, oController],
									valueHelpRequest: [oController.showStorLocDialog, oController],
									tokenUpdate: [oController.storBinTokenUpdate, oController]
								}).bindAggregation("suggestionItems", "storbins>/", new sap.ui.core.Item({
									text: "{storbins>StorBin}",
									key: "{storbins>StorBin}"
								})).addStyleClass("oStorbinInput")
							]
						})
						
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Label({
							text: "{i18n>countDate}"
						}),
						new sap.m.DatePicker(this.createId("countDate"), {
							dateValue: "{settings>/countDate}",
							displayFormat: "dd.MM.yyyy"
						})
					]
				}),
				new sap.ui.layout.VerticalLayout({
					visible: {path: 'pi>/PiDoc', formatter: oController.formatter.getPIDoc},
					content: [
						new sap.m.Label({
							text: "{i18n>piDoc}"
						}),
						new sap.m.Label({
							text: "{pi>/PiDoc}"
						})
					]
				}).addStyleClass("cPaddingBottom"),

				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Label({
							text: "{i18n>useReference}"
						}),
						new sap.m.SearchField(this.createId("oSearchField"), {
							enabled: {path: 'settings>/createMode', formatter: oController.formatter.createMode},
							value: "{settings>/piBin}",
							search: [oController.PISearch, oController],
							placeholder: "{i18n>enterPiDoc}"
						}).addStyleClass("oSearchField")
					]
				})
			]
		}).addStyleClass("oHeaderContainer contentPadding fullWidth whiteBg"); 
	},
	getToolbar: function(oController) {
		return new sap.m.Toolbar({
				content: [new sap.m.Label(this.createId("itemsCount"), {
					text: "{i18n>items}"
				}), 
				new sap.m.ToolbarSpacer({
				}).addStyleClass("sapMTBSpacerFlex"),
				]
		}).addStyleClass("oTblToolbar whiteBg");
	},
	getTable: function(oController) {
		var self = this;
		return new sap.m.Table(this.createId("oTbl"), {
			mode: "MultiSelect",
			select: [oController.tableSelect, oController],
			//sticky: ["ColumnHeaders"],
			columns: [
				new sap.m.Column({
					width: "3%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>item}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					minScreenWidth: "Tablet",
					width: "18%",
					header : new sap.m.Label({
						text : "{i18n>material}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					minScreenWidth: "Tablet",
					width: "6%",
					header : new sap.m.Label({
						text : "{i18n>storageBin}"
					})
				}),
				new sap.m.Column({
					width: "13%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					hAlign: "Center",
					header : new sap.m.Label({
						text : "{i18n>quantity}"
					})
				}),
				new sap.m.Column({
					width: "6%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>unit}"
					})
				}),
				new sap.m.Column({
					width: "6%",
					visible: true,//{path: 'materials>/', formatter: oController.formatter.checkItemsForVal},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>valuationType}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					width: "6%",
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>zeroStock}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					minScreenWidth: "Tablet",
					width: "7%",
					hAlign: "Center",
					header : new sap.m.Label({
						text : "{i18n>status}"
					})
				})
			]
		}).bindAggregation("items", "materials>/", self.getTableTmpl(oController)).addStyleClass("oTbl");
	},
	getUITable: function(oController) {
		/*var self = this;
		return new sap.ui.table.Table(this.createId("oTbl"), {
			columns: [
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>item}"
					}),
					template: new sap.m.Text({
						text: "{materials>line}"
					})
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>material}"
					}),
					template: new sap.m.ObjectIdentifier({
						title: "{materials>MatlDesc}",
						text: "{materials>Material}"
					})
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>storageBin}"
					}),
					template: new sap.m.Text({
						text: "{materials>StorageBin}"
					})
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>quantity}"
					}),
					template: new sap.ui.layout.HorizontalLayout({
						content: [
							new sap.m.Button({
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getBtnVisible
								},*/
						/*		icon: "sap-icon://less",
								press: [oController.decrease, oController]
							}).addStyleClass("oQuantityActions"), 
							new sap.m.Input({
								change: [oController.updateQuantity, oController],
								/*enabled: {
									path: "materials>",
									formatter: oController.formatter.getEditable
								},*/
				/*				type: "Number",
								value: "{materials>Quantity}",
								valueLiveUpdate: true
							}).addStyleClass("oQuantityActions"), 
							new sap.m.Button({
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getBtnVisible
								},*/
					/*			icon: "sap-icon://add",
								press: [oController.increase, oController]
							}).addStyleClass("oQuantityActions")
							]
					}).addStyleClass("oQuantityBox")
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>unit}"
					}),
					template: new sap.m.Select({
						selectedKey: "{materials>Uom}"
					}).bindAggregation("items", {
						path: "materials>units/", 
						templateShareable: true,
						template: new sap.ui.core.Item({
							text: "{materials>Unitlangu}",
							key: "{materials>Unitlangu}"
						})
					}).addStyleClass("oSelectActions")
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>valuationType}"
					}),
					template: new sap.m.Select({
						enabled: "{materials>valTypeEditable}",
						//visible: {path: 'materials>valTypes', formatter: oController.formatter.checkValtype},
						selectedKey: "{materials>ValType}"
					}).bindAggregation("items", {
						path: "materials>valTypes/", 
						templateShareable: true,
						template: new sap.ui.core.Item({
							text: "{materials>ValType}",
							key: "{materials>ValType}"
						})
					}).addStyleClass("oSelectActions")
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>zeroStock}"
					}),
					template: new sap.m.CheckBox({
						/*enabled: {
							path: "materials>",
							formatter: oController.formatter.getCheckBoxEditable
						},*/
			/*			selected: "{materials>zeroStock}",
						select: [oController.handleZeroStock, oController]
					})
				}),
				new sap.ui.table.Column({
					label : new sap.m.Label({
						text : "{i18n>status}"
					}),
					template: new sap.ui.layout.HorizontalLayout({
						content: [
							new sap.m.ObjectStatus({
								text: ""/*{
									path: "materials>",
									formatter: oController.formatter.getStatusText
								},*/
								/*state: {
									path: "materials>",
									formatter: oController.formatter.getStatusState
								}*//*,
								visible: {
									path: "materials>",
									formatter: oController.formatter.getStatusVisible
								}*/
			/*				}),
							new sap.m.Button({
								text: "{i18n>confirm}",
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getConfirmVisible
								},*/
						/*		press: [oController.handleConfirm, oController]
							})
						]
					}).addStyleClass("oStatusBox")
				})
			]
		}).bindAggregation("rows", "materials>/").addStyleClass("oTbl");*/
	},
	getTableTmpl: function(oController) {
		return new sap.m.ColumnListItem({
			unread: false,
			cells: [
					new sap.m.Text({
						text: "{materials>line}"
					}),
					new sap.m.ObjectIdentifier({
						title: "{materials>MatlDesc}",
						text: "{materials>Material}"
					}),
					new sap.m.Text({
						text: "{materials>StorageBin}"
					}),
					new sap.ui.layout.HorizontalLayout({
						content: [
							new sap.m.Button({
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getBtnVisible
								},*/
								icon: "sap-icon://less",
								press: [oController.decrease, oController]
							}).addStyleClass("oQuantityActions"), 
							new sap.m.Input({
								change: [oController.updateQuantity, oController],
								/*enabled: {
									path: "materials>",
									formatter: oController.formatter.getEditable
								},*/
								type: "Number",
								value: "{materials>Quantity}",
								valueLiveUpdate: true
							}).addStyleClass("oQuantityActions"), 
							new sap.m.Button({
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getBtnVisible
								},*/
								icon: "sap-icon://add",
								press: [oController.increase, oController]
							}).addStyleClass("oQuantityActions")
							]
					}).addStyleClass("oQuantityBox"),
					new sap.m.Select({
						selectedKey: "{materials>Uom}"
					}).bindAggregation("items", {
						path: "materials>units/", 
						templateShareable: true,
						template: new sap.ui.core.Item({
							text: "{materials>Unitlangu}",
							key: "{materials>Unitlangu}"
						})
					}).addStyleClass("oSelectActions"),
					new sap.m.Select({
						enabled: "{materials>valTypeEditable}",
						//visible: {path: 'materials>valTypes', formatter: oController.formatter.checkValtype},
						selectedKey: "{materials>ValType}"
					}).bindAggregation("items", {
						path: "materials>valTypes/", 
						templateShareable: true,
						template: new sap.ui.core.Item({
							text: "{materials>ValType}",
							key: "{materials>ValType}"
						})
					}).addStyleClass("oSelectActions"),
					new sap.m.CheckBox({
						/*enabled: {
							path: "materials>",
							formatter: oController.formatter.getCheckBoxEditable
						},*/
						selected: "{materials>zeroStock}",
						select: [oController.handleZeroStock, oController]
					}),
					new sap.ui.layout.HorizontalLayout({
						content: [
							new sap.m.ObjectStatus({
								text: ""/*{
									path: "materials>",
									formatter: oController.formatter.getStatusText
								},*/
								/*state: {
									path: "materials>",
									formatter: oController.formatter.getStatusState
								}*//*,
								visible: {
									path: "materials>",
									formatter: oController.formatter.getStatusVisible
								}*/
							}),
							new sap.m.Button({
								text: "{i18n>confirm}",
								/*visible: {
									path: "materials>",
									formatter: oController.formatter.getConfirmVisible
								},*/
								press: [oController.handleConfirm, oController]
							})
						]
					}).addStyleClass("oStatusBox")
				]
		}).addStyleClass("oListItem");
	},
	getFooter: function(oController) {
		return new sap.m.Bar({
			contentLeft: [
				new sap.m.Button(this.createId("cameraBtn"), {
					visible: {path: 'settings>/', formatter: oController.formatter.checkCameraAvailability},
					enabled: {path: 'pi>/', formatter: oController.formatter.checkPI},
					icon: "sap-icon://camera",
					press: [oController.scanBarcode, oController]
				}),
				new sap.m.SearchField(this.createId("matSearch"), {
					enabled: {path: 'pi>/', formatter: oController.formatter.checkPI},
					width: "20rem",
					placeholder: "{i18n>countItemByScanning}",
					search: [oController.materialSearch, oController]
				}),
				new sap.m.Button({
					text: "{i18n>markUncountedZero}",
					press: [oController.markZero, oController]
				}),
				new sap.m.Button({
					visible: false,
					type: "Transparent",
					icon: "sap-icon://add"
				}),
				new sap.m.Button({
					type: "Transparent",
					icon: "sap-icon://edit",
					press: [oController.enableRowEdit, oController]
				}),
				new sap.m.Button({
					type: "Transparent",
					icon: "sap-icon://delete",
					press: [oController.deleteRow, oController]
				})
			],
			contentRight : [ 
				new sap.m.Button({
					visible: {path: 'settings>/', formatter: oController.formatter.startCountingVisible},
					text : "{i18n>startCounting}",
					type : "Emphasized",
					press: [oController.startCounting, oController]
				}).addStyleClass("footerbutton"),
				new sap.m.Button({
					visible: {path: 'settings>/', formatter: oController.formatter.countingStartedVisible},
					text : "{i18n>cancel}",
					type : "Reject",
					press: [oController.cancel, oController]
				}).addStyleClass("footerbutton"),
				new sap.m.Button(this.createId("saveBtn"), {
					visible: {path: 'settings>/', formatter: oController.formatter.countingStartedVisible},
					text : "{i18n>save}",
					type: "Accept",
					press: [oController.complete, oController]
				}).addStyleClass("footerbutton"),
				new sap.m.Button({
					visible: false,
					text : "{i18n>complete}",
					type : "Emphasized",
					press: [oController.complete, oController]
				}).addStyleClass("footerbutton")
			]
		}).addStyleClass("footerbar");
	},
	getStorbinSelectDialog: function(oController) {
		var selectDlg = new sap.m.TableSelectDialog({
			multiSelect: true,
			title: "{i18n>searchStorbin}",
			confirm: [oController.storBinSelect, oController],
			liveChange: [oController.storBinSearch, oController],
			columns: [
				new sap.m.Column({
					header: new sap.m.Text({
						text: ""
					})
				})
			]
		});
		var	oListItem = new sap.m.ColumnListItem({
			cells: [
				new sap.m.Title({
					text: "{storbins>StorBin}"
				})
			],
			selected: {path: 'storbins>StorBin', formatter: oController.formatter.isStorBinSelected}
		});
	
		selectDlg.bindAggregation("items", "storbins>/", oListItem);
		
		this.addDependent(selectDlg);
		return selectDlg;
	},
	onAfterRendering: function() {
		
	}

});