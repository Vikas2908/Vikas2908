/* global App:true 
   global Quagga:true */
sap.ui.define([
	"com/upm/pw/z_wh_postpi/controller/BaseController",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	'sap/ui/model/json/JSONModel',
	"com/upm/pw/z_wh_postpi/include/formatter",
	'sap/m/Dialog',
	'sap/m/MessageBox',
	'sap/ui/model/Filter'
], function(BaseController, Sorter, MessageToast, JSONModel, Formatter, Dialog, MessageBox, Filter) {

	return BaseController.extend("com.upm.pw.z_wh_postpi.controller.App", {
		formatter: Formatter,
		onInit: function() {
			App.view = this;
			this.view = this.getView();
			this.searchField = this.view.byId("oSearchField");
			this.storbinSelectDialog = this.view.storbinSelectDialog;
			this.scanningNewAllowed = false;
		},
		handleBack: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			// Navigate back to FLP home
			oCrossAppNavigator.toExternal({
				target : {shellHash: "#"}
			});
		},
		onExit: function() {
			if (this.extendingSession)
				clearInterval(this.extendingSession);
		},
		startExtendingSession: function() {
        	this.extendingSession = setInterval(App.sync.checkHostReachableASync, 300000); //refresh last server ping every 5 minutes
        },
		//called after view rendering
		prepareFunc: function() {
			var self = this;
			var settings = App.getModel("settings");
			jQuery.sap.delayedCall(800, this, function() {
				self.initBarcodeScanning(function(){
					settings.refresh(true);
					self.refreshItemsCount();
					self.searchField.focus();
				});
			});
			this.startExtendingSession();
		},
		//refresh material and pi models, material counter, calculates line numbers for each material item
		refreshModels: function() {
			var settings = App.getModel("settings");
			var pi = App.getModel("pi");
			var materials = App.getModel("materials");
			var table = this.view.byId("oTbl");
			settings.refresh(true);
			pi.refresh(true);
			materials.refresh(true);
			table.removeSelections();
			this.refreshItemsCount();
			this.calculateLineNumbers();
			this.refreshTblCells();
		},
		refreshTblCells: function() {
			var self = this;
			App.showLoader();
			var table = this.byId('oTbl');
			var tableItems = table.getItems();
			
			function refreshCells() {
				var def = $.Deferred();
				for (var i in tableItems) {
					var rowElem = tableItems[i];
					var itemData = rowElem.getBindingContext("materials").getObject();
					self.updateRowElems(itemData, rowElem);                       
				}
				def.resolve();
				return def;
			}
			refreshCells().done(function() {
				App.hideLoader();
			});
		},
		//material counter in toolbar header
		refreshItemsCount: function() {
			var itemsCountTitle = this.view.byId("itemsCount");
			var items = App.getModel("materials").getProperty("/");
			var table = this.view.byId("oTbl");
			var itemsSelected = table.getSelectedItems();
			if (itemsSelected.length > 0) {
				itemsCountTitle.setText(App.getTran("itemsCount", [itemsSelected.length, items.length]));
			} else {
				itemsCountTitle.setText(App.getTran("itemsCount", [items.length, items.length]));
			}
		},
		getStorBinFilters: function(storbins) {
			return storbins.map(function(storbin) {
				return new Filter('PiDoc', 'EQ', storbin);
			});
		},
		//search for physical inventory document / storage bin
		//plant and storage location is needed
		PISearch: function(oEvent) {
			var self = this;
			var value = oEvent.getParameter("query"),
			settings = App.getModel("settings"),
			plantInput = this.view.byId("plantSelect"),
			stgInput = this.view.byId("stgInput"),
			plant = settings.getProperty("/plant"), 
			storloc = settings.getProperty("/stgloc"),
			materialModel = App.getModel("materials"),
			materials = materialModel.getProperty("/"),
			valid = false,
			storbins = this.byId('storbinInput').getTokens().map(function(token) {
				return token.getKey();
			});
			if (value.length === 0 && storbins.length === 0 && settings.getProperty('/storageBinVisible')) {
				return;
			}
			
			App.showLoader();
			if (value.indexOf("/") > -1) {
				value = window.encodeURIComponent(value);
			}
			if (!plant || !storloc) {
				App.hideLoader();
				self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("missingPlantOrStg"), function() {
					self.searchField.setValue("");
					jQuery.sap.delayedCall(500, self, function() {
						if (!plant) {
							plantInput.focus();
						} else if (!storloc) {
							stgInput.focus();
						}
					});
				});
				return false;
			}
			function search() {
				var filters = storbins.length > 1 ? [
					new Filter('Plant', 'EQ', plant),
					new Filter('Storloc', 'EQ', storloc),
					new Filter({
						and: false,
						filters: self.getStorBinFilters(storbins)
					})
				] : [];
				if (!value && storbins.length > 0) {
					value = storbins[0];
				}
				if (!value) {
					filters = [
						new Filter('Plant', 'EQ', plant),
						new Filter('Storloc', 'EQ', storloc)
					];
				}
				App.sync.getPI(filters, value, plant, storloc).done(function(response) {
					App.hideLoader();
					if (filters.length === 0) {
				
						/*
						* If we don't have PI document then we will notify user and SAP will create it when posting
						*/
						if (response.PiDoc.length === 0 && response.NavPiHeaderToItem.results.length > 0) {
							App.hideLoader();
							self.showPromptDialog(App.getTran("inventoryDocument"),	"None", App.getTran("noPIFound", [response.StorageBin]), App.getTran("createNew"),
								function(dlg) {
									dlg.close();
									self.handlePIData(response);
								},
								App.getTran("cancel"),
								function(dlg) {
									dlg.close();
									return false;
								}
							);
						} else {
							self.handlePIData(response);
						}
					} else {
						self.handleManyPIData(response.results);
					}
					settings.setProperty("/editEnabled", false);
					settings.setProperty("/countingStarted", true);
				}).fail(function(e) {
					App.hideLoader();
					settings.setProperty("/editEnabled", true);
					settings.setProperty("/countingStarted", false);
					settings.setProperty("/createMode", false);
					self.getAppModel('pi').setData({});
					settings.refresh(true);
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						self.searchField.setValue("");
						jQuery.sap.delayedCall(500, self, function() {self.searchField.focus();});
					});
				});
			}
			if (materials.length > 0) {
				this.showDeleteDialog("Warning", 
					App.getTran("warning"),
					App.getTran("materialsWillRemove"),
					function(dialog) {
						dialog.close();
						valid = true;
						search();
					},
					function(dialog) {
						dialog.close();
						App.hideLoader();
					}
				);
			} else {
				valid = true;
			}
			
			if (valid) {
				search();
			}
		},
		handleManyPIData: function(results) {
			var data = {
				Plant: '',
				Storloc: '',
				PiYear: '',
				PiDoc: '',
				CountStatus: '',
				CountDate: '',
				NavPiHeaderToItem: {
					results: []
				}
			};
			for (var i in results) {
				var res = results[i];
				if (parseInt(i) === 0) {
					data.Plant = res.Plant;
					data.Storloc = res.Storloc;
					data.PiYear = res.PiYear;
					data.PiDoc = res.PiDoc;
					data.CountStatus = res.CountStatus;
					data.CountDate = res.CountDate;
				}
				
				for (var ii in res.NavPiHeaderToItem.results) {
					var item = Object.assign({}, res.NavPiHeaderToItem.results[ii]);
					item.StorageBin = res.StorageBin;
					data.NavPiHeaderToItem.results.push(item);
				}
			}
			this.handlePIData(data);
		},
		//Process PI data from getPI OData call
		handlePIData: function(data) {
			var self = this;
			var settings = App.getModel("settings");
			var storlocsModel = App.getModel("stglocs");
			var storlocs = storlocsModel.getData(); 
			var piModel = App.getModel("pi");
			var materialModel = App.getModel("materials");
			var piItems = data.NavPiHeaderToItem.results;
			var items = [];
			var ids = [];
			var binFetchNeeded = false;
			App.showLoader();
			if (data.Plant.length > 0 && data.Storloc.length > 0) {
				var selectedStorLoc = storlocs.find(function(stg) {
					return stg.Plant == data.Plant && stg.Storloc == data.Storloc;
				});
				if (selectedStorLoc) {
					var currentStgLoc = settings.getProperty("/stgloc");
					if (currentStgLoc != selectedStorLoc.Storloc) {
						binFetchNeeded = true;
					}
					settings.setProperty("/plant", data.Plant);
					settings.setProperty("/stgloc", selectedStorLoc.Storloc);
					settings.setProperty("/stglocText", selectedStorLoc.StoreLocDesc);
					settings.setProperty("/stgbin", data.StorageBin);
				}
			}
			if (data.CountDate)
				settings.setProperty("/countDate", data.CountDate);
			
			settings.setProperty("/countingStarted", true);
			var selectedPlant = settings.getProperty("/plant");
			//get uoms, valtypes and units for material one by one
			for (var i in piItems) {
				var item = piItems[i];
				ids.push(item.Material);
				var isZeroCount = (item.ZeroCount.length > 0 ? true : false);
				items.push({
					Itemno: item.ItemNo,
					Material: item.Material,
					StorageBin: (item.StorageBin != undefined ? item.StorageBin : item.StorBin != undefined ? item.StorBin : ''),
					MatlDesc: item.Maktx,
					Quantity: (isZeroCount ? 0 : parseInt(item.Quantity) > 0 ? parseInt(item.Quantity) : ""),
					Uom: item.Unit,
					units: [],
					zeroStock: isZeroCount,
					confirm: false,
					deletable: false,
					ValType: (item.ValType ? item.ValType : ""),
					valTypeEditable: false
				});
			}
			if (ids.length > 0) {
				self.fetchMaterialUnitsAndValTypesFor(items, ids).done(function(result) {
					if (items.length > 0) {
						for (var ii in items) {
							var matItem = items[ii];
							var resItem = result.find(function(res) {
								return res.Matnr == matItem.Material;
							});
							if (!resItem) continue;
							//items.units.length==0 because we want to have uoms even for duplicates
							if (matItem.Material == resItem.Matnr && matItem.units.length == 0) {
								matItem.units = resItem.NavMaterialToUom.results;
								matItem.Uom = (matItem.Uom.length > 0 ? matItem.Uom : resItem.NavMaterialToUom.results.length > 0 ? resItem.NavMaterialToUom.results[0].Unitlangu : "");
								matItem.valTypes = resItem.NavMaterialToValType.results.filter(function(oIt) {
									return oIt.Plant == selectedPlant;
								});
							}
						}
						piModel.setData(data);
						materialModel.setData(items);
						self.refreshModels();
						settings.setProperty("/piBin", "");
						//to disable PI searchfield
						settings.setProperty("/createMode", true);
						App.hideLoader();
						if (binFetchNeeded) {
							self.getStoragebins(data.Plant, data.Storloc, function(storbins) {
								App.getModel("storbins").setSizeLimit(999999);
								App.getModel("storbins").setData(storbins);
								self.refreshModels();
							});
						}
						App.hideLoader();
					} else {
						App.hideLoader();
					}
					
					
				});
			} else {
				piModel.setData(data);
				materialModel.setData([]);
				App.hideLoader();
			}
			
			// if CountStatus has something then we cannot scan new materials
			this.scanningNewAllowed = settings.getProperty('/storageBinVisible') ? false : true;//(data.CountStatus ? false : true);
		},
		fetchMaterialUnitsAndValTypesFor: function(materials, materialIds) {
			var def = $.Deferred();
			var filters = materialIds.map(function(material) {
				return new Filter('Matnr', 'EQ', material);
			});
			App.sync.getMaterialLimited(filters).done(function(response) {
				def.resolve(response.results);
			});
			return def;
		},
		/*
		* Material search, very complicated ;)
		* Basically we scan materials and select valuation type
		* we can scan many times same material as long it's with different valuation type
		*/
		materialSearch: function(oEvent) {
			var self = this;
			App.showLoader();
			var view = this.getView();
			var materialModel = App.getModel("materials");
			var settings = App.getModel("settings");
			var materialItems = materialModel.getProperty("/");
			var selectedPlant = settings.getProperty("/plant");
			var selectedStgloc = settings.getProperty("/stgloc");
			var value = oEvent.getParameter("query");
			var input = oEvent.getSource();
			if (value.length == 0) {
				App.hideLoader();
				return;
			}
			
			var pann = /^[0-9+]*$/;
			if (!pann.test(value) || value.length > 18) {
				App.hideLoader();
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("valueError"), function() {
					input.setValue("");
					jQuery.sap.delayedCall(500, self, function() {input.focus(); });
				});
				return;
			}
			var foundMats = materialItems.filter(function(item) {
				return item.Material == value;
			});
			
			if ((!self.scanningNewAllowed && foundMats.length > 0) || foundMats.length > 0) {
				// if material exists and only one we increase the quantity
				if (foundMats.length === 1) {
					var mat = foundMats[0];
					mat.Quantity = (parseInt(mat.Quantity) ? parseInt(mat.Quantity) + 1 : 1);
					App.hideLoader();
					input.setValue("");
					self.updateElemByMat(mat, false, true);
					jQuery.sap.delayedCall(500, self, function() {input.focus(); });
				} else {
					// if we have multiple then we show valuation types
					// if material with selected valuation exists we increase its value, otherwise we copy
					// material as new line with selected valuation type
					var filteredMats = materialItems.filter(function(item) {
						return item.Material == value && item.valTypes.length > 0;
					});
					
					if (filteredMats.length > 0) {
						var valTypes = filteredMats[0].valTypes;
						self.showValTypeDialog(valTypes, function(selected) {
							//check if we have selected material with selected valuation type
							var selectedMat = materialItems.filter(function(itm) {
								return itm.Material == value && itm.ValType == selected;
							});
							//if we have then increase its value
							if (selectedMat.length > 0) {
								selectedMat[0].Quantity = (parseInt(selectedMat[0].Quantity) ? parseInt(selectedMat[0].Quantity) + 1 : 1);
								App.hideLoader();
								input.setValue("");
								self.updateElemByMat(selectedMat, selected, true);
								jQuery.sap.delayedCall(500, self, function() {input.focus(); });
							} else {
								//otherwise copy material line as new with different data
								var copyMatAsNew = $.extend({}, filteredMats[0]);
								copyMatAsNew.Quantity = 1;
								copyMatAsNew.zeroStock = false;
								copyMatAsNew.confirm = false;
								copyMatAsNew.deletable = true;
								copyMatAsNew.ValType = selected;
								copyMatAsNew.valTypeEditable = true;
								materialItems.push(copyMatAsNew);
								App.hideLoader();
								input.setValue("");
								self.refreshModels();
								jQuery.sap.delayedCall(500, self, function() {input.focus(); });
							}
						});
					} else {
						App.hideLoader();
						input.setValue("");
						//self.refreshModels();
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					}
				}
			} else if (self.scanningNewAllowed) {
				//otherwise if not in list and scanning new is enabled we search from SAP
				//we show select valuation type dialog if there's more than one valtype
				//
				App.sync.getMaterial(value).done(function(response) {
					var materialExistsInSelectedStorLoc = response.NavMaterialToSloc.results.filter(function(stg){
						return stg.Plant == selectedPlant && stg.Storloc == selectedStgloc;
					});

					if (!materialExistsInSelectedStorLoc.length) {
						self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("materialNotInStorageLocation", [selectedPlant, selectedStgloc]), function() {
							input.setValue("");
							jQuery.sap.delayedCall(500, self, function() {input.focus(); });
						});
						App.hideLoader();
						return false;
					}
					
					var valtypes = response.NavMaterialToValType.results.filter(function(oIt) {
						return oIt.Plant == selectedPlant && oIt.ValType.length > 0;
					});
					var valTypesAll = response.NavMaterialToValType.results.filter(function(oIt) {
						return oIt.Plant == selectedPlant;
					});
					
					function pushMat(valtype) {
						var matIndex = materialItems.findIndex(function(item) {
							return item.Material == response.Matnr && item.ValType == valtype;
						});
						
						if (matIndex > -1) {
							var mat = materialItems[matIndex];
							mat.Quantity = (parseInt(mat.Quantity) ? parseInt(mat.Quantity) + 1 : 1);
						} else if (self.scanningNewAllowed) {
							materialItems.push({
								Material: response.Matnr,
								MatlDesc: response.Maktx,
								Quantity: 1,
								Uom: (response.NavMaterialToUom.results.length > 0 ? response.NavMaterialToUom.results[0].Unitlangu : ""),
								units: response.NavMaterialToUom.results,
								zeroStock: false,
								confirm: false,
								deletable: true,
								valTypes: valTypesAll,
								ValType: valtype,
								valTypeEditable: true,
								StorageBin: materialExistsInSelectedStorLoc[0].StoreBin
							});
						}
						
						App.hideLoader();
						input.setValue("");
						self.refreshModels();
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					}
					
					if (valtypes.length > 1) {
						App.hideLoader();
						self.showValTypeDialog(valtypes, function(selected) {
							self.checkMaterialDocs(response, selected, input, function() {
								pushMat(selected);
							});
						});
					} else {
						var autoValType = valtypes.length ? valtypes[0].ValType : "";
						self.checkMaterialDocs(response, autoValType, input, function() {
							pushMat(autoValType);
						});
					}
				}).fail(function(e) {
					App.hideLoader();
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						input.setValue("");
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					});
				});
			} else {
				App.hideLoader();
				input.setValue("");
				//self.refreshModels();
				jQuery.sap.delayedCall(500, self, function() {input.focus(); });
			}
		},
		checkMaterialDocs: function(data, valtype, input, callback) {
			var self = this;
			var settings = App.getModel("settings");
			var selectedPlant = settings.getProperty("/plant");
			var selectedStgloc = settings.getProperty("/stgloc");
			var piDocsExists = data.NavMaterialToPiDoc.results.filter(function(doc) {
				return doc.Plant == selectedPlant && doc.StorLoc == selectedStgloc && doc.ValType == valtype;
			});
			if (!piDocsExists.length) {
				callback();
			} else {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("matDocExistsForSelected",
												[piDocsExists[0].PiDoc, piDocsExists[0].Plant, piDocsExists[0].StorLoc, piDocsExists[0].ValType]),
												function() {
													input.setValue("");
													jQuery.sap.delayedCall(500, self, function() {input.focus(); });
												}
				);
				App.hideLoader();
				return false;
			}
		},
		// valuation type dialog
		showValTypeDialog: function(valtypes, callback) {
			var dialog = new sap.m.Dialog({
    			title: App.getTran("selectValType"),
    			content: [],
    			buttons: []
    		}).addStyleClass("oDialogContent oCustomDlg");
    		
			var list = new sap.m.List({
				mode: "SingleSelectMaster",
				width: "auto",
				select: function(listEvent) {
					var selected = listEvent.getParameter("listItem").getBindingContext().getObject();
					callback(selected.ValType);
					dialog.close();
				}
			}).bindAggregation("items", "/", new sap.m.StandardListItem({
				title: "{ValType}"
			}));

			list.setModel(new JSONModel(valtypes));
			dialog.addContent(list);
			dialog.open();
		},
		//plant change
		plantChange: function(oEvent) {
			var settings = App.getModel("settings");
			settings.setProperty("/stgloc", "");
			settings.setProperty("/stglocText", "");
			settings.setProperty("/stgbin", "");
			App.getModel("storbins").setData([]);
		},
		//show storage locations
		showStorageLocations: function(oEvent) {
			var self = this;
			var settings = App.getModel("settings");
			var plant = settings.getProperty("/plant");
			var storlocModel = App.getModel("stglocs");
			var storlocs = storlocModel.getData(); 
			var selectDlg = new sap.m.SelectDialog({
				title: App.getTran("selectStgLoc"),
				confirm: function(oDlgEvent) {
					var selected = oDlgEvent.getParameter("selectedItem").getBindingContext().getObject();
					settings.setProperty("/stgloc", selected.Storloc);
					settings.setProperty("/stglocText", selected.StoreLocDesc);
					self.getStoragebins(plant, selected.Storloc, function(storbins) {
						App.getModel("storbins").setSizeLimit(999999);
						App.getModel("storbins").setData(storbins);
					});
				},
				liveChange: [self.stgLocSearch, self]
			});
			
			var	oListItem = new sap.m.StandardListItem({
				title: "{StoreLocDesc}",
				description: "{Storloc}"
			});
			var plantStorLocs = storlocs.filter(function(item) {
				return item.Plant == plant;
			});
			selectDlg.setModel(new JSONModel(plantStorLocs));
			selectDlg.bindAggregation("items", "/", oListItem);
			
			selectDlg.open();
			if (selectDlg.getBinding("items"))
				selectDlg.getBinding("items").filter([]);
		},
		//stg loc search
		stgLocSearch: function(oEvent) {
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Storloc", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("StoreLocDesc", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		//storage bin change
		storbinChange: function(oEvent) {
			var selectedKeys = oEvent.getSource().getTokens().map(function(item) {
				return item.getKey();
			});
			var selectedStorbins = this.getAppModel('storbins').getProperty('/').filter(function(item) {
				return selectedKeys.indexOf(item.StorBin) > -1;
			});
			this.getAppModel('selectedStorbins').setData(selectedStorbins);
		},
		storBinTokenUpdate: function(oEvent) {
			var removedTokens = oEvent.getParameter('removedTokens').map(function(token) {
				return token.getKey();
			});
			var selectedKeys = oEvent.getSource().getTokens().filter(function(item) {
				return removedTokens.indexOf(item.getKey()) === -1;
			}).map(function(item) {
				return item.getKey();
			});
			var selectedStorbins = this.getAppModel('storbins').getProperty('/').filter(function(item) {
				return selectedKeys.indexOf(item.StorBin) > -1;
			});
			this.getAppModel('selectedStorbins').setData(selectedStorbins);
		},
		showStorLocDialog: function() {
			var selectDlg = this.storbinSelectDialog;
			this.getAppModel('storbins').refresh(true);
			selectDlg.open();
			if (selectDlg.getBinding("items"))
				selectDlg.getBinding("items").filter([]);
		},
		storBinSelect: function(oEvent) {
			var selectedStorbins = oEvent.getParameter('selectedItems').map(function(item) {
				return item.getBindingContext("storbins").getObject();
			});
			this.getAppModel('selectedStorbins').setData(selectedStorbins);
			var selectedStorbinTokens = oEvent.getParameter('selectedItems').map(function(item) {
				return new sap.m.Token({
					text: item.getBindingContext("storbins").getProperty('StorBin'),
					key: item.getBindingContext("storbins").getProperty('StorBin')
				});
			});
			this.byId('storbinInput').setTokens(selectedStorbinTokens);
		},
		storBinSearch: function(oEvent) {
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("StorBin", "StartsWith", query)
					],
					false)
			]);
		},
		//if selected material item is counted/confirmed, here we open it again so we can edit
		enableRowEdit: function(oEvent) {
			var self = this;
			var view = self.getView();
			var table = view.byId("oTbl");
			var paths = table.getSelectedContextPaths();
			var model = App.getModel("materials");
			var items = model.getProperty("/");
			if (paths.length > 0) {
				var rowsToEdit = [];
				for (var i in paths) {
					rowsToEdit.push(paths[i].split("/")[1]);
				}
				for (var ii = 0; ii < rowsToEdit.length; ii++) {
					var index = rowsToEdit[ii];
					items[index].confirm = false;
					items[index].zeroStock = false;
				}
				model.refresh(true);
				table.removeSelections();
				self.refreshModels();
			}
		},
		//delete selected material rows if they can be deleted
		deleteRow: function(oEvent) {
			var self = this;
			var view = self.getView();
			var table = view.byId("oTbl");
			var paths = table.getSelectedContextPaths();
			var model = App.getModel("materials");
			var items = model.getProperty("/");
			var deleted = false;
			if (paths.length > 0) {
				var rowsToRemove = [];
				for (var i in paths) {
					rowsToRemove.push(paths[i].split("/")[1]);
				}
				for (var ii = rowsToRemove.length - 1; ii >= 0; ii--) {
					var index = rowsToRemove[ii];
					if (items[index].deletable) {
						items.splice(index, 1);
						deleted = true;
					}
				}
				table.removeSelections();
				if (deleted) {
					model.refresh(true);
					self.refreshModels();	
				}
			}
		},
		//mark all uncounted materials as zero and confirm them
		markZero: function(oEvent) {
			var self = this;
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			self.showPromptDialog(
				App.getTran("markUncountedZero"),
				"Warning",
				App.getTran("markUncountedPrompt"),
				App.getTran("yes"),
				function(dialog) {
					for (var i in materials) {
						var mat = materials[i];
						if (!mat.Quantity && !mat.confirm) {
							mat.Quantity = 0;
							mat.zeroStock = true;
							mat.confirm = true;
							self.updateElemByMat(mat);
						}
					}
					//materialModel.refresh(true);
			        dialog.close();
				},
				App.getTran("cancel"),
				function(dialog) {
					dialog.close();
				}
			);
		},
		updateQuantity: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext("materials").getObject();
			obj.Quantity = parseInt(oEvent.getParameter("value"));
			oEvent.getSource().setValue(obj.Quantity);
			this.updateRowElems(obj, oEvent.getSource().getParent().getParent());
			//App.getModel("materials").refresh(true);
		},
		//increase quantity on item level
		increase: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue();
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			item.Quantity = parseInt(value) || 0;
			item.Quantity++;
			input.setValue(item.Quantity);
			this.updateRowElems(item, oEvent.getSource().getParent().getParent());
			//model.refresh(true);
		},
		//decrease quantity on item level
		decrease: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue();
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			item.Quantity = parseInt(value) || 0;
			if (item.Quantity > 0) {
				item.Quantity--;
				input.setValue(item.Quantity);
				this.updateRowElems(item, oEvent.getSource().getParent().getParent());
				//model.refresh(true);
			}
		},
		updateRowElems: function(itemData, rowElem) {
			var self = this;
			var cells = rowElem.getCells();
			cells[3].getContent()[0].setVisible((itemData.zeroStock || itemData.confirm) ? false : true);
			cells[3].getContent()[1].setEditable((itemData.zeroStock || itemData.confirm) ? false : true);
			cells[3].getContent()[1].setValue(itemData.Quantity);
			cells[3].getContent()[2].setVisible((itemData.zeroStock || itemData.confirm) ? false : true);
		
			
			cells[6].setEnabled(itemData.confirm ? false : true);
			function getStatusVisible(item) {
	        	if (item.confirm)
					return true;
				if (item.zeroStock || item.Quantity > 0)
					return false;
				return true;
	        }
			function getConfirmVisible(item) {
				if (item.confirm)
					return false;
				if (item.zeroStock || item.Quantity > 0) 
					return true;
				return false;
			}
			cells[7].getContent()[0].setVisible(getStatusVisible(itemData));
			cells[7].getContent()[0].setText(self.getText(itemData.confirm ? 'counted': 'open'));
			cells[7].getContent()[0].setState(itemData.confirm ? 'Success' : 'Warning');
			cells[7].getContent()[1].setVisible(getConfirmVisible(itemData));
			
		},
		updateElemByMat: function(itemData, valtype, scroll) {
			var table = this.byId('oTbl');
			var rowElem;
			if (valtype) {
				rowElem = table.getItems().find(function(elem) {
					return elem.getBindingContext("materials").getProperty('Material') == itemData.Material && elem.getBindingContext("materials").getProperty('ValType') == valtype;
				});
			} else {
				rowElem = table.getItems().find(function(elem) {
					return elem.getBindingContext("materials").getProperty('Material') == itemData.Material;
				});
			}
			if (rowElem) {
				this.updateRowElems(itemData, rowElem);
				if (scroll) {
					rowElem.getDomRef().scrollIntoView();
				}
			}
			
		},
		//confirm button in item level
		handleConfirm: function(oEvent) {
			var model = App.getModel("materials");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			item.confirm = true;
			this.updateRowElems(item, oEvent.getSource().getParent().getParent());
			//model.refresh(true);
		},
		//zero stock checkbox
		handleZeroStock: function(oEvent) {
			var model = App.getModel("materials");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			var selected = oEvent.getParameter("selected");
			item.zeroStock = selected;
			item.Quantity = 0;
			this.updateRowElems(item, oEvent.getSource().getParent());
			//model.refresh(true);
		},
		// validation before posting to SAP
		valid: function(callback) {
			var self = this;
			var view = this.getView();
			var settings = App.getModel("settings");
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			var countDt = view.byId("countDate");
			//count date
			if (!countDt.getDateValue()) {
				countDt.setValueState("Error");
				countDt.setValueStateText(App.getTran("dateMissing"));
				countDt.focus();
				return false;
			}

			//all materials should be confirm=true before we can post
			self.validationErrors = [];
			if (materials.length > 0) {
				for (var i in materials) {
					var mat = materials[i];
					if (parseFloat(mat.Quantity) > 0 && !mat.confirm) {
						self.validationErrors.push(self.getText('unconfirmedMaterials'));
						break;
					}
				}
			} else {
				self.validationErrors.push(self.getText('materialsMissing'));
			}
			if (self.validationErrors.length > 0) {
				self.showValidateErrors();
				return false;
			} else {
				countDt.setValueState("None");
				self.showPromptDialog(
					App.getTran("warning"),
					"Warning",
					App.getTran("postPrompt"),
					App.getTran("yes"),
					function(dialog) {
						dialog.close();
						callback();
					},
					App.getTran("no"),
					function(dialog) {
						dialog.close();
						return false;
					}
				);
			}
			
		},
		cancel: function() {
			this.resetData(true);
		},
		//complete/save happens from here
		complete: function(oEvent) {
			var self = this;
			var settings = App.getModel("settings");
			var materialModel = App.getModel("materials");
			var piModel = App.getModel("pi");
			if ($.isEmptyObject(piModel.getData()))
				return false;
			
			var saveOrNew = oEvent.getParameter("id").indexOf("saveBtn") > -1;
			self.valid(function() {
				App.showLoader();
				var materials = materialModel.getProperty("/");
				//header data
				var dataToSend = {
					CountDate: settings.getProperty("/countDate"),
					CountStatus: saveOrNew ? "" : "P",
					PiDoc: piModel.getProperty("/PiDoc") || '',
					PiYear: piModel.getProperty("/PiYear") || '',
					Plant: settings.getProperty("/plant"),
					StorageBin: settings.getProperty("/stgbin"),
					Storloc: settings.getProperty("/stgloc"),
					NavPiHeaderToItem: []
				};
				//item data
				for (var i in materials) {
					var item = materials[i];
					//post only rows which are confirmed
					if (!item.confirm) continue;
					dataToSend.NavPiHeaderToItem.push({
						Material: item.Material,
						Maktx: item.MatlDesc,
						Quantity: item.Quantity.toString(),
						ItemNo: (item.Itemno ? item.Itemno : item.line),
						Unit: item.Uom,
						ValType: (item.ValType || '')
					});
				}
				if (!dataToSend.NavPiHeaderToItem.length) {
					MessageBox.error(self.getText('unconfirmedMaterials'));
					App.hideLoader();
					return;
				}
				//post to SAP
				App.sync.postPI(dataToSend).done(function(response) {
					App.hideLoader();
					self.showMessageDialog("Success", App.getTran("success"), "", App.getTran("piCreated", response.PiDoc), function() {
						self.resetData(false);
					});
				}).fail(function(e) {
					App.hideLoader();
					self.showMessageDialog('Error', e.title, "", e.message, function() {
					});
				});
			});
		},
		/*
		* This is done when creating new inventory document
		*/
		startCounting: function(oEvent) {
			var self = this;
			var settings = App.getModel("settings"),
				plant = settings.getProperty("/plant"), 
				storloc = settings.getProperty("/stgloc"),
				plantInput = self.view.byId("plantSelect"),
				stgInput = self.view.byId("stgInput"),
				storbinInput = self.view.byId('storbinInput');
			if (!plant || !storloc) {
				self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("missingPlantOrStg"), function() {
					jQuery.sap.delayedCall(500, self, function() {
						if (!plant) {
							plantInput.focus();
						} else if (!storloc) {
							stgInput.focus();
						}
					});
				});
				return false;
			}
			if (settings.getProperty('/storageBinVisible') && !storbinInput.getTokens().length) {
				self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("storageBinMissing"), function() {
					jQuery.sap.delayedCall(500, self, function() {
						storbinInput.focus();
					});
				});
				return false;
			}
			function callback() {
				settings.setProperty("/countingStarted", true);
				settings.setProperty("/createMode", true);
				settings.setProperty("/editEnabled", false);
				App.getModel("pi").setData({createNew: true});
				App.getModel("pi").refresh(true);
				settings.refresh(true);
				self.scanningNewAllowed = true;
				if (settings.getProperty('/storageBinVisible')) {
					self.byId('oSearchField').fireSearch({query: ''});
				}
				
			}
			self.showPromptDialog(
				App.getTran("warning"),
				"Warning",
				App.getTran("startCountingPrompt"),
				App.getTran("yes"),
				function(dialog) {
					callback();
			        dialog.close();
				},
				App.getTran("cancel"),
				function(dialog) {
					dialog.close();
				}
			);
		},
		/*
		* Reset view when clicking cancel button
		* Reset view when PI has been posted successfully
		* {showPrompt} determines if prompt before resetting is shown
		*/
		resetData: function(showPrompt) {
			var self = this;
			var settings = App.getModel("settings");
			var piModel = App.getModel("pi");
			var materialModel = App.getModel("materials");
			var storbinModel = App.getModel("storbins");
			//get current values and store them so we use it after resetting
			var plant = settings.getProperty("/plant");
			var stgloc = settings.getProperty("/stgloc");
			var stglocText = settings.getProperty("/stglocText");
			var barcodeScanEnabled = settings.getProperty("/barcodeScanEnabled");
			function reset() {
				settings.setData({
					"countDate": new Date(),
		        	"piBin": "",
		        	"plant": plant,
		        	"stglocText": "",
		        	"stgloc": "",
		        	"createMode": false,
		        	"editEnabled": true,
		        	"barcodeScanEnabled": barcodeScanEnabled,
		        	"countingStarted": false,
	        		"storageBinVisible": false
				});
				self.byId('storbinInput').removeAllTokens();
				self.getAppModel('selectedStorbins').setData([]);
		        piModel.setData({});
		        materialModel.setData([]);
		        storbinModel.setData([]);
		        self.refreshModels();
		        self.scanningNewAllowed = false;
			}
			//show prompt or just reset
			if (showPrompt) {
				self.showPromptDialog(
					App.getTran("resetData"),
					"Warning",
					App.getTran("resetPrompt"),
					App.getTran("yes"),
					function(dialog) {
						reset();
				        dialog.close();
					},
					App.getTran("no"),
					function(dialog) {
						dialog.close();
					}
				);
			} else {
				reset();
			}
		},
		tableSelect: function() {
			this.refreshItemsCount();	
		},
		// scan barcode with camera in create purchase order mode, opens dialog where you can scan barcodes
		// using QuaggaJS libarary
		// https://serratus.github.io/quaggaJS/
		scanBarcode: function(oEvent) {
			var self = this;
			if (!this._oScanDialog) {
				this._oScanDialog = new sap.m.Dialog({
					title: "{i18n>scanBarcode}",
					contentWidth: "640px",
					contentHeight: "480px",
					horizontalScrolling: false,
					verticalScrolling: false,
					stretchOnPhone: true,
					content	: [new sap.ui.core.HTML({
						id: this.createId("scanContainer"),
						content: "<div />"
					}).addStyleClass("scanContainer")],
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function(oEvent) {
							this._oScanDialog.close();
						}.bind(this)
					}),
					afterOpen: function() {
						this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function() {
							// Initialisation done, start Quagga
							Quagga.start();
						}).fail(function(oError) {
							MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name),{
								onClose: function() {
									this._oScanDialog.close();
								}.bind(this)
							});
						}.bind(this));
					}.bind(this),
					afterClose: function() {
						// Dialog closed, stop Quagga
						Quagga.stop();
					}
				}).addStyleClass("cameraDialog");
				
				this.getView().addDependent(this._oScanDialog);
			}
			this._oScanDialog.open();
		},
		//this initializes quaggaJS and when it detects barcode it runs Quagga.onDetected function
		//and searches that material ID from SAP
		_initQuagga: function(oTarget) {
			var self = this;
			var oDeferred = jQuery.Deferred();
			
			Quagga.init({
				inputStream: {
					type: "LiveStream",
					target: oTarget,
					constraints: {
						width: {min: 640},
	            		height: {min: 480},
						facingMode: "environment"
					}
				},
				locator: {
					patchSize: "medium",
					halfSample: true
				},
				numOfWorkers: 4,
				frequency: 10,
				//currectly we look only for CODE128 and EAN bar codes
				decoder	: {
					readers : [{
						format: "code_128_reader",
						config: {}
					}, {
						format: "ean_reader",
						config: {}
					}]
				},
				locate: true
			}, function(error) {
				if (error) {
					oDeferred.reject(error);
				} else {
					oDeferred.resolve();
				}
			});
			
			if(!this._oQuaggaEventHandlersAttached) {
				// Attach event handlers...
	
				Quagga.onProcessed(function(result) {
					var drawingCtx = Quagga.canvas.ctx.overlay,
						drawingCanvas = Quagga.canvas.dom.overlay;
					
					if (result) {
						// The following will attempt to draw boxes around detected barcodes
						if (result.boxes) {
							drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
							result.boxes.filter(function (box) {
								return box !== result.box;
							}).forEach(function (box) {
								Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
							});
						}
						
						if (result.box) {
							Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "#00F", lineWidth: 2});
						}
						
						if (result.codeResult && result.codeResult.code) {
							Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
						}
					}
				}.bind(this));
				// barcode detected
				Quagga.onDetected(function(result) {
					App.view.byId("matSearch").setValue(result.codeResult.code);
					this._oScanDialog.close();
					App.view.byId("matSearch").fireSearch({query: result.codeResult.code});
					Quagga.stop();
				}.bind(this));
				// Set flag so that event handlers are only attached once...
				this._oQuaggaEventHandlersAttached = true;
			}
			
			return oDeferred.promise();
		}
		
	});
});