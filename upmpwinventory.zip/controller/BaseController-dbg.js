/* global App:true 
   global Quagga:true */
sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'com/upm/pw/z_wh_postpi/include/formatter',
    'sap/ui/core/BusyIndicator',
    'sap/ui/model/json/JSONModel',
    'sap/m/Dialog',
    'sap/m/MessageBox'
], function(Controller, Formatter, BusyIndicator, JSONModel, Dialog, MessageBox) {
    return Controller.extend("com.upm.pw.z_wh_postpi.controller.BaseController", {
        formatter: Formatter,
        getApp: function() {
			return this.getOwnerComponent();	
		},
		getText: function(text, args) {
			return this.getApp().getModel('i18n').getResourceBundle().getText(text, args);	
		},
        getAppModel: function(model) {
        	return this.getOwnerComponent().getModel(model);
        },
        showValidateErrors: function() {
			var message = ""
			for (let error of this.validationErrors) {
				message += error + "\n";
			}
			MessageBox.error(message);
		},
        showMessageDialog: function(state, title, icon, message, callback) {
        		var dialog = new Dialog({
        			state: state,
        			title: title,
        			icon: icon,
        			content: new sap.m.Text({text: message}),
        			beginButton: new sap.m.Button({
        				text: App.getTran("close"),
        				press: function() {
        					dialog.close();
        					if (callback)
        						callback();
        					
        				}
        			})
        		}).addStyleClass("oMsgDialog");
        		dialog.open();
        },
    	showPromptDialog: function(title, state, text, btn1Text, btn1Callback, btn2Text, btn2Callback) {
    		var oDialog = new sap.m.Dialog({
    			title: title,
    			state: state,
    			content: [new sap.m.Text({
    				text: text
    			})],
    			buttons: [new sap.m.Button({
    				text: btn1Text,
    				press: function() {
    					if (btn1Callback)
    						btn1Callback(oDialog);
    				}
    			}), new sap.m.Button({
    				text: btn2Text,
    				press: function() {
    					oDialog.close();
    					if (btn2Callback)
    						btn2Callback(oDialog);
    				}
    			})]
    		}).addStyleClass("oDialogContent");
    		
    		oDialog.open();	
    	},
    	showDeleteDialog: function(state, title, text, handleRemove, cancel) {
    		var oDialog = new sap.m.Dialog({
    			state: state,
    			title: title,
    			content: [new sap.m.Text({
    				text: text
    			})],
    			buttons: [new sap.m.Button({
    				text: App.getTran("yes"),
    				press: function() {
    					if (handleRemove)
    						handleRemove(oDialog);
    				}
    			}), new sap.m.Button({
    				text: App.getTran("cancel"),
    				press: function() {
    					oDialog.close();
    					if (cancel)
    						cancel(oDialog);
    				}
    			})]
    		}).addStyleClass("oDialogContent");
    		
    		oDialog.open();	
    	},
    	calculateLineNumbers: function() {
     		var model = App.getModel("materials");
 			var items = model.getProperty("/");
 			
 			if (!items.length)
 				return;
 			
 			for (var i = 0; i < items.length; i++) {
 				var item = items[i];
 				item.line = (parseInt(i) === 0 ? "1" : parseInt(i) === 1 ? "2" : parseInt(i) + 1 + "");
 			}
 			model.refresh(true);
     	},
     	initBarcodeScanning: function(callback) {
			if(navigator && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
				navigator.mediaDevices.getUserMedia({video:true}).then(function(stream) {
					App.getModel("settings").setProperty("/barcodeScanEnabled", true);
					if (callback) callback();
				}).catch(function(err) {
					console.log("error getting mediadevice", err);
				});
			}
    	},
    	getStoragebins: function(plant, stgloc, callback) {
    		var self = this;
    		App.showLoader();
    		App.sync.getStorageBins(plant, stgloc).done(function(response){
    			App.hideLoader();
    			callback(response.results);
    		}).fail(function(e) {
				App.hideLoader();
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
    	}

    });
});