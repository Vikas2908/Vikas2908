/* global App:true 
   global Quagga:true */
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"com/upm/pw/z_wh_postpi/include/formatter",
	"com/upm/pw/z_wh_postpi/include/sync",
	"sap/m/Dialog"
], function(UIComponent, Device, JSONModel, Formatter, Sync, Dialog) {
	"use strict";

	return UIComponent.extend("com.upm.pw.z_wh_postpi.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			window.App = this;
			UIComponent.prototype.init.apply(this, arguments);
			this.predefineFunction();
		},
		predefineFunction: function() {
			var self = this;
			App.sync = Sync;
			App.formatter = Formatter;
			
			App.loader =  new sap.m.BusyDialog({
				text: "",
				title: "",
				showCancelButton: false
			});
			
			App.showLoader = function() {
				App.loader.open();
			}
			App.hideLoader = function() {
				App.loader.close();
			};
			App.setLanguage = function(lang) {
				
				var i18nModel = new sap.ui.model.resource.ResourceModel({
					bundleName : "com.upm.pw.z_wh_postpi.i18n.i18n",
					bundleLocale: lang
				});
				
				App.setModel(i18nModel, "i18n");
				App.getModel("i18n").refresh(true);
			};
			
			var lang = sap.ui.getCore().getConfiguration().getLanguage() ? sap.ui.getCore().getConfiguration().getLanguage() : 'en';
			
			App.setLanguage(lang);
			App.getTran = function(tran, args) {
	         	return App.getModel('i18n').getResourceBundle().getText(tran, (args ? args : ''));
	        };
	        function createJSONModel(data) {
	        	var model = new JSONModel(data);
	        	model.setSizeLimit(999999);
	        	return model;
	        }
	        App.setModel(new JSONModel({}), "pi");
	        App.setModel(createJSONModel([]), "materials");
	        App.setModel(new JSONModel([]), "plants");
	        App.setModel(new JSONModel([]), "stglocs");
	        App.setModel(new JSONModel([]), "storbins");
	        App.setModel(new JSONModel([]), "selectedStorbins");
	        App.setModel(new JSONModel({
	        	"countDate": new Date(),
	        	"piBin": "",
	        	"plant": "",
	        	"stglocText": "",
	        	"stgloc": "",
	        	"stgbin": "",
	        	"createMode": false,
	        	"editEnabled": true,
	        	"barcodeScanEnabled": false,
	        	"countingStarted": false,
	        	"storageBinVisible": false
	        }), "settings");
	        this.prepareData();
		},
		prepareData: function() {
			var self = this;
			App.showLoader();
			App.sync.getUserPlant().done(function(response) {
				App.getModel("settings").setProperty("/plant", response.results[0] ? response.results[0].Plant : "");
				App.setModel(new JSONModel(response.results), "plants");
				App.sync.getPlantStorLocs().done(function(resp) {
					App.setModel(new JSONModel(resp.results), "stglocs");
					App.hideLoader();
					if (App.view)
						App.view.prepareFunc();
				}).fail(function(e) {
					App.hideLoader();
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						
					});
				});
			}).fail(function(e) {
				App.hideLoader();
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
		
		},
		showMessageDialog: function(state, title, icon, message, callback) {
			var dialog = new Dialog({
				state: state,
				title: title,
				icon: icon,
				content: new sap.m.Text({text: message}),
				beginButton: new sap.m.Button({
					text: App.getTran("close"),
					press: function() {
						dialog.close();
						if (callback)
							callback();
						
					}
				})
			}).addStyleClass("oMsgDialog");
			dialog.open();
        }
	});
});