sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/export/Spreadsheet",
	"sap/m/MessageToast",
	"sap/ui/core/format/NumberFormat",
	"sap/ui/core/format/DateFormat"
], function (Controller, ODataModel, JSONModel, Token, Filter, MessageBox, Spreadsheet, MessageToast, NumberFormat, DateFormat) {
	"use strict";

	var oTableData = {
		Count: 0,
		PurOrder: [],
		DownloadPurOrder: []
	};
	var oLocale = new sap.ui.core.Locale("en-US");
	var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oLocale);

	return Controller.extend("supplieronlineportal.controller.Worklist", {

		onInit: function () {
			this.getView().byId("workflowPage").setBusy(true);
			var oMultiInputMatDesp = this.getView().byId("idmultiInput");
			var oDateRange = this.getView().byId("idDateRange");
			this.userInfo = {
				LoggedInUserName: "",
				LoggedInUserCode: ""
			};
			var oMdlUser = new JSONModel(this.userInfo);
			oMdlUser.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oMdlUser, "oMdlUserInfo");
			//	this.getView().getModel("oMdlUserInfo").setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			var date = new Date();
			var monthFirstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			var monthLastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
			oDateRange.setFrom(monthFirstDay);
			oDateRange.setTo(monthLastDay);

			oMultiInputMatDesp.addValidator(function (args) {
				var oToken = new Token({
					key: args.text,
					text: args.text
				});
				args.asyncCallback(oToken);

				return sap.m.MultiInput.WaitForAsyncValidation;
			});
			var oTable = this.getView().byId("idTreeTable");
			oTable.setModel(new JSONModel(oTableData));
			oTable.setBusyIndicatorDelay(0);
			oTable.setBusy(true);
			this.oMatDescSelectDialog = sap.ui.xmlfragment("supplieronlineportal.view.MaterialDespDialo", this);
			this.getView().addDependent(this.oMatDescSelectDialog);
			this.oMdlMain = new ODataModel("/GWaaS/sap/opu/odata/sap/ZRCP_SOP_NEW_SRV", true);
			this.oMdlMain.read("/ZrcpSopPoInfoSet?$expand=NavPoToDel/POItemToDel", null, null, true, this.onGetTableDataSucc.bind(this), this.onGetTableDataErr
				.bind(this));
			this.oMdlMain.read("/ZRcpSopSuppListSet", null, null, true, this.getSupplierSucc.bind(this), this.getSupplierErr.bind(this));
			this.oMdlMain.read("/ZrcpMatSearchSet", null, null, true, this.getMaterialDespSucc.bind(this), this.getMaterialDespErr.bind(this));

			// /sap/opu/odata/sap/SUPPLIERONLINEPORTAL/ZrcpSopSuppNameSet('V774117’)
			this.oMdlMain.read("/ZrcpSopSuppNameSet('')", null, null, true, this.getUserInfoSucc.bind(this), this.getgetUserInfoErr.bind(this));
			this.getView().byId("workflowPage").setBusyIndicatorDelay(1);
			this.getView().byId("workflowPage").setBusy(false);

		},
		getSupplierSucc: function (data, response) {
			var oComboSupplier = this.getView().byId("idMCBSuppl");
			var oSupplData = {
				Supplier: []
			};
			for (var i = 0; i < data.results.length; i++) {
				oSupplData.Supplier.push({
					SupplierCode: data.results[i].SupplierCode,
					SupplierName: data.results[i].SupplierName,
					SupplierType: data.results[i].SupplierType
				});
			}
			this.getView().getModel("oMdlUserInfo").setData(this.userInfo);
			oComboSupplier.setModel(new JSONModel(oSupplData));
		},
		getSupplierErr: function (data, response) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				"Error while fetching supplier", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		getUserInfoSucc: function (data, response) {

			if (data.SupplierName !== "") {
				this.userInfo.LoggedInUserName = data.SupplierName;
				this.userInfo.LoggedInUserCode = data.SupplierCode;
				this.userInfo.SupplierType = data.SupplierType;
				this.userInfo.ShowPrice = true;

				if (this.userInfo.SupplierType === "G") {
					this.userInfo.ShowPrice = false;
				}
			}
			this.getView().getModel("oMdlUserInfo").setData(this.userInfo);

		},
		getgetUserInfoErr: function (data, response) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				"Error while fetching user info", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		onGetTableDataSucc: function (data, response) {
			var oTable = this.getView().byId("idTreeTable");
			var oModelTreeTable = oTable.getModel();

			var oModelTreeTableData = oModelTreeTable.getData();
			var poCount = this.getPOCount(data.results);
			oModelTreeTableData.Count = poCount;
			oModelTreeTableData.PurOrder = [];
			oModelTreeTableData.DownloadPurOrder = [];

			if (typeof response.headers["sap-message"] !== "undefined" && response.headers["sap-message"] !== "") {
				var errorMessage = JSON.parse(response.headers["sap-message"]);
				oTable.setNoData(errorMessage.message);
				oTable.setShowNoData(true);
			} else {

				for (var i = 0; i < data.results.length; i++) {
					//altering the tree json format to 2-level expansion
					if (data.results[i].NavPoToDel.results.length > 0) {
						for (var j = 0; j < data.results[i].NavPoToDel.results.length; j++) {
							data.results[i].NavPoToDel.results[j].POItemToDel = data.results[i].NavPoToDel.results[j].POItemToDel.results;
						}
					}
					//altering the tree json format to 2-level expansion
					oModelTreeTableData.PurOrder.push({
						PurchOrder: data.results[i].PurchOrder,
						PoItem: data.results[i].PoItem,
						MatDescp: data.results[i].MatDescp,
						OrdQuantity: data.results[i].OrdQuantity,
						eOrdQuantity: oFloatFormat.parse(data.results[i].OrdQuantity), // For shorting in the case of comma delimeter
						Price: data.results[i].Price,
						ePrice: oFloatFormat.parse(data.results[i].Price), // For shorting in the case of comma delimeter
						Currency: data.results[i].Currency,
						DelQuantity: data.results[i].DelQuantity,
						eDelQuantity: oFloatFormat.parse(data.results[i].DelQuantity), // For shorting in the case of comma delimeter
						OpenQuantity: data.results[i].OpenQuantity,
						eOpenQuantity: oFloatFormat.parse(data.results[i].OpenQuantity), // For shorting in the case of comma delimeter
						PlanDelCount: data.results[i].PlanDelCount,
						ePlanDelCount: oFloatFormat.parse(data.results[i].OpenQuantity), // For shorting in the case of comma delimeter
						PlannedQuantity: data.results[i].PlanQuantity,
						Material: data.results[i].Material,
						SupplierCode: data.results[i].SupplierCode,
						DeliveryNo: data.results[i].DeliveryNo,
						//PlannedDeliveryDate: data.results[i].PlanDelDate,
						GoodsSuppliers: data.results[i].GoodsSupplier,
						Mill: data.results[i].Mill,
						YourReference: data.results[i].YourReference,
						Incoterm: data.results[i].Incoterm,
						POValidityMonth: data.results[i].ValidityMonth,
						SumOrdered: data.results[0].SumOrdered,
						SumPlanned: data.results[0].SumPlanned,
						SumDelivered: data.results[0].SumDelivered,
						SumOpen: data.results[0].SumOpen,
						PlanDelData: (data.results[i].NavPoToDel.results.length > 0) ? data.results[i].NavPoToDel.results : []
					});

					oModelTreeTableData.DownloadPurOrder.push({
						PurchOrder: data.results[i].PurchOrder,
						PoItem: data.results[i].PoItem,
						MatDescp: data.results[i].MatDescp,
						OrdQuantity: data.results[i].OrdQuantity,
						Price: data.results[i].Price,
						Currency: data.results[i].Currency,
						DelQuantity: data.results[i].DelQuantity,
						OpenQuantity: data.results[i].OpenQuantity,
						PlanDelCount: data.results[i].PlanDelCount,
						Material: data.results[i].Material,
						SupplierCode: data.results[i].SupplierCode,
						PlannedQuantity: data.results[i].PlanQuantity,
						DeliveryNo: data.results[i].DeliveryNo,
						PlanDelDate: data.results[i].PlanDelDate,
						GoodsSuppliers: data.results[i].GoodsSupplier,
						Mill: data.results[i].Mill,
						YourReference: data.results[i].YourReference,
						Incoterm: data.results[i].Incoterm,
						POValidityMonth: data.results[i].ValidityMonth,
						PlanDelData: (data.results[i].NavPoToDel.results.length > 0) ? data.results[i].NavPoToDel.results : []
					});

					if (data.results[i].NavPoToDel.results.length > 0) {
						for (var childEntity = 0; childEntity < data.results[i].NavPoToDel.results.length; childEntity++) {
							oModelTreeTableData.DownloadPurOrder.push(data.results[i].NavPoToDel.results[childEntity]);
							if (data.results[i].NavPoToDel.results[childEntity].POItemToDel.length > 0) {
								for (var j = 0; j < data.results[i].NavPoToDel.results[childEntity].POItemToDel.length; j++) {
									oModelTreeTableData.DownloadPurOrder.push(data.results[i].NavPoToDel.results[childEntity].POItemToDel[j]);
								}
							}
						}
					}

				}
			}

			oModelTreeTable.refresh();
			oTable.setBusy(false);
		},
		onGetTableDataErr: function (data, response) {
			this.getView().byId("idTreeTable").setBusy(false);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				"Error while fetching Data.", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		getPOCount: function (polist) {
			var tempArray = [];
			for (var i = 0; i < polist.length; i++) {
				tempArray.push(polist[i].PurchOrder);
			}
			var myNewArray = tempArray.filter(function (elem, index, self) {
				return index === self.indexOf(elem);
			});
			return myNewArray.length;
		},
		openMaterialHelp: function (oEvent) {
			// this.oMatDescSelectDialog.setBusyIndicatorDelay(0);
			// this.oMatDescSelectDialog.setBusy(true);
			//	this.oMatDescSelectDialog.getModel("oMdlMatDesp").setData({});
			this.oMatDescSelectDialog.open();
		},
		handleSearch: function (oEvent) {
			//	var oMdlMatDes = new ODataModel("/GWaaS/sap/opu/odata/sap/SUPPLIERONLINEPORTAL", true);
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Maktx", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleClose: function (oEvent) {
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},
		getMaterialDespSucc: function (data, response) {
			this.oMatDescSelectDialog.setModel(new JSONModel(data.results), "oMdlMatDesp");
			this.oMatDescSelectDialog.setBusy(false);
		},
		getMaterialDespErr: function (data, response) {
			this.oMatDescSelectDialog.setBusy(false);

			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				"Error while fetching Material data", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		handleMatSelect: function (oEvent) {
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
			var oSelMatData = oEvent.getParameter("selectedContexts");
			var oMultiInputMatDesp = this.getView().byId("idmultiInput");
			oMultiInputMatDesp.destroyTokens();
			if (oSelMatData && oSelMatData.length) {
				for (var i = 0; i < oSelMatData.length; i++) {
					var oToken = new Token();
					oToken.setKey(oSelMatData[i].getObject().Matnr);
					oToken.setText(oSelMatData[i].getObject().Maktx);
					oMultiInputMatDesp.addToken(oToken);
				}
			}
			this.oMatDescSelectDialog.close();
		},
		onSearch: function (oEvent) {
			var oTable = this.getView().byId("idTreeTable");
			oTable.setBusyIndicatorDelay(0);
			oTable.setBusy(true);
			var bDateRange = this.validateDateField(oEvent.getParameter("selectionSet")[0].getFrom(), oEvent.getParameter("selectionSet")[0].getTo());
			if (!bDateRange) {
				oEvent.getParameter("selectionSet")[0].setValueState(sap.ui.core.ValueState.Error);

				oTable.setBusy(false);
				return;
			} else {
				oEvent.getParameter("selectionSet")[0].setValueState(sap.ui.core.ValueState.None);
			}
			var oMatDescKey = [],
				startDate = "",
				endDate = "",
				oSuppl = [];
			var tokens = oEvent.getParameter("selectionSet")[2].getTokens();
			for (var i = 0; i < tokens.length; i++) {
				oMatDescKey.push(tokens[i].getKey());
			}
			startDate = this.getDateInFormat(oEvent.getParameter("selectionSet")[0].getFrom());
			endDate = this.getDateInFormat(oEvent.getParameter("selectionSet")[0].getTo());
			oSuppl = oEvent.getParameter("selectionSet")[1].getSelectedKeys();

			var query = "/ZrcpSopPoInfoSet?$expand=NavPoToDel/POItemToDel";
			if (!oMatDescKey.length || !oSuppl.length || startDate !== "" || endDate !== "") {
				query = query + "&$filter=";

				if (startDate !== "" && endDate !== "") {
					query = query + "(DelDate ge '" + startDate + "' and DelDate le '" + endDate + "')";
				}
				if (oSuppl.length) {
					var supplierQuery = [];
					var squery = "";
					for (var iScode = 0; iScode < oSuppl.length; iScode++) {
						supplierQuery.push("SupplierCode eq '" + oSuppl[iScode] + "'");
					}
					if (supplierQuery.length) {
						squery = supplierQuery.join(" or ");
						squery = "(" + squery + ")";
					}
					query = query + " and " + squery;
				}
				if (oMatDescKey.length) {
					var materialQuery = [];
					var mquery = "";
					for (var iMdesc = 0; iMdesc < oMatDescKey.length; iMdesc++) {
						materialQuery.push("MatDescp eq '" + oMatDescKey[iMdesc] + "'");
					}
					if (materialQuery.length) {
						mquery = materialQuery.join(" or ");
						mquery = "(" + mquery + ")";
					}
					query = query + " and " + mquery;
				}

			}
			this.oMdlMain.read(query, null, null, true, this.onGetTableDataSucc.bind(this), this.onGetTableDataErr.bind(
				this));

			// /sap/opu/odata/sap/SUPPLIERONLINEPORTAL/ZrcpSopPoInfoSet?$expand=
			// NavPoToDel&$filter=(SupplierCode eq '153203' or SupplierCode eq '141976') 
			// and (MatDescp eq '10009181') and (DelDate ge '20090101' and DelDate le '20190101') 

		},
		validateDateField: function (startDate, endDate) {
			var bValid = false;
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (startDate === null || endDate === null) {

				MessageBox.error(
					this.getView().getModel("i18n").getResourceBundle().getText("DateMandt"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return bValid;
			}
			var oneDay = 24 * 60 * 60 * 1000;
			var diffDays = Math.round(Math.abs((startDate.getTime() - endDate.getTime()) / (oneDay)));
			if ((diffDays + 1) > 92) {
				MessageBox.error(
					this.getView().getModel("i18n").getResourceBundle().getText("ValidDayRange"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				bValid = false;
			} else {
				bValid = true;
			}
			return bValid;

		},
		getDateInFormat: function (date) {
			if (date) {
				var month = date.getMonth() + 1;
				if (month < 10) {
					month = "0" + month;
				}
				var day = date.getDate();
				if (day < 10) {
					day = "0" + day;
				}

				return date.getFullYear() + "" + month + "" + day;
			} else {
				return "";
			}
		},
		onBeforeRebindTable: function (oEvent) {
			var mBindingParams = oEvent.getParameter("bindingParams");
			//	mBindingParams.parameters["expand"] = "NavPoToDel";
			mBindingParams.parameters.threshold = 50000;
			mBindingParams.parameters.countMode = "Inline";
			mBindingParams.parameters.operationMode = "Server";
			mBindingParams.parameters.numberOfExpandedLevels = 1;

		},
		createColumnConfig: function (totalColumns) {
			var userInfo = this.getView().getModel("oMdlUserInfo").getData();
			var aCols = [];
			var visibleCols = jQuery.grep(totalColumns, function (elem) {
				return (elem.visible === true);
			});
			for (var i = 0; i < visibleCols.length; i++) {
				if (visibleCols[i].columnKey === "PurOrder") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("PurchaseOrder"),
						property: "PurchOrder"
					});
				}
				if (visibleCols[i].columnKey === "POItem") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("PoItem"),
						property: "PoItem"
					});
				}
				if (visibleCols[i].columnKey === "GoodsSuppliers") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("GoodsSuppliers"),
						property: "GoodsSuppliers"
					});
				}
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				if (visibleCols[i].columnKey === "YourReference") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("YourReference"),
						property: "YourReference"
					});
				}
				if (visibleCols[i].columnKey === "Mill") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("Mill"),
						property: "Mill"
					});
				}
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				if (visibleCols[i].columnKey === "MatDesc") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("MaterialDescription"),
						property: "MatDescp",
						type: "string"
					});
				}
				if (visibleCols[i].columnKey === "Price") {
					if (userInfo.ShowPrice === true) {
						aCols.push({
							label: this.getView().getModel("i18n").getResourceBundle().getText("Price"),
							property: "Price",
							type: 'number',
							scale: 2
						});
					}
				}
				if (visibleCols[i].columnKey === "Currency") {
					if (userInfo.ShowPrice === true) {
						aCols.push({
							label: this.getView().getModel("i18n").getResourceBundle().getText("Currency"),
							property: "Currency"
						});
					}
				}

				if (visibleCols[i].columnKey === "OrdrQuant") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("OrderedQuantity"),
						property: "OrdQuantity",
						type: 'number',
						scale: 2
					});
				}
				if (visibleCols[i].columnKey === "DelQuant") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("DeliveredQuantity"),
						property: "DelQuantity",
						type: 'number',
						scale: 2
					});
				}
				if (visibleCols[i].columnKey === "OpQuant") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("OpenQuantity"),
						property: "OpenQuantity",
						type: 'number',
						scale: 2
					});
				}
				if (visibleCols[i].columnKey === "PlanDel") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("PlannedDelivery"),
						property: "PlanDelCount"
					});
				}
				if (visibleCols[i].columnKey === "PlannedQuantity") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("PlannedQuantity"),
						property: "PlannedQuantity"
					});
				}
				if (visibleCols[i].columnKey === "DeliveryNo") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("DeliveryNo"),
						property: "DeliveryNo"
					});
				}
				if (visibleCols[i].columnKey === "PlanDelDate") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("PlannedDeliveryDate"),
						property: "PlanDelDate"
					});
				}
				if (visibleCols[i].columnKey === "MaterialCode") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("MaterialCode"),
						property: "Material"
					});
				}
				if (visibleCols[i].columnKey === "SupplierCode") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("SupplierCode"),
						property: "SupplierCode"
					});
				}
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/
				if (visibleCols[i].columnKey === "Incoterm") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("Incoterm"),
						property: "Incoterm"
					});
				}
				if (visibleCols[i].columnKey === "POValidityMonth") {
					aCols.push({
						label: this.getView().getModel("i18n").getResourceBundle().getText("POValidityMonth"),
						property: "POValidityMonth"
					});
				}
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/
			}

			return aCols;
		},

		onDataExport: function (oEvent) {
			var aCols, aProducts, oSettings;
			if (!this.oPersonalizationDialog) {
				this.onChangeColumnSetting("null", true);
			}
			aCols = this.createColumnConfig(this.oPersonalizationDialog.getModel().getData().ColumnsItems);
			aProducts = this.getView().byId("idTreeTable").getModel().getProperty("/DownloadPurOrder");
			oSettings = {
				workbook: {
					columns: aCols
						/*context: {
							title: "TEST TITLE",
							sheetName: "TEST"
						}*/
				},
				dataSource: aProducts,
				fileName: "PO Report"
			};
			var that = this;
			new Spreadsheet(oSettings)
				.build()
				.then(function () {
					MessageToast.show(that.getView().getModel("i18n").getResourceBundle().getText("DownloadFin"));
				});

		},
		onChangeColumnSetting: function (oEvent, bOpen) {

			var userInfo = this.getView().getModel("oMdlUserInfo").getData();

			if (!this.oPersonalizationDialog) {
				this.oPersonalizationDialog = sap.ui.xmlfragment("supplieronlineportal.view.PersonalizationDialog", this);

				var oPerData = {
					ColumnCollection: [],
					ColumnsItems: []
				};
				oPerData.ColumnCollection.push({
					columnKey: "PurOrder",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("PurchaseOrder")
				});
				oPerData.ColumnCollection.push({
					columnKey: "POItem",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("PoItem")
				});
				oPerData.ColumnCollection.push({
					columnKey: "GoodsSuppliers",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("GoodsSuppliers")
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				oPerData.ColumnCollection.push({
					columnKey: "YourReference",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("YourReference")
				});
				oPerData.ColumnCollection.push({
					columnKey: "Mill",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("Mill")
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				oPerData.ColumnCollection.push({
					columnKey: "MatDesc",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("MaterialDescription")
				});
				if (userInfo.ShowPrice === true) {
					oPerData.ColumnCollection.push({
						columnKey: "Price",
						columnText: this.getView().getModel("i18n").getResourceBundle().getText("Price")
					});
					oPerData.ColumnCollection.push({
						columnKey: "Currency",
						columnText: this.getView().getModel("i18n").getResourceBundle().getText("Currency")
					});
				}

				oPerData.ColumnCollection.push({
					columnKey: "OrdrQuant",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("OrderedQuantity")
				});

				oPerData.ColumnCollection.push({
					columnKey: "DelQuant",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("DeliveredQuantity")
				});
				oPerData.ColumnCollection.push({
					columnKey: "OpQuant",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("OpenQuantity")
				});
				oPerData.ColumnCollection.push({
					columnKey: "PlanDel",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("PlannedDelivery")
				});
				oPerData.ColumnCollection.push({
					columnKey: "PlannedQuantity",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("PlannedQuantity")
				});
				oPerData.ColumnCollection.push({
					columnKey: "DeliveryNo",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("DeliveryNo")
				});
				oPerData.ColumnCollection.push({
					columnKey: "PlanDelDate",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("PlannedDeliveryDate")
				});
				oPerData.ColumnCollection.push({
					columnKey: "MaterialCode",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("MaterialCode")
				});
				oPerData.ColumnCollection.push({
					columnKey: "SupplierCode",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("SupplierCode")
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/
				oPerData.ColumnCollection.push({
					columnKey: "Incoterm",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("Incoterm")
				});
				oPerData.ColumnCollection.push({
					columnKey: "POValidityMonth",
					columnText: this.getView().getModel("i18n").getResourceBundle().getText("POValidityMonth")
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/

				oPerData.ColumnsItems.push({
					columnKey: "PurOrder",
					visible: true,
					index: 0
				});
				oPerData.ColumnsItems.push({
					columnKey: "POItem",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "GoodsSuppliers",
					visible: true
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				oPerData.ColumnsItems.push({
					columnKey: "YourReference",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "Mill",
					visible: true
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding default column to layout*/
				oPerData.ColumnsItems.push({
					columnKey: "MatDesc",
					visible: true
				});
				if (userInfo.ShowPrice === true) {
					oPerData.ColumnsItems.push({
						columnKey: "Price",
						visible: true
					});
					oPerData.ColumnsItems.push({
						columnKey: "Currency",
						visible: true
					});
				}

				oPerData.ColumnsItems.push({
					columnKey: "OrdrQuant",
					visible: true
				});

				oPerData.ColumnsItems.push({
					columnKey: "DelQuant",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "OpQuant",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "PlanDel",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "PlannedQuantity",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "DeliveryNo",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "PlanDelDate",
					visible: true
				});
				oPerData.ColumnsItems.push({
					columnKey: "MaterialCode",
					visible: false
				});
				oPerData.ColumnsItems.push({
					columnKey: "SupplierCode",
					visible: false
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/
				oPerData.ColumnsItems.push({
					columnKey: "Incoterm",
					visible: false
				});
				oPerData.ColumnsItems.push({
					columnKey: "POValidityMonth",
					visible: false
				});
				/*FETR0070756_ PO INFO APP - findings from pilot adding additional column to layout*/
				this.oPersonalizationDialog.setModel(new JSONModel(oPerData));
			}
			if (!bOpen) {
				this.oPersonalizationDialog.open();
			}
		},
		onCancel: function () {
			this.oPersonalizationDialog.close();
		},
		onChangeVisColumns: function (oEvent) {
			var oModelDialog = this.oPersonalizationDialog.getModel();
			var oModelDialogData = oModelDialog.getData();
			oModelDialogData.ColumnsItems = [];
			var visibleColumns = oEvent.getParameter("payload").columns.selectedItems;
			var userInfo = this.getView().getModel("oMdlUserInfo").getData();

			var columnVisiblity = {
				PurOrder: false,
				POItem: false,
				MatDesc: false,
				OrdrQuant: false,
				Price: false,
				Currency: false,
				DelQuant: false,
				OpQuant: false,
				PlanDel: false,
				SupplierCode: false,
				MaterialCode: false,
				DeliveryNo: false,
				GoodsSuppliers: false,
				YourReference: false,
				Mill: false,
				PlannedQuantity: false,
				Incoterm: false,
				POValidityMonth: false,
				PlanDelDate: false
			};
			for (var i = 0; i < visibleColumns.length; i++) {

				oModelDialogData.ColumnsItems.push({
					columnKey: visibleColumns[i].columnKey,
					visible: true
				});
				if (visibleColumns[i].columnKey === "PurOrder") {
					columnVisiblity.PurOrder = true;
				}
				if (visibleColumns[i].columnKey === "GoodsSuppliers") {
					columnVisiblity.GoodsSuppliers = true;
				}
				if (visibleColumns[i].columnKey === "POItem") {
					columnVisiblity.POItem = true;
				}
				if (visibleColumns[i].columnKey === "MatDesc") {
					columnVisiblity.MatDesc = true;
				}
				if (visibleColumns[i].columnKey === "OrdrQuant") {
					columnVisiblity.OrdrQuant = true;
				}
				if (userInfo.ShowPrice === true) {
					if (visibleColumns[i].columnKey === "Price") {
						columnVisiblity.Price = true;
					}
					if (visibleColumns[i].columnKey === "Currency") {
						columnVisiblity.Currency = true;
					}
				}

				if (visibleColumns[i].columnKey === "DelQuant") {
					columnVisiblity.DelQuant = true;
				}
				if (visibleColumns[i].columnKey === "OpQuant") {
					columnVisiblity.OpQuant = true;
				}
				if (visibleColumns[i].columnKey === "SupplierCode") {
					columnVisiblity.SupplierCode = true;
				}
				if (visibleColumns[i].columnKey === "MaterialCode") {
					columnVisiblity.MaterialCode = true;
				}
				if (visibleColumns[i].columnKey === "PlanDel") {
					columnVisiblity.PlanDel = true;
				}
				if (visibleColumns[i].columnKey === "DeliveryNo") {
					columnVisiblity.DeliveryNo = true;
				}
				if (visibleColumns[i].columnKey === "PlannedQuantity") {
					columnVisiblity.PlannedQuantity = true;
				}
				if (visibleColumns[i].columnKey === "Mill") {
					columnVisiblity.Mill = true;
				}
				if (visibleColumns[i].columnKey === "Incoterm") {
					columnVisiblity.Incoterm = true;
				}
				if (visibleColumns[i].columnKey === "POValidityMonth") {
					columnVisiblity.POValidityMonth = true;
				}
				if (visibleColumns[i].columnKey === "YourReference") {
					columnVisiblity.YourReference = true;
				}
				if (visibleColumns[i].columnKey === "PlanDelDate") {
					columnVisiblity.PlanDelDate = true;
				}
			}
			this.getView().byId("idColumnPONum").setVisible(columnVisiblity.PurOrder);
			this.getView().byId("idColumnPOItem").setVisible(columnVisiblity.POItem);
			this.getView().byId("idColumnMatDescp").setVisible(columnVisiblity.MatDesc);
			this.getView().byId("idColumnOrdQuant").setVisible(columnVisiblity.OrdrQuant);
			this.getView().byId("idColumnPrice").setVisible(columnVisiblity.Price);
			this.getView().byId("idColumnCurrency").setVisible(columnVisiblity.Currency);
			this.getView().byId("idColumnDelQuant").setVisible(columnVisiblity.DelQuant);
			this.getView().byId("idColumnOpenQuant").setVisible(columnVisiblity.OpQuant);
			this.getView().byId("idColumnPlanDelCount").setVisible(columnVisiblity.PlanDel);
			this.getView().byId("idColumnMatCode").setVisible(columnVisiblity.MaterialCode);
			this.getView().byId("idColumnSupplierCode").setVisible(columnVisiblity.SupplierCode);
			this.getView().byId("idColumnPlannedQuantity").setVisible(columnVisiblity.PlannedQuantity);
			this.getView().byId("idColumnDeliveryNo").setVisible(columnVisiblity.DeliveryNo);
			this.getView().byId("idColumnGoodsSupplier").setVisible(columnVisiblity.GoodsSuppliers);
			this.getView().byId("idColumnIncoterm").setVisible(columnVisiblity.Incoterm);
			this.getView().byId("idColumnPOValidityMonth").setVisible(columnVisiblity.POValidityMonth);
			this.getView().byId("idColumnYourReference").setVisible(columnVisiblity.YourReference);
			this.getView().byId("idColumnPlannedDeliveryDate").setVisible(columnVisiblity.PlanDelDate);

			oModelDialog.refresh();
			this.oPersonalizationDialog.close();
		},
		onUserNamePress: function (event) {
			var popover = new sap.m.Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [
					/*new sap.m.Button({
						text: 'Feedback',
						type: sap.m.ButtonType.Transparent
					}),*/
					new sap.m.Button({
						text: this.getView().getModel("i18n").getResourceBundle().getText("HelpTxt"),
						type: sap.m.ButtonType.Transparent,
						icon: "sap-icon://hint"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getResourceBundle().getText("LogoutTxt"),
						type: sap.m.ButtonType.Transparent,
						icon: "sap-icon://log",
						press: function () {

						}
					})
				]
			}).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");

			popover.openBy(event.getSource());
		},
		onPressHome: function () {
			var hardCodedURL = this.getView().getModel("i18n").getResourceBundle().getText("URL");
			/*window.location.href = "https://upmsoplandingpage-" + this.getAccountId() +
				".dispatcher.hana.ondemand.com/dashboard.html?sap-ui-language=" + this.getCurrentLanguage();*/
			window.location.href = hardCodedURL + this.getAccountId() +
				".dispatcher.hana.ondemand.com/dashboard.html?sap-ui-language=" + this.getCurrentLanguage();
		},
		getAccountId: function () {
			var location = window.location.href;
			var parts = location.split("-");
			var accountId = parts[1].split(".");
			return accountId[0];
		},
		onHelpButtonPress: function (oEvent) {

			var oHelpPopOver = this.getHelpPopover();
			this.oHelpPopOver = oHelpPopOver;
			this.oHelpPopOver.openBy(oEvent.getSource());
			this.oHelpPopOver.setBusyIndicatorDelay(0);
			this.oHelpPopOver.setBusy(true);
			this.getHelpData();
		},
		getHelpPopover: function () {
			var popover = new sap.m.ResponsivePopover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [],
				endButton: new sap.m.Button({
					text: "Close",
					press: function () {
						this.oHelpPopOver.close();
					}.bind(this)
				}),
				showCloseButton: true
			}).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");
			return popover;
		},
		getHelpData: function () {
			this.getView().byId("idBtnHint").setEnabled(false);
			this.oMdlMain.read("/ZrcpAppHelpSet('" + this.getCurrentLanguage() + "')", null, null, true, this.getHelpDataSucc.bind(this), this.getHelpDataErr
				.bind(this));
		},
		getCurrentLanguage: function () {
			var langCode = sap.ui.getCore().getConfiguration().getLanguage();
			var currentLanguage = "";
			if (langCode.length > 2) {
				var array = langCode.split("-");
				currentLanguage = array[0];
			} else {
				currentLanguage = langCode;
			}
			return currentLanguage.toUpperCase();

		},
		getHelpDataSucc: function (data, response) {
			var oHelpText = new sap.m.Text({
				text: data.Text
			});
			this.oHelpPopOver.addContent(oHelpText);
			this.oHelpPopOver.setBusy(false);
			this.getView().byId("idBtnHint").setEnabled(true);
		},
		getHelpDataErr: function (data, response) {
			this.getView().byId("idBtnHint").setEnabled(true);
			this.oHelpPopOver.setBusy(false);
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				"Error while fetching help data", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		onLogoutPress: function () {
			window.location.href = window.location.origin + '/logout.html';
			/*window.location.href = "https://sso.upm.com/adfs/ls/?wa=wsignout1.0&wreply={https://upmsoplandingpage-" + this.getAccountId() +
				".dispatcher.hana.ondemand.com/?hc_reset}";*/
		},
		numFormat: function (num) {
			var germanNum;
			if (num != undefined)
				germanNum = String(num).replace(".", ",");
			if (num < 0) {

				germanNum = String(String(Math.abs(num) + "-").replace(".", ","));
			}
			return germanNum;
		},
		onFilterDataWithColumns: function (oEvent) {
			var oValue = oEvent.getParameter("value");
			var oTable = this.getView().byId("idTreeTable");
			var oModelTreeTable = oTable.getModel();
			var oModelTreeTableData = oModelTreeTable.getData().PurOrder;
			var filterData = this.getFilteringColumn(oEvent, oModelTreeTableData);
			var SumOrdered = 0;
			var SumDelivered = 0;
			var SumOpen = 0;
			var SumPlanned = 0;

			for (var i = 0; i < filterData[0].length; i++) {
				if (filterData[0].length > 0) {
					SumOrdered += parseFloat(filterData[0][i].OrdQuantity);
					SumDelivered += parseFloat(filterData[0][i].DelQuantity);
					SumOpen += parseFloat(filterData[0][i].OpenQuantity);
					SumPlanned += parseFloat(filterData[0][i].PlannedQuantity);
				} else {
					oModelTreeTableData[0].SumOrdered = oModelTreeTableData[1].SumOrdered;
					oModelTreeTableData[0].SumDelivered = oModelTreeTableData[1].SumDelivered;
					oModelTreeTableData[0].SumOpen = oModelTreeTableData[1].SumOpen;
					oModelTreeTableData[0].SumPlanned = oModelTreeTableData[1].SumPlanned;
				}
			}
			if (oValue !== "") {
				oModelTreeTableData[0].SumOrdered = parseFloat(SumOrdered).toFixed(1);
				oModelTreeTableData[0].SumDelivered = parseFloat(SumDelivered).toFixed(1);
				oModelTreeTableData[0].SumOpen = parseFloat(SumOpen).toFixed(1);
				oModelTreeTableData[0].SumPlanned = parseFloat(SumPlanned).toFixed(1);
			} else {
				oModelTreeTableData[0].SumOrdered = oModelTreeTableData[1].SumOrdered;
				oModelTreeTableData[0].SumDelivered = oModelTreeTableData[1].SumDelivered;
				oModelTreeTableData[0].SumOpen = oModelTreeTableData[1].SumOpen;
				oModelTreeTableData[0].SumPlanned = oModelTreeTableData[1].SumPlanned;
			}
			oModelTreeTable.updateBindings();
		},
		getFilteringColumn: function (oEvent, oModelTreeTableData) {
			var oColumnId = oEvent.getParameter('column').getId();
			oColumnId = oColumnId.split('--')[2];
			var oValue = oEvent.getParameter("value");
			var filteredData = [];
			var fieldName;
			switch (oColumnId) {
			case "idColumnPONum":
				fieldName = "PurchOrder";
				for (var i = 0; i < oModelTreeTableData.length; i++) {
					if (parseFloat(oModelTreeTableData[i].PurchOrder) === parseFloat(oValue)) {
						filteredData.push(oModelTreeTableData[i]);
					}
				}
				break;
			case "idColumnMill":
				fieldName = "Mill";
				for (var m = 0; m < oModelTreeTableData.length; m++) {
					for (var k = 0; k < oModelTreeTableData[m].PlanDelData.length; k++) {
						if (oModelTreeTableData[m].PlanDelData[k].Mill === oValue) {
							filteredData.push(oModelTreeTableData[m].PlanDelData[k]);
						}
					}
				}
				break;
			case "idColumnYourReference":
				fieldName = "YourReference";
				for (var j = 0; j < oModelTreeTableData.length; j++) {
					if (oModelTreeTableData[j].YourReference === oValue) {
						filteredData.push(oModelTreeTableData[j]);
					}
				}
				break;
			}
			return [filteredData, fieldName];
		},
		foramtDeliveryDate: function (date) {
			var formattedDate = null;
			if (date) {
				var year = date.slice(0, 4);
				var month = date.slice(4, 6);
				var date1 = date.slice(6, 8);
				formattedDate = date1 + '.' + month + '.' + year;
			}
			return formattedDate;
		}
	});

});