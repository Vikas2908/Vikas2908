sap.ui.define([
	"supplieronlineportal/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("supplieronlineportal.controller.NotFound", {
		onLinkPressed: function() {
			this.getRouter().navTo("worklist");
		}

	});

});