function initModel() {
	var sUrl = "/GWaaS/odata/SAP/ZRCP_SOP_NEW_SRV;v&#x3D;1/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}