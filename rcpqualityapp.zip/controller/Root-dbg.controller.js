sap.ui.define([
	'com/upm/rcp/rcpqualityapp/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.rcp.rcpqualityapp.controller.Root', {

		onInit: function() {
			this.rootControl = this.byId('rootControl');
		},

		hideMaster: function() {
			this.rootControl.setMode(sap.m.SplitAppMode.HideMode);
		},

		showMaster: function() {
			this.rootControl.setMode(sap.m.SplitAppMode.ShowHideMode);
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		navigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'navigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		}

	});
});