sap.ui.define([
	'sap/ui/core/mvc/Controller',

	// SAPUI5 controls
	'sap/ui/core/routing/History',

	// Utils
	'com/upm/rcp/rcpqualityapp/util/formatter',
	'com/upm/rcp/rcpqualityapp/util/customTypes',
	'com/upm/rcp/rcpqualityapp/util/messagebox',
	'com/upm/rcp/rcpqualityapp/util/oData',
	'com/upm/rcp/rcpqualityapp/util/sorter',
	'com/upm/rcp/rcpqualityapp/util/validation',
	'com/upm/rcp/rcpqualityapp/util/CordovaCamera',
	'com/upm/rcp/rcpqualityapp/model/models'
], function (
	Controller,

	// SAPUI5 controls
	History,

	// Utils
	formatterUtil,
	customTypesUtil,
	messageBoxUtil,
	oDataUtil,
	sorterUtil,
	validationUtil,
	cordovaCameraUtil,
	models
) {
	'use strict';

	return Controller.extend('com.upm.rcp.rcpqualityapp.controller.BaseController', {

		// Utils
		formatterUtil: formatterUtil,
		customTypesUtil: customTypesUtil,
		messageBoxUtil: messageBoxUtil,
		oDataUtil: oDataUtil,
		sorterUtil: sorterUtil,
		validationUtil: validationUtil,
		cordovaCameraUtil: cordovaCameraUtil,
		models: models,

		onInit: function () {
			var that = this;
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function () {
				that.routeMatched.apply(that, arguments);
			});
			var eventBus = this.getMyComponent().getEventBus();
			eventBus.subscribe('app', 'afterNavigate', function handleAfterNavigate() {
				that.handleAfterNavigate.apply(that, arguments);
			}, this);
		},

		routeMatched: function (oEvent) {
			var parameters = oEvent.getParameter('arguments');

			if (parameters && !$.isEmptyObject(parameters)) {
				var decodeArr = parameters['?query'] ? parameters['?query'] : parameters;
				$.each(decodeArr, function (key, value) {
					decodeArr[key] = typeof value === 'string' ? decodeURIComponent(decodeURI(value)) : value;
				});
			}

			this.setUrlParameters(parameters);
		},

		/**
		 *
		 * PlaceHolder method that should be extended in case something needs to be done right after navigation
		 *
		 * @param  {[type]} oEvent [description]
		 * @return {[type]}        [description]
		 */
		handleAfterNavigate: function () {

		},

		/* =========================================================== */
		/* Common helpers                                              */
		/* =========================================================== */

		getMyComponent: function () {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
		},

		getRootControl: function () {
			return this.getMyComponent().getAggregation('rootControl').getController();
		},

		/**
		 * @param {string} sElementId - ID of UI element
		 * @returns {object} the element object
		 */
		getElementById: function (sElementId) {
			return this.getView().byId(sElementId);
		},

		/**
		 * @param {string=} sFragmentName - name of fragment
		 * @param {string} sElementId - ID of UI element
		 * @returns {object} the element object
		 */
		getFragmentElementById: function (sFragmentName, sElementId) {
			return sap.ui.core.Fragment.byId(sFragmentName, sElementId);
		},

		setUrlParameters: function (parameters) {
			this.urlParameters = parameters;
		},

		getUrlParameters: function () {
			return this.urlParameters;
		},

		getUrlParameter: function (parameterName) {
			return this.urlParameters[parameterName] || null;
		},

		/**
		 * @param {string} sTextToGet - text property from i18n
		 * @returns {string} the translated text
		 */
		getResourceBundleText: function (sTextToGet, aPlaceHolders) {
			return this.getView().getModel('i18n').getResourceBundle().getText(sTextToGet, aPlaceHolders);
		},

		/**
		 * Convenience method for getting model by name in every controller of the application.
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName) || this.getMyComponent().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @param {string} sName the model name
		 * @param {object} oData the model data
		 * @param {function} fOnChange the model onChange function
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (sName, oData, fOnChange) {
			var oModel = new sap.ui.model.json.JSONModel();
			if (oData) {
				oModel.setData(oData);
			}

			var createdModel = this.getView().setModel(oModel, sName);

			if (fOnChange) {
				var binding = new sap.ui.model.Binding(oModel, '/', oModel.getContext('/'));
				binding.attachChange(function () {
					fOnChange();
				});
			}

			return createdModel;
		},

		setGlobalModel: function (sName, oData, fOnChange) {
			var oModel = new sap.ui.model.json.JSONModel();
			if (oData) {
				oModel.setData(oData);
			}

			var createdModel = this.getMyComponent().setModel(oModel, sName);

			if (fOnChange) {
				var binding = new sap.ui.model.Binding(oModel, '/', oModel.getContext('/'));
				binding.attachChange(function () {
					fOnChange();
				});
			}

			return createdModel;
		},

		/**
		 * Convenience method to get the global model containing the global properties of the app.
		 * @returns {object} the global Propery model
		 */
		getGlobalPropertiesModel: function () {
			return this.getMyComponent().getModel('GlobalProperties');
		},

		/**
		 * Generated filter that can be passed to back end call
		 * @param {string} sValueToFilter - key of the value that should be filtered
		 * @param {array} aFilterValues - value or values that operator should be applied
		 * @param {sOperator=} sOperator - operator of filter, default is EQ
		 * @returns {array} multiSelect - determines if dialog allows multiselection. Default is false
		 */
		generateFilter: function (sValueToFilter, aFilterValues, sOperator) {
			sOperator = sOperator || 'EQ';
			var sFilterOperator = {
				EQ: sap.ui.model.FilterOperator.EQ,
				Contains: sap.ui.model.FilterOperator.Contains,
				NE: sap.ui.model.FilterOperator.NE,
				StartsWith: sap.ui.model.FilterOperator.StartsWith
			}[sOperator];
			var aFilterArray = aFilterValues.map(function (sFilterValue) {
				return new sap.ui.model.Filter(sValueToFilter || '', sFilterOperator, sFilterValue);
			});
			return aFilterArray;
		},

		/**
		 * Finds array index that contains object with given key value pair
		 * @param {string} sIdValue - value which should be found
		 * @param {string} sProperty - key of the value
		 * @param {array} aValuesToLookFrom
		 * @returns {integer} index of object with key value pair
		 */
		findRightArrayIndexById: function (sIdValue, sProperty, aValuesToLookFrom) {
			var rightIndex = false;
			aValuesToLookFrom.map(function (object, i) {
				if (object[sProperty] === sIdValue) {
					rightIndex = i;
					return;
				}
			});
			return rightIndex;
		},

		/**
		 * @param {array} arr
		 * @param {integer} index
		 * @returns {array}
		 */
		removeIndexFromArray: function (arr, index) {
			arr.splice(index, 1);
			return arr;
		},

		/* =========================================================== */
		/* Routing			 										   */
		/* =========================================================== */

		/**
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getMyComponent().getRouter();
		},

		/**
		 * @returns {string} Launchpad user id
		 */
		getUserId: function () {
			return sap.ushell.Container.getUser().getId();
		},

		onNavBack: function () {
			// Can be used by controllers to add custom functionality to navBack
			!this.beforeNavBack || this.beforeNavBack();

			window.history.go(-1);
		},

		onNavToLaunchpad: function () {
			var crossAppNavigation = sap.ushell.Container.getService('CrossApplicationNavigation');
			crossAppNavigation.toExternal({
				target: {
					shellHash: '#'
				}
			});
		},

		// Navigates to given view; ie. this.navTo('Menu');
		navTo: function (routeName, parameters, replace) {
			var router = sap.ui.core.UIComponent.getRouterFor(this);

			if (parameters && !$.isEmptyObject(parameters)) {
				var encodeArr = parameters.query ? parameters.query : parameters;
				$.each(encodeArr, function (key, value) {
					encodeArr[key] = typeof value === 'string' ? encodeURIComponent(value) : value;
				});
			}

			router.navTo(
				routeName,
				parameters || {},
				replace || false
			);
		},

		/**
		 * @param {string} viewName
		 * @returns {boolean}
		 */
		navigatedFrom: function (viewPath, viewName) {
			return viewPath && viewPath.indexOf(viewName) !== -1;
		},

		/**
		 * @param {string} viewName
		 * @returns {boolean}
		 */
		navigatedToCurrentView: function (viewName) {
			return this.getView().sViewName.indexOf(viewName) !== -1;
		},

		/* =========================================================== */
		/* DOM Manipulations                                           */
		/* =========================================================== */

		showLoader: function () {
			if (!this.BusyDialogLight) {
				this.BusyDialogLight = sap.ui.xmlfragment('BusyDialogLight', 'com.upm.rcp.rcpqualityapp.view.fragment.BusyDialogLight', this);
				this.getView().addDependent(this.BusyDialogLight);
			}
			this.BusyDialogLight.open();
		},

		hideLoader: function () {
			this.BusyDialogLight.close();
		},

		/** Shows busy indicator, default delay is 0 second. This is used for busy states that requires no message
		 * @param {integer=} milliseconds - time of delay
		 */
		showBusyIndicator: function (milliseconds) {
			var delay = milliseconds || 0;
			sap.ui.core.BusyIndicator.show(delay);
		},

		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide();
		},

		/** Shows busy indicator, default delay is 1 second. This is used for busy states that requires no message
		 * @param {object=} arguments object - possible values: {text, title, cancelButtonText, showCancelButton, customIcon, customIconRotationSpeed, customIconDensityAware, customIconWidth, customIconHeight}
		 */
		openBusyDialog: function (args) {
			var parameters = args || {};
			this.busyDialog = new sap.m.BusyDialog(parameters);
			this.busyDialog.open();
		},

		getBusyDialog: function () {
			return this.busyDialog;
		},

		closeBusyDialog: function () {
			this.busyDialog.close();
		},

		setAppBusyMode: function (iDelay) {
			iDelay = iDelay || 200;
			sap.ui.core.BusyIndicator.show(iDelay);
		},

		setAppNotBusyMode: function () {
			sap.ui.core.BusyIndicator.hide();
		},

		/**
		 * @param {integer} spaceAboveElement - manually make function to scroll certain pixels higher
		 * @param {sap.ui.core.Control || array} control - single control or array of controls, if array of controls is passed highest one will be target for scrolling
		 */
		scrollToElement: function (spaceAboveElement, control) {
			control = Number.isInteger(spaceAboveElement) ? control : spaceAboveElement;
			spaceAboveElement = spaceAboveElement || 0;
			control = Array.isArray(control) ? this.getHighestDomElement(control) : control;
			var pageElement = this.getView().mAggregations.content[0];
			// scroll to position of control, need to reduce header offset and label height to get right position
			pageElement.scrollTo(
				pageElement.getScrollDelegate().getScrollTop() +
				$('#' + control.getId()).offset().top -
				$('#' + this.getView().getId()).find('section').first().offset().top -
				spaceAboveElement, 1000
			);
		},

		/**
		 * @param {array} controls
		 * @returns {sap.ui.core.Control} highest DOM element
		 */
		getHighestDomElement: function (controls) {
			return controls.reduce(function (highestElement, currentElement) {
				return !highestElement && currentElement ||
					$('#' + highestElement.getId()).offset().top < $('#' + currentElement.getId()).offset().top ?
					highestElement :
					currentElement;
			});
		},

		openDialog: function (fragmentName, parameters) {
			if (!this[fragmentName]) {
				this[fragmentName] = sap.ui.xmlfragment(
					fragmentName,
					'com.upm.rcp.rcpqualityapp.view.fragment.' + fragmentName,
					sap.ui.controller('com.upm.rcp.rcpqualityapp.controller.fragment.' + fragmentName));
				this.getView().addDependent(this[fragmentName]);
			}
			sap.ui.controller('com.upm.rcp.rcpqualityapp.controller.fragment.' + fragmentName)
				.init(this, this[fragmentName], parameters);
		},

		/* =========================================================== */
		/* Validation functions                                        */
		/* =========================================================== */

		/**
		 * @param {sap.ui.core.Control=} control - control that should be validated recursively, default is current view
		 * @param {function=} functionToCallOnInvalidElements - function that gets array of invalid elements as argument
		 * @returns {boolean} indicates if invalid controls were found
		 */

		validate: function (control, functionToCallOnInvalidElements) {
			functionToCallOnInvalidElements = functionToCallOnInvalidElements || $.noop;
			this.validationUtil.controlValidationResults = [];
			this.validationUtil.validateControlType(control || this.getView());
			!this.validationUtil.controlValidationResults.length || functionToCallOnInvalidElements.call(this, this.validationUtil.controlValidationResults);
			return this.validationUtil.controlValidationResults.length === 0;
		},

		/* =========================================================== */
		/* Message handler helper                                      */
		/* =========================================================== */

		/**
		 * Open message box (Info, Success, Error, Warning, Confirm)
		 * @param  {object} parameters
		 */
		showMessageBox: function (parameters) {
			messageBoxUtil.show(parameters);
		},

		/* =========================================================== */
		/* Error handler helpers                                       */
		/* =========================================================== */

		/**
		 * @param {string=} error - error event passed from service
		 * @param {string=} i18nKey - key of the text from i18n
		 */
		openErrorMessagePopup: function (oErrEvt, i18nKey) {
			i18nKey = i18nKey || 'ERROR_MESSAGE_ERROR_LOADING_DATA';
			var messageBoxParameters = {
				type: 'Error',
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: oErrEvt ?
					this.getResourceBundleText(i18nKey, formatterUtil.oDataErrorToErrorString(oErrEvt)) : this.getResourceBundleText(i18nKey)
			};
			messageBoxUtil.show(messageBoxParameters);
		},

		openErrorMessagePopupWithoutEvent: function (oErrEvt, validate) {
			var that = this;
			var messageBoxParameters = {
				type: 'Error',
				title: that.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: oErrEvt,
				actions: that.getResourceBundleText('OK_LABEL'),
				onClose: function (oAction) {
					if (oAction === "Ok" || oAction === "OK") {
						that.enableButtons(true);   //// RITM1953293 - NQA: UD not stored in UP6 for few deliveries
						if(validate === true){
							that.navTo('RcpQualityMain', {}, false);
						}
					}
				}
			};
			messageBoxUtil.show(messageBoxParameters);
		},

		/* =========================================================== */
		/* List Helpers     	                                       */
		/* =========================================================== */

		/**
		 * Filter list with given list and filters
		 * @param  {sapui5 list element} list
		 * @param  {array} filters - example:
		 * [{
				path: 'PropertyName1',
				operator: sap.ui.model.FilterOperator.Contains,
				value1: 'filterValue'
			}, {
				path: 'PropertyName2',
				operator: sap.ui.model.FilterOperator.Contains,
				value1: filterValue
			}]
		 *
		 */
		filterList: function (list, filters) {
			var binding = list.getBinding('items');

			var filtersArray = [];
			$.map(filters, function (filter) {
				filtersArray.push(new sap.ui.model.Filter(filter));
			});

			var combinedFilter = new sap.ui.model.Filter(filtersArray, false);

			binding.filter(combinedFilter, 'Application');
			binding.refresh(true);
		}
	});
});