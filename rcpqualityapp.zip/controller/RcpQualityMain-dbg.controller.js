sap.ui.define([
	'com/upm/rcp/rcpqualityapp/controller/CommonController',
	'com/upm/rcp/rcpqualityapp/controller/BaseController',
	'sap/m/MessageToast'
], function (CommonController, BaseController, MessageToast) {
	return CommonController.extend('com.upm.rcp.rcpqualityapp.controller.RcpQualityMain', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function () {
			BaseController.prototype.onInit.apply(this, arguments);

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'navigate', this.handleNavigate.bind(this));

			this.setGlobalModel('RcpQualityMainViewModel');
			this.setGlobalModel('QualityCheckViewModel');
			this.setGlobalModel('VisualViewModel');
			this.setGlobalModel('ViewModel');
			this.setGlobalModel('AdditionalDataModel');
			this.setGlobalModel('GravametricksViewModel');
			this.setGlobalModel('TextFieldsViewModel');
			this.setGlobalModel('SelectViewModel');
			this.setGlobalModel('LongTextModel');
		},

		onAfterRendering: function () {
			jQuery.sap.delayedCall(700, this, this.focusToDeliveryNumberInput);
		},

		routeMatched: function (navigationEvent) {
			if (navigationEvent.getParameter('name') === 'RcpQualityMain') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				var deliveryNum = navigationEvent.getParameter('arguments').deliveryNumber;
				if (deliveryNum) {
					this.getDlvDetails(deliveryNum);
				} else {
					this.resetInputFields();
					this.showFields(false);
				}
				if (sap.ui.Device.system.phone) {
					this.getElementById('uploadImageButton').setText('');
				}
			}
		},

		handleNavigate: function (channel, eventName, navigationData) {
			if (
				this.navigatedToCurrentView(navigationData.toView) &&
				this.navigatedFrom(navigationData.fromView, 'NotFound')
			) {
				console.log("navigated");
			}
			jQuery.sap.delayedCall(0, this, this.focusToDeliveryNumberInput);
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		resetView: function () {
			/*var oToViewModel = this.getModel('ToViewModel');
			if (oToViewModel) {
				oToViewModel.setData({});
				this.clearFilterInput();
			}*/
		},

		onDeliveryBarcodeInputChange: function (oEvent) {
			var scannedValue = oEvent.getParameter('value');
			this.scannedDliveryValueChange(scannedValue);
		},

		onDeliveryScanSuccess: function (oEvent) {
			var scannedValue = oEvent.getParameter('value');
			this.scannedDliveryValueChange(scannedValue);
		},

		onScanError: function (oEvent) {
			var errorMessage = '';
			if (oEvent) {
				errorMessage = oEvent.getParameter('value');
			}
			this.openErrorMessagePopup(errorMessage, null);
		},

		onNavBackPress: function () {
			this.onNavBack();
		},

		onUploadImagePress: function () {
			this.openUploadImageDialog();
		},

		onQualityCheckPress: function () {
			var object = this.getModel('RcpQualityMainViewModel').getData();
			this.navTo('RcpQualityCheck', {
				deliveryNumber: object.Vbeln
			});
		},

		onAcceptWithoutCheckPress: function (oEvent) {
			var object = this.getModel('RcpQualityMainViewModel').getData();
			if (object && object.QualityCheckMade === 'X') {
				this.showMessageBox({
					type: 'Warning',
					title: this.getResourceBundleText('COMMON_WARNING_TITLE'),
					message: this.getResourceBundleText('QUALITY_CHECK_MADE_WARNING_MESSAGE', [object.Vbeln])
				});
			} else {
				this.createInspLot();
				this.navTo('UsageDecision', {
					deliveryNumber: object.Vbeln,
					materialNumber: object.Matnr,
					plant: object.Werks,
					key: 'FromMainView'
				}, false);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		scannedDliveryValueChange: function (scannedDeliveryNumber) {
			if (scannedDeliveryNumber) {
				//this.getModel('RcpQualityMainViewModel').setProperty('/DeliveryNumber', scannedDeliveryNumber);
				this.getDlvDetails(scannedDeliveryNumber);
			}
		},

		getDlvDetails: function (deliveryNumber) {
			this.setAppBusyMode();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetDlvDetails?inDlvNo=\'' + deliveryNumber + '\'')
				.done(function (oData) {
					this.resetInputFields();
					//	this.getUsageDecision(oData.Prueflos);
					this.handleGetDlvDetailsSuccess(deliveryNumber, oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.resetInputFields();
					this.showFields(false);
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		handleGetDlvDetailsSuccess: function (deliveryNumber, oData) {
			if (oData) {
				if (oData.Vbeln === deliveryNumber) {
					this.getModel('RcpQualityMainViewModel').setData(oData);
					this.getUsageDecision(oData.Prueflos);
					this.showFields(true);
				} else {
					this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('ERROR_MESSAGE_DELIVERY_NUMBER_NOT_FOUND', [deliveryNumber]));
					this.getModel('RcpQualityMainViewModel').setData({});
					this.showFields(false);
				}
				jQuery.sap.delayedCall(0, this, this.focusToDeliveryNumberInput);
			}
		},

		getUsageDecision: function (inInspLot) {
			this.setAppBusyMode();
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel');
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetUsageDecision?inInspLot=\'' + inInspLot + '\'')
				.done(function (oData) {
					oRcpQualityMainViewModel.setProperty('/Message', oData.Message);
					oRcpQualityMainViewModel.setProperty('/Type', oData.Type);
					oRcpQualityMainViewModel.setProperty('/UsageDecisionCode', oData.UsageDecisionCode);
					/*if(oData.Message){
						this.getElementById('acceptWithoutCheckButton').setVisible(false);
					} else {
						this.getElementById('acceptWithoutCheckButton').setVisible(true);
					}*/
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		createInspLot: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var deliveryNumber = oRcpQualityMainViewModel.Vbeln;
			this.getModel('QualityCheckViewModel').setData('');
			this.setAppBusyMode();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'CreateInspLot?inDlvNo=\'' + deliveryNumber + '\'')
				.done(function (oData) {
					this.getModel('QualityCheckViewModel').setData(oData);
				}.bind(this))
				.fail(function () {
					//	this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		showFields: function (visible) {
			this.getElementById('deliveryDetailsForm').setVisible(visible);
			this.getElementById('uploadImageButton').setVisible(visible);
			this.getElementById('qualityCheckButton').setVisible(visible);
			this.getElementById('idBoxButton').setVisible(false);
			//	this.getElementById('acceptWithoutCheckButton').setVisible(visible);
		},

		resetInputFields: function () {
			this.getElementById('deliveryBarcodeInput').setValue('');
			this.getModel('RcpQualityMainViewModel').setData({});
		},

		onBoxPress: function () {
			var object = this.getModel('RcpQualityMainViewModel').getData();
			this.navTo('UsageDecision', {
				deliveryNumber: object.Vbeln,
				materialNumber: object.Matnr || '',
				plant: object.Werks || '',
				key: 'FromBoxButtonClick'
			}, false);
		},

		/* =========================================================== */
		/*     Focus handling			                          	   */
		/* =========================================================== */

		focusToDeliveryNumberInput: function () {
			this.getElementById('deliveryBarcodeInput').focus();
		}
	});
});