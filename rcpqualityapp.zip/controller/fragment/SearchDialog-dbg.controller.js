sap.ui.define([
	'com/upm/rcp/rcpqualityapp/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.rcp.rcpqualityapp.controller.fragment.SearchDialog', {

		/* =========================================================== */
		/* Search dialog API	 									   */
		/* =========================================================== */

		/**
		 * Combines setting up search dialog and API request for helper values
		 * @param {string} pathToModel - path to the model
		 * @param {string} saveModelName - model where selected values should be saved
		 * @param {string} listItemValueKey - key of the JSON item object value/id
		 * @param {string} listItemDescriptionKey - key of the JSON item object description
		 * @param {string} firstValueToSave - path where value/id key value should be saved
		 * @param {string=} secondValueToSave - path where description key value should be saved
		 * @param {string=} configurationModelName - name of the configuration model that stores dialog configurations, default value is ViewModel
		 * @param {string=} service - part of the uri, before path to service
		 * @param {string=} pathToService - path to the service
		 * @param {array=} filters - filters for service call
		 * @param {string=} dialogTitle - title of the dialog, default is 'Select value'
		 * @param {boolean=} getValuesAfterEverySearch - determines if call is made to back end after every search. This is handy for large data sets only. Default is false
		 * @param {boolean=} multiSelect - determines if dialog allows multiselection. Default is false
		 */

		init: function(parent, fragment, oParameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.attachAfterClose(this.onAfterSearchDialogClose.bind(this));

			this.configureObjectForHelperDialog(oParameters);
			this.getHelperDialogValues(oParameters)
				.done([
					this.changeSearchDialogTitle.bind(this, oParameters.dialogTitle),
					this.bindSearchDialogToModel.bind(this, oParameters.pathToModel, oParameters.listItemValueKey, oParameters.listItemDescriptionKey)
				])
				.done(this.openSearchDialog.bind(this));
		},

		configureObjectForHelperDialog: function(oParameters) {
			this.searchDialogConfigurationModelName = oParameters.configurationModelName || 'ViewModel';
			this.helperDialogProperties = oParameters;
		},

		getHelperDialogValues: function(oParameters) {
			var deferred = $.Deferred();

			var readParameters = {
				filters: oParameters.filters || []
			};

			if (!oParameters.service || !oParameters.pathToService || oParameters.getValuesAfterEverySearch) {
				deferred.resolve();
			} else {
				this.setAppBusyMode();
				this.oDataUtil.read(oParameters.service, oParameters.pathToService, readParameters)
					.done([this.handleHelperDialogValuesSuccess.bind(this), deferred.resolve])
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setAppNotBusyMode);
			}
			return deferred.promise();
		},

		handleHelperDialogValuesSuccess: function(helperDialogData) {
			var oConfigurationModel = this.parentView.getModel(this.searchDialogConfigurationModelName);
			oConfigurationModel.setProperty(this.helperDialogProperties.pathToModel, helperDialogData);
		},


		openSearchDialog: function() {
			this.fragment.open();
		},

		changeSearchDialogTitle: function(title) {
			this.getFragmentElementById('SearchDialog', 'searchDialogTitle')
				.setTitle(title || this.getResourceBundleText.call(this.parentView, 'SEARCH_DIALOG_DEFAULT_TITLE'));
		},

		bindSearchDialogToModel: function() {
			this.bindEventHandlers();
			this.bindFields();
		},

		bindFields: function() {
			var helperDialogProperties = this.helperDialogProperties;
			var oDialogListElement = this.getFragmentElementById('SearchDialog', 'searchDialogList');
			var oDialogListItemElement = this.getFragmentElementById('SearchDialog', 'searchDialogListItem');
			helperDialogProperties.multiSelect ?
				this.handleMultiSelect() :
				this.handleSingleSelect();
			this.getFragmentElementById('SearchDialog', 'searchDialogListValue')
				.bindText(this.searchDialogConfigurationModelName + '>' + helperDialogProperties.listItemValueKey);
			this.getFragmentElementById('SearchDialog', 'searchDialogListDescription')
				.bindText(this.searchDialogConfigurationModelName + '>' + helperDialogProperties.listItemDescriptionKey);
			oDialogListElement.bindItems({
				path: this.searchDialogConfigurationModelName + '>' + helperDialogProperties.pathToModel,
				template: oDialogListItemElement
			});
		},

		handleMultiSelect: function() {
			var helperDialogProperties = this.helperDialogProperties;
			var oDialogListElement = this.getFragmentElementById('SearchDialog', 'searchDialogList');
			var oDialogListItemElement = this.getFragmentElementById('SearchDialog', 'searchDialogListItem');
			oDialogListItemElement.bindProperty('selected', {
				parts: [{
					path: this.searchDialogConfigurationModelName + '>' + helperDialogProperties.listItemValueKey
				}, {
					path: helperDialogProperties.saveModelName + '>/' + helperDialogProperties.firstValueToSave
				}],
				formatter: function(idOfItem, selectedItems) {
					return this
						.formatterUtil
						.selectedStateFormatter(helperDialogProperties.listItemValueKey, idOfItem, selectedItems);
				}.bind(this)
			});
			oDialogListElement.setMode('MultiSelect');
			oDialogListElement.setIncludeItemInSelection(true);
			this.getFragmentElementById('SearchDialog', 'selectSelectionButton').setVisible(true);
		},

		handleSingleSelect: function() {
			var oDialogListElement = this.getFragmentElementById('SearchDialog', 'searchDialogList');
			oDialogListElement.setMode('None');
			oDialogListElement.setIncludeItemInSelection(false);
			this.getFragmentElementById('SearchDialog', 'selectSelectionButton').setVisible(false);
		},

		bindEventHandlers: function() {
			var helperDialogProperties = this.helperDialogProperties;
			var listItem = this.getFragmentElementById('SearchDialog', 'searchDialogListItem');
			if(helperDialogProperties.getValuesAfterEverySearch) {
				this.handleValuesAfterEverySearch();
			} else {
				this.handleValuesAtStart();
			}
		helperDialogProperties.itemPressHandler ? listItem.attachPress(helperDialogProperties.itemPressHandler, this) : listItem.attachPress(this.onSearchDialogItemPress, this);
			this.getFragmentElementById('SearchDialog', 'selectSelectionButton').attachPress(this.onSelectSelectionPress, this);
			this.getFragmentElementById('SearchDialog', 'searchDialogCloseButton').attachPress(this.onSearchDialogCloseButtonPress, this);
		},

		handleValuesAfterEverySearch: function() {
			var oSearchBarElement = this.getFragmentElementById('SearchDialog', 'searchDialogSearchField');
			oSearchBarElement.attachSearch(this.onSearchDialogSearch, this);
			oSearchBarElement.detachLiveChange(this.onSearchDialogLiveChange, this);
		},

		handleValuesAtStart: function() {
			var oSearchBarElement = this.getFragmentElementById('SearchDialog', 'searchDialogSearchField');
			oSearchBarElement.detachSearch(this.onSearchDialogSearch, this);
			oSearchBarElement.attachLiveChange(this.onSearchDialogLiveChange, this);
		},

		onSearchDialogLiveChange: function() {
			var helperDialogProperties = this.helperDialogProperties;
			this.applyFiltersToListBinding(
				helperDialogProperties.listItemValueKey,
				helperDialogProperties.listItemDescriptionKey
			);
		},

		onSearchDialogSearch: function() {
			var helperDialogProperties = this.helperDialogProperties;
			var filterValue = this.getFragmentElementById('SearchDialog', 'searchDialogSearchField').getValue();
			var valueToFilter = /\d/.test(filterValue) ? helperDialogProperties.listItemValueKey : helperDialogProperties.listItemDescriptionKey;
			var filter = this.generateFilter(valueToFilter, [filterValue]);
			this.getSearchedValues(filter, helperDialogProperties);
		},

		getSearchedValues: function(filter, helperDialogProperties) {
			var parameters = {
				filters: filter
			};
			this.setAppBusyMode();
			this.oDataUtil.read(helperDialogProperties.service, helperDialogProperties.pathToService, parameters)
				.done(this.handleHelperDialogValuesSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		applyFiltersToListBinding: function(sValueToFilter, sSecondValueToFilter) {
			var oDialogListBinding = this.getFragmentElementById('SearchDialog', 'searchDialogList').getBinding('items');
			var oSearchBarElement = this.getFragmentElementById('SearchDialog', 'searchDialogSearchField');
			var sFilterValue = oSearchBarElement.getValue();
			var oFirstFilter = new sap.ui.model.Filter(sValueToFilter, sap.ui.model.FilterOperator.Contains, sFilterValue);
			var oSecondFilter = new sap.ui.model.Filter(sSecondValueToFilter, sap.ui.model.FilterOperator.Contains, sFilterValue);
			var oCombinedFilter = new sap.ui.model.Filter([oFirstFilter, oSecondFilter]);
			oDialogListBinding.filter([oCombinedFilter], 'Application');
		},

		onSearchDialogItemPress: function(oEvent) {
			var helperDialogProperties = this.helperDialogProperties;
			var oSaveModel = this.parentView.getModel(helperDialogProperties.saveModelName);
			var selectedListItem = oEvent.getSource().getBindingContext(this.searchDialogConfigurationModelName).getObject();
			var selectedProperty = selectedListItem[helperDialogProperties.listItemValueKey];
			var selectedDescription = selectedListItem[helperDialogProperties.listItemDescriptionKey];
			oSaveModel.setProperty('/' + helperDialogProperties.firstValueToSave, selectedProperty);
			if (helperDialogProperties.secondValueToSave) {
				oSaveModel.setProperty('/' + helperDialogProperties.secondValueToSave, selectedDescription);
			}
			this.onSearchDialogCloseButtonPress();
		},

		onSelectSelectionPress: function() {
			var helperDialogProperties = this.helperDialogProperties;
			var selectedItemContexts = this.getFragmentElementById('SearchDialog', 'searchDialogList').getSelectedContexts(true);
			var selectedItems = selectedItemContexts.reduce(function(items, itemContext) {
				return items.concat(itemContext.getObject());
			}, []);
			this.parentView.getModel(helperDialogProperties.saveModelName).setProperty('/' + helperDialogProperties.firstValueToSave, selectedItems);
			this.onSearchDialogCloseButtonPress();
		},

		onSearchDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		/**
		 * This event is fired when search dialog is closed. onSearchDialogCloseButtonPress function doesn't catch events
		 * where user exits without close button.
		 * Is used to reset state of dialog
		 */
		onAfterSearchDialogClose: function() {
			var oSearchBarElement = this.getFragmentElementById('SearchDialog', 'searchDialogSearchField');
			this.getFragmentElementById('SearchDialog', 'searchDialogSearchField').setValue('');
			oSearchBarElement.detachSearch(this.onSearchDialogSearch, this);
			oSearchBarElement.detachLiveChange(this.onSearchDialogLiveChange, this);
			oSearchBarElement.destroy(true);
			this.getFragmentElementById('SearchDialog', 'searchDialogList').destroy(true);
			this.getFragmentElementById('SearchDialog', 'searchDialogListItem').destroy(true);
			this.getFragmentElementById('SearchDialog', 'selectSelectionButton').destroy(true);
			this.getFragmentElementById('SearchDialog', 'searchDialogCloseButton').destroy(true);
			this.parentView.SearchDialog.destroy(true);
			this.parentView.SearchDialog = null;
		}
	});
});