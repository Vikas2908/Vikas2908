sap.ui.define([
	'com/upm/rcp/rcpqualityapp/controller/BaseController'

], function(BaseController) {
	'use strict';
	return BaseController.extend('com.upm.rcp.rcpqualityapp.controller.NotFound', {
		onInit: function() {}
	});
});