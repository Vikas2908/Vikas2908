sap.ui.define([
	'sap/ui/core/UIComponent',
	"./controller/Application"
], function(UIComponent, Application) {
	return UIComponent.extend('com.upm.rcp.rcpqualityapp.Component', {
		metadata: {
			stereotype: 'component',
			includes: [],
			dependencies: {
				libs: ['sap.m']
			},
			rootView: 'com.upm.rcp.rcpqualityapp.view.Root',
			config: {
				resourceBundle: 'i18n/i18n.properties',
				serviceConfig: {
					'ZRCP_QUALITY_INSPECTION_SRV': {
						name: 'ZRCP_QUALITY_INSPECTION_SRV',
						serviceUrl: '/odata/SAP/ZRCP_QUALITY_INSPECTION_SRV;v=1'
					}
				},
				fullWidth: true
			},
			routing: {
				config: {
					routerClass: 'sap.m.routing.Router',
					viewType: 'XML',
					viewPath: 'com.upm.rcp.rcpqualityapp.view',
					controlId: 'rootControl',
					controlAggregation: 'pages',
					clearTarget: false,
					bypassed: {
						target: 'NotFound'
					}
				},
				routes: [{
					pattern: ':deliveryNumber:',
					name: 'RcpQualityMain',
					target: 'RcpQualityMain'
				}, {
					pattern: 'rcpQualityCheck/:deliveryNumber:/',
					name: 'RcpQualityCheck',
					target: 'RcpQualityCheck'
				}, {					
					pattern: 'usageDecision/{deliveryNumber}/{materialNumber}/{plant}/:key:/',
					name: 'UsageDecision',
					target: 'UsageDecision'
				}
				],
				targets: {
					RcpQualityMain: {
						viewName: 'RcpQualityMain',
						viewLevel: 1,
						transition: 'slide'
					},
					RcpQualityCheck: {
						viewName: 'RcpQualityCheck',
						viewLevel: 2,
						transition: 'slide'
					},
					UsageDecision: {
						viewName: 'UsageDecision',
						viewLevel: 3,
						transition: 'slide'
					},
					NotFound: {
						viewName: 'NotFound',
						viewLevel: 99,
						transition: 'slide'
					}
				}
			}
		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);
			new Application(this).init();
		},

		destroy: function(){
			if(this.routeHandler){
				this.routeHandler.destroy();
			}
			sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
		}
	});
});