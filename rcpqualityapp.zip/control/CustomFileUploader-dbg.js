/*eslint-disable */
sap.ui.define([
	'sap/ui/unified/FileUploader'
], function(FileUploader) {
	'use strict';

	var CustomFileUploader = FileUploader.extend('com.upm.rcp.rcpqualityapp.control.CustomFileUploader', {
		metadata: {
			properties: {
				'maxImageHeight': {
					type: 'int',
					defaultValue: null
				},
				'maxImageWidth': {
					type: 'int',
					defaultValue: null
				}
			}
		}
	});

	CustomFileUploader.init = function() {
		FileUploader.prototype.init.call(this);
	};
	
	CustomFileUploader.prototype.upload = function() {
        //supress Upload if the FileUploader is not enabled
        if (!this.getEnabled()) {
            return;
        }
        var uploadForm = this.getDomRef("fu_form");
        var iFiles, sHeader, sValue, oXhrEntry;
        try {
            this._bUploading = true;
            if (this.getSendXHR() && window.File) {
                var filesForUpload = this.FUEl.files;

				this.scaleImagesFiles(filesForUpload).always(function(aFiles) {
	                if (aFiles.length > 0) {
	                    if (this.getUseMultipart()) {
	                        //one xhr request for all files
	                        iFiles = 1;
	                    } else {
	                        //several xhr requests for every file
	                        iFiles = aFiles.length;
	                    }
	                    // Save references to already uploading files if a new upload comes between upload and complete or abort
	                    this._aXhr = this._aXhr || [];
	                    for (var j = 0; j < iFiles; j++) {
	                        //keep a reference on the current upload xhr
	                        this._uploadXHR = new window.XMLHttpRequest();
	                        oXhrEntry = {
	                            xhr: this._uploadXHR,
	                            requestHeaders: []
	                        };
	                        this._aXhr.push(oXhrEntry);
	                        oXhrEntry.xhr.open("POST", this.getUploadUrl(), true);
	                        if (this.getHeaderParameters()) {
	                            var aHeaderParams = this.getHeaderParameters();
	                            for (var i = 0; i < aHeaderParams.length; i++) {
	                                sHeader = aHeaderParams[i].getName();
	                                sValue = aHeaderParams[i].getValue();
	                                oXhrEntry.requestHeaders.push({
	                                    name: sHeader,
	                                    value: sValue
	                                });
	                            }
	                        }
	                        var sFilename = aFiles[j].name;
	                        var aRequestHeaders = oXhrEntry.requestHeaders;
	                        oXhrEntry.fileName = sFilename;
	                        oXhrEntry.file = aFiles[j];
	                        this.fireUploadStart({
	                            "fileName": sFilename,
	                            "requestHeaders": aRequestHeaders
	                        });
	                        for (var k = 0; k < aRequestHeaders.length; k++) {
	                            // Check if request is still open in case abort() was called.
	                            if (oXhrEntry.xhr.readyState === 0) {
	                                break;
	                            }
	                            sHeader = aRequestHeaders[k].name;
	                            sValue = aRequestHeaders[k].value;
	                            oXhrEntry.xhr.setRequestHeader(sHeader, sValue);
	                        }
	                    }
	                    if (this.getUseMultipart()) {
	                        var formData = new window.FormData();
	                        var name = this.FUEl.name;
	                        for (var l = 0; l < aFiles.length; l++) {
	                            formData.append(name, aFiles[l]);
	                        }
	                        formData.append("_charset_", "UTF-8");
	                        var data = this.FUDataEl.name;
	                        if (this.getAdditionalData()) {
	                            var sData = this.getAdditionalData();
	                            formData.append(data, sData);
	                        } else {
	                            formData.append(data, "");
	                        }
	                        if (this.getParameters()) {
	                            var oParams = this.getParameters();
	                            for (var m = 0; m < oParams.length; m++) {
	                                var sName = oParams[m].getName();
	                                sValue = oParams[m].getValue();
	                                formData.append(sName, sValue);
	                            }
	                        }
	                        oXhrEntry.file = formData;
	                        this.sendFiles(this._aXhr, 0);
	                    } else {
	                        this.sendFiles(this._aXhr, 0);
	                    }
	                    this._bUploading = false;
	                    this._resetValueAfterUploadStart();
	                }
				}.bind(this));
            } else if (uploadForm) {
                uploadForm.submit();
                this._resetValueAfterUploadStart();
            }
        } catch (oException) {
            jQuery.sap.log.error("File upload failed:\n" + oException.message);
        }
    };

	CustomFileUploader.prototype.scaleImagesFiles = function(files) {
		var deferred = $.Deferred();

		var promises = [];

		for (var i = files.length - 1; i >= 0; i--) {
			promises.push(this.scaleImageFile(files[i]));
		}

		$.when.apply($, promises).done(function() {
			var scaledFiles = [];
			for (var i = arguments.length - 1; i >= 0; i--) {
				scaledFiles.push(arguments[i]);
			}
			deferred.resolve(scaledFiles);
		});

		return deferred.promise();
	};

	CustomFileUploader.prototype.scaleImageFile = function(file) {
		var deferred = $.Deferred();

		if (file.type.match('image/.*')) {
			this.drawImageToCanvas(file).done(function(canvas) {
				var fileName = file.name;
				var fileType = file.type;
				if(canvas.toBlob){
					// Chrome / Firefox
					canvas.toBlob(function(blob) {
						blob.name = fileName;
						deferred.resolve(blob);
					}, fileType);
				}else if(canvas.msToBlob){
					// IE 
					var blob = canvas.msToBlob();
					blob.name = fileName;
					deferred.resolve(blob);
				}else{
					// return original file
					deferred.resolve(file);
				}
			}).fail(function(rejectedFile) {
				deferred.resolve(rejectedFile);
			});
		} else {
			deferred.resolve(file);
		}

		return deferred.promise();
	};

	CustomFileUploader.prototype.drawImageToCanvas = function(file) {
		var deferred = $.Deferred();

		var maxHeight = this.getMaxImageHeight();
		var maxWidth = this.getMaxImageWidth();
		var image = new Image();
		image.onload = function() {
			var ratio = 0;
			var width = image.width;
			var height = image.height;

			if (maxWidth && width > maxWidth) {
				ratio = maxWidth / width;
				image.width = maxWidth;
				image.height = height * ratio;
				height = height * ratio;
				width = width * ratio;
			}

			if (maxHeight && height > maxHeight) {
				ratio = maxHeight / height;
				image.height = maxHeight;
				image.width = width * ratio;
				width = width * ratio;
				height = height * ratio;
			}

			var canvas = document.createElement("canvas");
			canvas.ctx = canvas.getContext("2d");
			// canvas.ctx.drawImage(image, 0, 0, image.width, image.height);
			// var ctx = canvas.getContext("2d");
			canvas.ctx.clearRect(0, 0, canvas.width, canvas.height);
			canvas.width = image.width;
			canvas.height = image.height;
			canvas.ctx.drawImage(image, 0, 0, image.width, image.height);

			deferred.resolve(canvas);
		}.bind(this);

		image.onerror = function() {
			deferred.reject(file);
		};

		image.src = URL.createObjectURL(file);

		return deferred.promise();
	};

	//Standard renderer method is not overridden
	CustomFileUploader.renderer = {

	};

	return CustomFileUploader;
});
/*eslint-enable */