/*eslint-disable */
sap.ui.define([
	'sap/m/UploadCollection',
	'com/upm/rcp/rcpqualityapp/control/CustomFileUploader'
], function(UploadCollection) {
	'use strict';

	var CustomUploadCollection = UploadCollection.extend('com.upm.rcp.rcpqualityapp.control.CustomUploadCollection', {
		metadata: {
			properties: {
				'maxImageHeight': {
					type: 'int',
					defaultValue: null
				},
				'maxImageWidth': {
					type: 'int',
					defaultValue: null
				}
			}
		}
	});

	CustomUploadCollection.init = function() {
		UploadCollection.prototype.init.call(this);
	};

	CustomUploadCollection.prototype._getFileUploader = function() {
		var that = this, bUploadOnChange = this.getInstantUpload();
		if (!bUploadOnChange || !this._oFileUploader) { // In case of instantUpload = false always create a new FU instance. In case of instantUpload = true only create a new FU instance if no FU instance exists yet
			var bSendXHR = (sap.ui.Device.browser.msie && sap.ui.Device.browser.version <= 9) ? false : true,
				sTooltip = this.getInstantUpload() ? this._oRb.getText("UPLOADCOLLECTION_UPLOAD") : this._oRb.getText("UPLOADCOLLECTION_ADD");
			this._iFUCounter = this._iFUCounter + 1; // counter for FileUploader instances
			this._oFileUploader = new com.upm.rcp.rcpqualityapp.control.CustomFileUploader(this.getId() + "-" + this._iFUCounter + "-uploader",{
				buttonOnly : true,
				buttonText: sTooltip,
				tooltip: sTooltip,
				iconOnly : true,
				enabled : this.getUploadEnabled(),
				fileType : this.getFileType(),
				icon : "sap-icon://add",
				iconFirst : false,
				style : "Transparent",
				maximumFilenameLength : this.getMaximumFilenameLength(),
				maximumFileSize : this.getMaximumFileSize(),
				mimeType : this.getMimeType(),
				multiple : this.getMultiple(),
				name : "uploadCollection",
				uploadOnChange : bUploadOnChange,
				sameFilenameAllowed : true,
				uploadUrl : this.getUploadUrl(),
				useMultipart : false,
				sendXHR : bSendXHR, // false for IE8, IE9
				visible: !this.getUploadButtonInvisible(),
				change : function(oEvent) {
					that._onChange(oEvent);
				},
				filenameLengthExceed : function(oEvent) {
					that._onFilenameLengthExceed(oEvent);
				},
				fileSizeExceed : function(oEvent) {
					that._onFileSizeExceed(oEvent);
				},
				typeMissmatch : function(oEvent) {
					that._onTypeMissmatch(oEvent);
				},
				uploadAborted : function(oEvent) { // only supported with property sendXHR set to true
					that._onUploadTerminated(oEvent);
				},
				uploadComplete : function(oEvent) {
					that._onUploadComplete(oEvent);
				},
				uploadProgress : function(oEvent) { // only supported with property sendXHR set to true
					if (that.getInstantUpload()) {
						that._onUploadProgress(oEvent);
					}
				},
				uploadStart : function(oEvent) {
					that._onUploadStart(oEvent);
				}
			});
		}
		this._oFileUploader.setMaxImageHeight(this.getMaxImageHeight());
		this._oFileUploader.setMaxImageWidth(this.getMaxImageWidth());

		return this._oFileUploader;
	};

	//Standard renderer method is not overridden
	CustomUploadCollection.renderer = {

	};

	return CustomUploadCollection;
});
/*eslint-enable */