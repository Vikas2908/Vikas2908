/*!
 * ${copyright}
 */
sap.ui.define(["jquery.sap.global"],function(r){"use strict";var e={};e.render=function(r,e){r.write("<div");r.writeControlData(e);r.addClass("sapMUC");r.writeClasses();r.write(">");r.renderControl(e._oList);r.write("</div>")};return e},true);