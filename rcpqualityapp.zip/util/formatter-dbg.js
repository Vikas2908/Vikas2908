sap.ui.define([
	'sap/ui/core/format/NumberFormat',
	'sap/ui/core/format/DateFormat'
], function(NumberFormat, DateFormat) {
	return {

		formatInputValue: function() {
			var values = [];
			if (arguments && arguments.length > 0) {
				values = $.map(arguments, function(value) {
					if (value) {
						return value;
					}
				});
			}
			return values ? values.join(' - ') : '';
		},

		checkboxValueFormatter: function(value) {
			return value === 'X' ? true : false;
		},

		oDataErrorToErrorString: function(oDataErrEvt) {
			var errorString = '';
			if (oDataErrEvt) {
				// HTTP request failed
				errorString = oDataErrEvt.message || errorString;
				if (oDataErrEvt.response && oDataErrEvt.response.body) {
					// get actual error message if available
					var errorBody = JSON.parse(oDataErrEvt.response.body);
					if (errorBody && errorBody.error && errorBody.error.message) {
						errorString = errorBody.error.message.value || errorString;
					}
				}
				return errorString;
			}
		},

		formatDate: function(date) {
			var formattedDate = null;
			var dateFormat = 'dd.MM.yyyy';
			if (date) {
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: dateFormat
				});
				formattedDate = oDateFormat.format(date);
				return formattedDate;
			}
		},

		formatTime: function(inputTime) {
			var outputTime = '';
			if (inputTime) {
				var timeFormat = DateFormat.getTimeInstance({
					pattern: 'HH:mm'
				});
				if (inputTime) {
					// timezoneOffset is in hours convert to milliseconds
					var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
					// format time to strings offsetting to GMT
					outputTime = ' ' + timeFormat.format(new Date(inputTime.ms + TZOffsetMs));
				}
			}
			return outputTime;
		},

		formateDateAndTime: function(inputDate, inputTime) {
			var outputDate = '';
			var outputTime = '';
			if (inputDate) {
				var outputDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: 'dd.MM.yyyy'
				});
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: 'kk:mm:ss'
				});
				outputDate = outputDateFormat.format(inputDate);
				if (inputTime) {
					// timezoneOffset is in hours convert to milliseconds
					var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
					// format time to strings offsetting to GMT
					outputTime = ' ' + timeFormat.format(new Date(inputTime.ms + TZOffsetMs));
				}
			}
			return outputDate + outputTime;
		},
		
		formateDateAndTimeForAttachment: function(inputDate) {
			var outputDate = '';
			if (inputDate) {
				var outputDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: 'ddMMyyyy_HHmmss'
				});
				outputDate = outputDateFormat.format(inputDate);
			}
			return outputDate;
		},

		createJavaScriptDateTimeObject: function(date, time) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: 'MM/dd/yyyy'
			});
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: 'HH:mm:ss'
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

			var dateStr = dateFormat.format(new Date(date.getTime() + TZOffsetMs));
			var timeStr = timeFormat.format(new Date(time.ms + TZOffsetMs));

			return new Date(dateStr + ' ' + timeStr);
		},

		selectedStateFormatter: function(itemKey, idOfItem, selectedItems) {
			selectedItems = selectedItems || [];
			return !!(selectedItems.filter(function(itemObject) {
				return itemObject[itemKey] === idOfItem;
			}).length);
		},

		trimLeadingZeros: function(string) {
			if (string) {
				var replacedString = string.replace(/^0+(?!\.|$)/, '');
				return replacedString;
			} else {
				return string;
			}
		},

		inputValueTextFormatter: function(value, description) {
			if (value || description) {
				if (value && description) {
					return value + ' - ' + description;
				} else if (value) {
					return value;
				}else if(description) {
					return description;
				}
			} else {
				// Empty item text should be empty
				return '';
			}
		},
		
		toPercent: function (Input20 , totalGr) {
			if(totalGr){
				if (Input20 && totalGr !== '0' && totalGr !== 0) {
					 var c = parseFloat(Input20.replace(',' , '.'));
	                 var num = ( c / totalGr) * 100;
	                 var nxtNum = num.toFixed(2);
	                 //var commaNum = nxtNum.toString();
	                 return nxtNum.replace('.' , ',');
	             }
			  }
		},
		
		NumberCommaFormatter: function(value){
			if (value) {
			 var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
			         groupingSeparator: '.',
			         decimalSeparator: ',',
			         groupingEnabled: true,
			         maxFractionDigits : 0,
			         minFractionDigits: 0
			  });
			 return oNumberFormat.parse(value).toString();
			}
	      },
	      
	      NumberDecimalFormatter: function(value){
			if (value) {
				var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
			         groupingSeparator: ',',
			         decimalSeparator: '.',
			         groupingEnabled: true,
			         maxFractionDigits : 0,
			         minFractionDigits: 0
				  });
				 return oNumberFormat.parse(value).toFixed(2).toString();
			}
	     }
	};
});