// SorterUtil
sap.ui.define([], function() {
	'use strict';

	return {
		descMemory: {},
		/**
		 * Example:
		 *
		 *	this.sorterUtil.sort(this.getElementById('tableId').getBinding('items'), [{
		 *		propertyName: sortProperyName,
		 *		desc: false
		 *	}], groupPropertyName);
		 */
		sort: function(binding, sorters, groupBy) {
			// create group function if group given
			var groupFn = null;
			if (groupBy) {
				groupFn = function(oContext) {
					return oContext.getObject() ? oContext.getObject()[groupBy] : '';
				};
			}

			// Sort
			var oSorter = new sap.ui.model.Sorter('', null, groupFn);
			oSorter.fnCompare = function(a, b) {
				if (groupBy && (a[groupBy] < b[groupBy])) {
					return -1;
				} else if (groupBy && (a[groupBy] > b[groupBy])) {
					return 1;
				} else if (!sorters) {
					return 0;
				} else {
					var res = 0;
					$.each(sorters, function(index, sorter) {
						if (a[sorter.propertyName] < b[sorter.propertyName]) {
							res = sorter.desc ? 1 : -1;
							return false;
						} else if (a[sorter.propertyName] > b[sorter.propertyName]) {
							res = sorter.desc ? -1 : 1;
							return false;
						}
					});
					return res;
				}
			};

			binding.sort(oSorter);
		},

		sortByTableBinding: function(field, binding) {
			if (!this.sortDescMemory) {
				this.sortDescMemory = {};
			}

			var bDesc = this.sortDescMemory[field] ? !this.sortDescMemory[field].desc : false;
			this.sortDescMemory[field] = {
				desc: bDesc
			};

			this.sort(binding, [{
				propertyName: field,
				desc: bDesc
			}]);
		}
	};
});