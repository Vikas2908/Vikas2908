// oDataUtil
sap.ui.define([],
	function() {
		'use strict';

		return {
			// Define services here
			services: {
				'ZRCP_QUALITY_INSPECTION_SRV': '/odata/SAP/ZRCP_QUALITY_INSPECTION_SRV;v=1'
			},

			getServiceUrl: function(serviceName) {
				var service = this.services[serviceName];
				if (!service) {
					throw new Error('Service: ' + service + ' not found');
				}
				return service;
			},

			handleResultsObjects: function(oData) {
				oData = oData['results'] ? oData['results'] : oData;
				return typeof oData === 'object' && oData !== null && !Array.isArray(oData) ?
					this.removeResultFromObject(oData) :
					oData;
			},

			removeResultFromObject: function(oData) {
				Object.keys(oData).map(function(key) {
					oData[key] = oData[key] !== null && typeof oData[key] === 'object' && oData[key] && oData[key]['results'] ?
						oData[key]['results'] :
						oData[key];
					if (Array.isArray(oData[key])) {
						oData[key] = oData[key].map(this.removeResultFromObject.bind(this));
					}
				}.bind(this));

				return oData;
			},

			/**
			 * Reads data from back end
			 * @param {string} sService - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object=} filters - filter parameters
			 * @param {object=} sorters - sorter parameters
			 * @param {string=} urlParameters - additional url parameters
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end or error event
			 */
			read: function(serviceName, pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
				oDataModel.read(pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					filters: oParameters && oParameters.filters ? oParameters.filters : null,
					sorters: oParameters && oParameters.sorters ? oParameters.sorters : null,
					urlParameters: oParameters && oParameters.urlParameters ? oParameters.urlParameters : null,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Removes data from back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end or error event
			 */
			remove: function(serviceName, pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
				oDataModel.remove(pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Posts data to back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToPost - data to be posted to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			create: function(serviceName, pathToService, dataToPost, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
				oDataModel.create(pathToService, dataToPost, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Updates data to back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToUpdate - data to be updated to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			update: function(serviceName, pathToService, dataToUpdate, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
				oDataModel.update(pathToService, dataToUpdate, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			}
		};
	});