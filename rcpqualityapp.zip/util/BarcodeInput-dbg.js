sap.ui.define([
	'sap/m/Input',
	'sap/m/Image',
	'sap/m/Button'
	//'sap/m/InputRenderer'
], function(Input, Image, Button) {
	'use strict';
	return Input.extend('com.upm.rcp.rcpqualityapp.util.BarcodeInput', {
		metadata: {
			properties: {
				selectOnFocus: {
					type: 'boolean',
					defaultValue: true
				}
			},
			aggregations: {
				_image: {
					type: 'sap.m.Button',
					multiple: false,
					visibility: 'hidden'
				},
				_button: {
					type: 'sap.m.Button',
					multiple: false,
					visibility: 'hidden'
				}
			},
			events: {
				scanSuccess: {
					parameters: {
						value: {
							type: 'String'
						}
					}
				},
				scanError: {
					parameters: {
						value: {
							type: 'String'
						}
					}
				}
			}
		},
		init: function() {
			document.addEventListener('deviceready', this._onDeviceReady.bind(this), false);
			var scannerAvailable = this._isScannedAvailable();
			this.setAggregation('_image', new Button({
				icon: 'sap-icon://bar-code',
				type: 'Transparent',
				press: this._onImagePress.bind(this),
				visible: !scannerAvailable
			}).addStyleClass('barcodeInputInnerButton'));
			this.setAggregation('_button', new Button({
				icon: 'sap-icon://camera',
				type: 'Transparent',
				press: this._onButtonPress.bind(this),
				visible: scannerAvailable
			}).addStyleClass('barcodeInputInnerButton'));
		},
		onAfterRendering: function() {
			if (Input.prototype.onAfterRendering) {
				Input.prototype.onAfterRendering.apply(this, arguments);
			}
			//this.addStyleClass('customBarcodeInput');
		},

		onfocusin: function(oEvent) {
			var that = this;
			if (oEvent && this.getSelectOnFocus()) {
				jQuery.sap.log.info('on focus Barcodeinput');
				window.setTimeout(function() {
					var $input = that.$().find('input')[0];
					if ($input) {
						$input.select();
					}
				}, 0);
			}
		},

		renderer: {
			writeInnerContent: function(oRM, oControl) {
				oRM.renderControl(oControl.getAggregation('_image'));
				oRM.renderControl(oControl.getAggregation('_button'));
			}
		},

		_isScannedAvailable: function() {
			var scannerAvailable = false;
			if (window.cordova && window.cordova.plugins.barcodeScanner) {
				scannerAvailable = true;
			}
			return scannerAvailable;
		},

		_onDeviceReady: function() {
			var scannerAvailable = this._isScannedAvailable();
			if (this.getAggregation('_image')) {
				this.getAggregation('_image').setVisible(!scannerAvailable);
			}
			if (this.getAggregation('_button')) {
				this.getAggregation('_button').setVisible(scannerAvailable);
			}
		},

		_onImagePress: function() {
			// focus back to input
			jQuery.sap.delayedCall(10, this, this.focus);
		},

		_onButtonPress: function() {
			if (window.cordova && window.cordova.plugins.barcodeScanner) {
				window.cordova.plugins.barcodeScanner.scan(this._scanSuccessCallback.bind(this), this._scanErrorCallback.bind(this));
			} else {
				jQuery.sap.log.warning('no cordova barcode scanner available');
			}
		},

		_scanSuccessCallback: function(result) {
			if (result) {
				var scannedValue = result;
				if (scannedValue) {
					if (scannedValue.text || scannedValue.text === '') {
						scannedValue = scannedValue.text;
					} else {
						scannedValue = JSON.stringify(scannedValue);
					}
				}
				this.fireEvent('scanSuccess', {
					value: scannedValue
				});
			}
		},

		_scanErrorCallback: function(error) {
			var errorMessage = 'error';
			if (error) {
				errorMessage = JSON.stringify(error);
			}
			this.fireEvent('scanError', {
				value: errorMessage
			});
		}

	});
});