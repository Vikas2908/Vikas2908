#!/usr/bin/env node
var fs = require('fs');
var path = require('path');
var compile = require('es6-template-strings/compile');
var resolveToString = require('es6-template-strings/resolve-to-string');

var FILES = {
    SRC: "config.tpl.xml",
    DEST: "config.xml",
    SERVICESCR: "service.tpl.json",
    SERVICEDEST: "service.json",
    VERSIONSRC: "version.tpl.json",
    VERSIONDEST: "version.json"
};

var env = process.env.NODE_ENV || 'dev';
var envFile = env + '.json';

var srcFileFull = path.join('./', FILES.SRC);
var destFileFull = path.join('./', FILES.DEST);
var serviceSrcFileFull = path.join('./www/webapp/dev/', FILES.SERVICESCR);
var serviceDestFileFull = path.join('./www/webapp/dev/', FILES.SERVICEDEST);
var versionSrcFileFull = path.join('./hooks/template/', FILES.VERSIONSRC);
var versionDestFileFull = path.join('./www/webapp/dev/', FILES.VERSIONDEST);
var configFileFull = path.join('./hooks/properties/', envFile);

var templateData = fs.readFileSync(srcFileFull, 'utf8');
var templateDataService = fs.readFileSync(serviceSrcFileFull, 'utf8');
var templateDataVersion = fs.readFileSync(versionSrcFileFull, 'utf8');

var configData = fs.readFileSync(configFileFull, 'utf8');
var config = JSON.parse(configData);

var compiled = compile(templateData);
var compiledService = compile(templateDataService);
var compiledVersion = compile(templateDataVersion);
var content = resolveToString(compiled, config);
var contentService = resolveToString(compiledService, config);
var contentVersion = resolveToString(compiledVersion, config);

fs.writeFileSync(destFileFull, content);
fs.writeFileSync(serviceDestFileFull, contentService);
fs.writeFileSync(versionDestFileFull, contentVersion);