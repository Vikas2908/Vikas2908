sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'com/upm/maint/dev/devapp'
], function(JSONModel, devapp) {
	'use strict';

	return JSONModel.extend('com.upm.maint.model.configurationModel', {

		constructor: function() {
			JSONModel.call(this, this.getConfigurationModelContentPulpMaint());

			return this;
		},

		getConfigurationModelContentPulpMaint: function() {
			var plantValueServices = this.getPlantDependedServicesContent();
			var userServices = this.getUserPreferenceServicesContent();
			var basePath = devapp.basePath;
			return {
				Api: {
					OfflinePath: basePath + '/ZGW_PM_PULPMAINT_OFFLINE_SRV/',
					OnlinePath: basePath + '/ZGW_PM_PULPMAINT_ONLINE_SRV/',
					HybridOfflinePath: basePath + devapp.hybridOfflinePath,
					HybridOnlinePath: basePath + '/ZGW_PM_PULPMAINT_ONLINE_SRV/',
					PlantDependedServices: plantValueServices,
					UserServices: userServices,
					OrderURLParameters: 'Operations,Attachments,Components,Assignments,Objects,Measurements',
					OfflinePlantServices: ['UserParamSet', 'PlantsSet', 'FuncLocSet', 'EquipmentSet', 'BomItemsSetMATNR', 'BomItemsSetEQUI', 'BomItemsSetFLOC', 'MaterialsSet', 'PlanningGroupSet', 'WorkCenterSet', 'NotifTypeSet', 'WorkOrderTypeSet', 'PrioritySet', 'CatalogCodeGroupSet', 'CatalogCodeSet', 'StatusesSet', 'PMActTypeSet', 'SystemConditionSet', 'CatalogProfilesSet', 'PersonsSet', 'ScheduleidSet', 'RouteSet', 'DateRangeValueSet', 'VariantSet', 'FuncLocLabelSystemSet'],
					OfflineListServices: ['UserParamSet', 'WorkOrderSet', 'NotifSet', 'AuthorizationSet', 'RouteWorkSet', 'VariantSet']
				},
				DomainObjects: {
					UseAlternativeLabeling: true
				},
				Applications: {
					WareHouseEnabled: false,
					ApprovalEnabled: false,
					CreateOrderEnabled: true,
					RouteEnabled: true,
					EquipmentExchangeEnabled: true
				},
				UserParameters: {
					VariantsEnabled: true,
					ShowDateRangeSelectionUserParameter: true,
					DisplayLabelCategorySelection: true
				},
				Notification: {
					SafetyRelatedWorkEnabled: true,
					ShowTaskField: false,
					ShowDamageField: false,
					ShowObjectPartField: true,
					AllowDirectWorkOrderCreate: true,
					AllowCompleteNotification: true,
					AllowCancelNotification: true,
					ShowMillSafetyDocuments: false,
					StatusLightKeyForCSS: 'statusLight',
					StatusLightDefaultPriority: '4',
					DamageCodeCatalogId: 'C',
					CauseCodeCatalogId: '5',
					ObjectPartCodeCatalogId: 'B',
					TaskCodeCatalogId: '2'
				},
				Order: {
					EnableScheduleId: false,
					EnableRevision: true,
					ShowOperationsHoursAsDuration: true,
					ShowOperationConfirmedHours: false,
					EnableGoodsIssue: false,
					EnableEquipmentInstallingThroughComponent: false,
					EnableEditOfFirstOperationWorkCenter: true,
					EnableOrderRelease: false,
					EnableOrderPlanningCompletion: true,
					EnableCompleteWork: false,
					EnableCompleteOperation: true,
					ShowActualWork: false,
					ShowStockLocation: false,
					EnableTrexSearch: true,
					EnableBatchSelection: false
				},
				FunctionalLocation: {
					ShowStockAndBatch: true,
					ShowStockAndLocation: false
				}
			};
		},

		isWareHouseEnabled: function() {
			return this.getProperty('/Applications/WareHouseEnabled');
		},

		isApprovalEnabled: function() {
			return this.getProperty('/Applications/ApprovalEnabled');
		},

		isRouteEnabled: function() {
			return this.getProperty('/Applications/RouteEnabled');
		},

		isVariantEnabled: function() {
			return this.getProperty('/Notification/VariantsEnabled');
		},

		shouldShowTaskField: function() {
			return this.getProperty('/Notification/ShowTaskField');
		},

		shouldObjectPartField: function() {
			return this.getProperty('/Notification/ShowObjectPartField');
		},

		getDamageCodeCatalogId: function() {
			return this.getProperty('/Notification/DamageCodeCatalogId');
		},

		getCauseCodeCatalogId: function() {
			return this.getProperty('/Notification/CauseCodeCatalogId');
		},

		getObjectPartCodeCatalogId: function() {
			return this.getProperty('/Notification/ObjectPartCodeCatalogId');
		},

		getTaskCodeCatalogId: function() {
			return this.getProperty('/Notification/TaskCodeCatalogId');
		},

		getShowActualWork: function() {
			return this.getProperty('/Order/ShowActualWork');
		},

		getOnlinePath: function() {
			return this.getProperty('/Api/OnlinePath');
		},

		getOfflinePath: function() {
			return this.getProperty('/Api/OfflinePath');
		},

		getHybridOfflinePath: function() {
			return this.getProperty('/Api/HybridOfflinePath');
		},

		getHybridOnlinePath: function() {
			return this.getProperty('/Api/HybridOnlinePath');
		},

		getPlantDependedServices: function() {
			return this.getProperty('/Api/PlantDependedServices');
		},

		getUserPreferenceServices: function() {
			return this.getProperty('/Api/UserServices');
		},

		getOrderURLParameters: function() {
			return this.getProperty('/Api/OrderURLParameters');
		},

		getOfflinePlantServices: function() {
			return this.getProperty('/Api/OfflinePlantServices');
		},

		getOfflineListServices: function() {
			return this.getProperty('/Api/OfflineListServices');
		},

		getUseAlternativeLabeling: function() {
			return this.getProperty('/DomainObjects/UseAlternativeLabeling');
		},

		getPlantDependedServicesContent: function() {
			var personsReadParameters = {
				urlParameters: {
					'$expand': 'WorkCenters'
				}
			};
			return [{
				service: 'UserParamSet'
			}, {
				service: 'PlantsSet'
			}, {
				service: 'PlanningGroupSet'
			}, {
				service: 'WorkCenterSet'
			}, {
				service: 'NotifTypeSet'
			}, {
				service: 'WorkOrderTypeSet'
			}, {
				service: 'PrioritySet'
			}, {
				service: 'CatalogProfilesSet'
			}, {
				service: 'CatalogCodeGroupSet'
			}, {
				service: 'CatalogCodeSet'
			}, {
				service: 'StatusesSet'
			}, {
				service: 'PMActTypeSet'
			}, {
				service: 'SystemConditionSet'
			}, {
				service: 'PersonsSet',
				parameters: personsReadParameters
			}, {
				service: 'RouteSet'
			}, {
				service: 'ScheduleidSet'
			}, {
				service: 'DateRangeValueSet'
			}, {
				service: 'AuthorizationSet'
			}, {
				service: 'VariantSet'
			}, {
				service: 'FuncLocLabelSystemSet'
			}];
		},

		getUserPreferenceServicesContent: function() {
			return [{
				service: 'UserParamSet'
			}, {
				service: 'AuthorizationSet'
			}];
		},

		getEnableTrexSearch: function() {
			return this.getProperty('/EnableTrexSearch');
		},

		getEnableBatchSelection: function() {
			return this.getProperty('/EnableBatchSelection');
		}
	});
});