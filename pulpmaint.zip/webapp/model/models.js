sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device',
	'com/upm/maint/dev/devapp'
], function(JSONModel, Device, devapp) {
	'use strict';

	var timeRecordModel;
	var configurationModel;

	return {

		setTimeRecordModel: function(timeRecordUtility) {
			timeRecordModel = timeRecordUtility;
		},

		getTimeRecordModel: function() {
			return timeRecordModel;
		},

		setConfigurationModelModel: function(model) {
			configurationModel = model;
		},

		getConfigurationModelModel: function() {
			return configurationModel;
		},

		createOfflineODataModel: function() {
			var oModel, appContext, sServiceUrl;
			var param = {
				'json': true,
				loadMetadataAsync: false,
				useBatch: !this.isHybridAppUser()
			};

			if (this.isHybridAppUser() && !window.sap_webide_FacadePreview && !window.sap_webide_companion) {
				if (devapp.devLogon) {
					appContext = devapp.devLogon.appContext;
				}
				sServiceUrl = appContext.applicationEndpointURL + this.getConfigurationModelModel().getHybridOfflinePath();
				var oHeader = {
					'X-SMP-APPCID': appContext.applicationConnectionId
				};
				if (appContext.registrationContext.user) {
					oHeader.Authorization = 'Basic ' + btoa(appContext.registrationContext.user + ':' + appContext.registrationContext.password);
				}
				param.headers = oHeader;
			} else {
				sServiceUrl = this.getConfigurationModelModel().getOfflinePath();
			}
			oModel = this.isHybridAppUser() ?
				new sap.ui.model.odata.ODataModel(sServiceUrl, param) :
				new sap.ui.model.odata.v2.ODataModel(sServiceUrl, param);
			oModel.setDefaultBindingMode('TwoWay');

			return oModel;
		},

		createOnlineODataModel: function(dontAttachMetadataFail, modelName) {
			var oModel, appContext, sServiceUrl;
			var param = {
				'json': true,
				loadMetadataAsync: false,
				useBatch: false
			};

			var that = this;

			if (!this.isHybridAppUser()) {
				param.defaultUpdateMethod = 'PUT';
			}

			if (this.isHybridAppUser() && !window.sap_webide_FacadePreview && !window.sap_webide_companion) {
				if (devapp.devLogon) {
					appContext = devapp.devLogon.appContext;
				}
				if (modelName === 'ZWM_COMMON_SRV') {
					sServiceUrl = (appContext.applicationEndpointURL + '.wm' + '/');
				} else {
					sServiceUrl = (appContext.applicationEndpointURL + this.getConfigurationModelModel().getHybridOnlinePath());
				}
				var oHeader = {
					'X-SMP-APPCID': appContext.applicationConnectionId
				};
				if (appContext.registrationContext.user) {
					oHeader.Authorization = 'Basic ' + btoa(appContext.registrationContext.user + ':' + appContext.registrationContext.password);
				}
				param.headers = oHeader;
			} else if (modelName === 'ZWM_COMMON_SRV') {
				sServiceUrl = '/odata/SAP/ZWM_COMMON_SRV/';
			} else {
				sServiceUrl = this.getConfigurationModelModel().getOnlinePath();
			}
			oModel = this.isHybridAppUser() ?
				new sap.ui.model.odata.ODataModel(sServiceUrl, param) :
				new sap.ui.model.odata.v2.ODataModel(sServiceUrl, param);
			oModel.setDefaultBindingMode('TwoWay');
			if (devapp.isOnline && !dontAttachMetadataFail) {
				oModel.attachEventOnce('metadataFailed', function(errorEvent) {
					var statusCode = errorEvent && errorEvent.getParameter('statusCode');
					if (statusCode !== 403) {
						sap.Logon.performSAMLAuth(
							function() {
								that.createOnlineODataModel();
							}
						);
					}
				});
			}

			return oModel;
		},

		createGeneralODataModel: function() {
			var param = {
				'json': true,
				loadMetadataAsync: false,
				useBatch: false
			};
			return new sap.ui.model.odata.v2.ODataModel('/odata/SAP/ZGENERAL_SRV/', param);
		},

		createDeviceModel: function(additionalProperties) {
			var deviceModel = new JSONModel(
				$.extend(true, {
					isTouch: Device.support.touch,
					isNoTouch: !Device.support.touch,
					isPhone: Device.system.phone,
					isNoPhone: !Device.system.phone,
					isTablet: Device.system.tablet,
					isNotTablet: !Device.system.tablet,
					isLandscape: Device.orientation.landscape,
					isOffline: this.isHybridAppUser() ? !devapp.isOnline : false,
					isCordova: !!(this.isHybridAppUser()),
					errorNum: 0
				}, additionalProperties)
			);
			deviceModel.setDefaultBindingMode('OneWay');
			return deviceModel;
		},

		isHybridAppUser: function() {
			return !!(devapp && devapp.smpInfo && devapp.smpInfo.appID);
		},

		createGlobalPropertiesModel: function(additionalProperties) {
			var userInfo;
			try {
				userInfo = JSON.parse(window.localStorage.getItem('UserInfo'));
			} catch (error) {
				jQuery.sap.log.info(error);
				userInfo = {};
			}
			var globalProperties = new JSONModel(
				$.extend(true, {
					UserId: '',
					PlantLevelFunctionalLocation: '',
					NotificationsNumber: 0,
					EditNotification: true,
					EditOrder: true,
					EditRoute: true,
					HierarchySelectionEvent: '',
					HierarchyGetEquipments: true,
					HierarchyGetMaterials: true,
					HasMaintenanceRole: window.localStorage && window.localStorage.getItem('HasMaintenanceRole') === 'true',
					ShowEquipmentExchange: true,
					IsResumingFromPlugin: false,
					isDownLoadingHelperValues: false,
					isDownloadingFunctionalLocations: false,
					IsPaused: false,
					NotificationsCreatedDuringRoute: [],
					RouteWorkCoverOrders: [],
					IsOdrRoute: false,
					RouteTimeRecord: {},
					IsRouteBusy: false,
					IsTimeRecordDialogBusy: false,
					IsRouteSummaryBusy: false,
					IsRouteListBusy: false,
					IsGoodsIssueDialogBusy: false,
					PlantLevelShowTimeConfirmation: true,
					PlantLevelShowStartAndStopButton: true,
					PlantLevelScanOptions: [],
					IsDownloadingUserSpecificValues: false,
					IsCancellingGoodsIssue: false,
					IsSearchingForMaterials: false,
					IsValidatingPrinter: false,
					UserInfo: userInfo,
					IsMultiUserDevice: window.localStorage && window.localStorage.getItem('isMultiUserDevice') === 'true',
					IsGettingHierarchy: false,
					PersonNumber: '',
					LatestRouteOrderId: ''
				}, additionalProperties)
			);
			this.globalProperties = globalProperties;
			return globalProperties;
		},

		authTokenHasMaintenanceGroup: function(authObject) {
			var maintenanceRoleRegExp = /(Maint Maintenance)/;
			return authObject &&
				authObject.groups &&
				authObject.groups.some(function(group) {
					return maintenanceRoleRegExp.test(group);
				});
		},

		createSelectionValuesModel: function() {
			var selectionValues = new JSONModel();
			selectionValues.setSizeLimit(1000);
			return selectionValues;
		},

		createUserPreferencesModel: function(additionalProperties) {
			var userPreferencesModel = new JSONModel(
				$.extend(true, {}, additionalProperties)
			);
			this.userPreferences = userPreferencesModel;
			return userPreferencesModel;
		},

		createObjectInfoModel: function(additionalProperties) {
			var objectInfoModel = new JSONModel(
				$.extend(true, {}, additionalProperties)
			);
			return objectInfoModel;
		},

		createNotificationsModel: function() {
			return new JSONModel({
				Notifications: []
			});
		},

		createNewNotificationModel: function(additionalProperties) {
			return new JSONModel(this.getNotificationDefaults(additionalProperties));
		},

		getNotificationDefaults: function(additionalProperties) {
			var userParameters = this.userPreferences && this.userPreferences.getData() || {};

			var newNotificationModel = $.extend(true, {
				NotifNo: this.getTemporaryId(),
				NotifType: userParameters.NotificationType || '',
				WorkcenterPlant: userParameters.Plant || '',
				Planplant: userParameters.Plant || '',
				FunctLocInternalId: userParameters.FunctLocInternalId || '',
				Desstdate: new Date(),
				Equipment: '',
				EquipmentDescr: '',
				Attachments: []
			}, additionalProperties);
			return newNotificationModel;
		},

		createOrdersModel: function() {
			return new JSONModel({
				Orders: []
			});
		},

		createMyWorksModel: function() {
			return new JSONModel({
				MyWorks: []
			});
		},

		createNewOrderModel: function(additionalProperties) {
			return new JSONModel(this.getOrderDefaults(additionalProperties));
		},

		getOrderDefaults: function(additionalProperties) {
			var userParameters = this.userPreferences && this.userPreferences.getData() || {};

			var newOrderModel = $.extend(true, {
				Orderid: this.getTemporaryId(),
				OrderType: userParameters.WorkOrderType || '',
				FunctLocInternalId: userParameters.FunctLocInternalId || '',
				WorkcenterPlant: userParameters.Plant || '',
				Planplant: userParameters.Plant || '',
				SchedType: '5',
				Operations: [],
				Components: [],
				Attachments: [],
				Assignments: [],
				Measurements: []
			}, additionalProperties);
			return newOrderModel;
		},

		createEditRouteModel: function(additionalProperties) {
			var editRouteModel = new JSONModel(
				$.extend(true, {}, additionalProperties)
			);
			return editRouteModel;
		},

		createRoutesModel: function() {
			return new JSONModel({
				Routes: []
			});
		},

		createApprovalsModel: function() {
			return new JSONModel({
				Approvals: []
			});
		},

		createNewApprovalModel: function() {
			return new JSONModel();
		},

		createNewGoodsIssueMultiModel: function() {
			return new JSONModel({
				PlantId: '',
				GoodsIssueNumber: '',
				UnloadingPoint: '',
				Workorder: '',
				Reservation: '',
				Items: []
			});
		},

		createNewOperationModel: function(additionalProperties) {
			return new JSONModel(this.getOperationDefaults(additionalProperties));
		},

		getOperationDefaults: function(additionalProperties) {
			var newOperationModel = $.extend(true, {
				Activity: '',
				Description: '',
				LongText: '',
				EarlSchedStartDate: null,
				EarlSchedStartTime: null,
				Systcond: '',
				ControlKey: 'PM01',
				Workcenter: '',
				WorkcenterDescr: '',
				WorkcenterPlant: '',
				Assignments: []
			}, additionalProperties);
			return newOperationModel;
		},

		createNewMaterialModel: function(additionalProperties) {
			return new JSONModel(this.getMaterialDefaults(additionalProperties));
		},

		getMaterialDefaults: function(additionalProperties) {
			var newMaterialModel = $.extend(true, {
				ItemNumber: '',
				Activity: '',
				Material: '',
				RequirementQuantityUnit: '',
				UnloadPt: '',
				GrRcpt: this.globalProperties && this.globalProperties.getProperty('/UserId') || '',
				IsStockMaterial: 'X'
			}, additionalProperties);
			return newMaterialModel;
		},

		createNewEquipmentDismantlingModel: function(additionalProperties) {
			var newEquipmentDismantlingModel = new JSONModel(
				$.extend(true, {
					EqunrOld: '',
					EqunrOldDescr: '',
					EqunrNew: '',
					EqunrNewDescr: '',
					InstallDate: new Date()
				}, additionalProperties)
			);
			return newEquipmentDismantlingModel;
		},

		getTemporaryId: function() {
			return '%' + Math.random().toFixed(11).substring(2, 13);
		}
	};
});