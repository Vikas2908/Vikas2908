sap.ui.define([
	'sap/ui/core/format/NumberFormat',
	'sap/ui/core/format/DateFormat'
], function(NumberFormat, DateFormat) {
	var statusMap = {};

	return {

		setStatusMap: function(statuses) {
			statuses.forEach(function(status) {
				statusMap[status.StatusInt] = status.Status;
			});
		},

		formatInputValue: function() {
			var values = [];
			if (arguments && arguments.length > 0) {
				values = $.map(arguments, function(value) {
					if (value) {
						return value;
					}
				});
			}
			return values ? values.join(' - ') : '';
		},

		checkboxValueFormatter: function(value) {
			return value === 'X' ? true : false;
		},

		oDataErrorToErrorString: function(oDataErrEvt) {
			var errorString = '';
			if (oDataErrEvt) {
				try {
					errorString = JSON.parse(oDataErrEvt.response ? oDataErrEvt.response.body : oDataErrEvt.responseText).error.message.value;
				} catch (e) {
					errorString = oDataErrEvt.message || errorString;
				}

				return errorString;
			}
		},

		formatDate: function(date) {
			if (date) {
				// handle timezone
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: 'dd.MM.yyyy',
					UTC: true
				});
				return this.formatterUtil.formatDateToDateFormat(date, oDateFormat);
			}
		},

		formatRelativeDate: function(date) {
			if (date) {
				// handle timezone
				var oDateFormat = DateFormat.getDateInstance({
					relative: true,
					UTC: true
				});
				return this.formatterUtil.formatDateToDateFormat(date, oDateFormat);
			}
		},

		formatDateToDateFormat: function(date, dateFormat) {
			var formattedDate = null;
			try {
				formattedDate = dateFormat.format(date);
			} catch (e) {
				formattedDate = dateFormat.format(new Date(parseInt(date.match(/\d/g).join(''), 10)));
			} finally {
				return formattedDate;
			}
		},

		formatTime: function(inputTime) {
			var outputTime = '';
			if (inputTime) {
				var timeFormat = DateFormat.getTimeInstance({
					pattern: 'HH:mm'
				});
				if (inputTime) {
					// timezoneOffset is in hours convert to milliseconds
					var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
					// format time to strings offsetting to GMT
					outputTime = ' ' + timeFormat.format(new Date(inputTime.ms + TZOffsetMs));
				}
			}
			return outputTime;
		},

		formatOdataTime: function(time) {
			var outputTime = '';
			if (time) {
				var timeFormat = DateFormat.getTimeInstance({
					/* eslint-disable */
					pattern: "'''PT'HH'H'mm'M'ss'S'''",
					UTC: true
					/* eslint-enable */
				});
				if (time.ms || time.ms === 0) {
					outputTime = timeFormat.format(new Date(time.ms));
				} else {
					outputTime = time;
				}
			}
			return typeof outputTime === 'string' ? outputTime.replace(/\'/g, '') : outputTime;
		},

		formateDateAndTimeForAttachment: function(inputDate) {
			var outputDate = '';
			if (inputDate) {
				var outputDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: 'ddMMyyyy_HHmmss'
				});
				outputDate = outputDateFormat.format(inputDate);
			}
			return outputDate;
		},

		formatTechnicalObject: function(functionalLocation, functionalLocationDescription, equipment, equipmentDescription) {
			return equipment ?
				this.formatterUtil.formatInputValue(equipment, equipmentDescription) :
				this.formatterUtil.formatInputValue(functionalLocation, functionalLocationDescription) || '';
		},

		formatTechnicalObjectForList: function(functionalLocation, equipment) {
			return equipment ?
				equipment :
				functionalLocation || '';
		},

		selectedStateFormatter: function(itemKey, idOfItem, selectedItems) {
			selectedItems = selectedItems || [];
			return !!(selectedItems.filter(function(itemObject) {
				return itemObject[itemKey] === idOfItem;
			}).length);
		},

		objectListTypeFormatter: function(hasChildren, hasEquipment) {
			return (hasChildren || hasEquipment) ? 'Active' : 'Inactive';
		},

		navigationArrowVisibilityFormatter: function(hasChildren, hasEquipment, shouldGetEquipments, hasBomItems, hasSubItems, shouldGetMaterials) {
			return !!(hasChildren || (hasEquipment && shouldGetEquipments) || ((hasBomItems || hasSubItems) && shouldGetMaterials));
		},

		selectObjectButtonVisibilityFormatter: function(type, shouldGetMaterials, disableMaterialSelection, shouldGetEquipments, shouldGetFunctionalLocations) {
			var visibility = false;
			if (shouldGetMaterials && !disableMaterialSelection) {
				visibility = type === 'Material';
			} else if (shouldGetEquipments && type === 'Equipment') {
				visibility = true;
			} else if (shouldGetFunctionalLocations && !type) {
				visibility = true;
			}

			return visibility;
		},

		completeNotificationVisibilityFormatter: function(notificationNumber, hasMaintenanceRole, allowComplete, isCompleted) {
			return this.formatterUtil.hasSapId(notificationNumber) && hasMaintenanceRole && allowComplete && !isCompleted;
		},

		createOrderVisibilityFormatter: function(notificationNumber, hasMaintenanceRole, orderNumber) {
			return this.formatterUtil.hasSapId(notificationNumber) && hasMaintenanceRole && !orderNumber;
		},

		cancelNotificationButtonVisibility: function(notificationNumber, isCompleted) {
			return !!(this.formatterUtil.hasSapId(notificationNumber) && !isCompleted);
		},

		isReleasable: function(isReleased, orderType, isCompleted) {
			return !!(!isReleased && orderType === 'PM11' && !isCompleted);
		},

		releaseOrderButtonVisibility: function(enableOrderRelease, orderNumber, isReleased, isCompleted) {
			return enableOrderRelease && this.formatterUtil.hasSapId(orderNumber) && !isReleased && !isCompleted;
		},

		planningCompletedButtonVisibility: function(enablePlanningCompletion, orderNumber, isReleased, isCompleted, isPlanningCompleted) {
			return enablePlanningCompletion && this.formatterUtil.hasSapId(orderNumber) && !isReleased && !isCompleted && !isPlanningCompleted;
		},

		completeOrderButtonVisibility: function(orderNumber, isReleased, isCompleted) {
			return !!(this.formatterUtil.hasSapId(orderNumber) && isReleased && !isCompleted);
		},

		printVisibility: function(id, isOffline) {
			return !!(this.formatterUtil.hasSapId(id) && !isOffline);
		},

		millSafetyDocumentVisibility: function(showMillSafetyDocuments, id, isOffline) {
			return !!(showMillSafetyDocuments && this.formatterUtil.hasSapId(id) && !isOffline);
		},

		multiGoodsIssueButtonVisibility: function(isRafMaintUser, orderNumber, isReleased, isCompleted, materials) {
			var mat = false;
			if (materials.length > 0) {
				mat = true;
			}
			return !!(isRafMaintUser && this.formatterUtil.hasSapId(orderNumber) && isReleased && !isCompleted && mat);
		},
		enableMultiGoodsIssue: function(materials) {
			var rows = materials.length;
			var ret = false;
			if (rows > 0) {
				for (var x = 0; x < rows; rows++) {
					if (materials[rows].isSelected === 'true') {
						ret = true;
					}
				}
			}

			return ret;
		},

		hierarchyIconFormatter: function(type) {
			return {
				Equipment: 'sap-icon://machine',
				Material: 'sap-icon://product'
			} [type] || 'sap-icon://tree';
		},

		hierarchyListItemTypeFormatter: function(hasChildren, hasEquipment, hasBomItems, hasSubItems, type, shouldGetMaterials, disableMaterialSelection, shouldGetFunctionalLocations) {
			var listItemType = 'Inactive';
			var materialButtonDisabled = shouldGetMaterials && !disableMaterialSelection;
			if (type === 'Material' && !disableMaterialSelection) {
				listItemType = 'Active';
			} else if (hasChildren || hasEquipment || hasBomItems || hasSubItems) {
				listItemType = 'Active';
			} else if (!materialButtonDisabled && shouldGetFunctionalLocations && !type) {
				listItemType = 'Active';
			} else if (!materialButtonDisabled && type) {
				listItemType = 'Active';
			}

			return listItemType;
		},

		formatLength: function(list) {
			return (list || []).length;
		},

		hasMoreThanOneEntry: function(list) {
			return Array.isArray(list) && list.length > 1;
		},

		hasEntries: function(array) {
			return !!(Array.isArray(array) && array.length);
		},

		hasNoEntries: function(array) {
			return !(array && array.length);
		},

		shouldShowEditButton: function(isEditMode, isCompleted) {
			return !(isEditMode) && !isCompleted;
		},

		shouldShowActionsButton: function(notificationNumber, isNotSync) {
			return !!(notificationNumber && notificationNumber.charAt(0) !== '%' || notificationNumber && notificationNumber.charAt(0) === '%' && isNotSync);
		},

		shouldShowAttachments: function(isEditMode, attachments) {
			return !!(isEditMode || attachments && attachments.length);
		},

		shouldShowMaterialTab: function(materials, isEditMode) {
			return !!(isEditMode || materials && materials.length);
		},

		masterListMode: function(isEditMode, isTouch, isTablet) {
			return !isEditMode && (!isTouch || isTablet) ? 'ShowHideMode' : 'HideMode';
		},

		routeMasterListMode: function(isTouch, isTablet) {
			return (!isTouch || isTablet) ? 'ShowHideMode' : 'HideMode';
		},

		formatTitle: function(title, number) {
			return number ? title + ' ' + number : title;
		},

		formatOperationTitle: function(title, operation, subOperation) {
			var returnString = title;

			if (operation) {
				returnString += ' ' + operation;
			}
			if (subOperation) {
				returnString += ' / ' + subOperation;
			}

			return returnString;
		},

		formatUserParameterWorkcenterRequirement: function(planGroups, isCordova) {
			return this.formatterUtil.hasNoEntries(planGroups) && isCordova;
		},

		notificationTitle: function(creationTitle, displayTitle, editTitle, notificationNumber, isEditMode, isNotSync) {
			var title = '';

			if (notificationNumber && notificationNumber.charAt(0) !== '%' && isEditMode) {
				title = editTitle + ' ' + notificationNumber;
			} else if (isEditMode) {
				title = isNotSync ? editTitle : creationTitle;
			} else {
				title = notificationNumber && notificationNumber.charAt(0) !== '%' ? displayTitle + ' ' + notificationNumber : displayTitle;
			}

			return title;
		},

		formatNumberOfCapacitiesText: function(numberOfCapacities) {
			return numberOfCapacities ? {
					0: this.getResourceBundleText('NUMBER_OF_CAPACITIES_NULL_TABLE_UNIT'),
					1: this.getResourceBundleText('NUMBER_OF_CAPACITIES_SINGLE_TABLE_UNIT', numberOfCapacities)
				} [numberOfCapacities] || this.getResourceBundleText('NUMBER_OF_CAPACITIES_MULTIPLE_TABLE_UNIT', numberOfCapacities) :
				this.getResourceBundleText('NUMBER_OF_CAPACITIES_NULL_TABLE_UNIT');
		},

		formatDuration: function(duration, durationUnit, work, workUnit, showOperationsHoursAsDuration) {
			if (showOperationsHoursAsDuration) {
				return work && workUnit ? work + ' ' + workUnit : '';
			} else {
				return duration && durationUnit ? duration + ' ' + durationUnit : '';
			}
		},

		formatConfirmedTime: function(confirmedText, confirmedHours, multipleUnitText, singleUnitText) {
			confirmedHours = confirmedHours || '0';
			multipleUnitText = multipleUnitText || '';
			singleUnitText = singleUnitText || '';
			return confirmedText + ': ' + this.formatterUtil.formatAssignedPersonHours(confirmedHours, multipleUnitText, singleUnitText);
		},

		formatTypeEnablement: function(isEditMode, notificationNumber) {
			return (!notificationNumber || notificationNumber.charAt(0) === '%') && isEditMode;
		},

		formatAddButtonEnablement: function(personName, hours) {
			return !!(personName && hours);
		},

		formatOperationDeleteButtonEnablement: function(controlKey) {
			return controlKey !== 'PM03' && controlKey !== 'ZPM2';
		},

		formatAssignedPersonHours: function(hours, multipleUnitText, singleUnitText) {
			return (hours === '1' || hours === '1.0') ? hours + ' ' + singleUnitText : hours + ' ' + multipleUnitText;
		},

		shouldShowAddPerson: function(duration, work) {
			return (!!duration && duration !== '0.0') || (!!work && work !== '0.0');
		},

		formatMeasurementPointButtonVisibility: function(functionalLocation, equipment, measurementPoints) {
			return (measurementPoints || []).filter(function(measurementPoint) {
				return measurementPoint.FunclocInternalId && measurementPoint.FunclocInternalId === functionalLocation || measurementPoint.Equipment && measurementPoint.Equipment === equipment;
			}).length > 0;
		},

		formatTitleWithNumber: function(title, number) {
			return title && number && number.length ? title + ' (' + number.length + ')' : title;
		},

		formatNotificationsLength: function(notifications) {
			return this.formatterUtil.formatLength(
				(notifications || []).filter(function(notification) {
					return !notification.Completed;
				})
			);
		},

		formatNotificationsTitleWithNumber: function(title, notifications) {
			return this.formatterUtil.formatTitleWithNumber(
				title,
				(notifications || [])
			);
		},

		formatObjectId: function(id) {
			return !id || id.charAt(0) === '%' ? '' : id;
		},

		formatAttachmentUrl: function(docId, url) {
			if (docId || url) {
				return url ? url : this.devapp.onlineModel.sServiceUrl + '/AttachmentDataSet(\'' + docId + '\')/$value';
			}
		},

		formatDMSFileUrl: function(fileId, storageCategory) {
			return this.devapp.onlineModel.sServiceUrl + '/DmsFileSet(FileId=\'' + fileId + '\',StorageCategory=\'' + storageCategory + '\')/$value';
		},

		hasSapId: function(id) {
			return id && id.charAt(0) !== '%';
		},

		hasTemporaryId: function(id) {
			return !id || id.charAt(0) === '%';
		},

		formatOrderSystemStatus: function(isCompleted, isReleased) {
			var systemStatus = 'I0001';
			if (isCompleted) {
				systemStatus = 'I0045';
			} else if (isReleased) {
				systemStatus = 'I0002';
			}

			return this.formatterUtil.formatSystemStatus(systemStatus);
		},

		formatSystemStatus: function(statusCode) {
			return statusMap[statusCode];
		},

		formatSystemStatusState: function(statusCode) {
			var state = 'Error';

			if (statusCode === 'I0070') {
				state = 'Warning';
			} else if (statusCode === 'I0072') {
				state = 'Success';
			}

			return state;
		},

		formatOrderSystemStatusState: function(isCompleted, isReleased) {
			var state = 'Error';

			if (isReleased) {
				state = 'Warning';
			} else if (isCompleted) {
				state = 'Success';
			}

			return state;
		},

		formatFileName: function(fileName) {
			return decodeURI(fileName);
		},

		formatBusyStateOfBackEndAction: function(isPostingLocalStorage, notSync, id) {
			return this.formatterUtil.hasTemporaryId(id) && isPostingLocalStorage && notSync;
		},

		formatMyWorkOrderIdAndOperation: function(orderId, operationId, subOperation) {
			var returnString = '';
			var displayedOrderNumber = this.formatterUtil.formatObjectId(orderId);

			if (displayedOrderNumber) {
				returnString += displayedOrderNumber + ' / ' + operationId;
			}
			if (displayedOrderNumber && subOperation) {
				returnString += ' / ' + subOperation;
			}
			return returnString || operationId;
		},

		formatMyWorksTileNumber: function(myWorks) {
			var userParameters = this.getUserParameters();
			var relevantUserIds = userParameters.Persons && userParameters.Persons.split(',') || [];
			var relevantWorkCenters = userParameters.Workcenters && userParameters.Workcenters.split(',') || [];
			return myWorks.reduce(function(totalWorks, orderObject) {
				var myWorkRelevantOrdersAmount = 0;
				var relevantOperations;

				if (orderObject.Released) {
					if (relevantUserIds.length) {
						var relevantAssignments = orderObject.Assignments.filter(function(assignment) {
							return !assignment.WorkFinished && relevantUserIds.indexOf(assignment.PersonNumber) !== -1;
						}).map(function(relevantAssignment) {
							return relevantAssignment.Activity;
						});

						relevantOperations = orderObject.Operations.filter(function(operation) {
							return !!(relevantAssignments.indexOf(operation.Activity) !== -1 && (!operation.Completed || orderObject.ErrorMessage) && !operation.SubActivity);
						});

						myWorkRelevantOrdersAmount = relevantOperations.length;
					} else {
						relevantOperations = orderObject.Operations.filter(function(operation) {
							return !!(relevantWorkCenters.indexOf(operation.Workcenter) !== -1 && (!operation.Completed || orderObject.ErrorMessage) && !operation.SubActivity);
						});

						myWorkRelevantOrdersAmount = relevantOperations.length;
					}
				}
				return totalWorks + myWorkRelevantOrdersAmount;
			}, 0);
		},

		formatWorkFlowApprovalId: function(type, orderId, poNumber, prNumber) {
			var idObject = {
				WO: orderId,
				SE: poNumber,
				PR: orderId,
				CC: prNumber,
				NW: prNumber
			};
			return idObject[type] || orderId;
		},

		formatWorkFlowApprovalTitle: function(type, orderId, poNumber, prNumber) {
			var idObject = {
				WO: 'WO - ' + orderId,
				SE: 'SE - ' + poNumber,
				PR: 'PR - ' + orderId,
				CC: 'PR - ' + prNumber,
				NW: 'PR - ' + prNumber
			};
			return idObject[type] || idObject['WO'];
		},

		formatMaterialPreqItem: function(isExternalMaterial, preqItem) {
			return isExternalMaterial ? preqItem : '';
		},

		formatMaterialPriceAndCurrency: function(isExternalMaterial, price, currency) {
			return isExternalMaterial ? this.formatterUtil.formatPriceAndCurrency(price, currency) : '';
		},

		formatPriceAndCurrency: function(price, currency) {
			return price && typeof price === 'string' ? price.replace('.', ',') + ' ' + currency : price || '';
		},

		calculateDeviation: function(total, planned) {
			return ('' + (parseFloat(total, 10) - parseFloat(planned, 10))).replace('.', ',');
		},

		formatFooterText: function(tableItems, totalText, currency) {
			return (
				totalText + ' ' + ((tableItems || []).reduce(function(totalCost, tableItem) {
					return tableItem && tableItem.Cost ? totalCost + parseFloat(tableItem.Cost) : totalCost;
				}, 0).toFixed(2))
			).replace('.', ',') + ' ' + currency;
		},

		formatMaterialFooterText: function(tableItems, totalText, currency) {
			return (
				totalText + ' ' + ((tableItems || []).reduce(function(totalCost, tableItem) {
					return tableItem && tableItem.ValueItem ? totalCost + parseFloat(tableItem.ValueItem) : totalCost;
				}, 0).toFixed(2))
			).replace('.', ',') + ' ' + currency;
		},

		formatSuccessDialogPictureUrl: function(path) {
			return jQuery.sap.getModulePath('com.upm.maint') + '/' + path;
		},

		formatOperationListItemTitle: function(operation, subOperation) {
			return subOperation ? operation + ' / ' + subOperation : operation;
		},

		formatMyWorksDate: function(assignments, isRafMaintUser, operationId, persons, startDate) {
			var dateToReturn = startDate;

			if (isRafMaintUser && assignments && assignments.length && persons && persons.length) {
				var orderAssignments = $.extend(true, [], Array.isArray(assignments) ? assignments : []);
				persons = persons.map(function(person) {
					return person.PersonNumber;
				});
				var operationAssignment = orderAssignments.filter(function(assignment) {
					return assignment && !assignment.SubActivity && assignment.Activity === operationId && persons.indexOf(assignment.PersonNumber) !== -1;
				});

				if (operationAssignment && operationAssignment.length && operationAssignment[0].StartDate) {
					dateToReturn = operationAssignment[0].StartDate;
				}
			}

			return this.formatterUtil.formatRelativeDate.call(this, dateToReturn);
		},

		hasPositiveValue: function(number) {
			return typeof number === 'string' && number.indexOf('-') === -1;
		},


		hasNegativeValue: function(number) {
			return typeof number === 'string' && number.indexOf('-') !== -1;
		},

		measurementPointHistoryVisibility: function(measurements, isOffline) {
			return this.formatterUtil.hasEntries(measurements) && !isOffline;
		},

		formatTimeRecordingButtonText: function(startText, stopText, options, timeRecording) {
			var optionIds = $.extend(true, [], options || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			var timeRecordingIds = $.extend(true, [], timeRecording || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			return options && this.areObjectsIdentical(timeRecordingIds, optionIds) ? stopText : startText;
		},

		formatTimeRecordingButtonIcon: function(options, timeRecording) {
			var optionIds = $.extend(true, [], options || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			var timeRecordingIds = $.extend(true, [], timeRecording || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			return options && this.areObjectsIdentical(timeRecordingIds, optionIds) ? 'sap-icon://stop' : 'sap-icon://begin';
		},

		formatTimeRecordingButtonType: function(options, timeRecording) {
			var optionIds = $.extend(true, [], options || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			var timeRecordingIds = $.extend(true, [], timeRecording || []).map(this.formatterUtil.shortTextDeleter.bind(this));
			return options && this.areObjectsIdentical(timeRecordingIds, optionIds) ? 'Reject' : 'Accept';
		},

		shortTextDeleter: function(option) {
			delete option.ShortText;

			return option;
		},

		formatTimeRecordingButtonTextMyWork: function(startText, stopText, timeRecording) {
			return timeRecording ? stopText : startText;
		},

		formatTimeRecordingButtonIconMyWork: function(timeRecording) {
			return timeRecording ? 'sap-icon://stop' : 'sap-icon://begin';
		},

		formatTimeRecordingButtonTypeMyWork: function(timeRecording) {
			return timeRecording ? 'Reject' : 'Accept';
		},

		isRecordingTimeForSpecificObject: function(timeRecording, id) {
			return this.formatterUtil.isRecordingTime(timeRecording) && timeRecording.object === id;
		},

		isRecordingTime: function(timeRecording) {
			return !!timeRecording.object;
		},

		formatTimeRecordingText: function(text, dateTime) {
			var dateTimeString = this.formatterUtil.formatTimeRecording(dateTime);

			return dateTimeString ? (text + ': ' + dateTimeString) : text;
		},

		formatTimeRecording: function(dateTime) {
			var months;
			var days;
			var hours;
			var minutes;
			if (dateTime) {
				months = dateTime.getMonth() + 1;
				days = dateTime.getDate();
				hours = dateTime.getHours();
				minutes = dateTime.getMinutes();

				if (minutes < 10) {
					minutes = '0' + minutes;
				}
			}

			return !isNaN(hours) && !isNaN(minutes) ? days + '.' + months + '. ' + hours + ':' + minutes : '';
		},

		formatOperationTimeRecordVisibility: function(plantLevelTimeRecording, isReleased, controlKey) {
			return !!(plantLevelTimeRecording && isReleased && controlKey === 'PM01');
		},

		formatRouteProgressPercentage: function(nIndex, routeWorks) {
			nIndex = nIndex ? nIndex + 1 : 1;
			return nIndex && Array.isArray(routeWorks) ? nIndex / routeWorks.length * 100 : 0;
		},

		formatRouteProgressText: function(nIndex, routeWorks) {
			nIndex = nIndex ? nIndex + 1 : 1;
			return Array.isArray(routeWorks) ? nIndex + ' / ' + routeWorks.length : '';
		},

		formatMeasurementPointProgressPercentage: function(nIndex, nItems) {
			nIndex = nIndex ? nIndex + 1 : 1;
			if (nIndex && nItems) {
				return (nIndex / nItems * 100) || 0;
			}
			return 0;
		},

		formatMeasurementPointProgressText: function(nIndex, nItems) {
			nIndex = nIndex ? nIndex + 1 : 1;
			if (nIndex && nItems) {
				return nIndex + ' / ' + nItems;
			}
			return '';
		},

		hasMultipleEntries: function(entries) {
			return this.formatterUtil.formatLength(entries) > 1;
		},

		hasSingleEntry: function(entries) {
			return this.formatterUtil.formatLength(entries) === 1;
		},

		formatRouteTimeConfirmationButtonVisibility: function(orderType, showTimeConfirmation) {
			return orderType !== 'PM13' && showTimeConfirmation;
		},

		formatRouteTitle: function(title, routes, filter) {
			if (filter) {
				var filters = filter.split(',');
				routes = routes.filter(function(route) {
					return filters.indexOf(route.RouteId) > -1;
				});
			}

			return this.formatterUtil.formatTitleWithNumber(title, routes);
		},

		coverWorkOrderTextFormatter: function(orderNumber, shortText) {
			return orderNumber + ' / ' + shortText;
		},

		formatStorageLocationAndBin: function(storageLocation, bin) {
			return bin ? storageLocation + ' / ' + bin : storageLocation;
		},

		formatStockAndBatch: function(stock, unit, batch) {
			var quantity = stock + ' ' + unit;
			return batch ? quantity + ' / ' + batch : quantity;
		},

		formatStockAndLocation: function(stock, unit, location) {
			var quantity = stock + ' ' + unit;
			return location ? quantity + ' / ' + location : quantity;
		},

		formatRouteStartAndStopVisibility: function(plantLevelStartAndStop, coverWorkOrders) {
			return plantLevelStartAndStop && coverWorkOrders && !!coverWorkOrders.length;
		},

		formatRouteSummarySaveButtonVisibility: function(plantLevelStartAndStop, coverWorkOrders, timeRecorded) {
			return plantLevelStartAndStop && coverWorkOrders && !!coverWorkOrders.length && timeRecorded && timeRecorded !== '0.0';
		},

		formatRouteSummaryContinueButtonVisibility: function(plantLevelStartAndStop, coverWorkOrders, timeRecorded) {
			return !plantLevelStartAndStop || !coverWorkOrders || !coverWorkOrders.length || !timeRecorded || timeRecorded === '0.0';
		},

		hierarchyAdditionalTextVisibilityFormatter: function(shouldShow, type) {
			return shouldShow && type === 'Material';
		},

		hierarchyAdditionalInfoVisibilityFormatter: function(shouldShow, type) {
			return shouldShow && type === 'Material';
		},

		hierarchyListItemHighlightFormatter: function(type) {
			var highLight;

			if (!type) {
				highLight = 'Information';
			} else if (type === 'Material') {
				highLight = 'Error';
			} else if (type === 'Equipment') {
				highLight = 'Success';
			}
			return highLight;
		},

		formatWorkFlowTileVisibility: function(shouldShowApproval, approvals) {
			return shouldShowApproval && this.formatterUtil.hasEntries(approvals) ? 'X' : '';
		},

		formatWorkFlowTileDomVisibility: function(shouldShowApproval, approvals) {
			return shouldShowApproval && this.formatterUtil.hasEntries(approvals);
		},

		formatEquipmentExchangeVisibility: function(equipmentExchangeEnabled, hasMaintenanceRole, showEquipmentExchange) {
			return equipmentExchangeEnabled && !!hasMaintenanceRole && !!showEquipmentExchange;
		},

		formatDummyTileVisibility: function(shouldShowApproval, approvals, showEquipmentExchange) {
			var showDummyTile = false;

			if (shouldShowApproval && this.formatterUtil.hasEntries(approvals) && showEquipmentExchange) {
				showDummyTile = true;
			} else if (shouldShowApproval && !this.formatterUtil.hasEntries(approvals) && !showEquipmentExchange) {
				showDummyTile = true;
			}
			return showDummyTile;
		},

		formatOperationWorkCenterEnablement: function(isEdit, enableEditOfFirstOperationWorkCenter, isReleased, operationNumber, operations) {
			var isFirstOperation = !operations || operations.length === 0 || operations[0].Activity === operationNumber;
			return isEdit && (enableEditOfFirstOperationWorkCenter || !!isReleased || !isFirstOperation);
		},

		isSystemStatusSelected: function(systemStatus, selectedStatuses) {
			selectedStatuses = Array.isArray(selectedStatuses) ? selectedStatuses : [];
			return selectedStatuses.some(function(status) {
				return status.StatusInt === systemStatus;
			});
		},

		formatCompleteWorkButtonVisibility: function(enableCompleteWork, isCompleted, assignments, personNumber) {
			var showCompleteWork = false;
			if (enableCompleteWork && !isCompleted && Array.isArray(assignments) && assignments.length && personNumber) {
				showCompleteWork = assignments.some(function(assignment) {
					return assignment.PersonNumber === personNumber && !assignment.WorkFinished;
				});
			}

			return showCompleteWork;
		},

		formatObjectTabVisibility: function(objects) {
			return this.formatterUtil.hasEntries(objects);
		},

		formatCodeDialogTitle: function(type, defaultTitle, damageTitle, causeTitle, taskTitle, objectTitle) {
			var title = '';
			if (type === 'S' || type === 'C') {
				title = damageTitle;
			} else if (type === 'R' || type === '5') {
				title = causeTitle;
			} else if (type === 'P') {
				title = taskTitle;
			} else if (type === 'B') {
				title = objectTitle;
			}
			if (!type || !title) {
				title = defaultTitle;
			}

			return title;
		},

		formatAgreement: function(agreement, agreementItem) {
			return agreement && agreementItem ? agreement + ' / ' + agreementItem : '';
		},

		formatGlAccountText: function(materials) {
			var glAccountDescriptions = materials.map(function(material) {
				var text = '';
				if (material.GlAccount && material.GlAccountDescr) {
					text = material.GlAccount + ' - ' + material.GlAccountDescr;
				} else if (material.GlAccount) {
					text = material.GlAccount;
				}
				return text;
			});

			var distinctGlAccounts = glAccountDescriptions.filter(function(glAccountDescription, index, array) {
				return glAccountDescription && array.indexOf(glAccountDescription) === index;
			});

			return distinctGlAccounts.join(', ');
		},

		formateDeliveryDate: function(services) {
			var deliveryDates = services.map(function(material) {
				return material.DeliveryDate;
			});

			var distinctDeliveryDates = deliveryDates.filter(function(date, index, array) {
				return date && array.indexOf(date) === index;
			});

			var distinctDeliveryDatesFormatted = distinctDeliveryDates.map(function(date) {
				return this.formatterUtil.formatStringDate(date);
			}.bind(this));

			return distinctDeliveryDatesFormatted.join(', ');
		},

		formatRequisitionerText: function(requisitionerName, requisitionerId) {
			return requisitionerName || requisitionerId || '';
		},

		formatWorkFlowInitiatorName: function(initiator, requisitionerName, requisitionerId) {
			return initiator || requisitionerName || requisitionerId || '';
		},

		formatStringDate: function(dateString) {
			if (dateString) {
				var year = dateString.substring(0, 4);
				var month = dateString.substring(4, 6);
				var day = dateString.substring(6, 8);

				if (month.charAt(0) === '0') {
					month = month.charAt(1);
				}

				if (day.charAt(0) === '0') {
					day = day.charAt(1);
				}

				return day + '.' + month + '.' + year;
			} else {
				return '';
			}
		},

		formatClassList: function(classList) {
			return classList && classList.replace(/,/g, ', ') || '';
		},

		formatCurrentRecording: function(currentRecording) {
			if (currentRecording && currentRecording.object) {
				return this.getResourceBundleText('CURRENT_RECORDING_INFO_TEXT', [currentRecording.object, currentRecording.objectDescription]);
			} else {
				return this.getResourceBundleText('CURRENT_RECORDING_INFO_TEXT_WITHOUT_OBJECT');
			}
		},

		showCurrentRecording: function(currentRecording) {
			return currentRecording.start ? true : false;
		},

		showCurrentRecordingLink: function(currentRecording) {
			if (currentRecording && currentRecording.object) {
				return true;
			}
			return false;
		},

		newVariantNameValueState: function(value, variants) {
			var variantNames = (variants || []).reduce(function(array, variant) {
				array.push(variant.Description);
				return array;
			}, []);
			if (variantNames.indexOf(value) !== -1) {
				return 'Warning';
			}
			return 'None';
		},

		editVariantsVisibility: function(array) {
			if (array && array.length > 1) {
				return true;
			}
			return false;
		},

		variantSelectionVisibility: function(array) {
			if (array && array.length) {
				return true;
			}
			return false;
		},

		removeLeadingZeros: function(value) {
			if (value) {
				value = value + '';
			}
			return value ? value.replace(/^0+/, '') : '';
		},

		shouldShowCreateNotificationCheckbox: function(allowDirectWorkOrderCreate, isEditMode, notificationNumber) {
			if (!allowDirectWorkOrderCreate || !isEditMode) {
				return false;
			} else if (notificationNumber && notificationNumber.charAt(0) !== '%') {
				return false;
			}
			return true;
		},

		shouldShowCauseCatalogTab: function(isRafMaintUser, isEditMode, orderId) {
			if (isRafMaintUser || !isEditMode) {
				return false;
			} else if (orderId && orderId.charAt(0) !== '%') {
				return false;
			}
			return true;
		},

		getFirstFoundValue: function() {
			var values = Array.prototype.slice.call(arguments);
			var result = '';
			values.some(function(value) {
				if (value) {
					result = value;
					return true;
				}
			});
			return result;
		},

		enableDisablePushNotificationsVisibility: function(isRafMaintUser) {
			if (!isRafMaintUser && sap.Push) {
				return true;
			}
			return false;
		},

		attachmentEditVisibility: function(isEdit, id) {
			if (isEdit && !this.formatterUtil.hasSapId(id)) {
				return true;
			}
			return false;
		},

		showAttacmentsButton: function(aItems) {
			if (aItems && aItems.length) {
				return true;
			}
			return false;
		},

		formatUploadUrl: function(url) {
			return url + 'AttachmentDataSet';
		},

		formatDMSUploadUrl: function(url) {
			return url + 'DmsFileSet';
		},

		formatComponentActionButtonVisibility: function(enableGoodsIssue, enableEquipmentInstall, batch, reservationNumber, released) {
			return (enableGoodsIssue || enableEquipmentInstall) && batch && reservationNumber && released;
		},

		formatRevisionSearchVisibility: function(enableRevision, isMyWorkList, isOrderList) {
			return enableRevision && (isMyWorkList || isOrderList);
		},

		formatFunctionalLocationStartSuggesting: function(isHybridAppUser) {
			return isHybridAppUser ? 0 : 100000;
		}
	};
});