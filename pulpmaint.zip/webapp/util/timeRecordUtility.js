sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'jquery.sap.storage'
], function(JSONModel, jQuery) {
	'use strict';

	var timeRecordMaxTime;

	return JSONModel.extend('com.upm.maint.util.timeRecordUtility', {

		_STORAGE_KEY: 'timeRecordingStorage',
		_storage: jQuery.sap.storage(jQuery.sap.storage.Type.local),

		constructor: function() {
			JSONModel.call(this, {
				CurrentRecording: {}
			});
			this.setSizeLimit(1000);

			this._loadData();

			return this;
		},

		/**
		 * Loads the current state of the model from local storage
		 */
		_loadData: function() {
			var sJSON = this._storage.get(this._STORAGE_KEY);

			var localStorageJSON = JSON.parse(sJSON);

			var dateKeys = ['start', 'finish'];

			if (sJSON) {
				this.setData({
					CurrentRecording: (this.formatDates(dateKeys, localStorageJSON.CurrentRecording) || {})
				});
			}
			this._bDataLoaded = true;
		},

		formatDates: function(dateKeys, storedObject) {
			dateKeys.forEach(function(dateKey) {
				storedObject[dateKey] = storedObject[dateKey] ? new Date(storedObject[dateKey]) : storedObject[dateKey];
			});
			return storedObject;
		},

		/**
		 * Saves the current state of the model to local storage
		 */
		_storeData: function() {
			var oData = this.getData();

			var sJSON = JSON.stringify(oData);
			this._storage.put(this._STORAGE_KEY, sJSON);
		},

		/**
		 * Sets a property for the JSON model
		 * @override
		 */
		setProperty: function() {
			JSONModel.prototype.setProperty.apply(this, arguments);
			this._storeData();
		},

		/**
		 * Sets the data for the JSON model
		 * @override
		 */
		setData: function() {
			JSONModel.prototype.setData.apply(this, arguments);
			// called from constructor: only store data after first load
			if (this._bDataLoaded) {
				this._storeData();
			}
		},

		/**
		 * Refreshes the model with the current data
		 * @override
		 */
		refresh: function() {
			JSONModel.prototype.refresh.apply(this, arguments);
			this._storeData();
		},

		startRecording: function(options) {
			var recordObject = {
				start: new Date(),
				options: options
			};
			if (options && options.length === 1) {
				recordObject.object = options[0].Orderid;
				recordObject.objectDescription = options[0].ShortText;
			}
			this.setCurrentRecording(recordObject);
		},

		setCurrentRecording: function(recording) {
			this.setProperty('/CurrentRecording', recording);
		},

		finishCurrentRecording: function() {
			this.setCurrentRecording({});
		},

		isRecording: function() {
			return !!this.getCurenctRecording().options;
		},

		isRecordingForObject: function(options) {
			var recordingFor = this.getCurenctRecording().options;

			return JSON.stringify(recordingFor) === JSON.stringify(options);
		},

		getCurenctRecording: function() {
			return this.getProperty('/CurrentRecording');
		},

		getSaveObject: function() {
			var currentRecording = $.extend(true, {}, this.getCurenctRecording());
			var recordingMaxTime = this.getTimeRecordMaxTime();

			currentRecording.finish = new Date();
			currentRecording.time = this.msToDurationString(currentRecording.finish - currentRecording.start);

			if (currentRecording.time > parseFloat(recordingMaxTime)) {
				currentRecording.time = recordingMaxTime;
			}

			return currentRecording;
		},

		msToDurationString: function(duration) {
			var hours = (duration / (1000 * 60 * 60));

			return isNaN(hours) ? '' : hours.toFixed(1).toString(10);
		},

		setTimeRecordMaxTime: function(maxTime) {
			timeRecordMaxTime = maxTime || '8';
		},

		getTimeRecordMaxTime: function() {
			return timeRecordMaxTime;
		}
	});
});