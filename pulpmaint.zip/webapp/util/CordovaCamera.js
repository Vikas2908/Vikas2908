sap.ui.define([],
	function() {
		'use strict';
		return {

			handleCaptureImage: function(onSuccess, onFail) {
				return navigator.camera.getPicture(onSuccess, onFail, {
					quality: 100,
					targetWidth: 2048,
					targetHeight: 1536,
					encodingType: navigator.camera.EncodingType.JPEG,
					sourceType: navigator.camera.PictureSourceType.CAMERA,
					destinationType: navigator.camera.DestinationType.DATA_URL
				});
			},

			handleSelectImage: function(onSuccess, onFail) {
				return navigator.camera.getPicture(onSuccess, onFail, {
					quality: 100,
					targetWidth: 2048,
					targetHeight: 1536,
					sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
					destinationType: navigator.camera.DestinationType.DATA_URL
				});
			},

			/**
			 * Convert a base64 string in a Blob according to the data and contentType.
			 *
			 * @param b64Data {String} Pure base64 string without contentType
			 * @param contentType {String} the content type of the file i.e (image/jpeg - image/png - text/plain)
			 * @param sliceSize {Int} SliceSize to process the byteCharacters
			 * @return Blob
			 */
			b64toBlob: function(b64Data, contentType, sliceSize) {
				contentType = contentType || '';
				sliceSize = sliceSize || 512;

				var byteCharacters = window.atob(b64Data);
				var byteArrays = [];

				for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
					var slice = byteCharacters.slice(offset, offset + sliceSize);

					var byteNumbers = new Array(slice.length);
					for (var i = 0; i < slice.length; i++) {
						byteNumbers[i] = slice.charCodeAt(i);
					}

					var byteArray = new Uint8Array(byteNumbers);

					byteArrays.push(byteArray);
				}

				var blob = new Blob(byteArrays, {
					type: contentType
				});
				return blob;
			}
		};
	});