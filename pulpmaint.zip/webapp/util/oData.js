// oDataUtil
sap.ui.define([
		'com/upm/maint/dev/devapp',
		'com/upm/maint/model/models'
	],
	function(devapp, models) {
		'use strict';

		var wmModels = {};
		var currentOperations = {};

		return {
			services: {
				'ZWM_COMMON_SRV': '/odata/SAP/ZWM_COMMON_SRV;v=1/'
			},

			getODataModel: function() {
				return devapp.offlineModel;
			},

			getOnlineModel: function(dontAttachMetadataFailed) {
				var metadataLoaded = devapp.onlineModel && devapp.onlineModel.oMetadata && devapp.onlineModel.oMetadata.bLoaded;
				var serviceUrl = devapp.onlineModel && devapp.onlineModel.sServiceUrl;
				var model;

				if (metadataLoaded) {
					model = devapp.onlineModel;
				} else if (serviceUrl === '/odata/SAP/ZGENERAL_SRV') {
					model = models.createGeneralODataModel();
				} else {
					model = models.createOnlineODataModel(dontAttachMetadataFailed);
				}

				return model;
			},

			getWMODataModel: function(modelName) {
				if (!wmModels[modelName]) {
					wmModels[modelName] = models.createOnlineODataModel(false, modelName);
				}
				return wmModels[modelName];
			},

			getServiceUrl: function(serviceName) {
				var service = this.services[serviceName];
				if (!service) {
					throw new Error('Service: ' + service + ' not found');
				}
				return service;
			},

			handleResultsObjects: function(oData) {
				oData = oData && oData['results'] ? oData['results'] : oData;
				return typeof oData === 'object' && oData !== null && !Array.isArray(oData) ?
					this.removeResultFromObject(oData) :
					oData;
			},

			handleBatchResultsObject: function(oData) {
				var response = {
					results: [],
					errors: []
				};
				response.results = oData.__batchResponses.map(function(batchResponse) {
					if (!(batchResponse.statusCode && batchResponse.statusCode < '300')) {
						response.errors.push(batchResponse);
					}
					return batchResponse && batchResponse.data ? this.handleResultsObjects(batchResponse.data) : null;
				}, this);

				return response;
			},

			removeResultFromObject: function(oData) {
				Object.keys(oData).map(function(key) {
					oData[key] = oData[key] !== null && typeof oData[key] === 'object' && oData[key] && oData[key]['results'] ?
						oData[key]['results'] :
						oData[key];
					if (Array.isArray(oData[key])) {
						oData[key] = oData[key].map(this.removeResultFromObject.bind(this));
					}
				}.bind(this));

				return oData;
			},

			/**
			 * Parses SAP messages from the response data
			 * @param {object} oResponse - Response object
			 * @returns {array} SAP messages
			 */
			parseSapMessages: function(oResponse) {
				var aMessages = [];
				if (oResponse && oResponse.headers && oResponse.headers['sap-message']) {
					var oMessage = JSON.parse(oResponse.headers['sap-message']);
					var severity = oMessage.severity ? oMessage.severity.charAt(0).toUpperCase() + oMessage.severity.slice(1) : 'Warning';
					aMessages.push({
						severity: severity || '',
						message: oMessage.message || '',
						code: oMessage.code || '',
						target: oMessage.target || ''
					});
					if (oMessage.details) {
						oMessage.details.map(function(detail) {
							var sSeverity = detail.severity ? detail.severity.charAt(0).toUpperCase() + detail.severity.slice(1) : 'Warning';
							aMessages.push({
								severity: sSeverity || '',
								message: detail.message || '',
								code: detail.code || '',
								target: detail.target || ''
							});
						});
					}
				}
				return aMessages;
			},

			/**
			 * Reads data from back end
			 * @param {string} pathToService - path to the service
			 * @param {object=} filters - filter parameters
			 * @param {object=} sorters - sorter parameters
			 * @param {string=} urlParameters - additional url parameters
			 * @param {boolean=} async - make call async
			 * @param {boolean=} recordOperation - recordOpertaion for cancellation
			 * @returns {object} data from back end or error event
			 */
			read: function(pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var model = null;
				if (oParameters.online) {
					model = this.getOnlineModel();
				} else if (oParameters.wmService) {
					model = this.getWMODataModel(oParameters.wmService);
				} else {
					model = devapp.offlineModel;
				}

				var request = model.read('/' + pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					filters: oParameters && oParameters.filters ? oParameters.filters : null,
					sorters: oParameters && oParameters.sorters ? oParameters.sorters : null,
					urlParameters: oParameters && oParameters.urlParameters ? oParameters.urlParameters : null,
					success: function(oData, oResponse) {
						if (oParameters.returnSapMessages) {
							deferred.resolve(this.handleResultsObjects(oData), this.parseSapMessages(oResponse));
						} else {
							deferred.resolve(this.handleResultsObjects(oData));
						}
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					},
					always: function() {
						if (oParameters.recordOperation) {
							currentOperations[pathToService] = null;
						}
					}
				});

				if (oParameters.recordOperation) {
					currentOperations[pathToService] = request;
				}

				return deferred.promise();
			},

			/**
			 * Removes data from back end
			 * @param {string} pathToService - path to the service
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end or error event
			 */
			remove: function(pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				devapp.offlineModel.remove('/' + pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData, oResponse) {
						if (oParameters.returnSapMessages) {
							deferred.resolve(this.handleResultsObjects(oData), this.parseSapMessages(oResponse));
						} else {
							deferred.resolve(this.handleResultsObjects(oData));
						}
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Posts data to back end
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToPost - data to be posted to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			create: function(pathToService, dataToPost, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var model = null;
				if (oParameters.online) {
					model = this.getOnlineModel(true);
				} else if (oParameters.wmService) {
					model = this.getWMODataModel(oParameters.wmService);
				} else {
					model = devapp.offlineModel;
				}

				model.create('/' + pathToService, dataToPost, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData, oResponse) {
						if (!oData && arguments[1] && arguments[1].statusCode === 200) {
							sap.Logon.performSAMLAuth(
								function() {
									this.create(pathToService, dataToPost, oParameters)
										.done(deferred.resolve)
										.fail(deferred.reject);
								}.bind(this),
								deferred.reject
							);
						} else if (oParameters.returnSapMessages) {
							deferred.resolve(this.handleResultsObjects(oData), this.parseSapMessages(oResponse));
						} else {
							deferred.resolve(this.handleResultsObjects(oData));
						}
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Updates data to back end
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToUpdate - data to be updated to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			update: function(pathToService, dataToUpdate, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var model = null;
				if (oParameters.online) {
					model = this.getOnlineModel();
				} else if (oParameters.wmService) {
					model = this.getWMODataModel(oParameters.wmService);
				} else {
					model = devapp.offlineModel;
				}

				model.update('/' + pathToService, dataToUpdate, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData, oResponse) {
						if (oParameters.returnSapMessages) {
							deferred.resolve(this.handleResultsObjects(oData), this.parseSapMessages(oResponse));
						} else {
							deferred.resolve(this.handleResultsObjects(oData));
						}
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			functionImport: function(pathToService, dataToPost) {
				var deferred = $.Deferred();

				this.getOnlineModel().callFunction('/' + pathToService, {
					method: 'GET',
					urlParameters: dataToPost,
					async: true,
					success: function() {
						deferred.resolve();
					},
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			functionImportPost: function(pathToService, dataToPost) {
				var deferred = $.Deferred();

				this.getOnlineModel().callFunction('/' + pathToService, {
					method: 'POST',
					urlParameters: dataToPost,
					async: true,
					success: function() {
						deferred.resolve();
					},
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			batch: function(aRequests, bRejectOnError) {
				var deferred = $.Deferred();

				// generate random id for batch group
				var sGroupId = jQuery.sap.uid();

				var oDataModel = devapp.offlineModel;
				oDataModel.setDeferredGroups([sGroupId]);

				aRequests.forEach(function(request) {
					if (request.type === 'remove') {
						this.remove(
							request.pathToService,
							$.extend({
								groupId: sGroupId
							}, request.parameters),
							oDataModel
						);
					} else if (request.type === 'create') {
						this.create(
							request.pathToService,
							request.dataToPost,
							$.extend({
								groupId: sGroupId
							}, request.parameters),
							oDataModel
						);
					} else if (request.type === 'update') {
						this.update(
							request.pathToService,
							request.dataToUpdate,
							$.extend({
								groupId: sGroupId
							}, request.parameters),
							oDataModel
						);
					} else {
						this.read(
							request.pathToService,
							$.extend({
								groupId: sGroupId
							}, request.parameters),
							oDataModel);
					}
				}, this);

				oDataModel.submitChanges({
					groupId: sGroupId,
					success: function(oData) {
						var response = this.handleBatchResultsObject(oData);
						if (bRejectOnError && response.errors && response.errors.length > 0) {
							deferred.reject(response.errors);
						} else {
							deferred.resolve.apply(this, response.results);
						}
					}.bind(this),
					error: function(oError) {
						deferred.reject(oError);
					}
				});

				return deferred.promise();
			},

			createGoodsIssue: function(dataToPost) {
				var deferred = $.Deferred();
				var serviceUrl = '/odata/SAP/ZRAFWM_GOODSISSUE_SRV/';
				var param = {
					'json': true,
					loadMetadataAsync: false,
					useBatch: false
				};
				var appContext;
				if (window.cordova && !window.sap_webide_FacadePreview && !window.sap_webide_companion) {
					if (devapp.devLogon) {
						appContext = devapp.devLogon.appContext;
					}
					serviceUrl = (appContext.applicationEndpointURL + '.goodsissue' + '/');
					var oHeader = {
						'X-SMP-APPCID': appContext.applicationConnectionId
					};
					if (appContext.registrationContext.user) {
						oHeader.Authorization = 'Basic ' + btoa(appContext.registrationContext.user + ':' + appContext.registrationContext.password);
					}
					param.headers = oHeader;
				}
				new sap.ui.model.odata.v2.ODataModel(
					serviceUrl,
					param
				).create('/GoodsIssueSet', dataToPost, {
					async: true,
					success: function(oData) {
						if (!oData && arguments[1] && arguments[1].statusCode === 200) {
							sap.Logon.performSAMLAuth(
								function() {
									this.createGoodsIssue(dataToPost)
										.done(deferred.resolve)
										.fail(deferred.reject);
								}.bind(this),
								deferred.reject
							);
						} else {
							deferred.resolve(this.handleResultsObjects(oData));
						}
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			abortService: function(service) {
				currentOperations && currentOperations[service] && currentOperations[service].abort();
			}
		};
	});