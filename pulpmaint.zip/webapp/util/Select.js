sap.ui.define([
	'sap/m/Select',
	'sap/ui/Device'
], function(Select, Device) {
	'use strict';
	return Select.extend('com.upm.maint.util.Select', {
		metadata: {},

		init: function() {
			if (Select.prototype.init) {
				Select.prototype.init.apply(this, arguments);
			}
		},

		ontap: function() {
			if (Device.system.phone) {
				this.focus();
			}
			if (Select.prototype.ontap) {
				Select.prototype.ontap.apply(this, arguments);
			}
		},

		renderer: {}

	});
});