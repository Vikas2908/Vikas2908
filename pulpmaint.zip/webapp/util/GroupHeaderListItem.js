sap.ui.define([
	'sap/m/GroupHeaderListItem'
], function(GroupHeaderListItem) {
	'use strict';
	return GroupHeaderListItem.extend('com.upm.maint.util.FragmentGroupHeaderListItem', {
		metadata: {
			properties: {
				fragment: {
					type: 'object'
				}
			},
			aggregations: {},
			events: {}
		},
		init: function() {},

		renderer: {
			renderLIContent: function(rm, oLI) {
				// return immediately if control is invisible, do not render any HTML
				if (!oLI.getVisible()) {
					return;
				}

				// start opening tag
				rm.write('<div');

				// write control data
				rm.writeControlData(oLI);

				// write classes
				rm.writeClasses();

				// write styles
				rm.writeStyles();

				// end opening tag
				rm.write('>');

				// render fragment controls (@see sap.ui.fragment.FragmentControl.metadata.properties._aFragmentControls)
				rm.renderControl(oLI.getFragment());

				// write closing tag
				rm.write('</div>');
			}
		}

	});
});