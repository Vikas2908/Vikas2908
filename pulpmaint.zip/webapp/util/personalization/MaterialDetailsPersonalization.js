sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service
		var MaterialDetailsPersonalization = {

			defaultData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					"order": 0,
					"visible": true,
					"id": "materialDetailsItemTable-materialDocumentColumn"
				}, {
					"order": 1,
					"visible": true,
					"id": "materialDetailsItemTable-movementTypeColumn"
				}, {
					"order": 2,
					"visible": true,
					"id": "materialDetailsItemTable-plantColumn"
				}, {
					"order": 3,
					"visible": true,
					"id": "materialDetailsItemTable-storageLocationColumn"
				}, {
					"order": 4,
					"visible": true,
					"id": "materialDetailsItemTable-specialStockColumn"
				}, {
					"order": 5,
					"visible": true,
					"id": "materialDetailsItemTable-postingDateColumn"
				}, {
					"order": 6,
					"visible": true,
					"id": "materialDetailsItemTable-postingTimeColumn"
				}, {
					"order": 7,
					"visible": true,
					"id": "materialDetailsItemTable-quantityColumn"
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.defaultData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				if (oBundle && oBundle.aColumns && oBundle.aColumns.length || oBundle && oBundle.length) {
					this._oBundle = oBundle;
				} else {
					this.resetPersData();
				}
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = this.defaultData;

				//set personalization
				this._oBundle = oInitialData;

				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return MaterialDetailsPersonalization;

	}, /* bExport= */ true);