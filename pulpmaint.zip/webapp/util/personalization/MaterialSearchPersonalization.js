sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service
		var MaterialSearchPersonalization = {

			defaultData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					"order": 0,
					"visible": true,
					"id": "materialSearchItemTable-materialColumn"
				}, {
					"order": 1,
					"visible": true,
					"id": "materialSearchItemTable-plantColumn"
				}, {
					"order": 2,
					"visible": true,
					"id": "materialSearchItemTable-storageLocationColumn"
				}, {
					"order": 3,
					"visible": true,
					"id": "materialSearchItemTable-storageTypeColumn"
				}, {
					"order": 4,
					"visible": true,
					"id": "materialSearchItemTable-storageBinColumn"
				}, {
					"order": 5,
					"visible": true,
					"id": "materialSearchItemTable-specialStockColumn"
				}, {
					"order": 6,
					"visible": true,
					"id": "materialSearchItemTable-quantityColumn"
				}, {
					"order": 7,
					"visible": true,
					"id": "materialSearchItemTable-actionColumn"
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.defaultData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				if (oBundle && oBundle.aColumns && oBundle.aColumns.length || oBundle && oBundle.length) {
					this._oBundle = oBundle;
				} else {
					this.resetPersData();
				}
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = this.defaultData;

				//set personalization
				this._oBundle = oInitialData;

				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return MaterialSearchPersonalization;

	}, /* bExport= */ true);