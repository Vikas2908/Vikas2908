sap.ui.define([
	'sap/m/Input'
], function(Input) {
	'use strict';
	return Input.extend('com.upm.maint.util.Input', {
		metadata: {
			properties: {
				selectOnFocus: {
					type: 'boolean',
					defaultValue: true
				}
			}
		},
		init: function() {
			if (Input.prototype.init) {
				Input.prototype.init.apply(this, arguments);
			}
		},
		onAfterRendering: function() {
			if (Input.prototype.onAfterRendering) {
				Input.prototype.onAfterRendering.apply(this, arguments);
			}
		},

		onfocusin: function() {
			if (Input.prototype.onfocusin) {
				Input.prototype.onfocusin.apply(this, arguments);
			}
			window.setTimeout(function() {
				var $input = this.$().find('input')[0];
				if ($input && $input === document.activeElement) {
					$input.select();
				}
			}.bind(this), 0);
		},

		renderer: {}

	});
});