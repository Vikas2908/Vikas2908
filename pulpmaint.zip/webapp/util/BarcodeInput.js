sap.ui.define([
	'sap/m/Input'
], function(Input) {
	'use strict';
	return Input.extend('com.upm.maint.util.BarcodeInput', {
		metadata: {
			properties: {
				selectOnFocus: {
					type: 'boolean',
					defaultValue: true
				}
			},
			events: {
				scanSuccess: {
					parameters: {
						value: {
							type: 'String'
						}
					}
				},
				scanError: {
					parameters: {
						value: {
							type: 'String'
						}
					}
				}
			}
		},
		init: function() {
			if (Input.prototype.init) {
				Input.prototype.init.apply(this, arguments);
			}
			document.addEventListener('deviceready', this._onDeviceReady.bind(this), false);

			this.setShowValueHelp(true);
			this._getValueHelpIcon().setSrc(this._isScannedAvailable() ? 'sap-icon://camera' : 'sap-icon://search');

			this.attachValueHelpRequest(this._onButtonPress.bind(this));
		},
		onAfterRendering: function() {
			if (Input.prototype.onAfterRendering) {
				Input.prototype.onAfterRendering.apply(this, arguments);
			}
			//this.addStyleClass('customBarcodeInput');
		},

		onfocusin: function(oEvent) {
			var that = this;
			if (oEvent && this.getSelectOnFocus()) {
				jQuery.sap.log.info('on focus Barcodeinput');
				window.setTimeout(function() {
					var $input = that.$().find('input')[0];
					if ($input) {
						$input.select();
					}
				}, 0);
			}
		},

		renderer: {
			writeInnerContent: function(oRM, oControl) {
				oRM.renderControl(oControl.getAggregation('_image'));
				oRM.renderControl(oControl.getAggregation('_button'));
			}
		},

		_isScannedAvailable: function() {
			var scannerAvailable = false;
			if (window.cordova && window.cordova.plugins.barcodeScanner) {
				scannerAvailable = true;
			}
			return scannerAvailable;
		},

		_onDeviceReady: function() {
			var scannerAvailable = this._isScannedAvailable();
			if (this.getAggregation('_image')) {
				this.getAggregation('_image').setVisible(!scannerAvailable);
			}
			if (this.getAggregation('_button')) {
				this.getAggregation('_button').setVisible(scannerAvailable);
			}
		},

		_onImagePress: function() {
			// focus back to input
			jQuery.sap.delayedCall(10, this, this.focus);
		},

		_onButtonPress: function() {
			if (window.cordova && window.cordova.plugins.barcodeScanner) {
				window.cordova.plugins.barcodeScanner.scan(this._scanSuccessCallback.bind(this), this._scanErrorCallback.bind(this));
			} else {
				jQuery.sap.log.warning('no cordova barcode scanner available');
			}
		},

		_scanSuccessCallback: function(result) {
			if (result) {
				var scannedValue = result;
				if (scannedValue) {
					if (scannedValue.text || scannedValue.text === '') {
						scannedValue = scannedValue.text;
					} else {
						scannedValue = JSON.stringify(scannedValue);
					}
				}
				this.fireEvent('scanSuccess', {
					value: scannedValue
				});
			}
		},

		_scanErrorCallback: function(error) {
			var errorMessage = 'error';
			if (error) {
				errorMessage = JSON.stringify(error);
			}
			this.fireEvent('scanError', {
				value: errorMessage
			});
		}

	});
});