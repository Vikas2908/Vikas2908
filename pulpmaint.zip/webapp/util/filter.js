// this file is needed only for mobilefirst platform projects
sap.ui.define([],
	function() {
		'use strict';

		return {
			filtersArr: [],

			/**
			 * Get filters as query string
			 * @return {string}
			 */
			getFilterQuery: function() {
				var filters = $.map(this.filtersArr, function(filter) {
					if (filter.operator === 'between') {
						if (filter.type === 'date') {
							return jQuery.sap.formatMessage('({0} ge datetime\'{1}\' and {0} le datetime\'{2}\')', [filter.name, filter.value[0], filter.value[1]]);
						} else {
							return jQuery.sap.formatMessage('({0} ge \'{1}\' and {0} le \'{2}\')', [filter.name, filter.value[0], filter.value[1]]);
						}
					} else if (filter.type === 'date') {
						return jQuery.sap.formatMessage('{0} {1} datetime\'{2}\'', [filter.name, filter.operator, filter.value]);
					} else {
						return jQuery.sap.formatMessage('{0} {1} \'{2}\'', [filter.name, filter.operator, filter.value]);
					}
				});

				var query = filters.join(' and ');

				return query;
			},

			addFilter: function(filter) {
				this.filtersArr.push(filter);
			},

			clearFilters: function() {
				this.filtersArr = [];
			}
		};
	});