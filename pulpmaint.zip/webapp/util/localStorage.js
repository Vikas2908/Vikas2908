sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'jquery.sap.storage'
], function(JSONModel, jQuery) {
	'use strict';

	return JSONModel.extend('com.upm.maint.util.localStorage', {

		_STORAGE_KEY: 'deepStructurePostStorage',
		_storage: jQuery.sap.storage(jQuery.sap.storage.Type.local),

		constructor: function() {
			JSONModel.call(this, {
				Notifications: [],
				Orders: [],
				Routes: [],
				TimeConfirmations: [],
				Variants: [],
				RemoveVariants: []
			});
			this.setSizeLimit(1000);

			this._loadData();

			return this;
		},

		/**
		 * Loads the current state of the model from local storage
		 */
		_loadData: function() {
			var sJSON = this._storage.get(this._STORAGE_KEY);

			var localStorageJSON = JSON.parse(sJSON);

			var attachmentDateKeys = ['ChangDate'];
			var notificationDateKeys = ['Desstdate', 'NotifDate', 'Desenddate'];
			var orderDateKeys = ['CreatedDate', 'StartDate', 'FinishDate', 'ReferenceDate'];
			var operationDateKeys = ['EarlSchedStartDate', 'EarlSchedFinDate'];
			var materialDateKeys = ['RequirementDate'];
			var assignmentDateKeys = ['StartDate', 'FinishDate'];
			var routeDateKeys = ['StartDate', 'FinishDate', 'ReferenceDate'];
			var timeConfirmationDateKeys = ['PostingDate'];

			if (sJSON) {
				this.setData({
					Notifications: (localStorageJSON.Notifications || []).map(this.formatNotificationDates.bind(this, attachmentDateKeys, notificationDateKeys)),
					Orders: (localStorageJSON.Orders || []).map(this.formatOrderDates.bind(this, attachmentDateKeys, orderDateKeys, operationDateKeys, assignmentDateKeys, materialDateKeys)),
					Routes: (localStorageJSON.Routes || []).map(this.formatDates.bind(this, routeDateKeys)),
					TimeConfirmations: (localStorageJSON.TimeConfirmations || []).map(this.formatDates.bind(this, timeConfirmationDateKeys)),
					Variants: (localStorageJSON.Variants || []),
					RemoveVariants: (localStorageJSON.RemoveVariants || [])
				});
			}
			this._bDataLoaded = true;
		},

		formatNotificationDates: function(attachmentDateKeys, notificationDateKeys, storedNotification) {
			storedNotification = this.formatDates(notificationDateKeys, storedNotification);
			storedNotification.Attachments = (storedNotification.Attachments || []).map(this.formatDates.bind(this, attachmentDateKeys));

			return storedNotification;
		},

		formatOrderDates: function(attachmentDateKeys, orderDateKeys, operationDateKeys, materialDateKeys, assignmentDateKeys, storedOrder) {
			storedOrder = this.formatDates(orderDateKeys, storedOrder);
			storedOrder.Attachments = (storedOrder.Attachments || []).map(this.formatDates.bind(this, attachmentDateKeys));
			storedOrder.Operations = (storedOrder.Operations || []).map(this.formatDates.bind(this, operationDateKeys));
			storedOrder.Components = (storedOrder.Components || []).map(this.formatDates.bind(this, materialDateKeys));
			storedOrder.Assignments = (storedOrder.Assignments || []).map(this.formatDates.bind(this, assignmentDateKeys));

			return storedOrder;
		},

		formatDates: function(dateKeys, storedObject) {
			dateKeys.forEach(function(dateKey) {
				var date = new Date(storedObject[dateKey]);
				storedObject[dateKey] = (typeof date.getMonth === 'function') ? date : null;
			});
			return storedObject;
		},

		/**
		 * Saves the current state of the model to local storage
		 */
		_storeData: function() {
			var oData = this.getData();

			var sJSON = JSON.stringify(oData);
			this._storage.put(this._STORAGE_KEY, sJSON);
		},

		insertNotification: function(notification) {
			this.insertItem('/Notifications', notification, 'NotifNo');
		},

		insertOrder: function(order) {
			this.insertItem('/Orders', order, 'Orderid');
		},

		insertRoute: function(route) {
			this.insertItem('/Routes', route, 'Orderid');
		},

		insertVariant: function(variant) {
			this.insertVariantItem(variant);
		},

		insertRemoveVariant: function(variant) {
			this.insertRemoveVariantItem(variant);
		},

		insertTimeConfirmation: function(timeConfirmation) {
			this.pushItemToList('/TimeConfirmations', timeConfirmation);
		},

		insertItem: function(property, item, idProperty) {
			this.hasEntry(property, item, idProperty) ?
				this.replaceOldItem(property, item, idProperty) :
				this.pushItemToList(property, item);
		},

		insertVariantItem: function(variant) {
			this.hasEntryWithIdArray('/Variants', variant, ['VariantType', 'VariantId']) ?
				this.replaceOldVariantItem('/Variants', variant, ['VariantType', 'VariantId']) :
				this.pushItemToList('/Variants', variant);
			if (variant.IsDefault === 'X') {
				this.updateDefault('/Variants', variant, 'VariantType', 'VariantId');
			}
			this.updateRemoveVariants(variant);
		},

		insertRemoveVariantItem: function(variant) {
			this.hasEntryWithIdArray('/RemoveVariants', variant, ['VariantType', 'VariantId']) ?
				this.replaceOldVariantItem('/RemoveVariants', variant, ['VariantType', 'VariantId']) :
				this.pushItemToList('/RemoveVariants', variant);
			this.removeVariant(variant.VariantType, variant.VariantId);
		},

		insertNotificationErrorMessage: function(notificationNumber, errorMessage) {
			this.setProperty(
				'/Notifications',
				(this.getProperty('/Notifications') || []).map(function(object) {
					if (object['NotifNo'] === notificationNumber) {
						object.ErrorMessage = errorMessage;
					}
					return object;
				})
			);
		},

		insertOrderErrorMessage: function(orderNumber, errorMessage) {
			this.setProperty(
				'/Orders',
				(this.getProperty('/Orders') || []).map(function(object) {
					if (object['Orderid'] === orderNumber) {
						object.ErrorMessage = errorMessage;
					}
					return object;
				})
			);
		},

		insertRouteErrorMessage: function(orderNumber, errorMessage) {
			this.setProperty(
				'/Routes',
				(this.getProperty('/Routes') || []).map(function(object) {
					if (object['Orderid'] === orderNumber) {
						object.ErrorMessage = errorMessage;
					}
					return object;
				})
			);
		},

		hasEntry: function(property, item, idProperty) {
			return this.getProperty(property).filter(function(object) {
				return object[idProperty] === item[idProperty];
			}).length !== 0;
		},

		hasEntryWithIdArray: function(property, item, aIdProperties) {
			return this.getProperty(property).filter(function(object) {
				var matchCount = 0;
				aIdProperties.map(function(idProperty) {
					if (object[idProperty] === item[idProperty]) {
						matchCount = matchCount + 1;
					}
				});
				return matchCount === aIdProperties.length;
			}).length !== 0;
		},

		replaceOldItem: function(property, item, idProperty) {
			this.setProperty(
				property,
				(this.getProperty(property) || []).map(function(object) {
					return object[idProperty] === item[idProperty] ? item : object;
				})
			);
		},

		replaceOldVariantItem: function(property, item, aIdProperties) {
			this.setProperty(
				property,
				(this.getProperty(property) || []).map(function(object) {
					var matchCount = 0;
					aIdProperties.map(function(idProperty) {
						if (object[idProperty] === item[idProperty]) {
							matchCount = matchCount + 1;
						}
					});
					return matchCount === aIdProperties.length ? item : object;
				})
			);
		},

		pushItemToList: function(property, item) {
			this.setProperty(
				property,
				(this.getProperty(property) || []).concat([item])
			);
		},

		removeNotification: function(notificationNumber) {
			this.removeItem('/Notifications', notificationNumber);
		},

		removeOrder: function(orderNumber) {
			this.removeItem('/Orders', orderNumber);
		},

		removeRoute: function(orderNumber) {
			this.removeItem('/Routes', orderNumber);
		},

		removeTimeConfirmation: function(orderNumber, operation) {
			this.setProperty(
				'/TimeConfirmations',
				this.getProperty('/TimeConfirmations').filter(function(object) {
					return operation ? !(object.Orderid === orderNumber && object.Activity === operation) : !(object.Orderid === orderNumber);
				})
			);
		},

		removeVariant: function(variantType, variantId) {
			this.setProperty(
				'/Variants',
				this.getProperty('/Variants').filter(function(object) {
					return !(object.VariantType === variantType && object.VariantId === variantId);
				})
			);
		},

		updateDefault: function(property, item, idProperty, skipId) {
			this.setProperty(
				property,
				this.getProperty(property).map(function(object) {
					if (object[idProperty] === item[idProperty] && object[skipId] !== item[skipId]) {
						object.IsDefault = '';
					}
					return object;
				})
			);
		},

		updateRemoveVariants: function(variant) {
			this.setProperty(
				'/RemoveVariants',
				this.getProperty('/RemoveVariants').filter(function(object) {
					return !(object.VariantId === variant.VariantId && object.VariantType === variant.VariantType);
				})
			);
		},

		removeItem: function(modelPath, id) {
			var idProperty = {
				'/Notifications': 'NotifNo',
				'/Orders': 'Orderid',
				'/Routes': 'Orderid'
			} [modelPath];

			this.setProperty(
				modelPath,
				this.getProperty(modelPath).filter(function(object) {
					return object[idProperty] !== id;
				})
			);
		},

		/**
		 * Sets a property for the JSON model
		 * @override
		 */
		setProperty: function() {
			JSONModel.prototype.setProperty.apply(this, arguments);
			this._storeData();
		},

		/**
		 * Sets the data for the JSON model
		 * @override
		 */
		setData: function() {
			JSONModel.prototype.setData.apply(this, arguments);
			// called from constructor: only store data after first load
			if (this._bDataLoaded) {
				this._storeData();
			}
		},

		/**
		 * Refreshes the model with the current data
		 * @override
		 */
		refresh: function() {
			JSONModel.prototype.refresh.apply(this, arguments);
			this._storeData();
		}
	});
});