sap.ui.define([
	'sap/ui/model/ValidateException',
	'sap/ui/model/SimpleType',
	'sap/ui/model/type/DateTime',
	'sap/ui/model/type/Time',
	'sap/ui/model/odata/type/Time',
	'sap/ui/model/type/Float',
	'sap/ui/model/type/String',
	'sap/ui/model/type/Integer'
], function(ValidateException, SimpleType, DateTime, TimeType, OdataTimeType, Float, StringType, Integer) {
	'use strict';

	var i18n;

	return {

		setI18n: function(i18nModel) {
			i18n = i18nModel;
		},

		UTCDate: DateTime.extend('UTCDate', {
			constructor: function() {
				DateTime.apply(this, arguments);
				this.setFormatOptions({
					UTC: true,
					pattern: 'dd.MM.yyyy'
				});
			}
		}),

		UTCDateNotInThePast: this.UTCDate.extend('UTCDateNotInThePast', {
			validateValue: function(oValue) {
				if (oValue && oValue.getTime() < new Date().setDate(new Date().getDate() - 1)) {
					throw new ValidateException(i18n.getText('START_DATE_NOT_PAST_MESSAGE'));
				}
			}
		}),

		RequiredUTCDate: this.UTCDate.extend('RequiredUTCDate', {
			validateValue: function(oValue) {
				if (oValue === null) {
					throw new ValidateException(i18n.getText('ENTER_DATE_MESSAGE'));
				}
			}
		}),

		Time: TimeType.extend('Time', {
			constructor: function() {
				TimeType.apply(this, arguments);
				this.setFormatOptions({
					UTC: true,
					pattern: 'HH:mm',
					style: 'short'
				});
			}
		}),

		InputTime: this.Time.extend('InputTime', {
			parseValue: function(oValue, sInternalType) {
				return new OdataTimeType()
					.parseValue(
						oValue.replace(/[,.]/, ':'),
						sInternalType
					);
			},
			formatValue: function(oValue, sInternalType) {
				oValue = oValue && oValue.ms || oValue && oValue.ms === 0 ? new Date(oValue.ms) : oValue;
				return new this.Time()
					.formatValue(
						oValue,
						sInternalType
					);
			}.bind(this),
			validateValue: function() {
				return true;
			}
		}),

		RequiredString: StringType.extend('RequiredString', {
			constructor: function() {
				StringType.apply(this, arguments);
				this.setConstraints({
					minLength: 1
				});
			}
		}),

		Price: Float.extend('Price', {
			constructor: function() {
				Float.apply(this, arguments);
				this.setFormatOptions({
					groupingEnabled: true,
					groupingSeparator: '',
					maxFractionDigits: 1,
					minFractionDigits: 0,
					decimalSeparator: '.'
				});
			}
		}),

		RequiredPriceWithComma: this.Price.extend('PriceWithComma', {
			parseValue: function(oValue, sInternalType) {
				return new this.Price().parseValue(oValue, sInternalType).toString();
			}.bind(this),
			validateValue: function(oValue) {
				new this.Price().validateValue(Number(oValue));
			}.bind(this)
		}),

		Percentage: Float.extend('Percentage', {
			constructor: function() {
				Float.apply(this, arguments);
				this.setFormatOptions({
					groupingEnabled: true,
					groupingSeparator: '',
					maxFractionDigits: 1,
					minFractionDigits: 0,
					decimalSeparator: '.'
				});
				this.setConstraints({
					maximum: 100,
					minimum: 0
				});
			}
		}),

		NumberAsStringInModel: this.Price.extend('NumberAsStringInModel', {
			parseValue: function(oValue, sInternalType) {
				oValue = oValue || '0.0';
				oValue = oValue.replace(',', '.');
				return new this.Price().parseValue(oValue, sInternalType).toString();
			}.bind(this),
			validateValue: function(oValue) {
				new this.Price().validateValue(Number(oValue));
			}.bind(this)
		}),

		NumberAsStringInModelDisplay: this.NumberAsStringInModel.extend('NumberAsStringInModelDisplay', {
			formatValue: function(oValue, sInternalType) {
				return oValue ? new this.Price().formatValue(oValue, sInternalType).toString().replace('.', ',') : '';
			}.bind(this)
		}),

		RequiredNumberAsStringInModel: this.Price.extend('NumberAsStringInModel', {
			parseValue: function(oValue, sInternalType) {
				if (oValue) {
					oValue = oValue.replace(',', '.');
				}
				return new this.Price().parseValue(oValue, sInternalType).toString();
			}.bind(this),
			validateValue: function(oValue) {
				new this.Price().validateValue(Number(oValue));
				if (!oValue) {
					throw new ValidateException('ENTER_NUMBER_MESSAGE');
				}
			}.bind(this)
		}),

		CustomInteger: Integer.extend('CustomInteger', {
			constructor: function() {
				Integer.apply(this, arguments);
				this.setConstraints({
					maximum: 99
				});
			}
		}),

		IntegerOrEmpty: Integer.extend('IntegerOrEmpty', {
			parseValue: function(oValue, sInternalType) {
				if (oValue) {
					return new Integer()
						.parseValue(oValue, sInternalType);
				}
			},
			validateValue: function(oValue) {
				if (oValue) {
					return new this.CustomInteger()
						.validateValue(oValue);
				}
			}.bind(this)
		}),

		QuantityWithComma: Float.extend('QuantityWithComma', {
			constructor: function() {
				Float.apply(this, arguments);
				this.setFormatOptions({
					groupingEnabled: true,
					groupingSeparator: '',
					maxFractionDigits: 3,
					minFractionDigits: 0,
					decimalSeparator: '.',
					minusSign: '-'
				});
			}
		}),

		QuantityWithCommaWithoutZeroes: this.QuantityWithComma.extend('QuantityWithCommaWithoutZeroes', {
			formatValue: function(oValue) {
				return new this.QuantityWithComma()
					.formatValue(parseFloat(oValue), 'string');
			}.bind(this),
			parseValue: function(oValue, sInternalType) {
				if (oValue) {
					oValue = oValue.replace(',', '.');
				}
				return new this.QuantityWithComma()
					.parseValue(oValue, sInternalType).toString();
			}.bind(this),
			validateValue: function(oValue) {
				new this.QuantityWithComma()
					.validateValue(Number(oValue));
			}.bind(this)
		}),

		QuantityWithCommaWithoutZeroesDisplay: this.QuantityWithCommaWithoutZeroes.extend('QuantityWithCommaWithoutZeroesDisplay', {
			formatValue: function(oValue) {
				var value = new this.QuantityWithComma().formatValue(parseFloat(oValue), 'string');
				return value ? value.replace('.', '.') : '';
			}.bind(this)
		}),

		FlagToBoolean: SimpleType.extend('FlagToBoolean', {

			formatValue: function(oValue) {
				return Boolean(oValue);
			},

			parseValue: function(oValue) {
				return oValue ? 'X' : '';
			},

			validateValue: function() {
				return true;
			}
		}),

		FlagToBooleanReverse: SimpleType.extend('FlagToBooleanReverse', {

			formatValue: function(oValue) {
				return !oValue;
			},

			parseValue: function(oValue) {
				return oValue ? '' : 'X';
			},

			validateValue: function() {
				return true;
			}
		}),

		LongTextCustomLineBreaks: SimpleType.extend('LongTextCustomLineBreaks', {

			formatValue: function(value) {
				return typeof value === 'string' ? value.replace(/\\n/g, '\n') : '';
			},

			parseValue: function(value) {
				return typeof value === 'string' ? value.replace(/\n/g, '\\n') : '';
			},

			validateValue: function() {
				return true;
			}
		}),

		RequiredLongTextCustomLineBreaks: this.LongTextCustomLineBreaks.extend('RequiredLongTextCustomLineBreaks', {
			validateValue: function(value) {
				if (!value) {
					throw new ValidateException(i18n.getText('ENTER_TEXT_MESSAGE'));
				}
			}
		}),

		DecodedUri: SimpleType.extend('DecodedUri', {

			formatValue: function(value) {
				return value ? decodeURI(value) : '';
			},

			parseValue: function(value) {
				return value ? decodeURI(value) : '';
			},

			validateValue: function() {
				return true;
			}
		})
	};
});