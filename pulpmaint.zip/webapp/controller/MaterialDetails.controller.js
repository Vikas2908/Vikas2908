sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController',
	'sap/m/TablePersoController',
	'com/upm/maint/util/personalization/MaterialDetailsPersonalization'
], function(CommonController, BaseController, TablePersoController, MaterialDetailsPersonalization) {
	return CommonController.extend('com.upm.maint.controller.MaterialDetails', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('MaterialDetailsModel');
			this.setModel('AttachmentModel');
			this.setModel('MaterialSearchResultsModel');
			this.setModel('SearchParameters');

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.oTablePersoController = new TablePersoController({
				table: this.getView().byId('materialDetailsItemTable'),
				persoService: MaterialDetailsPersonalization
			}).activate();
		},

		routeMatched: function(oEvent) {
			if (oEvent.getParameter('name') === 'MaterialDetails') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				this.loadUserParameters();
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {
				if (!this.checkUserParameters()) {
					this.allMandatoryParametersNotSet();
				}
			}
		},

		/* =========================================================== */
		/* Application Logic     	                                   */
		/* =========================================================== */

		openFileUploadPopup: function() {
			this.openSimpleDialog('FileUploadDialog');
		},

		onFileUploadDialogCloseButtonPress: function() {
			this.getDialog('FileUploadDialog').close();
		},

		onAfterUploadDialogClose: function() {
			var oAttachmentModel = this.getModel('AttachmentModel');
			oAttachmentModel.setProperty('Attachments', {});
		},

		onUploadCollectionChange: function(oEvent) {
			if (oEvent) {
				var oMaterialModel = this.getModel('MaterialModel');
				var material = oMaterialModel.getProperty('/MaterialNumber');
				var oDataModel = this.oDataUtil.getWMODataModel('ZWM_COMMON_SRV');
				var sSecurityToken = oDataModel.getSecurityToken();
				var oUploadCollection = oEvent.getSource();
				var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
					name: 'slug',
					value: oEvent.getParameter('files')[0].name + '|' + oEvent.getParameter('files')[0].type + '|' + material
				});
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'X-CSRF-Token',
					value: sSecurityToken
				}));
				oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'Accept',
					value: 'application/json'
				}));
			}
		},

		onUploadComplete: function(oEvent) {
			if (oEvent) {
				this.onFileUploadDialogCloseButtonPress();
				this.openSuccessMessagePopup(this.getResourceBundleText('FILEUPLOAD_SUCCESS_MESSAGE'));
			}
		},

		onCapture: function() {
			this.cordovaCameraUtil.handleCaptureImage(this.onSuccess, this.onFail);
		},

		onSelect: function() {
			this.cordovaCameraUtil.handleSelectImage(this.onSuccess, this.onFail);
		},

		onSuccess: function(imageURI) {
			var imageId = this.getFragmentElementById('FileUploadDialog', 'imageId');
			imageId.setSrc('data:image/jpg;base64,' + imageURI);
			this.getFragmentElementById('FileUploadDialog', 'uploadImageButton').setVisible(true);
		},

		onFail: function(message) {
			sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.Error, 'Error');
		},

		onUpload: function() {
			var imageData = sap.ui.core.Fragment.byId('fileUploadDialog', 'imageId').getSrc();

			var base64Marker = 'data:image/jpg;base64,';
			var base64Index = imageData.indexOf(base64Marker) + base64Marker.length;
			var base64EncodedData = imageData.substring(base64Index);
			var blob = this.cordovaCameraUtil.b64toBlob(base64EncodedData, 'image/jpg');

			var oMaterialModel = this.getModel('MaterialModel');
			var material = oMaterialModel.getProperty('/MaterialNumber');

			var oDataModel = this.oDataUtil.getWMODataModel('ZWM_COMMON_SRV');
			var sSecurityToken = oDataModel.getSecurityToken();

			var currentDate = new Date();
			currentDate.setHours(currentDate.getHours());
			currentDate.setMinutes(currentDate.getMinutes());
			currentDate.setSeconds(currentDate.getSeconds());
			var fileName = this.formatterUtil.formateDateAndTimeForAttachment(currentDate) + '.jpg';

			var xhr = new XMLHttpRequest();
			//xhr.open('POST', '/odata/SAP/ZWM_COMMON_SRV/AttachmentDataSet', true);
			xhr.open('POST', '/odata/SAP/ZWM_COMMON_SRV/DmsFileSet', true);
			xhr.setRequestHeader('slug', fileName + '|' + 'image/jpg' + '|' + material);
			xhr.setRequestHeader('Content-Type', 'image/jpg');
			xhr.setRequestHeader('Accept', 'application/json');
			xhr.setRequestHeader('X-CSRF-Token', sSecurityToken);

			xhr.upload.onprogress = function(e) {
				if (e.lengthComputable) {
					var percentComplete = (e.loaded / e.total) * 100;
					console.log(percentComplete + '% uploaded');
				}
			};

			xhr.onerror = function() {
				console.log('Error');
			};

			xhr.onload = function() {
				if (xhr.status === 201) {
					var successMessage = this.getResourceBundleText('FILEUPLOAD_SUCCESS_MESSAGE');
					sap.m.MessageBox.show(successMessage, sap.m.MessageBox.Icon.Info, 'Success');
					this.getFragmentElementById('FileUploadDialog', 'uploadImageButton').setVisible(false);
					var imageId = this.getFragmentElementById('FileUploadDialog', 'imageId');
					imageId.setSrc('');
				} else {
					sap.m.MessageBox.show(xhr.status + ' ' + xhr.statusText, sap.m.MessageBox.Icon.Error, 'Error');
				}
			}.bind(this);
			xhr.send(blob);
		},

		onFileTooLarge: function() {
			//this.openErrorMessagePopup('ERROR_FILE_TOO_LARGE');
		},

		getAttachmentsUrl: function(docId, notifNo) {
			var printUrl = '';
			var serviceUrl = this.oDataUtil.getServiceUrl('ZWM_COMMON_SRV');
			if (docId && notifNo) {
				printUrl = serviceUrl + '/AttachmentDataSet(DocId=\'' + docId + '\',NotifNo=\'' + notifNo + '\')/$value';
			}
			return printUrl;
		},

		getAttachmentsUrlForThumbnail: function(docId, notifNo, mimetype) {
			var printUrl = '';
			var serviceUrl = this.oDataUtil.getServiceUrl('ZWM_COMMON_SRV');
			var mimetypeIsImage = mimetype.indexOf('image') !== -1;
			if (docId && notifNo && mimetypeIsImage) {
				printUrl = serviceUrl + '/AttachmentDataSet(DocId=\'' + docId + '\',NotifNo=\'' + notifNo + '\')/$value';
			}
			return printUrl;
		},

		onPersonalizationPress: function(oEvent) {
			if (oEvent) {
				this.oTablePersoController.openDialog();
			}
		},

		onSortPress: function() {
			this.openSimpleDialog('MaterialDetailsSortDialog');
		},

		handleSort: function(oEvent) {
			if (oEvent) {
				var oTable = this.getElementById('materialDetailsItemTable');
				var mParams = oEvent.getParameters();
				var oBinding = oTable.getBinding('items');
				var aSorters = [new sap.ui.model.Sorter(mParams.sortItem.getKey(), mParams.sortDescending)];
				oBinding.sort(aSorters);
			}
		},

		/* =========================================================== */
		/* oData Service				                          	   */
		/* =========================================================== */

		materialSearch: function(materialNumber) {
			var searchParams = this.getModel('SearchParameters').getData();
			var plant = searchParams.Plant || '';
			var storageLocation = searchParams.StorageLocation || '';
			this.openBusyDialog();
			setTimeout(function() {
				this.getMaterialDetails(materialNumber, plant, storageLocation);
			}.bind(this), 0);
		},

		getMaterialDetails: function(materialNumber, plant, storageLocation) {
			var oMaterialDetailsModel = this.getModel('MaterialDetailsModel');
			oMaterialDetailsModel.setData({});
			if (materialNumber && materialNumber.length > 0) {
				$.when(this.oDataUtil.read('MaterialMoveHdrSet(MaterialNumber=\'' + materialNumber + '\',PlantId=\'' + plant + '\',StorageLocation=\'' + storageLocation + '\')?$expand=Items', {
						wmService: 'ZWM_COMMON_SRV'
					})
					.done(function(oData) {
						if (oData.MaterialNumber) {
							oMaterialDetailsModel.setData(oData);
							this.clearBarcodeInput();
							var list = this.getElementById('materialDetailsItemTable');
							this.sortList(list, [{
								propertyName: 'PostingDate',
								desc: true
							}, {
								propertyName: 'PostingTime',
								desc: true
							}, {
								propertyName: 'MaterialDocument',
								desc: true
							}]);
							this.getElementById('photoUploader').setVisible(true);
						} else {
							sap.m.MessageBox.show(this.getResourceBundleText('ERROR_MESSAGE_MATERIAL_NOT_FOUND', materialNumber), sap.m.MessageBox.Icon.INFO, this.getResourceBundleText('COMMON_INFO_TITLE'));
							this.clearBarcodeInput();
							this.getElementById('photoUploader').setVisible(false);
						}
					}.bind(this))
					.fail(function(oError) {
						if (oError) {
							this.clearBarcodeInput();
							this.getElementById('photoUploader').setVisible(false);
						}
					}.bind(this))
					.always(this.closeBusyDialog.bind(this))
				);
			}
		},

		sortList: function(list, sorters, groupBy) {
			var binding = list.getBinding('items');

			// create group function if group given
			var groupFn = null;
			if (groupBy) {
				groupFn = function(oContext) {
					return oContext.getObject() ? oContext.getObject()[groupBy] : '';
				};
			}

			// Sort
			var oSorter = new sap.ui.model.Sorter('', null, groupFn);
			oSorter.fnCompare = function(a, b) {
				if (groupBy && (a[groupBy] < b[groupBy])) {
					return -1;
				} else if (groupBy && (a[groupBy] > b[groupBy])) {
					return 1;
				} else if (!sorters) {
					return 0;
				} else {
					var res = 0;
					$.each(sorters, function(index, sorter) {
						if (a[sorter.propertyName] < b[sorter.propertyName]) {
							res = sorter.desc ? 1 : -1;
							return false;
						} else if (a[sorter.propertyName] > b[sorter.propertyName]) {
							res = sorter.desc ? -1 : 1;
							return false;
						}
					});
					return res;
				}
			};
			binding.sort(oSorter);
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		parseMaterialBarcode: function(value) {
			if (value) {
				var parsedValue = parseInt(value, 10);
				this.materialSearch(parsedValue.toString());
			}
		},

		onScannedOrderValueChange: function(oEvt) {
			if (oEvt) {
				var value = oEvt.getParameter('value');
				if (value) {
					this.parseMaterialBarcode(value);
				}
			}
		},

		onScanSuccess: function(oEvt) {
			if (oEvt) {
				var value = oEvt.getParameter('value');
				if (value) {
					this.parseMaterialBarcode(value);
				}
			}
		},

		onScanError: function(oEvt) {
			var errorMessage = '';
			if (oEvt) {
				errorMessage = oEvt.getParameter('value');
			}
			this.openErrorMessagePopup(errorMessage, null);
		},

		clearBarcodeInput: function() {
			this.getElementById('barcodeInput').setValue('');
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		specialStockFormatter: function(value) {
			if (value && value === 'X') {
				return 'sap-icon://accept';
			} else {
				return '';
			}
		},

		/* Trex material search */
		onMaterialTrexSearchPress: function(oEvent) {
			if (oEvent) {
				var oMaterialSearchResultsModel = this.getModel('MaterialSearchResultsModel');
				oMaterialSearchResultsModel.setData({});
				this.openSimpleDialog('WMMaterialSearchTrex');
			}
		},

		onTrextDialogCloseButtonPress: function() {
			this.getDialog('WMMaterialSearchTrex').close();
		},

		onMaterialListItemPress: function(oEvent) {
			if (oEvent) {
				this.onTrextDialogCloseButtonPress();
				var selectedMaterialObject = oEvent.getSource().getBindingContext('MaterialSearchResultsModel').getObject();
				if (selectedMaterialObject) {
					this.materialSearch(selectedMaterialObject.Material);
				}
			}
		},

		onMaterialInputSearchPress: function(oEvent) {
			if (oEvent) {
				var oMaterialSearchResultsModel = this.getModel('MaterialSearchResultsModel');
				var searchTerm = this.getFragmentElementById('WMMaterialSearchTrex', 'materialInput').getValue();
				var searchObject = this.getSearchObject(searchTerm);
				this.openBusyDialog();
				var query = 'MaterialSearchTREXSet';
				var filters = this.generateFilter('Plant', [searchObject.Plant])
					.concat(this.generateFilter('Warehouse', [searchObject.Warehouse]))
					.concat(this.generateFilter('SearchTerm', [searchTerm]));
				this.oDataUtil.read(query, {
						wmService: 'ZWM_COMMON_SRV',
						filters: filters
					}).done(function(oData) {
						if (oData) {
							oMaterialSearchResultsModel.setData(oData);
						}
					}).fail(function() {})
					.always(this.closeBusyDialog.bind(this));
			}
		},

		getSearchObject: function(searchTerm) {
			var searchParams = this.getModel('SearchParameters').getData();
			var warehouse = searchParams.Warehouse || '';
			var plant = searchParams.Plant || '';
			var searchObject = {};
			searchObject.SearchTerm = searchTerm;
			searchObject.Warehouse = warehouse;
			searchObject.Plant = plant;
			searchObject.PlantDesc = '';
			searchObject.Material = '';
			searchObject.MaterialDesc = '';
			searchObject.Quantity = '';
			searchObject.Unit = '';
			searchObject.StorageLoc = '';
			searchObject.StorageBin = '';
			searchObject.StorageType = '';
			searchObject.StorageTypeDesc = '';
			searchObject.SpecialStock = '';
			searchObject.SpecialStockNumber = '';
			searchObject.Type = '';
			return searchObject;
		},

		loadUserParameters: function() {
			var searchParameters = this.getModel('SearchParameters');
			var userParams = this.getUserParameters();
			var plants = this.getModel('SelectionValuesModel').getProperty('/Plants') || [];
			var plant = userParams.Plant || '';
			var warehouse = userParams.Warehouse || '';
			var storLoc = '';
			plants.some(function(object) {
				if (object.Plant === plant) {
					storLoc = object.DefaultStorageLoc || '';
					return true;
				}
			});
			searchParameters.setData({
				Plant: plant,
				Warehouse: warehouse,
				StorageLocation: storLoc
			});
		},

		checkUserParameters: function() {
			var params = this.getModel('SearchParameters').getData() || {};
			if (params.Plant === '' || params.Warehouse === '') {
				return false;
			}
			return true;
		},

		allMandatoryParametersNotSet: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WM_PARAMETERS_MISSING_TITLE'),
				message: this.getResourceBundleText('WM_PARAMETERS_MISSING_TEXT'),
				onClose: this.handleMandatoryParemetersNotSetClose.bind(this),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleMandatoryParemetersNotSetClose: function(action) {
			if (action === 'YES') {
				this.navTo('UserParameters', {}, true);
			} else {
				this.onNavBack();
			}
		}
	});
});