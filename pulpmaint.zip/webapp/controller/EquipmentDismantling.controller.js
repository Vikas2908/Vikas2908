sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.EquipmentDismantling', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel', {
				DismantledEquipmentIsValid: true,
				InstalledEquipmentIsValid: true,
				FunctionalLocationToInstallInIsValid: true,
				ScanToKey: '',
				HierarchyStartingPoint: ''
			});

			this.subscribeToEvent('functionalLocationSelected', 'EquipmentToDismantle', this.handleEquipmentToDismantleSelected.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'EquipmentToInstall', this.handleEquipmentToInstallSelected.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'FunctionalLocationToInstallIn', this.handleFunctionalLocationToInstallInSelected.bind(this));
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'EquipmentDismantling') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getModel('ViewModel').setData({
					DismantledEquipmentIsValid: true,
					InstalledEquipmentIsValid: true,
					FunctionalLocationToInstallInIsValid: true,
					ScanToKey: '',
					HierarchyStartingPoint: ''
				});
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			this.shouldShowWarningMessage() ?
				this.openNavigationConfimation() :
				this.onNavBack();
		},

		onEquipmentToDismantleChange: function(changeEvent) {
			this.validateEquipmentToDismantle(this.getIdFromChangeEvent(changeEvent));
		},

		onPressScanEquipmentToDismantle: function() {
			this.getModel('ViewModel').setProperty('/ScanToKey', 'DISMANTLE');

			this.onPressScanTechnicalObject();
		},

		onEquipmentToInstallChange: function(changeEvent) {
			this.validateEquipmentToInstall(this.getIdFromChangeEvent(changeEvent));
		},

		onPressScanEquipmentToInstall: function() {
			this.getModel('ViewModel').setProperty('/ScanToKey', 'INSTALL');

			this.onPressScanTechnicalObject();
		},

		onFunctionalLocationToInstallInChange: function(changeEvent) {
			this.validateFunctionalLocationToInstallIn(this.getIdFromChangeEvent(changeEvent));
		},

		onPressScanFunctionalLocationToInstallIn: function() {
			this.getModel('ViewModel').setProperty('/ScanToKey', 'INSTALLTO');

			this.onPressScanTechnicalObject();
		},

		onPressNavigateToHierarchyEquipmentToDismantle: function() {
			var startingPoint = this.getModel('ViewModel').getProperty('/HierarchyStartingPoint');

			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'EquipmentToDismantle');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(startingPoint);
		},

		onPressNavigateToHierarchyEquipmentToInstall: function() {
			var startingPoint = this.getModel('ViewModel').getProperty('/HierarchyStartingPoint');

			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'EquipmentToInstall');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(startingPoint);
		},

		onPressNavigateToHierarchyFunctionalLocationToInstallIn: function() {
			var startingPoint = this.getModel('ViewModel').getProperty('/HierarchyStartingPoint');

			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'FunctionalLocationToInstallIn');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(startingPoint);
		},

		onReplaceButtonPress: function() {
			this.isValid() ? this.postReplacement() : this.getModel('ViewModel').updateBindings(true);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		shouldShowWarningMessage: function() {
			var equipmentModel = this.getModel('NewEquipmentDismantlingModel');

			return !!(equipmentModel.getProperty('/EqunrOld') || equipmentModel.getProperty('/EqunrNew'));
		},

		handleScanSuccess: function(result) {
			var scanResult = result && result.text || '';

			var scanToKey = this.getModel('ViewModel').getProperty('/ScanToKey');

			if (scanToKey === 'DISMANTLE') {
				this.validateEquipmentToDismantle(scanResult);
			} else if (scanToKey === 'INSTALL') {
				this.validateEquipmentToInstall(scanResult);
			} else if (scanToKey === 'INSTALLTO') {
				this.validateFunctionalLocationToInstallIn(scanResult);
			}
		},

		handleEquipmentToDismantleSelected: function(channel, eventName, selectedObject) {
			this.validateEquipmentToDismantle(selectedObject.InternalId);
		},

		validateEquipmentToDismantle: function(equipmentNumber) {
			var parameters = {
				online: true
			};

			if (equipmentNumber) {
				this.validateEquipment(equipmentNumber, parameters)
					.done(this.handleEquipmentToDismantleValid.bind(this))
					.fail(this.handleEquipmentToDismantleNotValid.bind(this, equipmentNumber));
			} else {
				this.handleEquipmentToDismantleValid({});
			}
		},

		handleEquipmentToDismantleValid: function(equipment) {
			this.getModel('NewEquipmentDismantlingModel').setProperty('/EqunrOld', equipment.Equnr || '');
			this.getModel('NewEquipmentDismantlingModel').setProperty('/EqunrOldDescr', equipment.Descr || '');
			this.getModel('ViewModel').setProperty('/HierarchyStartingPoint', equipment.SupflocInternalId || '');

			this.getModel('ViewModel').setProperty('/DismantledEquipmentIsValid', true);
		},

		handleEquipmentToDismantleNotValid: function(equipmentNumber) {
			this.getModel('ViewModel').setProperty('/DismantledEquipmentIsValid', false);

			this.openEquipmentNotFoundMessage(equipmentNumber);
		},

		handleEquipmentToInstallSelected: function(channel, eventName, selectedObject) {
			this.validateEquipmentToInstall(selectedObject.InternalId);
		},

		validateEquipmentToInstall: function(equipmentNumber) {
			var parameters = {
				online: true
			};

			if (equipmentNumber) {
				this.validateEquipment(equipmentNumber, parameters)
					.done(this.handleEquipmentToInstallValid.bind(this))
					.fail(this.handleEquipmentToInstallNotValid.bind(this, equipmentNumber));
			} else {
				this.handleEquipmentToInstallValid({});
			}
		},

		handleEquipmentToInstallValid: function(equipment) {
			this.getModel('NewEquipmentDismantlingModel').setProperty('/EqunrNew', equipment.Equnr || '');
			this.getModel('NewEquipmentDismantlingModel').setProperty('/EqunrNewDescr', equipment.Descr || '');

			this.getModel('NewEquipmentDismantlingModel').setProperty('/FlocForOldEquInternalId', equipment.SupflocInternalId || '');

			this.getModel('ViewModel').setProperty('/HierarchyStartingPoint', equipment.SupflocInternalId || '');

			this.getModel('ViewModel').setProperty('/InstalledEquipmentIsValid', true);

			if (equipment.SupflocInternalId) {
				this.validateFunctionalLocationToInstallIn(equipment.SupflocInternalId);
			}
		},

		handleEquipmentToInstallNotValid: function(equipmentNumber) {
			this.getModel('ViewModel').setProperty('/InstalledEquipmentIsValid', false);

			this.openEquipmentNotFoundMessage(equipmentNumber);
		},

		openEquipmentNotFoundMessage: function(equipmentNumber) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('EQUIPMENT_NOT_FOUND_TITLE'),
				message: this.getResourceBundleText('EQUIPMENT_NOT_FOUND_MESSAGE', equipmentNumber)
			});
		},

		handleFunctionalLocationToInstallInSelected: function(channel, eventName, selectedObject) {
			this.validateFunctionalLocationToInstallIn(selectedObject.InternalId);
		},

		validateFunctionalLocationToInstallIn: function(functionalLocation) {
			var parameters = {
				online: true
			};

			if (functionalLocation) {
				this.validateFunctionalLocation(functionalLocation, parameters)
					.done(this.handleFunctionalLocationToInstallInValid.bind(this))
					.fail(this.handleFunctionalLocationToInstallInNotValid.bind(this, functionalLocation));
			} else {
				this.handleEquipmentToInstallValid({});
			}
		},

		handleFunctionalLocationToInstallInValid: function(functionalLocation) {
			this.getModel('NewEquipmentDismantlingModel').setProperty('/FlocForOldEquInternalId', functionalLocation.InternalId || '');
			this.getModel('NewEquipmentDismantlingModel').setProperty('/FlocForOldEqu', functionalLocation.Floc || '');
			this.getModel('NewEquipmentDismantlingModel').setProperty('/FlocForOldEquDescr', functionalLocation.Descr || '');

			this.getModel('ViewModel').setProperty('/HierarchyStartingPoint', functionalLocation.InternalId || '');

			this.getModel('ViewModel').setProperty('/FunctionalLocationToInstallInIsValid', true);
		},

		handleFunctionalLocationToInstallInNotValid: function() {
			this.getModel('ViewModel').setProperty('/FunctionalLocationToInstallInIsValid', false);
		},

		isValid: function() {
			return this.validate() && this.getModel('ViewModel').getProperty('/DismantledEquipmentIsValid') && this.getModel('ViewModel').getProperty('/InstalledEquipmentIsValid');
		},

		postReplacement: function() {
			var postObject = $.extend(true, {}, this.getModel('NewEquipmentDismantlingModel').getData());
			var postParameters = {
				online: true
			};

			postObject.FlocForOldEqu = postObject.FlocForOldEquInternalId;
			delete postObject.FlocForOldEquInternalId;
			delete postObject.FlocForOldEquDescr;

			this.setAppBusyMode();
			this.oDataUtil.create('EquipmentChangeSet', postObject, postParameters)
				.done(this.handleCreateSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleCreateSuccess: function(response) {
			this.openSuccessDialog(
				this.getResourceBundleText('EQUIPMENT_REPLACED_SUCCESS_MESSAGE', [response.EqunrOld, response.EqunrNew])
			);
		}

	});
});