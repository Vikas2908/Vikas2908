sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.ObjectInfo', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.subscribeToEvent('functionalLocationSelected', 'ObjectInfoSelection', this.handleTechnicalObjectSelectedFromHierarchy.bind(this));

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));

			this.subscribeToEvent('root', 'networkFound', this.handleOnline.bind(this));

			this.subscribeToEvent('notification', 'notificationChanged', this.handleNotificationChange.bind(this));
			this.subscribeToEvent('order', 'orderChanged', this.handleOrderChange.bind(this));

			this.setModel('ViewModel');
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'TechnicalObject') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				var navigationArguments = navigationEvent.getParameter('arguments');
				var query = navigationArguments['?query'];
				var technicalObject = navigationArguments['TechnicalObject'];

				this.getModel('ViewModel').setProperty(
					'/IconTabBarSelectedKey',
					query && query.Tab || 'Header'
				);

				if (this.shouldGetTechnicalObjectFromNavigationParameters(technicalObject)) {
					this.getModel('ViewModel').setProperty('/pictureSrc', '');
					// had to do some modification for the equipment syntax so it can pass navigation
					this.getTechnicalObjectDetails(technicalObject.replace(/\\/g, '/'));
				}
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.isObjectInfoRoute(navigationData)) {
				if (this.navigatedFromObjectInfoSelection(navigationData)) {
					this.getModel('ViewModel').setProperty('/pictureSrc', '');
					this.getTechnicalObjectValues(this.getCurrentObject());
				}
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNotificationPress: function(pressEvent) {
			var notificationNumber = pressEvent
				.getParameter('listItem')
				.getBindingContext('ObjectInfoModel')
				.getObject()
				.NotifNo;

			this.handleNavigateToNotification(notificationNumber);
		},

		onOrderPress: function(pressEvent) {
			var orderNumber = pressEvent
				.getParameter('listItem')
				.getBindingContext('ObjectInfoModel')
				.getObject()
				.Orderid;

			this.handleNavigateToOrder(orderNumber);
		},

		onPressNavigateToHierarchy: function() {
			var functionalLocation = this.isFunctionalLocation() ? this.getCurrentObjectId() : this.getCurrentSuperiorFunctionalLocation();
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'ObjectInfoSelection');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', true);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', true);

			this.navigateToHierarchy(functionalLocation);
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('ObjectInfoActionButtons').openBy(pressEvent.getSource());
		},

		onPictureActionsButtonPress: function(pressEvent) {
			this.initializeFragment('ObjectInfoPictureActionButtons').openBy(pressEvent.getSource());
		},

		onIconTabBarSelectionChange: function(selectEvent) {
			var selectedKey = selectEvent.getParameter('selectedKey');

			this.setSelectedIconTabBar(selectedKey);
		},

		onCreateNotificationPress: function() {
			var object = this.getCurrentObject();
			var isFunctionalLocation = this.isFunctionalLocation();

			var functLocInternal = '';
			if (isFunctionalLocation) {
				functLocInternal = this.getConfigurationModel().getUseAlternativeLabeling() ? object.InternalId : object.Floc;
			} else {
				functLocInternal = this.getConfigurationModel().getUseAlternativeLabeling() ? object.SupflocInternalId : object.Equnr;
			}
			this.getModel('NewNotificationModel').setData(this.models.getNotificationDefaults({
				FunctLocInternalId: functLocInternal,
				FunctLoc: isFunctionalLocation ? object.Floc : object.Supfloc,
				Equipment: isFunctionalLocation ? '' : object.Equnr,
				WorkcenterPlant: object.Planplant || '',
				Planplant: object.Planplant || ''
			}));

			this.navTo('CreateNotification', {
				Purpose: 'Create'
			});
		},

		onOpenMeasurementDocument: function() {
			var technicalObject = this.getCurrentObject();
			var isFunctionalLocation = this.isFunctionalLocation();

			this.openMeasurementPointDialog(isFunctionalLocation ? technicalObject.Floc : technicalObject.Supfloc, isFunctionalLocation ? '' : technicalObject.Equnr, 'ObjectInfoModel');
		},

		onOpenMeasurementHistory: function() {
			var parameters = {
				ModelName: 'ObjectInfoModel'
			};
			this.openDialog('MeasurementPointHistory', parameters);
		},

		onPressWriteNFCTag: function() {
			this.writeNFCTag(this.getCurrentObjectId());
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		isObjectInfoRoute: function() {
			return location.hash.split('/').indexOf('TechnicalObject') !== -1;
		},

		navigatedFromNotification: function(navigationData) {
			return this.navigatedFrom(navigationData.fromView, 'NotificationSplitContainer');
		},

		navigatedFromOrder: function(navigationData) {
			return this.navigatedFrom(navigationData.fromView, 'OrderSplitContainer');
		},

		navigatedFromObjectInfoSelection: function(navigationData) {
			return this.navigatedFrom(navigationData.fromView, 'ObjectInfoSelection');
		},


		technicalObjectValid: function(technicalObject) {
			if (technicalObject) {
				this.getObjectInfoModel().setProperty('/TechnicalObject', technicalObject);

				this.getTechnicalObjectValues(technicalObject);
			}
		},

		technicalObjectNotValid: function(technicalObject) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('NOT_FOUND_PAGE_TITLE'),
				message: this.getResourceBundleText('TECHNICAL_OBJECT_NOT_FOUND', technicalObject)
			});
		},

		handleTechnicalObjectSelectedFromHierarchy: function(channel, eventName, selectedObject) {
			setTimeout(function() {
				this.navTo('TechnicalObject', {
					TechnicalObject: (selectedObject.Floc || '').replace(/\//g, '\\'),
					query: {
						Tab: 'Header'
					}
				});
			}.bind(this), 0);
		},

		getCurrentObject: function() {
			return this.getObjectInfoModel().getProperty('/TechnicalObject');
		},

		getCurrentObjectId: function() {
			var technicalObjectID = '';
			var currentObject = this.getCurrentObject();

			if (currentObject) {
				technicalObjectID = currentObject.InternalId || currentObject.Equnr;
			}

			return technicalObjectID;
		},

		getCurrentSuperiorFunctionalLocation: function() {
			var currentObject = this.getCurrentObject();

			return currentObject.Supfloc;
		},

		isFunctionalLocation: function() {
			var currentObject = this.getCurrentObject();

			return !!currentObject.Floc;
		},

		shouldGetTechnicalObjectFromNavigationParameters: function(technicalObject) {
			return technicalObject && technicalObject !== this.getCurrentObjectId();
		},

		setSelectedIconTabBar: function(tabBarKey) {
			if (this.getCurrentObjectId()) {
				this.navTo('TechnicalObject', {
					TechnicalObject: this.getCurrentObjectId().replace(/\//g, '\\'),
					query: {
						Tab: tabBarKey
					}
				}, true);
			}
		},

		handleNotificationChange: function(channel, eventName, notification) {
			var currentObject = this.getCurrentObjectId();
			var isFunctionalLocation = this.isFunctionalLocation();
			var notificationTechnicalObject = isFunctionalLocation ? notification.FunctLoc : notification.Equipment;
			if (currentObject === notificationTechnicalObject) {
				this.refreshNotifications();
			}
		},

		handleOrderChange: function(channel, eventName, notification) {
			var currentObject = this.getCurrentObjectId();
			var isFunctionalLocation = this.isFunctionalLocation();
			var notificationTechnicalObject = isFunctionalLocation ? notification.FunctLoc : notification.Equipment;
			if (currentObject === notificationTechnicalObject) {
				this.refreshOrders();
			}
		},

		getTechnicalObjectDetails: function(technicalObject) {
			var busyPath = '/IsDownloadingTechnicalObjecDetails';
			this.setPathBusy(busyPath);
			this.validateTechnicalObjectDetails(technicalObject)
				.done(this.technicalObjectValid.bind(this))
				.fail(this.technicalObjectNotValid.bind(this, technicalObject))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		getTechnicalObjectValues: function(technicalObject) {
			var isFunctionalLocation = this.isFunctionalLocation();
			var technicalObjectID = isFunctionalLocation ? technicalObject.InternalId : technicalObject.Equnr;

			this.getNotificationsForTechnicalObject(technicalObjectID, technicalObject.Planplant, isFunctionalLocation);
			this.getOrdersForTechnicalObject(technicalObjectID, technicalObject.Planplant, isFunctionalLocation);
			this.getDocumentsForTechnicalObject(technicalObjectID, isFunctionalLocation);
			this.getMeasurementsForTechnicalObject(technicalObjectID, isFunctionalLocation);
		},

		refreshNotifications: function() {
			var technicalObject = this.getCurrentObject();

			var isFunctionalLocation = this.isFunctionalLocation();
			var technicalObjectID = isFunctionalLocation ? technicalObject.Floc : technicalObject.Equnr;

			this.getNotificationsForTechnicalObject(technicalObjectID, technicalObject.Planplant, isFunctionalLocation);
		},

		getNotificationsForTechnicalObject: function(technicalObjectID, plant, isFunctionalLocation) {
			var busyPath = '/IsDownloadingTechnicalObjectNotifications';

			var notificationDateFilter = new sap.ui.model.Filter('NotifDate', sap.ui.model.FilterOperator.BT, this.getFilteringEndDate(), this.getFilteringStartDate());

			var notificationParameters = {
				online: !this.isOffline(),
				filters: this.generateFilter('WorkcenterPlant', [plant]).concat(
					this.generateFilter(isFunctionalLocation ? 'FunctLocInternalId' : 'Equipment', [technicalObjectID]),
					this.generateFilter('SystemStatuses', ['I0068']),
					this.generateFilter('SystemStatuses', ['I0070']),
					this.generateFilter('SystemStatuses', ['I0072']),
					notificationDateFilter
				),
				urlParameters: {
					'$expand': 'Attachments'
				}
			};

			this.setPathBusy(busyPath);
			this.oDataUtil.read('NotifSet', notificationParameters)
				.done(this.handleGetNotificationsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGetNotificationsSuccess: function(notifications) {
			this.getObjectInfoModel().setProperty('/Notifications', notifications.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
		},

		refreshOrders: function() {
			var technicalObject = this.getCurrentObject();

			var isFunctionalLocation = this.isFunctionalLocation();
			var technicalObjectID = isFunctionalLocation ? technicalObject.Floc : technicalObject.Equnr;

			this.getOrdersForTechnicalObject(technicalObjectID, technicalObject.Planplant, isFunctionalLocation);
		},

		getOrdersForTechnicalObject: function(technicalObjectID, plant, isFunctionalLocation) {
			var busyPath = '/IsDownloadingTechnicalObjectOrders';

			var orderDateFilter = new sap.ui.model.Filter('ReferenceDate', sap.ui.model.FilterOperator.BT, this.getFilteringEndDate(), this.getFilteringStartDate());

			var orderParameters = {
				online: !this.isOffline(),
				filters: this.generateFilter('WorkcenterPlant', [plant]).concat(
					this.generateFilter(isFunctionalLocation ? 'FunctLocInternalId' : 'Equipment', [technicalObjectID]),
					this.generateFilter('SystemStatus', ['I0001']),
					this.generateFilter('SystemStatus', ['I0002']),
					this.generateFilter('SystemStatus', ['I0045']),
					orderDateFilter
				),
				urlParameters: {
					'$expand': 'Operations,Attachments,Components,Assignments,Objects,Measurements'
				}
			};

			this.setPathBusy(busyPath);
			this.oDataUtil.read('WorkOrderSet', orderParameters)
				.done(this.handleGetOrdersSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGetOrdersSuccess: function(orders) {
			this.getObjectInfoModel().setProperty('/Orders', orders.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
		},

		refreshDocuments: function() {
			this.getDocumentsForTechnicalObject(this.getCurrentObjectId(), this.isFunctionalLocation());
		},

		getDocumentsForTechnicalObject: function(technicalObjectID, isFunctionalLocation) {
			var busyPath = '/IsDownloadingTechnicalObjectDocuments';

			var technicalObjectreadParameters = {
				filters: this.generateFilter('SapObjectId', [technicalObjectID])
					.concat(this.generateFilter('SapObjectType', [isFunctionalLocation ? 'IFLOT' : 'EQUI'])),
				online: true,
				urlParameters: {
					'$expand': 'Files'
				}
			};

			if (!this.isOffline()) {
				this.setPathBusy(busyPath);
				this.oDataUtil.read('DmsDocumentSet', technicalObjectreadParameters)
					.done(this.handleGetDocumentsSuccess.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setPathNotBusy.bind(this, busyPath));
			}
		},

		handleGetDocumentsSuccess: function(documents) {
			this.getObjectInfoModel().setProperty('/Documents', documents);

			this.setDefaultPicture(documents);
		},

		setDefaultPicture: function(documents) {
			var fileId;
			var storageCategory;
			var url;

			documents.forEach(function(document) {
				document.Files.results.forEach(function(file) {
					if (file.DefaultPicture) {
						fileId = file.FileId;
						storageCategory = file.StorageCategory;
					}
				});
			});

			if (fileId && storageCategory) {
				url = this.formatterUtil.formatDMSFileUrl.call(this, fileId, storageCategory);
				this.getModel('ViewModel').setProperty('/pictureSrc', url);
			}
		},

		getMeasurementsForTechnicalObject: function(technicalObjectID, isFunctionalLocation) {
			var measurementParameters = {
				online: true,
				filters: this.generateFilter(isFunctionalLocation ? 'FunclocInternalId' : 'Equipment', [technicalObjectID])
			};

			if (!this.isOffline()) {
				this.oDataUtil.read('MeasurementSet', measurementParameters)
					.done(this.handleGetMeasurementsSuccess.bind(this));
			}
		},

		handleGetMeasurementsSuccess: function(measurements) {
			this.getObjectInfoModel().setProperty('/Measurements', measurements);
		},

		getFilteringStartDate: function() {
			return new Date();
		},

		getFilteringEndDate: function() {
			return new Date(new Date().setUTCFullYear(new Date().getUTCFullYear() - 1));
		},

		writeNFCTag: function(technicalObject) {
			var url = 'https://flpnwc-ab09da307.dispatcher.hana.ondemand.com/sites/production#ZPM4MaintSemObject-ObjectInfo&/TechnicalObject/' + encodeURIComponent(technicalObject);
			var nfc = JSON.stringify({
				TechnicalObject: technicalObject
			});

			this.getGlobalModel().setProperty('/GeneratedCode', url);
			this.getGlobalModel().setProperty('/GeneratedNFC', nfc);

			this.onPressReadNFCTechnicalObject();
		},

		handleNFCReadSuccess: function() {
			var nfcDialog = this.getDialog('NFCReadDialog');
			if (nfcDialog && nfcDialog.isOpen() && this.isObjectInfoRoute()) {
				var message = [
					ndef.uriRecord(this.getGlobalModel().getProperty('/GeneratedCode')),
					ndef.mimeMediaRecord('application/json', nfc.stringToBytes(this.getGlobalModel().getProperty('/GeneratedNFC')))
				];

				nfc.write(message, this.handleNFCWriteSuccess.bind(this), this.handleNFCWriteError.bind(this));
				nfc.transceive('00 B2 04 00 00 00 00 00 00 00 00')
					.then(function(response) {
						console.log(nfc.arrayBufferToString(response));
					}, function() {
						console.log('Transceive fail.');
					});
			}
		},

		handleNFCWriteSuccess: function() {
			var nfcDialog = this.getDialog('NFCReadDialog');
			nfcDialog && nfcDialog.close();

			sap.m.MessageToast.show(this.getResourceBundleText('NFC_TAG_WRITE_MESSAGE_SUCCESS'));
		},

		handleNFCWriteError: function() {
			var nfcDialog = this.getDialog('NFCReadDialog');
			nfcDialog && nfcDialog.close();

			sap.m.MessageToast.show(this.getResourceBundleText('NFC_TAG_WRITE_MESSAGE_ERROR'));
		},

		onUploadCollectionChange: function(uploadEvent) {
			this.addHeaderParameters(uploadEvent);
		},

		addHeaderParameters: function(uploadEvent) {
			this.setPathBusy('/IsUploadingPicture');

			var technicalObject = this.getCurrentObjectId();
			var isFunctionalLocation = this.isFunctionalLocation();

			var uploadCollection = uploadEvent.getSource();
			var sSecurityToken = this.devapp.onlineModel.getSecurityToken();

			uploadCollection.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: 'X-CSRF-Token',
				value: sSecurityToken
			}));
			uploadCollection.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: 'Accept',
				value: 'application/json'
			}));
			uploadCollection.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: 'Content-Type',
				value: 'image/jpeg'
			}));
			uploadCollection.addHeaderParameter(
				new sap.ui.unified.FileUploaderParameter({
					name: 'slug',
					value: encodeURIComponent(uploadEvent.getParameter('files')[0].name) + '|' + (isFunctionalLocation ? 'IFLOT' : 'EQUI') + '|' + technicalObject
				})
			);
		},

		handleUploadComplete: function(event) {
			var status = event.getParameter('status');
			this.setPathNotBusy('/IsUploadingPicture');
			if (status >= 400) {
				this.resetFileUploader();
				this.handleDMSUploadError();
			} else {
				this.handlePostDMSDocumentSuccess();
			}
		},

		handleCameraSuccess: function(fileURI) {
			var busyPath = '/IsUploadingPicture';
			this.setPathBusy(busyPath);
			this.postAttachment(fileURI)
				.done(this.handlePostDMSDocumentSuccess.bind(this))
				.fail(this.handleDMSUploadError.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGetPictureFromFileSystemSuccess: function(fileUris) {
			if (fileUris.length) {
				var busyPath = '/IsUploadingPicture';

				var postAttachmentRequests = fileUris.map(function(fileURI) {
					return this.postAttachment(fileURI.path);
				}.bind(this));

				this.setPathBusy(busyPath);
				$.when.apply(this, postAttachmentRequests)
					.done(this.handlePostDMSDocumentSuccess.bind(this))
					.fail(this.handleDMSUploadError.bind(this))
					.always(this.setPathNotBusy.bind(this, busyPath));
			}
		},

		postAttachment: function(url) {
			var deferred = $.Deferred();
			var technicalObject = this.getCurrentObjectId();
			var isFunctionalLocation = this.isFunctionalLocation();
			var fileName = this.generateFileName();

			var sSecurityToken = this.devapp.onlineModel.getSecurityToken();

			if (url) {
				new FileTransfer().upload(
					url,
					encodeURI(this.devapp.onlineModel.sServiceUrl + '/DmsFileSet'),
					deferred.resolve,
					deferred.reject, {
						fileName: fileName,
						mimeType: 'image/jpeg',
						headers: {
							'Accept': 'application/json',
							'X-CSRF-Token': sSecurityToken,
							'Content-Type': 'image/jpeg',
							'slug': fileName + '|' + (isFunctionalLocation ? 'IFLOT' : 'EQUI') + '|' + technicalObject
						}
					}
				);
				this.getModel('ViewModel').setProperty('/pictureSrc', url);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		handlePostDMSDocumentSuccess: function() {
			this.refreshDocuments();
			sap.m.MessageToast.show(this.getResourceBundleText('OBJECT_IFNO_DMS_DOCUMENT_ADDED'));
		},

		resetFileUploader: function() {
			var uploader = this.getElementById('fileUploader');

			uploader.setValue(null);
		},

		handleDMSUploadError: function() {
			var messageBoxParameters = {
				type: 'Error',
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: this.getResourceBundleText('ERROR_MESSAGE_ERROR_ADDING_DMS_DOCUMENT')
			};

			this.messageBoxUtil.show(messageBoxParameters);
		},

		postObjectMeasurementReadings: function() {
			var measurements = this.getObjectInfoModel().getProperty('/Measurements');

			var createMethods = measurements.filter(this.shouldCreateMeasurementDocument.bind(this)).map(this.generateCreateMethods.bind(this));

			$.when.apply(this, createMethods)
				.done(this.handleMeasurementDocumentsPosted.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
		},

		handleMeasurementDocumentsPosted: function() {
			var measurements = this.getObjectInfoModel().getProperty('/Measurements').map(function(document) {
				document.CreateMeasurementDoc = '';

				return document;
			});

			this.getObjectInfoModel().setProperty('/Measurements', measurements);
		},

		shouldCreateMeasurementDocument: function(document) {
			return !!document.CreateMeasurementDoc;
		},

		generateCreateMethods: function(document) {
			return this.oDataUtil.create('MeasurementSet', document, {
				online: true
			});
		},

		handleOnline: function() {
			var isDownloadingDetails = this.getGlobalModel().getProperty('/IsDownloadingTechnicalObjecDetails');
			var currentObjectIsFromOfflineStorage = this.getCurrentObject().IsFromOfflineStorage;

			if (!isDownloadingDetails && currentObjectIsFromOfflineStorage) {
				this.getTechnicalObjectDetails(this.getCurrentObjectId());
			}
		}

	});
});