sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.ObjectInfoSelection', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel', {
				TechnicalObjectIsValid: true,
				TechnicalObject: {}
			});

			this.subscribeToEvent('functionalLocationSelected', 'ObjectInfoTechnicalObjectSelected', this.handleTechnicalObjectSelected.bind(this));
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'TechnicalObjectSelection') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getModel('ViewModel').setData({
					TechnicalObjectIsValid: true,
					TechnicalObject: {}
				});
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onTechnicalObjectChange: function(changeEvent) {
			this.validateTechnicalObject(this.getIdFromChangeEvent(changeEvent));
		},

		onPressNavigateToHierarchy: function() {
			var currentObject = this.getModel('ViewModel').getProperty('/TechnicalObject');
			var startingPoint = '';

			if (currentObject) {
				startingPoint = currentObject.Equnr ? currentObject.Supfloc : currentObject.Floc;
			}

			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'ObjectInfoTechnicalObjectSelected');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(startingPoint);
		},

		onNextButtonPress: function() {
			// when user presses next button before change event is fired
			setTimeout(function() {
				var isValidatingTechnicalObject = this.getGlobalModel().getProperty('/IsValidatingTechnicalObject');
				if (!isValidatingTechnicalObject) {
					var technicalObject = this.getObjectInfoModel().getProperty('/TechnicalObject');

					this.navTo('TechnicalObject', {
						TechnicalObject: (technicalObject.Floc || technicalObject.Equnr).replace(/\//g, '\\'),
						query: {
							Tab: 'Header'
						}
					});
				}
			}.bind(this), 0);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handleScanSuccess: function(result) {
			var scanResult = result && result.text || '';
			this.validateTechnicalObject(scanResult);
		},

		handleTechnicalObjectSelected: function(channel, eventName, selectedObject) {
			this.validateTechnicalObject(selectedObject.Floc);
		},

		validateTechnicalObject: function(technicalObject) {
			var busyPath = '/IsValidatingTechnicalObject';

			this.setPathBusy(busyPath);
			this.validateTechnicalObjectDetails(technicalObject)
				.done(this.technicalObjectValid.bind(this))
				.fail(this.technicalObjectNotValid.bind(this, technicalObject))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		technicalObjectValid: function(technicalObject) {
			if (technicalObject) {
				this.getModel('ViewModel').setProperty('/TechnicalObject', technicalObject);
				this.getObjectInfoModel().setProperty('/TechnicalObject', technicalObject);

				// need to replace forwad slash for navigation
				this.navTo('TechnicalObject', {
					TechnicalObject: (technicalObject.Floc || (technicalObject.Equnr || '')).replace(/\//g, '\\'),
					query: {
						Tab: 'Header'
					}
				});

				this.getModel('ViewModel').setProperty('/TechnicalObjectIsValid', true);
			}
		},

		technicalObjectNotValid: function(technicalObject) {
			this.getModel('ViewModel').setProperty('/TechnicalObjectIsValid', false);

			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('NOT_FOUND_PAGE_TITLE'),
				message: this.getResourceBundleText('TECHNICAL_OBJECT_NOT_FOUND', technicalObject)
			});
		}

	});
});