sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.MyWorkSplitContainer', {

		onInit: function() {
			this.myWorkSplitContainer = this.byId('myWorkSplitContainer');

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'tilePageRouteMatched', this.hideMaster.bind(this));

			this.myWorkSplitContainer.attachOrientationChange(this.handleOrientationChange.bind(this));
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('myWorkSplitContainer', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		detailNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('myWorkSplitContainer', 'detailNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		showMaster: function() {
			this.myWorkSplitContainer.showMaster();
		},

		hideMaster: function() {
			this.myWorkSplitContainer.hideMaster();
		},

		getSplitContainer: function() {
			return this.myWorkSplitContainer;
		},

		handleOrientationChange: function(event) {
			if (location.hash.indexOf('MyWork') !== -1 && this.isTablet() && !event.getParameter('landscape') && this.myWorkSplitContainer.getMode() === 'ShowHideMode') {
				this.myWorkSplitContainer.showMaster();
			}
		}

	});
});