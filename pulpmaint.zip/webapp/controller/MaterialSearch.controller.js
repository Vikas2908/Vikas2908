sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController',
	'sap/m/TablePersoController',
	'com/upm/maint/util/personalization/MaterialSearchPersonalization'
], function(CommonController, BaseController, TablePersoController, MaterialSearchPersonalization) {
	return CommonController.extend('com.upm.maint.controller.MaterialSearch', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */
		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('MaterialStockListModel');
			this.setModel('MaterialModel');
			this.setModel('AttachmentModel');
			this.setModel('PrintModel');
			this.setModel('MaterialSearchResultsModel');
			this.setModel('SearchParameters');

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.oTablePersoController = new TablePersoController({
				table: this.getView().byId('materialSearchItemTable'),
				persoService: MaterialSearchPersonalization
			}).activate();
		},

		routeMatched: function(oEvent) {
			if (oEvent.getParameter('name') === 'MaterialSearch') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				this.loadUserParameters();
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {
				if (!this.checkUserParameters()) {
					this.allMandatoryParametersNotSet();
				}
			}
		},

		/* =========================================================== */
		/* Application Logic     	                                   */
		/* =========================================================== */

		openFileUploadPopup: function() {
			this.openSimpleDialog('FileUploadDialog');
		},

		onFileUploadDialogCloseButtonPress: function() {
			this.getDialog('FileUploadDialog').close();
		},

		onAfterUploadDialogClose: function() {
			var oAttachmentModel = this.getModel('AttachmentModel');
			oAttachmentModel.setProperty('Attachments', {});
		},

		onUploadCollectionChange: function(oEvent) {
			if (oEvent) {
				var oMaterialModel = this.getModel('MaterialModel');
				var material = oMaterialModel.getProperty('/MaterialNumber');
				var oDataModel = this.oDataUtil.getWMODataModel('ZWM_COMMON_SRV');
				var sSecurityToken = oDataModel.getSecurityToken();
				var oUploadCollection = oEvent.getSource();
				var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
					name: 'slug',
					value: oEvent.getParameter('files')[0].name + '|' + oEvent.getParameter('files')[0].type + '|' + material
				});
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'X-CSRF-Token',
					value: sSecurityToken
				}));
				oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'Accept',
					value: 'application/json'
				}));
			}
		},

		onUploadComplete: function(oEvent) {
			if (oEvent) {
				this.onFileUploadDialogCloseButtonPress();
				this.showMessageBox({
					type: 'Success',
					title: this.getResourceBundleText('COMMON_SUCCESS_TITLE'),
					message: this.getResourceBundleText('FILEUPLOAD_SUCCESS_MESSAGE')
				});
			}
		},

		onCapture: function() {
			this.cordovaCameraUtil.handleCaptureImage(this.onSuccess, this.onFail);
		},

		onSelect: function() {
			this.cordovaCameraUtil.handleSelectImage(this.onSuccess, this.onFail);
		},

		onSuccess: function(imageURI) {
			var imageId = this.getFragmentElementById('FileUploadDialog', 'imageId');
			imageId.setSrc('data:image/jpg;base64,' + imageURI);
			this.getFragmentElementById('FileUploadDialog', 'uploadImageButton').setVisible(true);
		},

		onFail: function(message) {
			sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.Error, 'Error');
		},

		onUpload: function() {
			var imageData = sap.ui.core.Fragment.byId('fileUploadDialog', 'imageId').getSrc();

			var base64Marker = 'data:image/jpg;base64,';
			var base64Index = imageData.indexOf(base64Marker) + base64Marker.length;
			var base64EncodedData = imageData.substring(base64Index);
			var blob = this.cordovaCameraUtil.b64toBlob(base64EncodedData, 'image/jpg');

			var oMaterialModel = this.getModel('MaterialModel');
			var material = oMaterialModel.getProperty('/MaterialNumber');

			var oDataModel = this.oDataUtil.getWMODataModel('ZWM_COMMON_SRV');
			var sSecurityToken = oDataModel.getSecurityToken();

			var currentDate = new Date();
			currentDate.setHours(currentDate.getHours());
			currentDate.setMinutes(currentDate.getMinutes());
			currentDate.setSeconds(currentDate.getSeconds());
			var fileName = this.formatterUtil.formateDateAndTimeForAttachment(currentDate) + '.jpg';

			var xhr = new XMLHttpRequest();
			//xhr.open('POST', '/odata/SAP/ZWM_COMMON_SRV/AttachmentDataSet', true);
			xhr.open('POST', '/odata/SAP/ZWM_COMMON_SRV/DmsFileSet', true);
			xhr.setRequestHeader('slug', fileName + '|' + 'image/jpg' + '|' + material);
			xhr.setRequestHeader('Content-Type', 'image/jpg');
			xhr.setRequestHeader('Accept', 'application/json');
			xhr.setRequestHeader('X-CSRF-Token', sSecurityToken);

			xhr.upload.onprogress = function(e) {
				if (e.lengthComputable) {
					var percentComplete = (e.loaded / e.total) * 100;
					console.log(percentComplete + '% uploaded');
				}
			};

			xhr.onerror = function() {
				console.log('Error');
			};

			xhr.onload = function() {
				if (xhr.status === 201) {
					var successMessage = this.getResourceBundleText('FILEUPLOAD_SUCCESS_MESSAGE');
					sap.m.MessageBox.show(successMessage, sap.m.MessageBox.Icon.Info, 'Success');
					this.getFragmentElementById('FileUploadDialog', 'uploadImageButton').setVisible(false);
					var imageId = this.getFragmentElementById('FileUploadDialog', 'imageId');
					imageId.setSrc('');
				} else {
					sap.m.MessageBox.show(xhr.status + ' ' + xhr.statusText, sap.m.MessageBox.Icon.Error, 'Error');
				}
			}.bind(this);
			xhr.send(blob);
		},

		onFileTooLarge: function() {
			//this.openErrorMessagePopup('ERROR_FILE_TOO_LARGE');
		},

		getAttachmentsUrl: function(docId, notifNo) {
			var printUrl = '';
			var serviceUrl = this.oDataUtil.getServiceUrl('ZWM_COMMON_SRV');
			if (docId && notifNo) {
				printUrl = serviceUrl + '/AttachmentDataSet(DocId=\'' + docId + '\',NotifNo=\'' + notifNo + '\')/$value';
			}
			return printUrl;
		},

		getAttachmentsUrlForThumbnail: function(docId, notifNo, mimetype) {
			var printUrl = '';
			var serviceUrl = this.oDataUtil.getServiceUrl('ZWM_COMMON_SRV');
			var mimetypeIsImage = mimetype.indexOf('image') !== -1;
			if (docId && notifNo && mimetypeIsImage) {
				printUrl = serviceUrl + '/AttachmentDataSet(DocId=\'' + docId + '\',NotifNo=\'' + notifNo + '\')/$value';
			}
			return printUrl;
		},

		onSearchResultsSortPress: function() {
			this.openSimpleDialog('MaterialSearchSortDialog');
		},

		handleSearchResultsSort: function(oEvent) {
			if (oEvent) {
				var oTable = this.getElementById('materialSearchItemTable');
				var oBinding = oTable.getBinding('items');
				var mParams = oEvent.getParameters();
				var aSorters = [new sap.ui.model.Sorter(mParams.sortItem.getKey(), mParams.sortDescending)];
				oBinding.sort(aSorters);
			}
		},

		onPersonalizationPress: function(oEvent) {
			if (oEvent) {
				this.oTablePersoController.openDialog();
			}
		},

		onMaterialTableItemPress: function(oEvent) {
			if (oEvent) {
				var obj = oEvent.getSource().getBindingContext('MaterialStockListModel').getObject();
				if (obj) {
					var searchParams = this.getModel('SearchParameters').getData();
					var plant = searchParams.Plant || '';
					var storageLocation = searchParams.StorageLocation || '';
					this.navTo('MaterialDetailsView', {
						'materialNumber': obj.MaterialNumber,
						'plant': plant,
						'storageLocation': storageLocation
					}, false);
				}
			}
		},

		onMaterialLabelPress: function(oEvent) {
			if (oEvent) {
				var oPrintModel = this.getModel('PrintModel');
				var obj = oEvent.getSource().getBindingContext('MaterialStockListModel').getObject();
				oPrintModel.setProperty('/LabelObject', obj);
				this.openSimpleDialog('PrintQuantityDialog');
			}
		},

		onPrintDialogPrintButtonPress: function() {
			var oPrintModel = this.getModel('PrintModel');
			var obj = oPrintModel.getProperty('/LabelObject');
			obj.printquantity = this.getFragmentElementById('PrintQuantityDialog', 'printQuantityInput').getValue();
			this.printLabel(obj);
			this.onPrintDialogCloseButtonPress();
		},

		onPrintDialogCloseButtonPress: function() {
			this.getDialog('PrintQuantityDialog').close();
		},

		printLabel: function(labelObject) {
			if (labelObject) {
				var searchParams = this.getModel('SearchParameters').getData();
				var warehouse = searchParams.Warehouse;
				var queryUrl = null;
				var labelId = null;
				if (labelObject.Type === 'IM') {
					labelId = 'IMMATLBL';
					labelObject.StorageType = '';
					labelObject.warehouse = '';
				} else if (labelObject.Type === 'WM') {
					labelId = 'WMMATLBL';
					labelObject.PlantId = '';
					labelObject.StorageLocation = '';
					labelObject.StorageType = '';
					labelObject.warehouse = warehouse;
				}
				queryUrl = {
					'LabelId': labelId,
					'Material': labelObject.MaterialNumber,
					'Plant': labelObject.PlantId,
					'StorageBin': labelObject.StorageBin,
					'StorageLocation': labelObject.StorageLocation,
					'StorageType': labelObject.StorageType,
					'WarehouseNumber': labelObject.warehouse,
					'PrintQuantity': labelObject.printquantity
				};
				//queryUrl = 'PrintLabel?LabelId=\'' + labelId + '\'&Material=\'' + labelObject.MaterialNumber + '\'&Plant=\'' + labelObject.PlantId + '\'&StorageBin=\'' + labelObject.StorageBin + '\'&StorageLocation=\'' + labelObject.StorageLocation + '\'&StorageType=\'' + labelObject.StorageType + '\'&WarehouseNumber=\'' + labelObject.warehouse + '\'';
				if (labelId) {
					this.print(queryUrl);
				}
			}
		},

		print: function(queryUrl) {
			if (queryUrl) {
				var oPrintModel = this.getModel('PrintModel');
				var that = this;
				this.openBusyDialog();
				var path = 'PrintLabel';
				this.oDataFunctionImport('ZWM_COMMON_SRV', path, queryUrl).done(function(oData) {
						if (oData) {
							that.showMessageBox({
								type: 'Success',
								title: this.getResourceBundleText('COMMON_SUCCESS_TITLE'),
								message: this.getResourceBundleText('PRINT_SUCCESS_MESSAGE')
							});
							oPrintModel.setProperty('LabelObject', {});
						}
					}).fail(function() {})
					.always(this.closeBusyDialog.bind(this));
			}
		},

		/* =========================================================== */
		/* oData Services   			                          	   */
		/* =========================================================== */

		materialSearch: function(materialNumber) {
			this.openBusyDialog();
			setTimeout(function() {
				this.getMaterialDetails(materialNumber);
			}.bind(this), 0);
		},

		getMaterialDetails: function(materialNumber) {
			var searchParams = this.getModel('SearchParameters').getData();
			var oMaterialModel = this.getModel('MaterialModel');
			var oMaterialStockListModel = this.getModel('MaterialStockListModel');
			var plant = searchParams.Plant;
			oMaterialStockListModel.setData({});
			if (materialNumber && materialNumber.length > 0) {
				var readParams = {
					wmService: 'ZWM_COMMON_SRV',
					filters: [
						new sap.ui.model.Filter('MaterialNumber', sap.ui.model.FilterOperator.EQ, materialNumber),
						new sap.ui.model.Filter('PlantId', sap.ui.model.FilterOperator.EQ, plant)
					]
				};
				$.when(this.oDataUtil.read('SearchMaterials', readParams)
					.done(function(oData) {
						oData = oData.results ? oData.results : oData;
						this.getElementById('materialNumberInput').setValue('');
						if (oData.length > 0) {
							oMaterialStockListModel.setData(oData);
							this.getElementById('photoUploader').setVisible(true);
							oMaterialModel.setProperty('/MaterialNumber', materialNumber);
						} else {
							sap.m.MessageBox.show(this.getResourceBundleText('ERROR_MESSAGE_MATERIAL_NOT_FOUND', materialNumber), sap.m.MessageBox.Icon.INFO, this.getResourceBundleText('COMMON_INFO_TITLE'));
							this.getElementById('photoUploader').setVisible(false);
							oMaterialModel.setProperty('/MaterialNumber', null);
						}
					}.bind(this))
					.fail(function(oError) {
						// empty barcode input
						this.getElementById('materialNumberInput').setValue('');
						oMaterialModel.setProperty('/MaterialNumber', null);
						if (oError) {

						}
					}.bind(this))
					.always(this.closeBusyDialog.bind(this))
				);
			}
		},

		confirmInternalMoving: function(saveObj) {
			this.openBusyDialog();
			this.oDataUtil.create('InternalMvmtMultSet', saveObj, {
					wmService: 'ZWM_INTERNALMOVING_SRV'
				}).done(function() {})
				.fail(function() {})
				.always(this.closeBusyDialog.bind(this));
		},

		getStorageTypes: function(plant) {
			var oSelectionValuesModel = this.getModel('SelectionValuesModel');
			var query = 'StorageTypes?$filter=PlantId eq \'' + plant + '\'';
			$.when(this.oDataUtil.read(query, {
					wmService: 'ZWM_COMMON_SRV'
				}))
				.done(function(oData) {
					if (oData) {
						var storageTypes = (oData.results) ? oData.results : oData;
						var empty = {
							'PlantId': '',
							'Warehouse': '',
							'StorageTypeId': '',
							'StorageDescription': ''
						};
						storageTypes.unshift(empty);
						oSelectionValuesModel.setProperty('/StorageTypes', storageTypes);
					}
				});
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		parseMaterialBarcode: function(value) {
			if (value) {
				var parsedValue = parseInt(value, 10);
				this.materialSearch(parsedValue.toString());
			}
		},

		onMaterialScanSuccess: function(oEvt) {
			if (oEvt) {
				var scannedValue = oEvt.getParameter('value');
				if (scannedValue) {
					this.parseMaterialBarcode(scannedValue);
				}
			}
		},

		onScannedMaterialValueChange: function(oEvt) {
			if (oEvt) {
				var scannedValue = oEvt.getParameter('value');
				if (scannedValue) {
					this.parseMaterialBarcode(scannedValue);
				}
			}
		},

		onScanError: function(oEvt) {
			var errorMessage = '';
			if (oEvt) {
				errorMessage = oEvt.getParameter('value');
			}
			this.openErrorMessagePopup(errorMessage, null);
		},


		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		specialStockFormatter: function(value) {
			if (value && value === 'K') {
				return 'sap-icon://accept';
			} else {
				return '';
			}
		},

		/* Trex material search */
		onMaterialTrexSearchPress: function(oEvent) {
			if (oEvent) {
				var oMaterialSearchResultsModel = this.getModel('MaterialSearchResultsModel');
				oMaterialSearchResultsModel.setData({});
				this.openSimpleDialog('WMMaterialSearchTrex');
			}
		},

		onTrextDialogCloseButtonPress: function() {
			this.getDialog('WMMaterialSearchTrex').close();
		},

		onMaterialListItemPress: function(oEvent) {
			if (oEvent) {
				this.onTrextDialogCloseButtonPress();
				var selectedMaterialObject = oEvent.getSource().getBindingContext('MaterialSearchResultsModel').getObject();
				if (selectedMaterialObject) {
					this.materialSearch(selectedMaterialObject.Material);
				}
			}
		},

		onMaterialInputSearchPress: function(oEvent) {
			if (oEvent) {
				var oMaterialSearchResultsModel = this.getModel('MaterialSearchResultsModel');
				var searchTerm = this.getFragmentElementById('WMMaterialSearchTrex', 'materialInput').getValue();
				var searchObject = this.getSearchObject(searchTerm);
				this.openBusyDialog();
				var query = 'MaterialSearchTREXSet';
				var filters = this.generateFilter('Plant', [searchObject.Plant])
					.concat(this.generateFilter('Warehouse', [searchObject.Warehouse]))
					.concat(this.generateFilter('SearchTerm', [searchTerm]));
				this.oDataUtil.read(query, {
						wmService: 'ZWM_COMMON_SRV',
						filters: filters
					}).done(function(oData) {
						if (oData) {
							oMaterialSearchResultsModel.setData(oData);
						}
					}).fail(function() {})
					.always(this.closeBusyDialog.bind(this));
			}
		},

		getSearchObject: function(searchTerm) {
			var searchParams = this.getModel('SearchParameters').getData();
			var warehouse = searchParams.Warehouse || '';
			var plant = searchParams.Plant || '';
			var searchObject = {};
			searchObject.SearchTerm = searchTerm;
			searchObject.Warehouse = warehouse;
			searchObject.Plant = plant;
			searchObject.PlantDesc = '';
			searchObject.Material = '';
			searchObject.MaterialDesc = '';
			searchObject.Quantity = '';
			searchObject.Unit = '';
			searchObject.StorageLoc = '';
			searchObject.StorageBin = '';
			searchObject.StorageType = '';
			searchObject.StorageTypeDesc = '';
			searchObject.SpecialStock = '';
			searchObject.SpecialStockNumber = '';
			searchObject.Type = '';
			return searchObject;
		},

		loadUserParameters: function() {
			var searchParameters = this.getModel('SearchParameters');
			var userParams = this.getUserParameters();
			var plants = this.getModel('SelectionValuesModel').getProperty('/Plants') || [];
			var plant = userParams.Plant || '';
			var warehouse = userParams.Warehouse || '';
			var storLoc = '';
			plants.some(function(object) {
				if (object.Plant === plant) {
					storLoc = object.DefaultStorageLoc || '';
					return true;
				}
			});
			var parameters = {
				Plant: plant,
				Warehouse: warehouse,
				StorageLocation: storLoc
			};
			searchParameters.setData(parameters);
		},

		checkUserParameters: function() {
			var params = this.getModel('SearchParameters').getData() || {};
			if (params.Plant === '' || params.Warehouse === '') {
				return false;
			}
			return true;
		},

		allMandatoryParametersNotSet: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WM_PARAMETERS_MISSING_TITLE'),
				message: this.getResourceBundleText('WM_PARAMETERS_MISSING_TEXT'),
				onClose: this.handleMandatoryParemetersNotSetClose.bind(this),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleMandatoryParemetersNotSetClose: function(action) {
			if (action === 'YES') {
				this.navTo('UserParameters', {}, true);
			} else {
				this.onNavBack();
			}
		}
	});
});