sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.MyWorks', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				IsOrderList: false,
				IsMyWorkList: true,
				IsNotificationList: false,
				EnableCompleteOperations: false,
				ScheduleId: '',
				FilterParameters: {},
				IsRecordingCurrentMyWork: false,
				SaveVariantDialog: {
					CreateNew: false,
					IsDefault: false,
					IsBusy: false
				},
				Variants: [],
				OriginalFilterParameters: {},
				SelectedVariant: ''
			};

			this.setModel('ViewModel', initialViewModel);

			this.getFilterParameters();

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'AdvancedSearchOrderListFunctionalLocations', this.handleListFunctionalLocationsSelected.bind(this));
			this.subscribeToEvent('userParameters', 'update', this.getFilterParameters.bind(this));
			this.subscribeToEvent('root', 'variantsUpdated', this.setVariantsToModel.bind(this));

			this.getElementById('myWorksSearchField')._getValueHelpIcon().setSrc(this.isScannerAvailable() ? 'sap-icon://camera' : 'sap-icon://refresh');

			if (!this.isHybridApplicationUser() && this.isMyWorksRoute()) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.getFilterParameters.bind(this));
				this.getOrdersForBrowser();
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'MyWorks') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getGlobalModel().setProperty('/EditOrder', false);

				this.getModel('ViewModel').setProperty('/SelectedWork', '');
				this.getModel('ViewModel').setProperty('/SelectedOperation', '');
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.isMyWorksRoute() && this.navigatedFrom(navigationData.fromView, 'FunctionalLocationHierarchy')) {
				this.onAdvancedSearchPress();
			}
			if (this.shouldShowMaster(navigationData)) {
				this.getModel('ViewModel').setProperty('/SelectedWork', '');
				this.getModel('ViewModel').setProperty('/SelectedOperation', '');
				this.getParentController().showMaster();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onScheduleIdChange: function(selectEvent) {
			var scheduleId = selectEvent.getParameter('selectedItem').getProperty('key');
			var list = this.getElementById('myWorkListContainer');

			this.filterListWithScheduleId(scheduleId, list);
		},

		onSelectionChange: function() {
			setTimeout(function() {
				var selectedItems = this.getElementById('myWorkListContainer').getSelectedItems();
				var items = this.getElementById('myWorkListContainer').getItems();

				var allItemsAreSelectedFromList = selectedItems.length && items.length === selectedItems.length;

				var itemsAreSelected = selectedItems.length !== 0;

				this.getModel('ViewModel').setProperty('/EnableCompleteOperations', itemsAreSelected);

				this.getElementById('selectAllCheckBox').setSelected(allItemsAreSelectedFromList);
			}.bind(this), 0);
		},

		onSelectAllPress: function(selectEvent) {
			var isAllCheckBoxSelected = selectEvent.getParameter('selected');
			var list = this.getElementById('myWorkListContainer');

			if (isAllCheckBoxSelected) {
				list.selectAll();
				this.getModel('ViewModel').setProperty('/EnableCompleteOperations', true);
			} else {
				list.removeSelections();
				this.getModel('ViewModel').setProperty('/EnableCompleteOperations', false);
			}
		},

		onCompleteOperationsPress: function() {
			var selectedItems = $.extend(true, [], this.getElementById('myWorkListContainer').getSelectedItems());
			var orderOperationToPost = [];

			selectedItems.forEach(function(operation) {
				operation = operation.getBindingContext('MyWorksModel').getObject();
				var isPushedToList = orderOperationToPost.some(function(order) {
					return order.Orderid === operation.Orderid;
				});

				if (isPushedToList) {
					orderOperationToPost.forEach(function(order, index) {
						if (order.Orderid === operation.Orderid) {
							orderOperationToPost[index].Activity.push(operation.Activity);
						}
					});
				} else {
					orderOperationToPost.push({
						Orderid: operation.Orderid,
						Activity: [operation.Activity]
					});
				}
			}, []);

			var postObjects = orderOperationToPost.map(function(order) {
				var orderObject = $.extend(true, {}, this.getMyWorkOrder(order.Orderid));

				orderObject.Operations = orderObject.Operations.map(function(operation) {
					if (order.Activity.indexOf(operation.Activity) !== -1) {
						operation.Completed = 'X';
					}
					return operation;
				});

				if (this.isOffline()) {
					orderObject.NotSync = true;
					this.insertOrderToList(orderObject);
					this.localStorage.insertOrder(orderObject);
				}

				return orderObject;
			}.bind(this));
			if (this.isOffline()) {
				this.handleOrderPostEnd();
				this.handleMyWorksSavedOffline();
			} else {
				this.setAppBusyMode();
				this.postOrders(postObjects)
					.always(this.handleOrderPostEnd.bind(this));
			}
		},

		onMasterListItemPress: function(pressEvent) {
			var pressEventObject = pressEvent
				.getParameter('listItem')
				.getBindingContext('MyWorksModel')
				.getObject();
			var orderId = pressEventObject.Orderid;
			var activity = pressEventObject.Activity;

			var orderObject = this.getMyWorkOrder(orderId);

			this.getModel('NewOrderModel').setData(this.models.getOrderDefaults(orderObject));

			this.navTo('EditMyWork', {
				Purpose: 'Display',
				OrderNumber: orderObject.Orderid,
				query: {
					Tab: 'Operations',
					Activity: activity
				}
			}, this.getModel('Device').getProperty('/isNoPhone'));
			this.getParentController().hideMaster();
		},

		onAdvancedSearchPress: function() {
			if (!this.getDialog('AdvancedSearch')) {
				var advancedSearch = this.initializeFragment('AdvancedSearch');
				var listFunctionalLocationInputControl = this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl');

				listFunctionalLocationInputControl.addValidator(this.functionalLocationListValidator.bind(this));

				this.isHybridApplicationUser() && this.renderSuggestionInput(listFunctionalLocationInputControl);

				advancedSearch.open();
			} else {
				this.openSimpleDialog('AdvancedSearch');
			}

			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
		},

		onAdvancedSearch: function() {
			this.getFilteredOrders();
			this.getDialog('AdvancedSearch').close();
		},

		onListFunctionalLocationsValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'AdvancedSearchOrderListFunctionalLocations');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onMyWorkPersonsValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPersonDialogParameters({
					firstValueToSave: 'FilterParameters/Persons',
					secondValueToSave: '',
					configurationModelName: 'SelectionValuesModel',
					pathToModel: '/Persons',
					multiSelect: true
				})
			);
		},

		onNotificationTypeValueHelp: function() {
			this.openDialog('SearchDialog', this.getOrderTypeDialogParameters());
		},

		onListFunctionalLocationTokensAdd: function(tokensToAdd, action) {
			this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl').setValue('');

			if (action === 'OK') {
				this.addListFunctionalLocationToModel(tokensToAdd);
			}
		},

		onOrderTypeValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getOrderTypeDialogParameters()
			);
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'FilterParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'FilterParameters/Plangroups'
				})
			);
		},

		onScheduleIdValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getScheduleDialogParameters({
					saveModelName: 'ViewModel',
					firstValueToSave: 'FilterParameters/ScheduleIdFilter'
				})
			);
		},

		onMyWorkPersonSuggestionItemSelected: function(selectEvent) {
			var selectedPerson = selectEvent.getParameter('selectedRow').getBindingContext().getObject();

			this.getModel('ViewModel').setProperty(
				'/FilterParameters/Persons',
				this.getModel('ViewModel').getProperty('/FilterParameters/Persons')
				.concat([selectedPerson])
			);

			setTimeout(function(storedSelectEvent) {
				this.getModel('ViewModel').setProperty('/PeronsMyWorkTokenValue', '');
				storedSelectEvent.getSource()._oPopupInput && storedSelectEvent.getSource()._oPopupInput.setValue('');
			}.bind(this, $.extend(true, {}, selectEvent)), 0);
		},

		onCloseAdvancedSearch: function() {
			this.getDialog('AdvancedSearch').close();
		},

		onOpenErrorInformationPopover: function(pressEvent) {
			this.initializeFragment('ErrorMessages').openBy(pressEvent.getSource());
		},

		onMyWorkLiveSearch: function(searchEvent) {
			this.filterOrders(searchEvent.getParameter('newValue'));
		},

		onMyWorkPullToRefresh: function() {
			this.handleListRefresh();
		},

		onSearchBarValueHelpPress: function() {
			this.isHybridApplicationUser() ? this.onPressScanId() : this.handleListRefresh();
		},

		onSystemConditionChange: function(changeEvent) {
			if (!changeEvent.getParameters().selectedItem.getKey()) {
				this.getModel('ViewModel').setProperty('/FilterParameters/SystemCondition', '');
			}
		},

		onTimeRecordingButtonPress: function(pressEvent) {
			var pressedObject = pressEvent.getSource().getParent()._swipedItem.getBindingContext('MyWorksModel').getObject();
			var operationNumber = pressedObject.Activity;
			var orderId = pressedObject.Orderid;
			var shortText = pressedObject.Description;
			var recordOption = [{
				Orderid: orderId + '/' + operationNumber,
				ShortText: shortText
			}];
			var recordObject = this.getTimeRecordUtility().getSaveObject();

			if (this.getTimeRecordUtility().isRecordingForObject(recordOption)) {
				this.openTimeRecordConfirmation(recordObject);
			} else if (this.getTimeRecordUtility().isRecording()) {
				this.handleStopTimeRecording(recordObject, recordOption);
			} else {
				this.handleStartRecording(recordOption);
			}
		},

		onSwipe: function(swipeEvent) {
			var listItem = swipeEvent.getParameter('listItem');
			var operation = listItem.getBindingContext('MyWorksModel').getObject();
			var recordOption = [{
				Orderid: operation.Orderid + '/' + operation.Activity,
				ShortText: operation.Description
			}];

			var isRecordingForCurrentMyWork = this.getTimeRecordUtility().isRecordingForObject(recordOption);

			this.getModel('ViewModel').setProperty('/IsRecordingCurrentMyWork', isRecordingForCurrentMyWork);
		},

		onSortButtonPress: function() {
			this.openSimpleDialog('MyWorkSort');
		},

		onSortConfirm: function(confirmEvent) {
			this.handleSort(confirmEvent, this.getElementById('myWorkListContainer'));
		},

		onSaveVariantButtonPress: function() {
			this.setVariantSaveDefaults();
			this.openSimpleDialog('SaveVariant');
		},

		onSaveVariant: function() {
			var variantInfo = this.validateVariantNaming('MYWORKS');
			if (variantInfo) {
				this.setVariantDialogBusy(true);
				var viewModel = this.getModel('ViewModel');
				this.saveVariant(
						variantInfo.VariantId,
						'MYWORKS',
						variantInfo.Description,
						viewModel.getProperty('/FilterParameters'),
						viewModel.getProperty('/SaveVariantDialog/IsDefault')
					)
					.done(function() {
						this.setVariantsToModel();
						this.onCloseSaveVariant();
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setVariantDialogBusy.bind(this, false));
			}
		},

		onSelectedVariantChange: function() {
			var selectedId = this.getModel('ViewModel').getProperty('/SelectedVariant');
			if (selectedId === '000') {
				var originalFilterParameters = this.getModel('ViewModel').getProperty('/OriginalFilterParameters');
				this.getModel('ViewModel').setProperty('/FilterParameters', this.generateFilterParametersCopy(originalFilterParameters));
			} else {
				var selectedVariant = this.getVariantWithTypeAndId('MYWORKS', selectedId);
				var oFilterParameters = this.generateFilterParametersObject(JSON.parse(selectedVariant.Data));
				this.getModel('ViewModel').setProperty('/FilterParameters', oFilterParameters);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handlePostOrderSuccess: function(orderNumber, response) {
			if (response) {
				var attachments = $.extend(true, [], Array.isArray(response.Attachments) ? response.Attachments : []);

				(Array.isArray(response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));

				this.localStorage.removeOrder(orderNumber);
				this.removeListObject('MyWorks', orderNumber);
				this.insertOrderToList(response);
				this.postAttachments(attachments);
				this.handleSynchronizedOrderEdit(orderNumber, response);
			}
		},

		handlePostOrderError: function(orderNumber, errorEvent) {
			var errorMessage = this.formatterUtil.oDataErrorToErrorString(errorEvent);

			this.localStorage.insertOrderErrorMessage(orderNumber, errorMessage);

			this.getModel('MyWorksModel').setProperty(
				'/MyWorks',
				(this.getModel('MyWorksModel').getProperty('/MyWorks') || []).map(function(object) {
					if (object['Orderid'] === orderNumber) {
						object.ErrorMessage = errorMessage;
					}
					return object;
				})
			);
		},

		handleMyWorksSavedOffline: function() {
			this.openSuccessDialog(this.getResourceBundleText('POST_SAVE_OFFLINE_MYWORKS_MESSAGE'));
		},

		onSuccessDialogClose: function() {
			this.handleOrderPostEnd();
		},

		filterMyWorkRelevantOrders: function(orderObject) {
			if (orderObject.Released) {
				var userParameters = this.getUserParameters();
				var relevantUserIds = this.getRelevantUserIds() || [];
				var relevantWorkCenters = this.getRelevantWorkCenters() || [];

				if (!relevantUserIds.length && !relevantWorkCenters.length) {
					relevantUserIds = userParameters.Persons && userParameters.Persons.split(',') || [];
					relevantWorkCenters = userParameters.Workcenters && userParameters.Workcenters.split(',') || [];
				}

				if (relevantUserIds.length) {
					var relevantAssignments = orderObject.Assignments.filter(function(assignment) {
						return !assignment.WorkFinished && relevantUserIds.indexOf(assignment.PersonNumber) !== -1;
					}).map(function(relevantAssignment) {
						return relevantAssignment.Activity;
					});

					var relevantOperations = orderObject.Operations.filter(function(operation) {
						return !!(relevantAssignments.indexOf(operation.Activity) !== -1 && (!operation.Completed || orderObject.ErrorMessage));
					});

					orderObject.Operations = orderObject.Operations.map(function(operation) {
						operation.MyWorkRelevant = relevantAssignments.indexOf(operation.Activity) !== -1 && (!operation.Completed || orderObject.ErrorMessage) ? 'X' : '';
						return operation;
					});
					return !!relevantOperations.length;
				} else {
					orderObject.Operations = orderObject.Operations.map(function(operation) {
						operation.MyWorkRelevant = relevantWorkCenters.indexOf(operation.Workcenter) !== -1 && (!operation.Completed || orderObject.ErrorMessage) ? 'X' : '';
						return operation;
					});

					return true;
				}
			} else {
				return false;
			}
		},

		getRelevantUserIds: function() {
			return this.getModel('ViewModel').getProperty('/FilterParameters/Persons').map(function(person) {
				return person.PersonNumber;
			});
		},

		getRelevantWorkCenters: function() {
			return this.getModel('ViewModel').getProperty('/FilterParameters/Workcenters').map(function(workCenter) {
				return workCenter.Workcenter;
			});
		},

		operationListItemFactory: function(id, context) {
			var pathToOrder = context.getPath().match(/\/MyWorks\/\d+\//g).pop();
			var orderObject = context.getModel().getProperty(pathToOrder);
			var customListItem = new sap.m.CustomListItem({
				type: sap.m.ListType.Active,
				content: [
					this.getListItemContent(orderObject)
				]
			});
			return customListItem;
		},

		getListItemContent: function(orderObject) {
			var content = new sap.m.FlexBox({
				alignItems: sap.m.FlexAlignItems.Start,
				justifyContent: sap.m.FlexJustifyContent.SpaceBetween,
				width: '100%',
				items: [
					this.getLeftContent(orderObject),
					this.getRightContent(orderObject)
				]
			});
			content.addStyleClass('sapUiTinyMarginTop').addStyleClass('myWorkDataContainer');
			return content;
		},

		getLeftContent: function(orderObject) {
			var idTextControl = new sap.m.Text({
				text: {
					parts: ['MyWorksModel>Orderid', 'MyWorksModel>Activity', 'MyWorksModel>SubActivity'],
					formatter: this.formatterUtil.formatMyWorkOrderIdAndOperation.bind(this)
				}
			});
			var descriptionTextControl = new sap.m.Text({
				text: {
					path: 'MyWorksModel>Description'
				}
			});
			var TechnicalObjectTextControl = new sap.m.Text({
				text: orderObject.Equipment || orderObject.FunctLoc
			});
			var TechnicalObjectDescriptionTextControl = new sap.m.Text({
				text: orderObject.EquipmentDescr || orderObject.FunctLocDescr
			});
			var systemConditionTextControl = new sap.m.Text({
				text: {
					path: 'MyWorksModel>SystcondDescr'
				}
			});
			var emptyTextController = new sap.m.Text({
				text: ''
			});
			idTextControl.addStyleClass('boldText');
			descriptionTextControl.addStyleClass('boldText');
			return new sap.m.VBox({
				items: [
					idTextControl,
					descriptionTextControl,
					emptyTextController,
					systemConditionTextControl,
					TechnicalObjectTextControl,
					TechnicalObjectDescriptionTextControl
				]
			});
		},

		getRightContent: function(orderObject) {
			var startDateTextControl = new sap.m.Text({
				text: {
					parts: ['GlobalPropertiesModel>/IsRafMaintUser', 'MyWorksModel>Activity', 'ViewModel>/FilterParameters/Persons', 'MyWorksModel>EarlSchedStartDate'],
					formatter: this.formatterUtil.formatMyWorksDate.bind(this, orderObject.Assignments)
				},
				maxLines: 1
			});
			var workCenterTextControl = new sap.m.Text({
				text: {
					path: 'MyWorksModel>Workcenter'
				},
				maxLines: 1
			});
			var planGroupTextControl = new sap.m.Text({
				text: orderObject.Plangroup,
				maxLines: 1
			});
			var notSyncIcon = new sap.ui.core.Icon({
				src: 'sap-icon://synchronize',
				visible: !!orderObject.NotSync
			});
			var errorMessageIcon = new sap.ui.core.Icon({
				src: 'sap-icon://alert',
				color: 'Red',
				visible: !!orderObject.ErrorMessage
			});
			return new sap.m.VBox({
				items: [
					startDateTextControl,
					workCenterTextControl,
					planGroupTextControl,
					notSyncIcon,
					errorMessageIcon
				]
			});
		},

		getFilterParameters: function() {
			var filterParameters = this.getUserParameters();

			var workCenterParameters = {
				filters: this.generateFilter('Workcenter', filterParameters.Workcenters && filterParameters.Workcenters.split(',') || [''])
			};
			var planGroupParameters = {
				filters: this.generateFilter('Plangroup', filterParameters.Plangroups && filterParameters.Plangroups.split(',') || [''])
			};

			var endDate = this.getListSelectionEndDate();

			this.getModel('ViewModel').setProperty('/FilterParameters', {
				Plant: filterParameters.Plant,
				Workcenters: [],
				Plangroups: [],
				SystemCondition: '',
				Systcond: '',
				FunctLocs: filterParameters.FunctLocs && filterParameters.FunctLocs.split(',').map(this.modifyUserParameterStringToObject.bind(this, 'FunctLoc')) || [],
				WorkOrderTypes: [],
				ReferenceStartDate: new Date(),
				ReferenceEndDate: endDate,
				GetMyWork: 'X',
				Persons: this.handleMultipleParameters(filterParameters.Persons, 'PersonNumber'),
				ScheduleIdFilter: ''
			});

			if (!this.isRafMaintUser()) {
				this.setVariantsToModel();
			}

			$.when(
					this.oDataUtil.read('WorkCenterSet', workCenterParameters),
					this.oDataUtil.read('PlanningGroupSet', planGroupParameters)
				)
				.done(this.handleUserParametersObjectsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
		},

		handleUserParametersObjectsSuccess: function(workcenters, planGroups) {
			this.getModel('ViewModel').setProperty('/FilterParameters/Workcenters', workcenters);
			this.getModel('ViewModel').setProperty('/FilterParameters/Plangroups', planGroups);

			this.initialFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));

			var filterParams = this.getModel('ViewModel').getProperty('/FilterParameters');
			this.getModel('ViewModel').setProperty('/OriginalFilterParameters', this.generateFilterParametersCopy(filterParams));
			this.setDefaultVariant();
		},

		handleListRefresh: function() {
			this.areObjectsIdentical(
				this.getModel('ViewModel').getProperty('/FilterParameters'),
				this.initialFilterParameters
			) ? this.refreshOfflineOrders() : this.getFilteredOrders();
		},

		refreshOfflineOrders: function() {
			if (this.isHybridApplicationUser()) {
				this.setAppBusyMode();

				this.refreshOrders()
					.always(function() {
						if (this.getElementById('pullToRefresh')) {
							this.getElementById('pullToRefresh').hide();
						}
						this.setAppNotBusyMode();
					}.bind(this));
			} else {
				this.getOrdersForBrowser();
			}
		},

		getOrdersForBrowser: function() {
			var parameters = {
				recordOperation: true,
				urlParameters: {
					'$expand': 'Operations,Attachments,Components,Assignments,Objects,Measurements'
				}
			};

			if (this.isRafMaintUser()) {
				parameters.urlParameters['$expand'] += ',GoodsIssues';
			}

			this.getOrders(parameters);
		},

		getFilteredOrders: function() {
			var parameters = {
				online: true,
				filters: this.constructFilterArray(),
				recordOperation: true,
				urlParameters: {
					'$expand': 'Operations,Attachments,Components,Assignments,Objects,Measurements'
				}
			};

			if (this.isRafMaintUser()) {
				parameters.urlParameters['$expand'] += ',GoodsIssues';
			}

			this.getOrders(parameters);
		},

		getOrders: function(parameters) {
			this.openBusyDialog({
				service: 'WorkOrderSet'
			});

			parameters = parameters || {};
			this.oDataUtil.read('WorkOrderSet', parameters)
				.done(this.handleGetOrdersSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(function() {
					if (this.getElementById('pullToRefresh')) {
						this.getElementById('pullToRefresh').hide();
					}
					this.closeBusyDialog();
				}.bind(this));
		},

		handleGetOrdersSuccess: function(orders) {
			orders = (orders || []).map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil));
			var relevantUserIds = this.getRelevantUserIds();
			var relevantWorkCenters = this.getRelevantWorkCenters();
			var myWorkOrders = $.extend(true, [], orders);
			var myWorks;
			relevantUserIds = relevantUserIds && relevantUserIds.length ? relevantUserIds : null;
			relevantWorkCenters = relevantWorkCenters && relevantWorkCenters.length ? relevantWorkCenters : null;
			if (this.getRootControl().areUserParametersSet()) {
				myWorks = this.getMyWorkRelevantOperations(myWorkOrders, relevantUserIds, relevantWorkCenters);
				this.getModel('MyWorksModel').setProperty('/MyWorks', myWorks);
				this.getModel('MyWorkOrdersModel').setProperty('/MyWorks', orders);
			} else {
				this.subscribeToEvent('root', 'userParametersAreSet', function() {
					myWorks = this.getMyWorkRelevantOperations(myWorkOrders);
					this.getModel('MyWorksModel').setProperty('/MyWorks', myWorks);
					this.getModel('MyWorkOrdersModel').setProperty('/MyWorks', orders);
				}.bind(this));
			}
		},

		handleScanSuccess: function(result) {
			this.getElementById('myWorksSearchField').setValue(result.text || '');

			this.filterOrders(result.text || '');
		},

		filterOrders: function(searchValue) {
			var list = this.getElementById('myWorkListContainer');
			var listFilter = new sap.ui.model.Filter(
				this.generateFilter('Orderid', [searchValue.toUpperCase()], 'Contains')
				.concat(
					this.generateFilter('FunctLoc', [searchValue.toUpperCase()], 'Contains'),
					this.generateFilter('FunctLocDescr', [searchValue.toUpperCase()], 'Contains'),
					this.generateFilter('Equipment', [searchValue.toUpperCase()], 'Contains'),
					this.generateFilter('EquipmentDescr', [searchValue.toUpperCase()], 'Contains')
				)
			);

			list
				.getBinding('items')
				.filter([listFilter]);
		},

		filterListWithScheduleId: function(scheduleId, list) {
			var listFilter = this.generateFilter('Completed', ['X'], 'NE');

			if (scheduleId) {
				listFilter = listFilter.concat(this.generateFilter('ScheduleId', [scheduleId]));
			}

			list
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter({
						filters: listFilter,
						and: true
					})
				]);
		},

		shouldShowMaster: function(navigationData) {
			return !!(
				this.isMyWorksRoute() &&
				(this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'MyWorks') ||
					this.navigatedToDetailViewFromView(navigationData, 'CreateOrder', 'MyWorks'))
			);
		},

		isMyWorksRoute: function() {
			return location.hash.split('/').pop() === 'MyWorks';
		},

		addListFunctionalLocationToModel: function(functionalLocations) {
			this.getModel('ViewModel').setProperty(
				'/FilterParameters/FunctLocs',
				this.getModel('ViewModel').getProperty('/FilterParameters/FunctLocs')
				.concat(functionalLocations)
				.filter(this.filterDublicateFunctionalLocations)
			);
		},

		constructFilterArray: function() {
			var filterObject = this.getModel('ViewModel').getProperty('/FilterParameters');

			var arrayOfValues = [
				filterObject.Plant, filterObject.FunctLocs, filterObject.WorkOrderTypes,
				filterObject.Priority, filterObject.Workcenters, filterObject.Plangroups,
				filterObject.SystemCondition, filterObject.GetMyWork, filterObject.Persons,
				filterObject.Systcond, filterObject.ScheduleIdFilter
			];
			var arrayOfDateValues = [
				[filterObject.ReferenceStartDate, filterObject.ReferenceEndDate]
			];

			return this.createArray(arrayOfValues, arrayOfDateValues);
		},

		createArray: function(arrayOfValues, arrayOfDateValues) {
			var arrayParametersToIndecies = {
				'FunctLoc': 1,
				'Workcenter': 4,
				'Plangroup': 5,
				'OrderType': 2,
				'PersonNumberFilter': 8
			};

			var arrayOfProperties = [
				'WorkcenterPlant', 'FunctLoc', 'OrderType',
				'Priority', 'Workcenter', 'Plangroup',
				'SystemStatus', 'GetMyWork', 'PersonNumberFilter',
				'SystcondFilter', 'ScheduleIdFilter'
			];

			var servicePropertyToObjectKey = {
				'FunctLoc': 'FunctLoc',
				'Workcenter': 'Workcenter',
				'Plangroup': 'Plangroup',
				'OrderType': 'OrderType',
				'PersonNumberFilter': 'PersonNumber'
			};

			var arrayOfDateProperties = ['ReferenceDate'];

			var filterArray = arrayOfProperties.reduce(function(array, value, index) {
				var parameter = '';

				if (arrayParametersToIndecies[value]) {
					parameter = (arrayOfValues[arrayParametersToIndecies[value]] || []).map(function(parameterObject) {
						return parameterObject[servicePropertyToObjectKey[value]];
					}).join(',');
				} else {
					parameter = arrayOfValues[index];
				}
				return parameter ? array.concat(this.generateFilter(value, parameter.split(','))) : array;
			}.bind(this), []);

			filterArray = arrayOfDateValues.reduce(function(array, value, i) {
				return value[1] && value[0] ? array.concat(new sap.ui.model.Filter(arrayOfDateProperties[i], sap.ui.model.FilterOperator.BT, value[1].setHours(12), value[0].setHours(12))) : array;
			}, filterArray);

			return filterArray;
		},

		handleOrderPostEnd: function() {
			var list = this.getElementById('myWorkListContainer');

			this.setAppNotBusyMode();

			list.removeSelections(true);

			this.getModel('ViewModel').setProperty('/EnableCompleteOperations', false);

			this.getElementById('selectAllCheckBox').setSelected(false);
		},

		handleStartRecording: function(options) {
			this.getModel('ViewModel').setProperty('/IsRecordingCurrentMyWork', true);
			this.getTimeRecordUtility().startRecording(options);
		},

		handleStopTimeRecording: function(record, newRecord) {
			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TITLE'),
				message: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TEXT'),
				onClose: this.handleStopTimeRecordQuestionClose.bind(this, record, newRecord),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleStopTimeRecordQuestionClose: function(record, newRecord, action) {
			if (action === 'YES') {
				this.openTimeRecordConfirmation(record);
			} else if (action === 'NO') {
				this.getTimeRecordUtility().finishCurrentRecording();
				this.handleStartRecording(newRecord);
			}
		},

		openTimeRecordConfirmation: function(record) {
			this.getModel('ViewModel').setProperty('/IsRecordingCurrentMyWork', false);
			this.getTimeRecordUtility().finishCurrentRecording();
			this.openDialog('TimeRecordConfirmationDialog', {
				record: record,
				type: 'OPERATION'
			});
		},

		setVariantsToModel: function() {
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/Existing', this.getVariantsWithType('MYWORKS'));
			this.getModel('ViewModel').setProperty('/Variants', this.getVariantsWithTypeSelectionList('MYWORKS'));
		},

		setDefaultVariant: function() {
			var defaults = this.getDefaultVariants();
			var defaultVariant = '000';
			if (defaults['MYWORKS']) {
				defaultVariant = defaults['MYWORKS'];
			}
			this.getModel('ViewModel').setProperty('/SelectedVariant', defaultVariant);
			this.onSelectedVariantChange();
		}

	});
});