sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.WorkFlowApprovalSplitContainer', {

		onInit: function() {
			this.workFlowApprovalSplitContainer = this.byId('workFlowApprovalSplitContainer');

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'tilePageRouteMatched', this.hideMaster.bind(this));

			this.workFlowApprovalSplitContainer.attachOrientationChange(this.handleOrientationChange.bind(this));
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('workFlowApprovalSplitContainer', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		detailNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('workFlowApprovalSplitContainer', 'detailNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		showMaster: function() {
			this.workFlowApprovalSplitContainer.showMaster();
		},

		hideMaster: function() {
			this.workFlowApprovalSplitContainer.hideMaster();
		},

		getSplitContainer: function() {
			return this.workFlowApprovalSplitContainer;
		},

		handleOrientationChange: function(event) {
			if (location.hash.indexOf('WorkFlow') !== -1 && this.isTablet() && !event.getParameter('landscape') && this.workFlowApprovalSplitContainer.getMode() === 'ShowHideMode') {
				this.workFlowApprovalSplitContainer.showMaster();
			}
		}

	});
});