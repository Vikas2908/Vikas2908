sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.EditVariants', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel', {
				Items: [],
				OriginalItems: [],
				EditVariantView: true,
				IsOrderList: false,
				IsMyWorkList: false,
				IsNotificationList: false,
				FilterParameters: {},
				EditValuesPath: '/'
			});
			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.subscribeToEvent('root', 'variantsUpdated', this.setViewData.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'AdvancedSearchEditVariantsFunctionalLocations', this.handleListFunctionalLocationsSelected.bind(this));
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'EditVariants') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				this.getModel('ViewModel').setProperty('/Type', this.getUrlParameter('type'));
				this.setViewData();
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView) && this.navigatedFrom(navigationData.fromView, 'FunctionalLocationHierarchy')) {
				this.onEditValuesPress(null, true);
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onEditButtonPress: function(oEvent) {
			var path = oEvent.getSource().getBindingContext('ViewModel').getPath();
			this.getModel('ViewModel').setProperty(path + '/IsEditing', true);
		},

		onSaveButtonPress: function(oEvent) {
			var oBinding = oEvent.getSource().getBindingContext('ViewModel');
			var path = oBinding.getPath();
			var object = oBinding.getObject();
			this.getModel('ViewModel').setProperty(path + '/IsEditing', false);
			var index = path.split('/')[path.split('/').length - 1];
			var original = this.getModel('ViewModel').getProperty('/OriginalItems/' + index);
			if (original.Description !== object.Description || original.IsDefault !== object.IsDefault || original.Data !== object.Data) {
				this.setVariantListBusy(true);
				this.updateVariant(
						object.VariantId,
						this.getModel('ViewModel').getProperty('/Type'),
						object.Description,
						JSON.parse(object.Data),
						object.IsDefault
					)
					.done(function() {
						this.getModel('ViewModel').setProperty('/OriginalItems/' + index + '/IsDefault', object.IsDefault);
						this.getModel('ViewModel').setProperty('/OriginalItems/' + index + '/Description', object.Description);
						this.getModel('ViewModel').setProperty('/OriginalItems/' + index + '/Data', object.Data);
						if (this.isOffline()) {
							this.setViewData();
						}
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setVariantListBusy.bind(this, false));
			}
		},

		onDeleteButtonPress: function(oEvent) {
			var oBinding = oEvent.getSource().getBindingContext('ViewModel');
			var object = oBinding.getObject();
			this.setVariantListBusy(true);
			this.deleteVariant(object.VariantId, this.getModel('ViewModel').getProperty('/Type'))
				.done(this.removeVariantFromList.bind(this, object.VariantId))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setVariantListBusy.bind(this, false));
		},

		onCancelButtonPress: function(oEvent) {
			var path = oEvent.getSource().getBindingContext('ViewModel').getPath();
			this.getModel('ViewModel').setProperty(path + '/IsEditing', false);
			var index = path.split('/')[path.split('/').length - 1];
			var original = this.getModel('ViewModel').getProperty('/OriginalItems/' + index);
			this.getModel('ViewModel').setProperty(path + '/Description', original.Description);
			this.getModel('ViewModel').setProperty(path + '/IsDefault', original.IsDefault);
			this.getModel('ViewModel').setProperty(path + '/Data', original.Data);
		},

		onEditValuesPress: function(oEvent, skipSettingValues) {
			if (!skipSettingValues) {
				var bindingContext = oEvent.getSource().getBindingContext('ViewModel');
				var variantData = bindingContext.getObject().Data || '{}';
				var oModel = this.getModel('ViewModel');
				var path = bindingContext.getPath();
				oModel.setProperty('/EditValuesPath', path);
				var type = oModel.getProperty('/Type');
				oModel.setProperty('/IsOrderList', type === 'ORDERS');
				oModel.setProperty('/IsMyWorkList', type === 'MYWORKS');
				oModel.setProperty('/IsNotificationList', type === 'NOTIFS');
				var oFilterParameters = this.generateFilterParametersObject(JSON.parse(variantData));
				oModel.setProperty('/FilterParameters', oFilterParameters);
			}
			if (type === 'ROUTES') {
				if (!this.getDialog('RoutesAdvancedSearch')) {
					this.initializeFragment('RoutesAdvancedSearch').open();
				} else {
					this.openSimpleDialog('RoutesAdvancedSearch');
				}
			} else if (!this.getDialog('AdvancedSearch')) {
				var advancedSearch = this.initializeFragment('AdvancedSearch');
				var listFunctionalLocationInputControl = this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl');
				listFunctionalLocationInputControl.addValidator(this.functionalLocationListValidator.bind(this));
				this.isHybridApplicationUser() && this.renderSuggestionInput(listFunctionalLocationInputControl);
				advancedSearch.open();
			} else {
				this.openSimpleDialog('AdvancedSearch');
			}
		},

		onAdvancedSearchSavePress: function() {
			var oModel = this.getModel('ViewModel');
			var path = oModel.getProperty('/EditValuesPath');
			var oFilterParameters = oModel.getProperty('/FilterParameters') || {};
			var data = this.generateVariantObject(oFilterParameters);
			oModel.setProperty(path + '/Data', JSON.stringify(data));
			this.onCloseAdvancedSearch();
		},

		onCloseAdvancedSearch: function() {
			var type = this.getModel('ViewModel').getProperty('/Type');
			if (type === 'ROUTES') {
				this.getDialog('RoutesAdvancedSearch').close();
			} else {
				this.getDialog('AdvancedSearch').close();
			}
		},

		onListFunctionalLocationsValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'AdvancedSearchEditVariantsFunctionalLocations');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onNotificationTypeValueHelp: function() {
			var type = this.getModel('ViewModel').getProperty('/Type');
			if (type === 'ORDER' || type === 'MYWORKS') {
				this.openDialog('SearchDialog', this.getOrderTypeDialogParameters());
			} else if (type === 'NOTIFS') {
				this.openDialog('SearchDialog', this.getNotificationTypeDialogParameters());
			}
		},

		onOrderTypeValueHelp: function() {
			var filters = [];
			var type = this.getModel('ViewModel').getProperty('/Type');
			if (type === 'ROUTES') {
				filters = this.generateFilter('Route', ['X']).concat(this.generateFilter('OrderType', [''], 'NE'));
			}
			this.openDialog(
				'SearchDialog',
				this.getOrderTypeDialogParameters({
					filters: filters
				})
			);
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'FilterParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'FilterParameters/Plangroups'
				})
			);
		},

		onScheduleIdValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getScheduleDialogParameters({
					saveModelName: 'ViewModel',
					firstValueToSave: 'FilterParameters/ScheduleIdFilter'
				})
			);
		},

		onMyWorkPersonsValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPersonDialogParameters({
					firstValueToSave: 'FilterParameters/Persons',
					secondValueToSave: '',
					configurationModelName: 'SelectionValuesModel',
					pathToModel: '/Persons',
					multiSelect: true
				})
			);
		},

		onRouteValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getRouteDialogParameters({
					firstValueToSave: 'FilterParameters/Routes'
				})
			);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		setViewData: function() {
			var type = this.getModel('ViewModel').getProperty('/Type');
			var variants = this.getVariantsWithType(type);
			this.getModel('ViewModel').setProperty('/Items', variants);
			this.getModel('ViewModel').setProperty('/OriginalItems', JSON.parse(JSON.stringify(variants)));
		},

		removeVariantFromList: function(variantId) {
			var oModel = this.getModel('ViewModel');
			oModel.setProperty(
				'/Items',
				oModel.getProperty('/Items').filter(function(item) {
					return item.VariantId !== variantId;
				})
			);
			oModel.setProperty(
				'/OriginalItems',
				oModel.getProperty('/OriginalItems').filter(function(originalItem) {
					return originalItem.VariantId !== variantId;
				})
			);
		},

		handleListFunctionalLocationsSelected: function(channel, eventName, selectedObject) {
			this.addListFunctionalLocationToModel([selectedObject.Floc]);
		},

		addListFunctionalLocationToModel: function(functionalLocations) {
			this.getModel('ViewModel').setProperty(
				'/FilterParameters/FunctLocs',
				this.getModel('ViewModel').getProperty('/FilterParameters/FunctLocs')
				.concat(functionalLocations)
				.map(this.removeObjectLayer)
				.filter(this.filterDublicates)
				.map(this.modifyUserParameterStringToObject.bind(this, 'FunctLoc'))
			);
		},

		setVariantListBusy: function(bBusy) {
			this.getModel('ViewModel').setProperty('/VariantListBusy', bBusy || false);
		}

	});
});