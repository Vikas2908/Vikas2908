sap.ui.define([
	'com/upm/maint/controller/BaseController',
	'com/upm/maint/util/CustomFileUploader'
], function(BaseController, CustomFileUploader) {
	var nfcReadSuccessHandler;
	var hasAttachedEmptyTagListener;

	return BaseController.extend('com.upm.maint.controller.CommonController', {

		getUserId: function() {
			return this.getGlobalModel().getProperty('/UserId');
		},

		getNotificationModel: function() {
			return this.getModel('NewNotificationModel');
		},

		getOrderModel: function() {
			return this.getModel('NewOrderModel');
		},

		getGlobalModel: function() {
			return this.getModel('GlobalPropertiesModel');
		},

		getConfigurationModel: function() {
			return this.getModel('ConfigurationModel');
		},

		getObjectInfoModel: function() {
			return this.getModel('ObjectInfoModel');
		},

		getSelectionValuesModel: function() {
			return this.getModel('SelectionValuesModel');
		},

		getNotificationNumber: function() {
			return this.getNotificationModel().getProperty('/NotifNo');
		},

		getOrderNumber: function() {
			return this.getOrderModel().getProperty('/Orderid');
		},

		getActivityPath: function(activity) {
			var operations = this.getOrderModel().getProperty('/Operations') || [];
			var operationIndex = -1;
			operations.some(function(operation, index) {
				if (operation.Activity === activity) {
					operationIndex = index;
					return true;
				}
			});
			if (operationIndex > -1) {
				return '/Operations/' + operationIndex;
			}
		},

		getSAPCloudTenant: function() {
			var tenant = '';
			var host = this.devapp && this.devapp.smpInfo && this.devapp.smpInfo.server || '';

			if (host) {
				var urlParts = host.split('-');
				tenant = urlParts[1].split('.')[0];
			}

			return tenant;
		},

		getUserParameters: function() {
			return this.getModel('UserPreferences').getData();
		},

		getUserIdParameters: function() {
			return this.getUserParameters().Persons;
		},

		getAlternativeLabelingCategory: function() {
			var category = this.getUserParameters().AlternativeLabelCategory;

			if (!category) {
				category = this.getDefaultCategory();
			}
			return category;
		},

		getDefaultCategory: function() {
			var categories = this.getSelectionValuesModel().getProperty('/AlternativeLabelingCategories');
			var primaryCategory = categories && categories.filter(function(category) {
				return !!category.PrimarySystem;
			});

			return primaryCategory && primaryCategory.length ? primaryCategory[0].LabelSystem : '';
		},

		hasRequiredParameters: function() {
			var userParameters = this.getUserParameters();
			var hasRequiredUserParameters = true;

			// hybrid and browser have different required parameters
			if (this.isHybridApplicationUser()) {
				hasRequiredUserParameters = !!(!userParameters || !userParameters.hasOwnProperty('Plant') || (userParameters.Plant && (userParameters.Workcenters || userParameters.Plangroups)));
			} else {
				hasRequiredUserParameters = !!(!userParameters || !userParameters.hasOwnProperty('Plant') || userParameters.Plant);
			}

			return hasRequiredUserParameters;
		},

		flushOfflineStore: function() {
			var deferred = $.Deferred();

			if (!this.getGlobalModel().getProperty('/PostingLocalStorage')) {
				this.getGlobalModel().setProperty('/PostingLocalStorage', true);
				$.when(
					this.postLocalStorage()
				).always(function() {
					this.getGlobalModel().setProperty('/PostingLocalStorage', false);
					deferred.resolve();
				}.bind(this));
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		postLocalStorage: function() {
			return $.when.apply(this, this.getPostMethods());
		},

		getPostMethods: function() {
			return this.localStorage.getProperty('/TimeConfirmations').map(this.generateTimeConfirmationPostObject.bind(this)).map(this.generateTimeConfirmationPostMethod.bind(this))
				.concat(
					this.localStorage.getProperty('/Notifications').map(this.generateNotificationPostObject.bind(this)).map(this.generatePostMethod.bind(this)),
					this.localStorage.getProperty('/Orders').map(this.generateOrderPostObject.bind(this)).map(this.generateOrderPostMethod.bind(this)),
					this.localStorage.getProperty('/Routes').map(this.generateRoutePostMethod.bind(this)),
					this.localStorage.getProperty('/Variants').map(this.generateVariantPostMethod.bind(this)),
					this.localStorage.getProperty('/RemoveVariants').map(this.generateRemoveVariantMethod.bind(this))
				);
		},

		generateOrderPostObject: function(saveObject) {
			saveObject = this.getPostObject(saveObject);

			var timeProperties = ['StartTime', 'FinishTime', 'CreatedTime'];

			timeProperties.forEach(function(timeProperty) {
				if (saveObject[timeProperty]) {
					saveObject[timeProperty] = this.formatterUtil.formatOdataTime(saveObject[timeProperty]);
				}
			}.bind(this));

			(Array.isArray(saveObject.Operations) ? saveObject.Operations : []).map(this.modifyOperationProperties.bind(this));
			(Array.isArray(saveObject.Components) ? saveObject.Components : []).map(this.removeComponentProperties.bind(this));
			(Array.isArray(saveObject.Assignments) ? saveObject.Assignments : []).map(this.modifyOperationAssignments.bind(this));
			(Array.isArray(saveObject.Objects) ? saveObject.Objects : []).map(this.modifyObjectProperties.bind(this));
			(Array.isArray(saveObject.Measurements) ? saveObject.Measurements : []).map(this.modifyMeasurementProperties.bind(this));

			if (this.getConfigurationModel().getOrderURLParameters().indexOf('GoodsIssues') !== -1) {
				(Array.isArray(saveObject.GoodsIssues) ? saveObject.GoodsIssues : []).map(this.removeMetadataProperty.bind(this));
			} else {
				delete saveObject.GoodsIssues;
			}
			delete saveObject.NotifType;

			return saveObject;
		},

		generateTimeConfirmationPostObject: function(saveObject) {
			var postObject = $.extend(true, {}, saveObject);
			var isConfirmationForOperation = !!saveObject.Activity;

			var object = {
				PostingDate: postObject.PostingDate,
				ConfirmedTime: postObject.ConfirmedTime,
				Orderid: postObject.Orderid
			};

			if (isConfirmationForOperation) {
				object.Activity = postObject.Activity;
			}

			return object;
		},

		generateNotificationPostObject: function(saveObject) {
			saveObject = this.getPostObject(saveObject);

			if (saveObject.NotifTime) {
				saveObject.NotifTime = this.formatterUtil.formatOdataTime(saveObject.NotifTime);
			}
			if (!saveObject.CreateWo) {
				saveObject.WoType = '';
				saveObject.WoPmacttype = '';
			}

			return saveObject;
		},

		getPostObject: function(postObject) {
			var saveObject = $.extend(true, {}, postObject);

			delete saveObject.NotSync;
			delete saveObject.ErrorMessage;
			delete saveObject.__metadata;

			(Array.isArray(saveObject.Attachments) ? saveObject.Attachments : []).map(this.removeAttachmentProperties.bind(this));
			return saveObject;
		},

		getAttachmentPostObject: function(attachment) {
			if (attachment.DocId && !this.formatterUtil.hasTemporaryId(attachment.DocId) && attachment.LinkId) {
				delete attachment.DocId;
			}
			return attachment;
		},

		removeAttachmentProperties: function(attachment) {
			if (attachment.LinkId) {
				delete attachment.DocId;
			}

			delete attachment.__metadata;
			delete attachment['@com.sap.vocabularies.Offline.v1.serverMediaEditLink'];
			delete attachment['@com.sap.vocabularies.Offline.v1.serverMediaReadLink'];

			return attachment;
		},

		removeComponentProperties: function(component) {
			if (component.RequirementTime) {
				component.RequirementTime = this.formatterUtil.formatOdataTime(component.RequirementTime);
			}

			delete component.RequirementQuantityUnit;
			delete component.__metadata;

			return component;
		},

		modifyOperationProperties: function(operation) {
			var timeProperties = ['EarlSchedStartTime', 'EarlSchedFinTime'];

			timeProperties.forEach(function(timeProperty) {
				if (operation[timeProperty]) {
					operation[timeProperty] = this.formatterUtil.formatOdataTime(operation[timeProperty]);
				}
			}.bind(this));

			if (!operation.NumberOfCapacities) {
				operation.NumberOfCapacities = 0;
			}
			delete operation.MyWorkRelevant;
			delete operation.__metadata;

			return operation;
		},

		modifyOperationAssignments: function(assignment) {
			var timeProperties = ['StartTime', 'FinishTime'];

			timeProperties.forEach(function(timeProperty) {
				if (assignment[timeProperty]) {
					assignment[timeProperty] = this.formatterUtil.formatOdataTime(assignment[timeProperty]);
				}
			}.bind(this));

			delete assignment.__metadata;

			return assignment;
		},

		modifyObjectProperties: function(object) {
			delete object.__metadata;

			return object;
		},

		modifyMeasurementProperties: function(measurement) {
			delete measurement.__metadata;

			return measurement;
		},

		modifyCoverWorkOrderProperties: function(coverWorkorder) {
			delete coverWorkorder.__metadata;

			return coverWorkorder;
		},

		removeMetadataProperty: function(object) {
			delete object.__metadata;

			return object;
		},


		generatePostMethod: function(postObject) {
			var deferred = $.Deferred();

			var parameters = {
				online: true
			};

			this.oDataUtil.create('NotifSet', postObject, parameters)
				.done(this.handleLocalStorageNotificationSuccess.bind(this, postObject.NotifNo))
				.fail(this.handleLocalStorageNotificationError.bind(this, postObject.NotifNo))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handleLocalStorageNotificationSuccess: function(notificationNumber, response) {
			if (response) {
				var attachments = $.extend(true, [], Array.isArray(response.Attachments) ? response.Attachments : []);

				(Array.isArray(response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));

				this.localStorage.removeNotification(notificationNumber);
				this.removeListObject('Notifications', notificationNumber);
				this.insertNotificationToList(response);
				this.postAttachments(attachments);
				this.handleSynchronizedNotificationEdit(notificationNumber, response);

				if (response.RouteId) {
					this.handleNotificationCreatedDuringRoute(response, notificationNumber);
				}
			}
		},

		handleLocalStorageNotificationError: function(notificationNumber, errorEvent) {
			this.localStorage.insertNotificationErrorMessage(notificationNumber, this.formatterUtil.oDataErrorToErrorString(errorEvent));
		},

		handleSynchronizedNotificationEdit: function(notificationNumber, response) {
			var notificationModel = this.getNotificationModel();
			var notificationIdIsTemporary = this.formatterUtil.hasTemporaryId(notificationNumber);

			if (notificationModel.getProperty('/NotifNo') === notificationNumber) {
				notificationModel.setProperty(
					'/Attachments',
					this.combineArraysByIdProperty(response.Attachments || [], this.getNotificationModel().getProperty('/Attachments') || [], 'LinkId')
				);
				if (notificationIdIsTemporary) {
					notificationModel.setProperty('/NotifNo', response.NotifNo);
				}
			}
		},

		handleNotificationCreatedDuringRoute: function(notification, notificationNumber) {
			var notificationsCreatedDuringRoute = this.getGlobalModel().getProperty('/NotificationsCreatedDuringRoute');
			var notificationAlreadyInList = notificationsCreatedDuringRoute.some(function(listNotification) {
				return listNotification.NotifNo === notification.NotifNo || listNotification.NotifNo === notificationNumber;
			});

			if (notificationAlreadyInList) {
				notificationsCreatedDuringRoute = notificationsCreatedDuringRoute.map(function(listNotification) {
					if (listNotification.NotifNo === notification.NotifNo || listNotification.NotifNo === notificationNumber) {
						listNotification = notification;
					}

					return listNotification;
				});
			} else {
				notificationsCreatedDuringRoute.push(notification);
			}

			this.getGlobalModel().setProperty('/NotificationsCreatedDuringRoute', notificationsCreatedDuringRoute);
		},

		postOrders: function(orderObjects) {
			var deferred = $.Deferred();

			$.when.apply(this, orderObjects.map(this.generateOrderPostObject.bind(this)).map(this.generateOrderPostMethod.bind(this)))
				.done(deferred.resolve)
				.fail(deferred.reject);

			return deferred.promise();
		},

		generateOrderPostMethod: function(postObject) {
			var deferred = $.Deferred();

			var parameters = {
				online: true
			};

			this.oDataUtil.create('WorkOrderSet', postObject, parameters)
				.done(this.handlePostOrderSuccess.bind(this, postObject.Orderid))
				.fail(this.handlePostOrderError.bind(this, postObject.Orderid))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handlePostOrderSuccess: function(orderNumber, response) {
			if (response) {
				var attachments = $.extend(true, [], Array.isArray(response.Attachments) ? response.Attachments : []);

				(Array.isArray(response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));

				this.localStorage.removeOrder(orderNumber);
				this.removeListObject('Orders', orderNumber);
				this.removeListObject('MyWorks', orderNumber);
				this.insertOrderToList(response);
				this.postAttachments(attachments);
				this.handleOrderReferenceToNotification(response);
				this.handleSynchronizedOrderEdit(orderNumber, response);
			}
		},

		handlePostOrderError: function(orderNumber, errorEvent) {
			this.localStorage.insertOrderErrorMessage(orderNumber, this.formatterUtil.oDataErrorToErrorString(errorEvent));
		},

		generateTimeConfirmationPostMethod: function(postObject) {
			var deferred = $.Deferred();

			var isConfirmationForOperation = !!postObject.Activity;
			postObject.PostingDate = this.getUnixDate(postObject.PostingDate);

			this.oDataUtil.functionImport(isConfirmationForOperation ? 'WorkOrderOperConfirmTime' : 'RouteWorkConfirmTime', postObject)
				.done(this.handleTimeConfirmationPostSuccess.bind(this, postObject))
				.fail(this.handleTimeConfirmationPostError.bind(this, postObject))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handleTimeConfirmationPostSuccess: function(postObject) {
			this.localStorage.removeTimeConfirmation(postObject.Orderid, postObject.Activity);
		},

		handleTimeConfirmationPostError: function(postObject, errorEvent) {
			if (errorEvent && errorEvent.response && errorEvent.response.statusCode === 400) {
				this.localStorage.removeTimeConfirmation(postObject.Orderid, postObject.Activity);
			}
		},

		handleOrderReferenceToNotification: function(response) {
			if (response && response.NotifNo) {
				var notification = this.getNotificationModel().getData();
				this.getModel('NotificationsModel')
					.setProperty('/Notifications',
						this.getModel('NotificationsModel').getProperty('/Notifications')
						.map(function(notificationObject) {
							if (notificationObject.NotifNo === response.NotifNo) {
								notificationObject.WorkOrderNo = response.Orderid;
							}
							return notificationObject;
						})
					);
				if (response.NotifNo && response.NotifNo === notification.NotifNo && !notification.WorkOrderNo) {
					notification.WorkOrderNo = response.Orderid;
					this.getNotificationModel().setData(notification);
				}
			}
		},

		handleSynchronizedOrderEdit: function(orderNumber, response) {
			var orderModel = this.getOrderModel();
			var orderIdIsTemporary = this.formatterUtil.hasTemporaryId(orderNumber);

			if (orderModel.getProperty('/Orderid') === orderNumber) {
				orderModel.setProperty(
					'/Attachments',
					this.combineArraysByIdProperty(response.Attachments || [], this.getOrderModel().getProperty('/Attachments') || [], 'LinkId')
				);
				if (orderIdIsTemporary) {
					orderModel.setProperty('/Orderid', response.Orderid);
				}
			}
		},

		postAttachments: function(attachments) {
			(attachments || [])
			.filter(function(attachment) {
					return !attachment.DocId || attachment.DocId.charAt(0) === '%';
				})
				.forEach(this.postAttachment.bind(this));
		},

		removeAttachments: function(attachments) {
			(attachments || []).forEach(this.removeAttachment.bind(this));
		},

		postRoutes: function(routeObjects) {
			var deferred = $.Deferred();

			$.when.apply(this, routeObjects.map(this.generateRoutePostMethod.bind(this)))
				.done(deferred.resolve)
				.fail(deferred.reject);

			return deferred.promise();
		},

		generateRoutePostObject: function(saveObject) {
			saveObject = this.getPostObject(saveObject);

			var timeProperties = ['StartTime', 'FinishTime'];

			timeProperties.forEach(function(timeProperty) {
				if (saveObject[timeProperty]) {
					saveObject[timeProperty] = this.formatterUtil.formatOdataTime(saveObject[timeProperty]);
				}
			}.bind(this));
			
			(Array.isArray(saveObject.Measurements) ? saveObject.Measurements : []).map(this.modifyMeasurementProperties.bind(this));
			(Array.isArray(saveObject.CoverWorkOrder) ? saveObject.CoverWorkOrder : []).map(this.modifyCoverWorkOrderProperties.bind(this));
			(Array.isArray(saveObject.Objects) ? saveObject.Objects : []).map(this.modifyObjectProperties.bind(this));
			
			// Set Process indicator to correct level
			if (saveObject.ProcessInd === 'X') {
				saveObject.Objects = saveObject.Objects.map(function(oObject) {
					if (oObject.FunctLocInternalId === saveObject.ObjectFunctLocInternalId &&
						oObject.Equipment === saveObject.ObjectEquipment) {
						oObject.ProcessInd = 'X';
					}
					return oObject;
				});
			}

			delete saveObject.Counter;
			delete saveObject.ObjectFunctLocInternalId;
			delete saveObject.ObjectFunctLocLabelSystem;
			delete saveObject.ObjectFunctLoc;
			delete saveObject.ObjectFunctLocDescr;
			delete saveObject.ObjectEquipment;
			delete saveObject.ObjectEquipmentDescr;
			delete saveObject.ProcessInd;

			return saveObject;
		},

		generateRoutePostMethod: function(routeObject) {
			routeObject = this.generateRoutePostObject(routeObject);

			var deferred = $.Deferred();

			var parameters = {
				online: true
			};

			this.oDataUtil.create('RouteWorkSet', routeObject, parameters)
				.done(this.handleRoutePostSuccess.bind(this, routeObject.Orderid))
				.fail(this.handleRoutePostError.bind(this, routeObject.Orderid))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handleRoutePostSuccess: function(orderNumber, response) {
			if (response) {
				this.localStorage.removeRoute(orderNumber);
				this.removeListObject('Routes', orderNumber);
				if (!response.Completed) {
					this.insertRouteToList(response);
				}
			}
		},

		handleRoutePostError: function(orderNumber, errorEvent) {
			this.localStorage.insertRouteErrorMessage(orderNumber, this.formatterUtil.oDataErrorToErrorString(errorEvent));
		},

		generateVariantPostMethod: function(variantObject) {
			variantObject = this.getPostObject(variantObject);
			var deferred = $.Deferred();

			var parameters = {
				online: true
			};

			this.oDataUtil.create('VariantSet', variantObject, parameters)
				.done(this.handleVariantPostSuccess.bind(this, variantObject))
				.fail(this.handleVariantPostError.bind(this, variantObject))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handleVariantPostSuccess: function(variant) {
			this.localStorage.removeVariant(variant);
		},

		handleVariantPostError: function() {

		},

		generateRemoveVariantMethod: function(variantObject) {
			var deferred = $.Deferred();

			var path = 'VariantSet(UserId=\'\',VariantId=\'' + variantObject.VariantId + '\',VariantType=\'' + variantObject.VariantType + '\')';
			this.oDataUtil.remove(path)
				.done(this.handleRemoveVariantSuccess.bind(this, variantObject))
				.fail(this.handleRemoveVariantError.bind(this))
				.always(deferred.resolve);

			return deferred.promise();
		},

		generateRoutePostMethodBackGround: function(routeObject) {
			routeObject = this.generateRoutePostObject(routeObject);

			var deferred = $.Deferred();

			var parameters = {
				online: true
			};

			this.oDataUtil.create('RouteWorkSet', routeObject, parameters)
				.done(this.handleRoutePostSuccessBackGround.bind(this, routeObject.Orderid))
				.fail(this.handleRoutePostErrorBackGround.bind(this, routeObject.Orderid))
				.always(deferred.resolve);

			return deferred.promise();
		},

		handleRemoveVariantSuccess: function(variant) {
			this.localStorage.updateRemoveVariants(variant);
		},

		handleRemoveVariantError: function() {

		},

		handleRoutePostErrorBackGround: function(orderNumber, errorEvent) {
			this.localStorage.insertRouteErrorMessage(orderNumber, this.formatterUtil.oDataErrorToErrorString(errorEvent));
		},

		insertNotificationToList: function(postObject) {
			this.insertObjectToList('NotificationsModel', 'Notifications', postObject);
		},

		insertOrderToList: function(postObject) {
			var myWorkOrder = $.extend(true, {}, postObject);
			this.insertObjectToList('OrdersModel', 'Orders', postObject);
			this.insertObjectToList('MyWorkOrdersModel', 'MyWorks', postObject);
			(this.getMyWorkRelevantOperations([myWorkOrder]) || []).forEach(this.insertMyWorkToList.bind(this));
		},

		insertRouteToList: function(postObject) {
			this.insertObjectToList('RoutesModel', 'Routes', postObject);
		},

		refreshAllOfflineRequests: function() {
			return this.refreshOfflineStore(this.getRootControl().getHelperValues.bind(this.getRootControl()));
		},

		refreshUserParameters: function() {
			return this.refreshOfflineStore(
				this.getRootControl().getUserPreferences.bind(this.getRootControl()), ['UserParamSet']
			);
		},

		refreshPlantSpecificValues: function() {
			var services = this.getConfigurationModel().getOfflinePlantServices();

			return this.refreshOfflineStore(
				this.getRootControl().getPlantSpecificValues.bind(this.getRootControl()), services
			);
		},

		refreshFunctionalLocationValues: function() {
			var services = ['FuncLocSet'];
			var refreshAPICalls = [this.refreshOfflineStore(null, services)];

			if (this.isHybridApplicationUser()) {
				refreshAPICalls.push(this.refreshListValues());
			}
			return $.when.apply(refreshAPICalls);
		},

		refreshListValues: function() {
			var listServices = this.getConfigurationModel().getOfflineListServices();

			return this.refreshOfflineStore(
				this.getRootControl().getListValuesWithUserParameters.bind(this.getRootControl()), listServices
			);
		},

		refreshNotifications: function() {
			return this.refreshOfflineStore(
				this.getRootControl().getNotifications.bind(this.getRootControl()), ['NotifSet']
			);
		},

		refreshOrders: function() {
			return this.refreshOfflineStore(
				this.getRootControl().getOrders.bind(this.getRootControl()), ['WorkOrderSet']
			);
		},

		refreshRouteWorks: function() {
			return this.refreshOfflineStore(
				this.getRootControl().getRouteWorks.bind(this.getRootControl()), ['RouteWorkSet']
			);
		},

		refreshUserSpecificValues: function() {
			return this.refreshListValues();
		},

		refreshVariantValues: function() {
			return this.refreshOfflineStore(
				this.getRootControl().getVariants.bind(this.getRootControl()), ['VariantSet']
			);
		},

		refreshOfflineStore: function(successHandler, requestsToRefresh) {
			var deferred = $.Deferred();

			this.devapp.devLogon.refreshAppOfflineStore(requestsToRefresh)
				.done(function() {
					if (successHandler) {
						successHandler()
							.done(deferred.resolve)
							.fail(deferred.reject);
					} else {
						deferred.resolve();
					}
				})
				.fail(deferred.reject);

			return deferred.promise();
		},

		notificationIsInEditMode: function() {
			return this.getGlobalModel().getProperty('/EditNotification');
		},

		orderIsInEditMode: function() {
			return this.getGlobalModel().getProperty('/EditOrder');
		},

		isRafMaintUser: function() {
			return this.getGlobalModel().getProperty('/IsRafMaintUser');
		},

		isOffline: function() {
			return this.isHybridApplicationUser() && this.getModel('Device').getProperty('/isOffline');
		},

		isHybridApplicationUser: function() {
			return this.getModel('Device').getProperty('/isCordova');
		},

		isResumingFromPlugin: function() {
			return this.getGlobalModel() && this.getGlobalModel().getProperty('/IsResumingFromPlugin');
		},

		isPhone: function() {
			return this.getModel('Device').getProperty('/isPhone');
		},

		isTablet: function() {
			return this.getModel('Device').getProperty('/isTablet');
		},

		isTouch: function() {
			return this.getModel('Device').getProperty('/isTouch');
		},

		isCordova: function() {
			return this.getModel('Device').getProperty('/isCordova');
		},

		getFunctionalLocation: function() {
			return this.getNotificationModel().getProperty('/FunctLocInternalId');
		},

		getOrderFunctionalLocation: function() {
			return this.getOrderModel().getProperty('/FunctLocInternalId');
		},

		getSuperiorFunctionalLocationObject: function(functionalLocation, shouldGetMaterials) {
			var deferred = $.Deferred();

			this.oDataUtil.read('FuncLocSet(\'' + encodeURIComponent(functionalLocation.toUpperCase()) + '\')')
				.done(function(functionalLocationObject) {
					if (functionalLocationObject && (functionalLocationObject.HasChildren || functionalLocationObject.HasEquipment || shouldGetMaterials && functionalLocationObject.HasBomitems)) {
						deferred.resolve(functionalLocationObject);
					} else {
						this.getSuperiorFunctionalLocationObject(functionalLocationObject.Supfloc, shouldGetMaterials)
							.done(deferred.resolve);
					}
				}.bind(this))
				.fail(deferred.reject);

			return deferred.promise();
		},

		filterBySuperiorFunctionalLocation: function(objectId, functionalLocationObject) {
			return functionalLocationObject.Supfloc === objectId || !objectId && !functionalLocationObject;
		},

		filterByFunctionalLocation: function(objectId, functionalLocationObject) {
			return functionalLocationObject.Floc === objectId || !objectId && !functionalLocationObject;
		},

		getFunctionalLocations: function(superiorFunctionalLocation) {
			var parameters = {
				filters: this.generateFilter('Supfloc', [superiorFunctionalLocation])
			};
			this.oDataUtil.read('FuncLocSet', parameters)
				.done(this.handleGetFunctionalLocationsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
		},

		navigateToHierarchy: function(functionalLocation) {
			this.navTo('FunctionalLocationHierarchy', {
				query: {
					SuperiorFunctionalLocation: functionalLocation || ''
				}
			}, false);
		},

		getPlant: function() {
			return this.getNotificationModel().getProperty('/WorkcenterPlant');
		},

		validateTechnicalObject: function(technicalObject) {
			var deferred = $.Deferred();

			if (technicalObject) {
				this.validateFunctionalLocation(technicalObject)
					.done(deferred.resolve)
					.fail(function() {
						this.validateEquipment(technicalObject)
							.done(deferred.resolve)
							.fail(deferred.reject);
					}.bind(this));
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateFunctionalLocation: function(functionalLocation, parameters) {
			return this.getConfigurationModel().getUseAlternativeLabeling() ?
				this.validateFunctionalLocationAlternativeLabel(functionalLocation, parameters) :
				this.validateFunctionalLocationNoAlternativeLabel(functionalLocation, parameters);
		},

		validateFunctionalLocationNoAlternativeLabel: function(functionalLocation, parameters) {
			var deferred = $.Deferred();

			if (functionalLocation) {
				this.oDataUtil.read('FuncLocSet(\'' + encodeURIComponent(functionalLocation.toUpperCase()) + '\')', parameters)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateFunctionalLocationAlternativeLabel: function(functionalLocation, parameters) {
			return functionalLocation.lastIndexOf('?', 0) === 0 ?
				this.validateFunctionalLocationInternalId(functionalLocation) :
				this.validateFunctionalLocationWithLabelAndCategory(functionalLocation, parameters);
		},

		validateFunctionalLocationWithLabelAndCategory: function(functionalLocation, parameters) {
			var deferred = $.Deferred();

			if (functionalLocation) {
				var filter = this.generateFilter('Floc', [functionalLocation.toUpperCase()]).concat(this.generateFilter('LabelSystem', [this.getAlternativeLabelingCategory()]));
				if (parameters) {
					parameters.filters = filter;
				} else {
					parameters = {
						filters: filter
					};
				}
				this.oDataUtil.read(parameters.getFunctionalLocationDetails ? 'FuncLocDetailSet' : 'FuncLocSet', parameters)
					.done(function(functionalLocations) {
						if (functionalLocations.length) {
							deferred.resolve(functionalLocations[0]);
						} else {
							deferred.reject();
						}
					})
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateEquipment: function(equipment, parameters) {
			var deferred = $.Deferred();

			if (equipment) {
				this.oDataUtil.read('EquipmentSet(\'' + encodeURIComponent(equipment.toUpperCase()) + '\')', parameters)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		validateBOM: function(bom) {
			var deferred = $.Deferred();

			if (bom) {
				this.oDataUtil.read('BomItemsSet(Bom=\'' + encodeURIComponent(bom.Bom) + '\',Item=\'' + bom.Item + '\',Structnodetype=\'' + bom.Structnodetype + '\')')
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		validateTechnicalObjectDetails: function(technicalObject) {
			var deferred = $.Deferred();

			if (technicalObject) {
				if (this.isOffline()) {
					this.validateTechnicalObject(technicalObject)
						.done(function(offlineTechnicalObject) {
							deferred.resolve(this.transformToDetailTechnicalObject(offlineTechnicalObject));
						}.bind(this))
						.fail(deferred.reject);
				} else {
					this.validateFunctionalLocationDetails(technicalObject)
						.done(deferred.resolve)
						.fail(function() {
							this.validateEquipmentDetails(technicalObject)
								.done(deferred.resolve)
								.fail(deferred.reject);
						}.bind(this));
				}
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateFunctionalLocationDetails: function(functionalLocation) {
			return this.getConfigurationModel().getUseAlternativeLabeling() ?
				this.validateFunctionalLocationDetailsAlternativeLabel(functionalLocation) :
				this.validateFunctionalLocationDetailsNoAlternativeLabel(functionalLocation);
		},

		validateFunctionalLocationDetailsNoAlternativeLabel: function(functionalLocation) {
			var deferred = $.Deferred();
			var parameters = {
				online: true
			};

			if (functionalLocation) {
				this.oDataUtil.read('FuncLocDetailSet(\'' + encodeURIComponent(functionalLocation.toUpperCase()) + '\')', parameters)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateFunctionalLocationDetailsAlternativeLabel: function(functionalLocation) {
			return functionalLocation.lastIndexOf('?', 0) === 0 ?
				this.validateFunctionalLocationDetailsInternalId(functionalLocation) :
				this.validateFunctionalLocationDetailsWithLabelAndCategory(functionalLocation);
		},

		validateFunctionalLocationDetailsInternalId: function(functionalLocation) {
			return this.validateFunctionalLocationInternalId(functionalLocation, {
				getFunctionalLocationDetails: true,
				online: true
			});
		},

		validateFunctionalLocationDetailsWithLabelAndCategory: function(functionalLocation) {
			return this.validateFunctionalLocationWithLabelAndCategory(functionalLocation, {
				getFunctionalLocationDetails: true,
				online: true
			});
		},

		validateEquipmentDetails: function(functionalLocation) {
			var deferred = $.Deferred();
			var parameters = {
				online: true
			};

			if (functionalLocation) {
				this.oDataUtil.read('EquipmentDetailSet(\'' + encodeURIComponent(functionalLocation.toUpperCase()) + '\')', parameters)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		validateFunctionalLocationInternalId: function(functionalLocation, parameters) {
			var deferred = $.Deferred();

			var service = parameters && parameters.getFunctionalLocationDetails ? 'FuncLocDetailSet' : 'FuncLocSet';

			if (functionalLocation) {
				this.oDataUtil.read(service + '(\'' + encodeURIComponent(functionalLocation) + '\')', parameters)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		transformToDetailTechnicalObject: function(technicalObject) {
			var detailTechnicalObject = {};
			if (technicalObject.Equnr) {
				detailTechnicalObject.Equnr = technicalObject.Equnr;
				detailTechnicalObject.Descr = technicalObject.Descr;
				detailTechnicalObject.Supfloc = technicalObject.Supfloc;
				detailTechnicalObject.Plangroup = technicalObject.Plangroup;
			} else {
				detailTechnicalObject.Floc = technicalObject.Floc;
				detailTechnicalObject.Descr = technicalObject.Descr;
				detailTechnicalObject.Supfloc = technicalObject.Supfloc;
				detailTechnicalObject.Plangroup = technicalObject.Plangroup;
				detailTechnicalObject.Workcenter = technicalObject.Workcenter;
			}

			detailTechnicalObject.IsFromOfflineStorage = true;

			return detailTechnicalObject;
		},

		openSuccessDialog: function(dialogText, workOrder) {
			this.getModel('ViewModel').setProperty('/SuccessDialogText', dialogText);
			this.getModel('ViewModel').setProperty('/SuccessDialogWorkOrder', workOrder || '');
			this.openSimpleDialog('SuccessDialog');
		},

		onSuccessDialogOkButtonPress: function() {
			this.getModel('ViewModel').setProperty('/SuccessDialogWorkOrder', '');
			this.getDialog('SuccessDialog').close();
		},

		onSuccessDialogToWorkOrderButtonPress: function() {
			this.getDialog('SuccessDialog').close();
			var workOrder = this.getModel('ViewModel').getProperty('/SuccessDialogWorkOrder');
			this.handleNavigateToOrder(workOrder);
		},

		onSuccessDialogClose: function() {
			var workOrder = this.getModel('ViewModel').getProperty('/SuccessDialogWorkOrder');
			if (!workOrder) {
				this.onNavBack();
			}
			this.getModel('ViewModel').setProperty('/SuccessDialogWorkOrder', '');
		},

		openPushNotificationDialog: function(dialogText, data) {
			if (!this.getModel('ViewModel')) {
				this.setModel('ViewModel');
			}
			this.getModel('ViewModel').setProperty('/PushNotificationText', dialogText);
			this.getModel('ViewModel').setProperty('/PushNotificationData', data);
			this.openSimpleDialog('PushNotificationDialog');
		},

		onPushNotificationOpen: function() {
			this.getDialog('PushNotificationDialog').close();
			var data = this.getModel('ViewModel').getProperty('/PushNotificationData') || {};
			if (data.type === 'NOTIFICATION' && data.id) {
				this.handleNavigateToNotification(data.id);
			} else if (data.type === 'ORDER' && data.id) {
				this.handleNavigateToOrder(data.id);
			} else if (data.type === 'OPERATION' && data.id && data.operation) {
				this.navTo('EditMyWork', {
					Purpose: 'Display',
					OrderNumber: data.id,
					query: {
						Tab: 'Operations',
						Activity: data.operation
					}
				});
			}
		},

		onPushNotificationClose: function() {
			this.getDialog('PushNotificationDialog').close();
		},

		openNavigationConfimation: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('CONFIRM_NAVIGATING_BACK_TEXT'),
				onClose: this.handleConfirmPopUpClose.bind(this),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.onNavBack();
		},

		updateNotifications: function() {
			this.oDataUtil.read('NotifSet')
				.done(this.handleUpdateNotificationsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleUpdateNotificationsSuccess: function(notifications) {
			this.getModel('NotificationsModel').setProperty('/Notifications', notifications);
		},

		parseUserParameters: function(userParameters) {
			var userParameterPropertieCodes = this.getUserParameterPropertieCodes();
			return userParameters.reduce(function(userParamtersObject, userParameter) {
				if (userParameter && userParameter.ParamType) {
					userParamtersObject[userParameterPropertieCodes[userParameter.ParamType]] = userParameter.UserParameter;
				}
				return userParamtersObject;
			}, {});
		},

		getUserParameterPropertieCodes: function() {
			return {
				'01': 'Plant',
				'02': 'FunctLocInternalId',
				'03': 'FunctLocs',
				'04': 'Workcenters',
				'05': 'Plangroups',
				'06': 'DateRange',
				'07': 'MaxResults',
				'08': 'AlternativeLabelCategory',
				'21': 'NotificationType',
				'22': 'WorkOrderType',
				'23': 'Persons',
				'24': 'Routes',
				'41': 'Printers',
				'42': 'PushNotifsDisabled',
				'51': 'Warehouse'
			};
		},

		getTopValue: function() {
			var maxResults = 0;
			var userParams = this.getUserParameters();
			if (userParams.MaxResults && userParams.MaxResults !== '0') {
				maxResults = Number(userParams.MaxResults);
			}
			return maxResults;
		},

		parseAuthorizations: function(authorizations) {
			var authorizationPropertieCodes = this.getAuthorizationrPropertieCodes();
			return authorizations.reduce(function(authorizationsObject, authorization) {
				if (authorization && authorization.Action) {
					authorizationsObject[authorizationPropertieCodes[authorization.Action]] = !!authorization.IsAuthorized;
				}
				return authorizationsObject;
			}, {});
		},

		getAuthorizationrPropertieCodes: function() {
			return {
				'EQUIPMENTCHANGE': 'HasEquipmentExchangeRole'
			};
		},

		handleMultipleParameters: function(parameter, property) {
			return parameter && parameter.split(',').map(this.modifyUserParameterStringToObject.bind(this, property)) || [];
		},

		getPlantDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/Plants',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'Plant',
				listItemDescriptionKey: 'Name',
				firstValueToSave: 'UserParameters/Plant',
				secondValueToSave: 'PlantDescr',
				dialogTitle: this.getResourceBundleText('SELECT_PLANT_DIALOG_TITLE'),
				itemPressHandler: this.handlePlantSelected.bind(this)
			}, properties);
		},

		onRevisionValueHelp: function() {
			var parameters = this.getRevisionDialogParameters({
				saveModelName: 'ViewModel',
				firstValueToSave: 'FilterParameters/ScheduleIdFilter',
				secondValueToSave: ''
			});
			this.openDialog('RevisionDialog', parameters);
		},

		getRevisionDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/ScheduleIds',
				saveModelName: 'NewOrderModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'ScheduleId',
				listItemDescriptionKey: 'Description',
				firstValueToSave: 'Revision',
				secondValueToSave: 'RevisionDescr',
				firstAdditionalInfo: 'StartDate',
				secondAdditionalInfo: 'EndDate',
				dialogTitle: this.getResourceBundleText('SELECT_REVISIO_DIALOG_TITLE')
			}, properties);
		},

		getNotificationTypeDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/NotificationTypeValues',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'Notiftype',
				listItemDescriptionKey: 'Notiftypetext',
				firstValueToSave: 'FilterParameters/NotificationTypes',
				multiSelect: true,
				dialogTitle: this.getResourceBundleText('SELECT_NOTIFICATION_TYPE_DIALOG_TITLE'),
				filters: this.generateFilter('List', ['X']).concat(this.generateFilter('Notiftype', [''], 'NE'))
			}, properties);
		},

		getOrderTypeDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/OrderTypeValues',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'OrderType',
				listItemDescriptionKey: 'Name',
				firstValueToSave: 'FilterParameters/WorkOrderTypes',
				multiSelect: true,
				dialogTitle: this.getResourceBundleText('SELECT_ORDER_TYPE_DIALOG_TITLE'),
				filters: this.generateFilter('List', ['X']).concat(this.generateFilter('OrderType', [''], 'NE'))
			}, properties);
		},

		getWorkCenterDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/WorkCenters',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'Workcenter',
				listItemDescriptionKey: 'Name',
				firstValueToSave: 'Workcenter',
				secondValueToSave: 'WorkcenterDescr',
				dialogTitle: this.getResourceBundleText('SELECT_WORK_CENTER_DIALOG_TITLE'),
				multiSelect: true
			}, properties);
		},

		getPlannerGroupDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/PlanGroups',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'Plangroup',
				listItemDescriptionKey: 'PlangroupDescr',
				firstValueToSave: 'Plangroup',
				dialogTitle: this.getResourceBundleText('SELECT_PLANNING_GROUP_DIALOG_TITLE'),
				multiSelect: true
			}, properties);
		},

		getCatalogProfileDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/CatalogProfiles',
				saveModelName: 'NewNotificationModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'CatalogProfile',
				listItemDescriptionKey: 'CatalogProfileDescr',
				firstValueToSave: 'CatalogProfile',
				secondValueToSave: 'CatalogProfileDescr',
				dialogTitle: this.getResourceBundleText('SELECT_CATALOG_PROFILE_TITLE')
			}, properties);
		},

		getRouteDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/RouteIds',
				saveModelName: 'ViewModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'RouteId',
				listItemDescriptionKey: 'RouteDescr',
				firstValueToSave: 'RouteId',
				dialogTitle: this.getResourceBundleText('SELECT_ROUTE_DIALOG_TITLE'),
				multiSelect: true,
				filters: this.generateFilter('RouteId', [''], 'NE')
			}, properties);
		},

		getScheduleDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/ScheduleIds',
				saveModelName: 'NewOperationModel',
				configurationModelName: 'SelectionValuesModel',
				listItemValueKey: 'ScheduleId',
				listItemDescriptionKey: 'Description',
				firstValueToSave: 'ScheduleId',
				dialogTitle: this.getResourceBundleText('SELECT_SCHEDULE_DIALOG_TITLE'),
				filters: this.generateFilter('ScheduleId', [''], 'NE')
			}, properties);
		},

		getPersonDialogParameters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/PersonsToAssign',
				saveModelName: 'ViewModel',
				configurationModelName: 'ViewModel',
				listItemValueKey: 'PersonNumber',
				listItemDescriptionKey: 'Fullname',
				firstValueToSave: 'AssignPersonParameters/PersonNumber',
				secondValueToSave: 'AssignPersonParameters/Fullname',
				dialogTitle: this.getResourceBundleText('SELECT_PERSON_DIALOG_TITLE')
			}, properties);
		},

		getEquipmenActionDialogParamaters: function(properties) {
			properties = properties || {};
			return $.extend({
				pathToModel: '/EquipmentsToInstall',
				saveModelName: 'ViewModel',
				configurationModelName: 'ViewModel',
				listItemValueKey: 'Equnr',
				listItemDescriptionKey: 'EqunrDescr',
				firstValueToSave: 'EquipmentPlaceHolder',
				dialogTitle: this.getResourceBundleText('SELECT_EQUIPMENT_TO_INSTALL_TITLE'),
				itemPressHandler: this.onEquipmentToInstallSelect.bind(this)
			}, properties);
		},

		getShortText: function(longText) {
			var shortText = longText && longText.split('\\n').shift() || '';
			return shortText.substring(0, shortText.length <= 40 ? shortText.length : 40);
		},

		handleHardwareNavBack: function() {
			if ($('#sap-ui-blocklayer-popup').css('visibility') !== 'hidden') {
				this.closePopups();
			} else if (this.onHardwareNavigateBack) {
				this.onHardwareNavigateBack();
			} else {
				this.onNavigateBack ? this.onNavigateBack() : this.onNavBack();
			}
		},

		insertObjectToList: function(model, property, item) {
			var idProperty = this.getIdProperty(property);

			this.listHasEnty(this.getModel(model).getProperty('/' + property), property, idProperty, item) ?
				this.replaceOldListObject(model, idProperty, property, item) :
				this.pushObjectToList(model, property, item);
		},

		removeListObject: function(modelProperty, id) {
			var idProperty = this.getIdProperty(modelProperty);
			var model = this.getListModel(modelProperty);

			model.setProperty(
				'/' + modelProperty,
				model.getProperty('/' + modelProperty).filter(function(object) {
					return object[idProperty] !== id;
				})
			);
		},

		getIdProperty: function(modelProperty) {
			return {
				'Notifications': 'NotifNo',
				'Orders': 'Orderid',
				'MyWorks': 'Orderid',
				'Routes': 'Orderid'
			} [modelProperty];
		},

		insertMyWorkToList: function(operation) {
			var listHasEntry = this.getModel('MyWorksModel').getProperty('/MyWorks').some(function(listOperation) {
				return listOperation.Activity === operation.Activity && listOperation.Orderid === operation.Orderid;
			});

			if (listHasEntry) {
				var list = this.getModel('MyWorksModel').getProperty('/MyWorks').reduce(function(operations, listOperation) {
					if (listOperation.Activity === operation.Activity && listOperation.Orderid === operation.Orderid) {
						listOperation = operation;
					}
					if (!listOperation.Completed) {
						operations.push(listOperation);
					}
					return operations;
				}, []);

				this.getModel('MyWorksModel').setProperty('/MyWorks', list);
			} else if (!operation.Completed) {
				this.pushObjectToList('MyWorksModel', 'MyWorks', operation);
			}
		},

		getListModel: function(modelProperty) {
			return this.getModel({
				'Notifications': 'NotificationsModel',
				'Orders': 'OrdersModel',
				'MyWorks': 'MyWorksModel',
				'Routes': 'RoutesModel'
			} [modelProperty]);
		},

		listHasEnty: function(list, property, idProperty, item) {
			return list.filter(function(object) {
				return object[idProperty] === item[idProperty];
			}).length !== 0;
		},

		replaceOldListObject: function(model, idProperty, property, item) {
			this.getModel(model).setProperty(
				'/' + property,
				this.getModel(model).getProperty('/' + property).map(function(object) {
					return object[idProperty] === item[idProperty] ? item : object;
				})
			);
		},

		pushObjectToList: function(model, property, item) {
			this.getModel(model).setProperty(
				'/' + property,
				this.getModel(model).getProperty('/' + property).concat([item])
			);
		},

		generateDateObject: function(date) {
			return typeof date === 'string' ? new Date(parseInt(date.replace(/\D/g, ''), 10)) : date;
		},

		generateTimeObject: function(time) {
			if (typeof time === 'string') {
				time = time.replace(/\D/g, '');
				time = time.length === 3 ? '0' + time : time;
				return new this.customTypesUtil.InputTime().parseValue(time, 'string');
			} else {
				return time;
			}
		},

		changeToNumberInput: function(controlId) {
			var control = this.getElementById(controlId);
			if (control) {
				control.$().children().attr('type', 'Number').attr('step', '0.01');
			}
		},

		changeToTelephoneInput: function(controlId) {
			this.getElementById(controlId).$().children().attr('type', 'tel');
		},

		getIdFromChangeEvent: function(changeEvent) {
			return changeEvent.getParameter('newValue').substr(
				0,
				changeEvent.getParameter('newValue').indexOf(' - ') !== -1 ?
				changeEvent.getParameter('newValue').indexOf(' - ') :
				changeEvent.getParameter('newValue').length
			);
		},

		openMeasurementPointDialog: function(functionalLocation, equipment, modelName) {
			this.openDialog('MeasurementPointDialog', {
				FunctionalLocation: functionalLocation,
				Equipment: equipment,
				ModelName: modelName
			});
		},

		/* =========================================================== */
		/* Notification												   */
		/* =========================================================== */

		getNotificationNumberFromUrlParameters: function() {
			this.getModel('NotificationsModel') &&
				this.getModel('NotificationsModel').getProperty('/Notifications') &&
				this.getNotificationModel()
				.setData(
					this.getNotification(location.hash.split('/')[3])
				);
		},

		getNotification: function(notificationNumber) {
			return $.extend(true, [],
				this.getModel('NotificationsModel').getProperty('/Notifications')
				.filter(function(notificationObject) {
					return notificationObject.NotifNo === notificationNumber;
				})
			).shift();
		},

		getNotificationFromSap: function(notificationNumber) {
			var parameters = {
				online: true,
				filters: this.generateFilter('NotifNo', [notificationNumber]).concat(
					this.generateFilter('SystemStatuses', ['I0068']),
					this.generateFilter('SystemStatuses', ['I0070']),
					this.generateFilter('SystemStatuses', ['I0072'])
				),
				urlParameters: {
					'$expand': 'Attachments'
				}
			};

			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}

			return this.oDataUtil.read('NotifSet', parameters);
		},

		/* =========================================================== */
		/* Order										 			   */
		/* =========================================================== */

		getOrderNumberFromUrlParameters: function() {
			this.getModel('OrdersModel') &&
				this.getModel('OrdersModel').getProperty('/Orders') &&
				this.getOrderModel()
				.setData(
					this.getOrder(location.hash.split('/')[3]) || this.getMyWorkOrder(location.hash.split('/')[3])
				);
		},

		getOrder: function(orderNumber) {
			return $.extend(true, [],
				this.getModel('OrdersModel').getProperty('/Orders')
				.filter(function(orderObject) {
					return orderObject.Orderid === orderNumber;
				})
			).shift();
		},

		getMyWorkOrder: function(orderNumber) {
			return $.extend(true, [],
				this.getModel('MyWorkOrdersModel').getProperty('/MyWorks')
				.filter(function(orderObject) {
					return orderObject.Orderid === orderNumber;
				})
			).shift();
		},

		getOrderFromSap: function(orderNumber) {
			var parameters = {
				online: true,
				filters: this.generateFilter('Orderid', [orderNumber]).concat(
					this.generateFilter('SystemStatus', ['I0001']),
					this.generateFilter('SystemStatus', ['I0002']),
					this.generateFilter('SystemStatus', ['I0045'])
				),
				urlParameters: {
					'$expand': this.getConfigurationModel().getOrderURLParameters()
				}
			};
			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}

			return this.oDataUtil.read('WorkOrderSet', parameters);
		},

		/* =========================================================== */
		/* WorkflowApproval 										   */
		/* =========================================================== */

		getWorkFlowApprovals: function() {
			var parameters = {
				urlParameters: {
					'$expand': 'Services,ServiceEntries,AdditionalPreqs,Materials,ApprovedPreqs,SMMaterials,SMServices'
				},
				online: true
			};

			return this.oDataUtil.read('WfApprovalItemSet', parameters);
		},

		handleGetApprovalsSuccess: function(approvals) {
			this.getModel('WorkFlowApprovalsModel').setProperty('/Approvals', approvals);
		},

		/* =========================================================== */
		/* Functional location selection for list				       */
		/* =========================================================== */

		functionalLocationListValidator: function(tokens) {
			// user validtor only if token wasn't selected from suggestion list
			if (!tokens.suggestionObject) {
				var tokensToAdd = tokens.text.toUpperCase().split(',').map(this.removeWhiteSpace);

				this.tokensAreValid(tokensToAdd)
					.done(function(functionalLocations) {
						this.openConfirmFunctionalLocationAdding(functionalLocations);
					}.bind(this))
					.fail(this.openFunctionalLocationNotValid.bind(this, tokensToAdd));

				return sap.m.MultiInput.WaitForAsyncValidation;
			}
		},

		removeWhiteSpace: function(functionalLocationToken) {
			return functionalLocationToken.trim();
		},

		tokensAreValid: function(tokens) {
			var deferred = $.Deferred();

			$.when.apply(this, tokens.map(this.generateGetMethods.bind(this)))
				.done(function() {
					deferred.resolve(Array.prototype.slice.call(arguments));
				})
				.fail(deferred.reject);

			return deferred.promise();
		},

		generateGetMethods: function(functionalLocation) {
			var deferred = $.Deferred();
			if (functionalLocation.indexOf('*') === -1) {
				this.validateFunctionalLocation(functionalLocation)
					.done(function(response) {
						deferred.resolve({
							Floc: response.Floc,
							InternalId: response.InternalId
						});
					})
					.fail(deferred.reject);
			} else {
				deferred.resolve({
					Floc: functionalLocation,
					InternalId: functionalLocation
				});
			}
			return deferred.promise();
		},

		openConfirmFunctionalLocationAdding: function(tokensToAdd) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('ADD_FUNCTIONAL_LOCATION_TITLE'),
				message: this.getAddTokensMessage(tokensToAdd.map(function(token) {
					return token.Floc;
				})),
				onClose: this.onListFunctionalLocationTokensAdd.bind(this, tokensToAdd),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		openFunctionalLocationNotValid: function(tokensToAdd) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('NOT_VALID_FUNCTIONAL_LOCATIONS_TITLE'),
				message: this.getResourceBundleText(
					tokensToAdd && tokensToAdd.length === 1 ?
					'NOT_VALID_FUNCTIONAL_LOCATION_MESSAGE' :
					'NOT_VALID_FUNCTIONAL_LOCATIONS_MESSAGE'
				)
			});
		},

		getAddTokensMessage: function(tokensToAdd) {
			return this.getResourceBundleText(
				tokensToAdd.length === 1 ?
				'ADD_FUNCTIONAL_LOCATION_MESSAGE' :
				'ADD_FUNCTIONAL_LOCATIONS_MESSAGE',
				tokensToAdd.reduce(function(message, token, index, array) {
					var delimiter = index + 1 === array.length ? ' & ' : ', ';
					return message ? message + delimiter + '\"' + token + '\"' : '\"' + token + '\"';
				}, '')
			);
		},

		removeObjectLayer: function(functionalLocation) {
			return typeof functionalLocation === 'string' ? functionalLocation : functionalLocation.FunctLoc;
		},

		filterDublicates: function(functionalLocation, index, array) {
			return array.indexOf(functionalLocation) === index;
		},

		modifyUserParameterStringToObject: function(property, userParameter) {
			var userParameterObject = {};
			userParameterObject[property] = userParameter;
			return userParameterObject;
		},

		onTokenUpdate: function(updateEvent) {
			if (updateEvent.getParameter('type') === 'added' && updateEvent.getSource()._oPopupInput) {
				updateEvent.getSource()._oPopupInput.setValue('');
			}
		},

		handleFunctionalLocationSuggestionItemSelected: function(selectEvent, modelProperty) {
			this.getModel('ViewModel').setProperty(
				modelProperty,
				this.getModel('ViewModel').getProperty(modelProperty)
				.concat([{
					FunctLoc: selectEvent.getParameter('selectedRow').getBindingContext().getObject().Floc
				}])
			);

			setTimeout(function(storedSelectEvent) {
				this.getModel('ViewModel').setProperty('/FunctionalLocationTokenValue', '');
				storedSelectEvent.getSource()._oPopupInput && storedSelectEvent.getSource()._oPopupInput.setValue('');
			}.bind(this, $.extend(true, {}, selectEvent)), 0);
		},

		onFilterFunctionalLocations: function(searchEvent) {
			this.filterSuggestionListWithUpperCase(searchEvent, 'Floc', 'Descr');
		},

		onListFunctionalLocationSuggestionItemSelected: function(selectEvent) {
			this.handleFunctionalLocationSuggestionItemSelected(selectEvent, '/FilterParameters/FunctLocs');
		},

		/* =========================================================== */
		/* Item number			     								   */
		/* =========================================================== */

		parseItemNumber: function(property, array, element) {
			return array.concat([parseInt(element[property], 10)]);
		},

		getDefaultItemNumber: function(id, currentItemNumbers) {
			return currentItemNumbers.indexOf(id) === -1 ? this.stringRepeat('0', (4 - id.toString().length)) + id.toString() : this.getDefaultItemNumber(id + 10, currentItemNumbers);
		},

		stringRepeat: function(str, times) {
			return (new Array(times + 1)).join(str);
		},

		/* =========================================================== */
		/* Plugins				     								   */
		/* =========================================================== */

		onPressScanTechnicalObject: function() {
			var scanOptions = this.getGlobalModel().getProperty('/PlantLevelScanOptions');
			var scanOptionTexts = scanOptions.map(function(scanOption) {
				return scanOption.text;
			});

			if (scanOptions.length === 1) {
				this.invokeScanTechnicalObject(scanOptions[0].key);
			} else {
				navigator.notification.confirm(
					'',
					this.handleScanOptionChosen.bind(this, scanOptions),
					this.getResourceBundleText('CHOOSE_SCANNING_OPTION_TITLE'),
					scanOptionTexts
				);
			}
		},

		handleScanOptionChosen: function(scanOptions, index) {
			var scanOption = scanOptions[index - 1];
			this.invokeScanTechnicalObject(scanOption && scanOption.key);
		},

		invokeScanTechnicalObject: function(key) {
			if (key === 'BARCODE') {
				this.scanTechnicalObject();
			} else if (key === 'NFC') {
				this.onPressReadNFCTechnicalObject();
			} else {
				this.scanTechnicalObject();
			}
		},

		scanTechnicalObject: function() {
			this.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
			cordova.plugins.barcodeScanner.scan(this.handleScanSuccess.bind(this), this.handleScanError.bind(this), {
				showTorchButton: true
			});
		},

		handleScanError: function() {

		},

		onPressReadNFCTechnicalObject: function() {
			nfc.enabled(this.handleNFCAvailable.bind(this), this.handleNFCNotAvailable.bind(this));
		},

		handleNFCAvailable: function() {
			var successHandler = this.handleNFCReadSuccess.bind(this);

			this.getGlobalModel().setProperty('/IsResumingFromPlugin', true);

			// multiple listeners for different tag types
			nfc.addMimeTypeListener('application/json', successHandler, this.handleNFCReadStarted.bind(this), this.handleNFCError.bind(this));
			nfc.addNdefListener(successHandler, this.handleNFCReadStarted.bind(this), this.handleNFCError.bind(this));
			// empty tag listener can't be detached, only attach once per session
			if (!this.getHasAttachedEmptyTagListener()) {
				this.setHasAttachedEmptyTagListener();
				nfc.addNdefFormatableListener(successHandler, this.handleNFCReadStarted.bind(this), this.handleNFCError.bind(this));
			}

			this.setNFCReadSuccessFunction(successHandler);
		},

		handleNFCNotAvailable: function() {
			this.messageBoxUtil.show({
				type: 'Error',
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: this.getResourceBundleText('NFC_NOT_AVAILABLE_TEXT')
			});
		},

		handleNFCReadStarted: function() {
			this.openDialog('NFCReadDialog');
		},

		handleNFCError: function() {
			var nfcDialog = this.getDialog('NFCReadDialog');
			nfcDialog && nfcDialog.close();
		},

		handleNFCReadSuccess: function(readEvent) {
			this.getDialog('NFCReadDialog').close();
			var tagText = '';
			try {
				tagText = JSON.parse(nfc.bytesToString(readEvent.tag.ndefMessage[1].payload));
			} catch (err) {
				tagText = '';
			}
			this.handleScanSuccess({
				text: tagText && tagText.TechnicalObject || ''
			});
		},

		handleNFCReadDialogClose: function() {
			var nfcReadSuccessFunction = this.getNFCReadSuccessFunction();

			nfc.removeMimeTypeListener('application/json', nfcReadSuccessFunction, $.noop, $.noop);
			nfc.removeNdefListener(nfcReadSuccessFunction, $.noop, $.noop);
			nfc.removeTagDiscoveredListener(nfcReadSuccessFunction, $.noop, $.noop);
		},

		getNFCReadSuccessFunction: function() {
			return nfcReadSuccessHandler;
		},

		setNFCReadSuccessFunction: function(successHandler) {
			nfcReadSuccessHandler = successHandler;
		},

		getHasAttachedEmptyTagListener: function() {
			return hasAttachedEmptyTagListener;
		},

		setHasAttachedEmptyTagListener: function() {
			hasAttachedEmptyTagListener = true;
		},

		onPressScanId: function(pressEvent) {
			if (this.isScannerAvailable()) {
				this.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
				cordova.plugins.barcodeScanner.scan(this.handleScanSuccess.bind(this), this.handleScanError.bind(this));
			} else {
				setTimeout(function() {
					this.getSource().focus();
				}.bind($.extend(true, {}, pressEvent)), 0);
			}
		},

		isScannerAvailable: function() {
			return !!(window.cordova && window.cordova.plugins.barcodeScanner);
		},

		onAddPictureAttachment: function() {
			this.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
			navigator.camera.getPicture(
				this.handleCameraSuccess.bind(this),
				this.handleCameraError.bind(this), {
					quality: 25,
					correctOrientation: true
				}
			);
		},

		handleCameraError: function() {

		},

		onGetPictureFromFileSystem: function() {
			var options = {
				selectMode: 100
			};
			this.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
			window.MediaPicker.getMedias(
				options,
				this.handleGetPictureFromFileSystemSuccess.bind(this),
				this.handleGetPictureFromFileSystemError.bind(this), {
					quality: 15
				}
			);
		},

		handleGetPictureFromFileSystemError: function() {

		},

		getUploadCollectionItem: function(fileUri) {
			return {
				Url: fileUri,
				Filename: this.generateFileName(),
				LinkId: this.generateLinkId()
			};
		},

		/* =========================================================== */
		/* Upload collection			     						   */
		/* =========================================================== */

		onUploadCollectionChange: function(uploadEvent) {
			this.addHeaderParameters(uploadEvent);
		},

		addHeaderParameters: function(uploadEvent) {
			var uploadCollection = uploadEvent.getSource();
			this.devapp.onlineModel.refreshSecurityToken();
			var sSecurityToken = this.devapp.onlineModel.getSecurityToken();

			uploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
				name: 'X-CSRF-Token',
				value: sSecurityToken
			}));
			uploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
				name: 'Accept',
				value: 'application/json'
			}));
			uploadCollection.addHeaderParameter(
				new sap.m.UploadCollectionParameter({
					name: 'slug',
					value: encodeURIComponent(uploadEvent.getParameter('files')[0].name) + '|' + this.generateLinkId()
				})
			);
		},

		handleUploadComplete: function(oEvent, model) {
			var oResponse;
			if (!oEvent.getParameter('files')) {
				oResponse = JSON.parse(oEvent.getParameters().responseRaw).d;
			} else {
				oResponse = JSON.parse(oEvent.getParameter('files')[0].responseRaw).d;
			}
			var attachments = $.extend(true, [], model.getProperty('/Attachments'));
			var httpSlug;
			if (!attachments) {
				attachments = [];
			}
			if (oResponse) {
				if (oEvent.getParameter('requestHeaders')) {
					httpSlug = oEvent.getParameter('requestHeaders');
				} else {
					httpSlug = oEvent.getParameters().getParameter('requestHeaders');
				}
				httpSlug = httpSlug.filter(function(httpHeader) {
					return httpHeader.name === 'slug';
				}).shift();

				oResponse.LinkId = httpSlug && httpSlug.value ? httpSlug.value.substring(httpSlug.value.indexOf('|') + 1, httpSlug.value.length) : '';
				delete oResponse.__metadata;
				attachments.push(oResponse);
				model.setProperty('/Attachments', attachments);
			} else {
				var errorMessageValue;
				if (!oEvent.getParameter('files')) {
					errorMessageValue = JSON.parse(oEvent.getParameters().responseRaw).error.message.value;
				} else {
					errorMessageValue = JSON.parse(oEvent.getParameter('files')[0].responseRaw).error.message.value;
				}
				this.openErrorMessagePopup(errorMessageValue, 'ERROR_MESSAGE_ERROR_ADDING_ATTACHMENTS');
			}
		},

		generateLinkId: function() {
			return Math.floor((1 + Math.random()) * 0x100000000).toString(36).substring(1);
		},

		generateFileName: function() {
			var currentdate = new Date();
			var minutes = currentdate.getMinutes() + '';
			if (minutes.length === 1) {
				minutes = '0' + minutes;
			}
			return currentdate.getDate() + '/' +
				(currentdate.getMonth() + 1) + '/' +
				currentdate.getFullYear() + '_' +
				currentdate.getHours() + ':' +
				minutes + '.jpg';
		},

		onUploadItemDelete: function() {

		},

		handleAttachmentDeletion: function(itemDeleted) {
			this.getModel('NewPrModel').setProperty('/Attachments',
				this.removeIndexFromArray(this.getModel('NewPrModel').getProperty('/Attachments'), itemDeleted.getPath().slice(-1))
			);
			this.getModel('NewPrModel').updateBindings(true);
		},

		getAttachmentsUrl: function(docId, filename) {
			docId = docId || '';
			filename = filename || '';
			return this.oDataUtil.services['COMMON'] + '/AttachmentDataSet(DocId=\'' + docId + '\',TechFilename=\'' + filename + '\')/$value';
		},

		addToAttachmentDeleteQueue: function(attachment) {
			attachment = $.extend(true, {}, attachment);
			if (!this.getModel('AttachmentDeletion')) {
				this.setModel('AttachmentDeletion');
			}
			this.getModel('AttachmentDeletion').setProperty('/Items',
				(this.getModel('AttachmentDeletion').getProperty('/Items') || []).concat(attachment)
			);
		},

		clearAttachmentDeleteQueue: function() {
			if (this.getModel('AttachmentDeletion')) {
				this.getModel('AttachmentDeletion').setProperty('/Items', []);
			}
		},

		removeAttachmentQueueItems: function() {
			if (this.getModel('AttachmentDeletion')) {
				this.removeAttachments(this.getModel('AttachmentDeletion').getProperty('/Items'));
				this.clearAttachmentDeleteQueue();
			}
		},

		removeAttachment: function(attachment) {
			var deferred = $.Deferred();
			if (attachment.LinkId && attachment.DocId) {
				var postData = {
					LinkId: attachment.LinkId || '',
					DocId: attachment.DocId || ''
				};
				this.oDataUtil.functionImport('AttachmentDelete', postData)
					.done(deferred.resolve)
					.fail(deferred.reject);
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		postAttachment: function(attachment) {
			var deferred = $.Deferred();

			if (attachment.Url) {
				if (this.isHybridApplicationUser() && this.isLocalFileUrl(attachment.Url)) {
					var sFileUrl = attachment.Url.indexOf('file://') === 0 ? attachment.Url : 'file://' + attachment.Url;
					this.getLocalFileWithUrl(sFileUrl)
						.done(function(oData) {
							attachment.Url = oData;
							this.sendAttachment(attachment)
								.done(deferred.resolve);
						}.bind(this))
						.fail(deferred.reject);
				} else {
					this.sendAttachment(attachment)
						.done(deferred.resolve);
				}
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		isLocalFileUrl: function(sUrl) {
			return sUrl.indexOf('file://') === 0 || sUrl.indexOf('/') === 0;
		},

		sendAttachment: function(attachment) {
			var deferred = $.Deferred();

			var sSecurityToken = this.devapp.onlineModel.getSecurityToken();

			if (attachment.Url) {
				var blob = this.generateFile(attachment.Url, attachment.Filename);
				var fileUploader = new CustomFileUploader();
				fileUploader.setUploadUrl(encodeURI(this.devapp.onlineModel.sServiceUrl + '/AttachmentDataSet'));
				fileUploader.setValue(attachment.Url);
				fileUploader.destroyHeaderParameters();
				fileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: 'X-CSRF-Token',
					value: sSecurityToken
				}));
				fileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: 'slug',
					value: attachment.Filename + '|' + attachment.LinkId
				}));
				fileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: 'Accept',
					value: 'application/json'
				}));
				fileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: 'Content-Type',
					value: 'image/jpeg'
				}));
				fileUploader.setSendXHR(true);
				fileUploader.setUseMultipart(false);
				fileUploader.attachUploadComplete(deferred.resolve);
				fileUploader.upload([blob]);
			} else {
				deferred.resolve();
			}

			return deferred.promise();
		},

		getLocalFileWithUrl: function(fileUri) {
			var deferred = $.Deferred();
			var request = new XMLHttpRequest();
			request.open('GET', fileUri, true);
			request.responseType = 'blob';
			request.onload = function() {
				var reader = new FileReader();
				reader.onloadend = function() {
					deferred.resolve(reader.result);
				};
				reader.onerror = function() {
					deferred.reject();
				}
				reader.readAsDataURL(request.response);
			};
			request.send();
			return deferred.promise();
		},

		generateFile: function(dataurl, filename) {
			var arr = dataurl.split(',');
			var mime = arr[0].match(/:(.*?);/)[1];
			var bstr = atob(arr[1]);
			var n = bstr.length;
			var u8arr = new Uint8Array(n);
			while (n--) {
				u8arr[n] = bstr.charCodeAt(n);
			}
			var file = new Blob([u8arr], {
				type: mime
			});
			file.name = filename;
			return file;
		},

		insertTemporaryDocIds: function(attachment) {
			if (!attachment.DocId) {
				attachment.DocId = this.models.getTemporaryId();
			}
			return attachment;
		},

		filterDummyAttachments: function(attachment) {
			return attachment.DocId || attachment.Url;
		},

		filterPostAttachments: function(attachment) {
			return !attachment.DocId;
		},

		/* =========================================================== */
		/* Smart search					     						   */
		/* =========================================================== */

		filterSuggestionListWithUpperCase: function(suggestionEvent, idField, descriptionField, filterOperator) {
			var inputValue = suggestionEvent.getParameter('suggestValue').toUpperCase();
			this.filterSuggestionList(suggestionEvent, inputValue, idField, descriptionField, filterOperator);
		},

		filterSuggestionListWithCaseSensitivity: function(suggestionEvent, idField, descriptionField, filterOperator) {
			var inputValue = suggestionEvent.getParameter('suggestValue');
			this.filterSuggestionList(suggestionEvent, inputValue, idField, descriptionField, filterOperator);
		},

		filterSuggestionList: function(suggestionEvent, inputValue, idField, descriptionField, filterOperator) {
			if (this.shouldFocusSuggestionInputField(suggestionEvent)) {
				suggestionEvent.getSource()._oPopupInput.$().find('input')[0].select();
				suggestionEvent.getSource()._oPopupInput.$().find('input')[0].focus();
			}

			if (suggestionEvent.getSource().getBinding('suggestionRows')) {
				suggestionEvent.getSource().getBinding('suggestionRows')
					.filter([
						new sap.ui.model.Filter(
							this.generateFilter(idField, [inputValue], filterOperator || 'StartsWith')
							.concat(this.generateFilter(descriptionField, [inputValue], filterOperator || 'StartsWith'))
						)
					]);
			}
		},

		shouldFocusSuggestionInputField: function(suggestionEvent) {
			return !!(
				this.isPhone() &&
				!document.activeElement.classList.contains('sapMInputBaseInner') &&
				suggestionEvent.getSource()._oPopupInput &&
				!(suggestionEvent.getSource() instanceof sap.m.MultiInput)
			);
		},

		renderSuggestionInput: function(suggestionField) {
			if (suggestionField._oSuggestionTable) {
				setTimeout(function() {
					suggestionField._oSuggestionTable.setGrowing(true);
					suggestionField._oSuggestionTable.setGrowingThreshold(this.isPhone() ? 3 : 5);
					suggestionField.setShowSuggestion(true);
				}.bind(this), 0);
			}
		},

		onFilterPersons: function(searchEvent) {
			this.filterSuggestionListWithUpperCase(searchEvent, 'PersonNumber', 'FullnameSearchfield', 'Contains');
		},

		subActivityComparator: function(a, b) {
			if (!a) {
				return -1;
			} else if (!b) {
				return 1;
			} else {
				return a < b ? -1 : 1;
			}
		},

		getMyWorkRelevantOperations: function(myWorks, userIds, workCenters) {
			var userParameters = this.getUserParameters();
			var relevantUserIds = userIds || userParameters.Persons && userParameters.Persons.split(',') || [];
			var relevantWorkCenters = workCenters || userParameters.Workcenters && userParameters.Workcenters.split(',') || [];

			return myWorks.reduce(this.getRelevantOperations.bind(this, relevantUserIds, relevantWorkCenters), []);
		},

		getRelevantOperations: function(relevantUserIds, relevantWorkCenters, relevantOperations, order) {
			var currentOrderRelevantOperations = [];

			if (order.Released) {
				if (relevantUserIds.length) {
					var relevantAssignments = order.Assignments.filter(function(assignment) {
						return !assignment.WorkFinished && relevantUserIds.indexOf(assignment.PersonNumber) !== -1;
					});
					var relevantAssignmentOperationIds = relevantAssignments.map(function(relevantAssignment) {
						return relevantAssignment.Activity;
					});

					currentOrderRelevantOperations = order.Operations.reduce(function(operations, operation) {
						if (relevantAssignmentOperationIds.indexOf(operation.Activity) !== -1 && (!operation.Completed || order.ErrorMessage) && !operation.SubActivity) {
							var operationWithOrderProperites = this.addOrderPropertiesToOperation(operation, order, relevantAssignments);
						}
						return operationWithOrderProperites ? operations.concat(operation) : operations;
					}.bind(this), []);
				} else {
					currentOrderRelevantOperations = order.Operations.reduce(function(operations, operation) {
						if (relevantWorkCenters.indexOf(operation.Workcenter) !== -1 && (!operation.Completed || order.ErrorMessage) && !operation.SubActivity) {
							var operationWithOrderProperites = this.addOrderPropertiesToOperation(operation, order);
						}

						return operationWithOrderProperites ? operations.concat(operation) : operations;
					}.bind(this), []);
				}
			}

			return relevantOperations.concat(currentOrderRelevantOperations);
		},

		addOrderPropertiesToOperation: function(operation, order, relevantAssignments) {
			operation.Plangroup = order.Plangroup;
			operation.Equipment = order.Equipment;
			operation.FunctLoc = order.FunctLoc;
			operation.EquipmentDescr = order.EquipmentDescr;
			operation.FunctLocDescr = order.FunctLocDescr;

			operation.Assignments = relevantAssignments || [];

			return operation;
		},

		handleNavigateToNotification: function(notificationNumber) {
			var notification = this.getNotification(notificationNumber);

			if (!notification && this.isOffline()) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('NOT_FOUND_PAGE_TITLE'),
					message: this.getResourceBundleText('NOTIFICATION_NOT_FOUND_MESSAGE', notificationNumber)
				});
			} else if (!notification) {
				this.setAppBusyMode();
				this.getNotificationFromSap(notificationNumber)
					.done(this.navigateToNotification.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setAppNotBusyMode);
			} else if (notification) {
				this.navigateToNotification([notification]);
			}
		},

		navigateToNotification: function(notification) {
			var notificationObject = this.getRootControl().modifyNotification(notification.shift());
			this.getModel('NewNotificationModel').setData(this.models.getNotificationDefaults(notificationObject));

			if (notificationObject) {
				this.navTo('CreateNotification', {
					Purpose: 'Display',
					NotificationNumber: notificationObject.NotifNo
				});
			}
		},

		handleNavigateToOrder: function(orderNumber) {
			var order = this.getOrder(orderNumber);

			if (!order && this.isOffline()) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('NOT_FOUND_PAGE_TITLE'),
					message: this.getResourceBundleText('ORDER_NOT_FOUND_MESSAGE', orderNumber)
				});
			} else if (!order) {
				this.setAppBusyMode();
				this.getOrderFromSap(orderNumber)
					.done(this.navigateToOrder.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setAppNotBusyMode);
			} else if (order) {
				this.navigateToOrder([order]);
			}
		},

		navigateToOrder: function(order) {
			// check that order was passed
			if (Array.isArray(order) && order.length) {
				var orderObject = this.getRootControl().modifyOrder(order.shift());
				this.getModel('NewOrderModel').setData(this.models.getOrderDefaults(orderObject));

				this.navTo('CreateOrder', {
					Purpose: 'Display',
					OrderNumber: orderObject.Orderid
				});
			} else {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('ORDER_TYPE_NOT_SUPPORTED_TITLE'),
					message: this.getResourceBundleText('ORDER_TYPE_NOT_SUPPORTED_MESSAGE')
				});
			}
		},

		handleRouteTimeConfirmation: function(timeConfirmation) {
			var deferred = $.Deferred();

			timeConfirmation.PostingDate = this.getCurrentDate();

			if (this.isOffline()) {
				this.localStorage.insertTimeConfirmation(timeConfirmation);
				this.openSuccessDialog('POST_SAVE_OFFLINE_ORDER_MESSAGE');
				deferred.resolve();
			} else {
				timeConfirmation.PostingDate = this.getUnixDate(timeConfirmation.PostingDate);
				this.oDataUtil.functionImport('RouteWorkConfirmTime', timeConfirmation)
					.done(deferred.resolve)
					.fail(deferred.reject);
			}

			return deferred.promise();
		},

		handleTimeConfirmationSuccess: function(response) {
			if (response) {
				this.openSuccessDialog(
					this.getResourceBundleText('TIME_CONFIRMED_FOR_ROUTE_MESSAGE', response.Orderid)
				);
			}
		},

		handleOperationConfirmation: function(timeConfirmation) {
			var deferred = $.Deferred();

			timeConfirmation.PostingDate = this.getCurrentDate();

			if (this.isOffline()) {
				this.localStorage.insertTimeConfirmation(timeConfirmation);
				this.openSuccessDialog(this.getResourceBundleText('POST_SAVE_OFFLINE_ORDER_MESSAGE', timeConfirmation.Orderid));
				deferred.resolve();
			} else {
				timeConfirmation.PostingDate = this.getUnixDate(timeConfirmation.PostingDate);
				this.oDataUtil.functionImport('WorkOrderOperConfirmTime', timeConfirmation)
					.done(deferred.resolve)
					.fail(deferred.reject);
			}

			return deferred.promise();
		},

		handleOperationTimeConfirmationSuccess: function(operation) {
			this.openSuccessDialog(
				this.getResourceBundleText('TIME_CONFIRMED_FOR_OPERTAION_MESSAGE', operation)
			);
		},

		handleRouteTimeConfirmationSuccess: function(order) {
			this.openSuccessDialog(
				this.getResourceBundleText('TIME_CONFIRMED_FOR_ROUTE_MESSAGE', order)
			);
		},

		handleNotificationComplete: function(notification) {
			var deferred = $.Deferred();
			if (this.isOffline()) {
				var notificationObject = this.getPostObject(this.getNotificationModel().getData());
				notificationObject.Completed = 'X';
				this.localStorage.insertNotification(notificationObject);
				this.removeListObject('Notifications', notification);
				this.openSuccessDialog('POST_SAVE_OFFLINE_MESSAGE');
				deferred.resolve();
			} else {
				this.oDataUtil.functionImport('NotifComplete', {
						NotifNo: notification
					})
					.done(deferred.resolve)
					.fail(deferred.reject);
			}

			return deferred.promise();
		},

		getCoverWorkOrders: function() {
			return this.getGlobalModel().getProperty('/RouteWorkCoverOrders') || [];
		},

		getTimeRecordUtility: function() {
			return this.models.getTimeRecordModel();
		},

		setPathBusy: function(path) {
			this.getGlobalModel().setProperty(path, true);
		},

		setPathNotBusy: function(path) {
			this.getGlobalModel().setProperty(path, false);
		},

		handleSort: function(sortEvent, list) {
			var parameters = sortEvent.getParameters();
			var sortKeys = parameters.sortItem.getKey().split('/');
			var isDescending = parameters.sortDescending;

			var sorters = sortKeys.map(function(sortKey) {
				return new sap.ui.model.Sorter(sortKey, isDescending);
			});

			list.getBinding('items').sort(sorters);
		},

		getListSelectionEndDate: function() {
			var datesBackwards = this.getUserParameters().DateRange || '0090';

			return new Date(new Date().setUTCDate(new Date().getUTCDate() - Number(datesBackwards)));
		},

		getXORBytes: function(byteArray1, byteArray2) {
			if (byteArray1.length === byteArray2.length) {
				var resultsArray = [];
				for (var i = 0; i < byteArray1.length; i++) {
					/* eslint-disable */
					resultsArray.push(byteArray1[i] ^ byteArray2[i]);
					/* eslint-enable */
				}
				return resultsArray;
			}
			return false;
		},

		uint8ArrayToByteArray: function(uint8Array) {
			var byteArray = [];

			for (var i = 0; i < uint8Array.byteLength; i++) {
				byteArray[i] = uint8Array[i];
			}

			return byteArray;
		},

		getNFCPasswordBytes: function() {
			// UPM1
			return [85, 80, 77, 49];
		},

		setLatestRouteOrderId: function(orderId) {
			this.getGlobalModel().setProperty('/LatestRouteOrderId', orderId);
		},

		getLatestRouteOrderId: function() {
			return this.getGlobalModel().getProperty('/LatestRouteOrderId') || '';
		},

		pushNotificationStatusChange: function(bShowNotifications) {
			if (bShowNotifications) {
				this.getRootControl().attachPush();
			} else {
				this.getRootControl().detachPush();
			}
		},

		getPushNotificationState: function() {
			if (window.localStorage) {
				return window.localStorage.getItem('isPushRegistered') === 'true';
			}
			return false;
		},

		checkIfAllResultsDisplayed: function(sapMessages) {
			var notDisplayed = sapMessages.some(function(message) {
				if (message.code === 'Z4M/001') {
					return true;
				}
			});
			if (notDisplayed) {
				this.showNotAllResultsDisplayedPopup();
			}
		},

		showNotAllResultsDisplayedPopup: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('NOT_ALL_RESULTS_SHOWN_TEXT')
			});
		},

		onSystemStatusToggleButtonPress: function(toggleEvent) {
			var selectedStatuses = this.getModel('ViewModel').getProperty('/FilterParameters/SystemCondition');
			var toggledStatus = toggleEvent.getSource().getBindingContext('SelectionValuesModel').getObject();
			if (toggleEvent.getParameter('pressed')) {
				selectedStatuses.push(toggledStatus);
			} else {
				selectedStatuses = selectedStatuses.filter(function(status) {
					return status.StatusInt !== toggledStatus.StatusInt;
				});
			}

			this.getModel('ViewModel').setProperty('/FilterParameters/SystemCondition', selectedStatuses);
		},

		/* =========================================================== */
		/* Variant handling				     						   */
		/* =========================================================== */

		setVariantSaveDefaults: function() {
			var oModel = this.getModel('ViewModel');
			oModel.setProperty('/SaveVariantDialog/CreateNew', false);
			oModel.setProperty('/SaveVariantDialog/NewVariantName', '');
			oModel.setProperty('/SaveVariantDialog/SelectedVariantName', '');
			oModel.setProperty('/SaveVariantDialog/IsDefault', false);
		},

		setVariantDialogBusy: function(bBusy) {
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/IsBusy', bBusy);
		},

		onCloseSaveVariant: function() {
			this.getDialog('SaveVariant').close();
		},

		onNewVariantNameChange: function(oEvent) {
			var value = oEvent.getParameter('value');
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/NewVariantName', value);
		},

		generateVariantObject: function(oFilterParameters) {
			var dateValueKeys = [
				'NotificationEndDate',
				'NotificationStartDate',
				'ReferenceEndDate',
				'ReferenceStartDate',
				'EndStartDate',
				'StartStartDate'
			];
			var skipDataKeys = [
				'Createdby'
			];
			var filterKeys = Object.keys(oFilterParameters);
			var deepCopy = {};
			filterKeys.map(function(key) {
				if (skipDataKeys.indexOf(key) !== -1) {
					// Do not add
				} else if (dateValueKeys.indexOf(key) === -1) {
					deepCopy[key] = JSON.parse(JSON.stringify(oFilterParameters[key]));
				} else {
					deepCopy[key] = this.getDayDifference(oFilterParameters[key]);
				}
			}.bind(this));
			return deepCopy;
		},

		generateFilterParametersObject: function(oVariantData) {
			var dateValueKeys = [
				'NotificationEndDate',
				'NotificationStartDate',
				'ReferenceEndDate',
				'ReferenceStartDate',
				'EndStartDate',
				'StartStartDate'
			];
			var filterKeys = Object.keys(oVariantData);
			var deepCopy = {};
			filterKeys.map(function(key) {
				if (dateValueKeys.indexOf(key) === -1) {
					deepCopy[key] = JSON.parse(JSON.stringify(oVariantData[key]));
				} else {
					deepCopy[key] = this.getDateWithDifference(oVariantData[key]);
				}
			}.bind(this));
			return deepCopy;
		},

		generateFilterParametersCopy: function(oFilterParams) {
			return $.extend(true, {}, oFilterParams);
		},

		validateVariantNaming: function(sType) {
			var oModel = this.getModel('ViewModel');
			var createNew = oModel.getProperty('/SaveVariantDialog/CreateNew');
			var selected = oModel.getProperty('/SaveVariantDialog/SelectedVariantName');
			var newName = oModel.getProperty('/SaveVariantDialog/NewVariantName');

			if (!createNew && selected) {
				return this.getVariantWithTypeAndName(sType, selected);
			} else if (createNew && newName) {
				return {
					VariantId: '',
					Description: newName
				};
			} else {
				return false;
			}
		},

		saveVariant: function(variantId, variantType, variantName, oData, bDefault) {
			var deferred = $.Deferred();
			if (variantName && oData) {
				var postObject = {
					IsDefault: bDefault ? 'X' : '',
					VariantId: variantId || this.getVariantId(variantType),
					VariantType: variantType,
					Description: variantName,
					Data: JSON.stringify(this.generateVariantObject(oData))
				};
				if (this.isOffline()) {
					postObject.NotSync = true;
					this.insertVariantToList(postObject);
					this.localStorage.insertVariant(postObject);
					deferred.resolve();
				} else {
					this.oDataUtil.create('VariantSet', postObject, {
							online: true
						})
						.done(function() {
							deferred.resolve();
							this.refreshVariantValues();
						}.bind(this))
						.fail(deferred.reject);
				}
			}
			return deferred.promise();
		},

		updateVariant: function(variantId, variantType, variantName, oData, bDefault) {
			var deferred = $.Deferred();
			if (variantName && oData) {
				var postObject = {
					IsDefault: bDefault ? 'X' : '',
					VariantId: variantId || this.getVariantId(variantType),
					VariantType: variantType,
					Description: variantName,
					Data: JSON.stringify(this.generateVariantObject(oData))
				};
				if (this.isOffline()) {
					postObject.NotSync = true;
					this.insertVariantToList(postObject);
					this.localStorage.insertVariant(postObject);
					deferred.resolve();
				} else {
					this.oDataUtil.create('VariantSet', postObject, {
							online: true
						})
						.done(function() {
							deferred.resolve();
							this.refreshVariantValues();
						}.bind(this))
						.fail(deferred.reject);
				}
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		deleteVariant: function(variantId, variantType) {
			var deferred = $.Deferred();
			if (variantId && variantType) {
				if (this.isOffline()) {
					var variant = {
						VariantId: variantId,
						VariantType: variantType
					};
					this.removeVariantFromList(variant);
					this.localStorage.insertRemoveVariant(variant);
					deferred.resolve();
				} else {
					var path = 'VariantSet(UserId=\'\',VariantId=\'' + variantId + '\',VariantType=\'' + variantType + '\')';
					this.oDataUtil.remove(path)
						.done(function() {
							deferred.resolve();
							this.removeVariantFromList(variant);
							this.refreshVariantValues();
						}.bind(this))
						.fail(deferred.reject);
				}
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		variantSetDefault: function(variantId, variantType) {
			var deferred = $.Deferred();
			var parameters = {
				VariantId: variantId,
				VariantType: variantType
			};
			var postObject = this.getVariantWithTypeAndId(variantType, variantId);
			postObject.IsDefault = 'X';

			if (this.isOffline()) {
				postObject.NotSync = true;
				this.insertVariantToList(postObject);
				this.localStorage.insertVariant(postObject);
				deferred.resolve();
			} else {
				this.oDataUtil.functionImport('VariantSetDefault', parameters)
					.done(function() {
						this.insertVariantToList(postObject);
						this.refreshVariantValues();
						deferred.resolve();
					}.bind(this))
					.fail(deferred.reject);
			}
			return deferred.promise();
		},

		getDayDifference: function(date) {
			if (date && typeof date.getTime === 'function') {
				var currentDate = new Date();
				currentDate.setHours(0, 0, 0, 0);
				date.setHours(0, 0, 0, 0);
				var dayInMs = 60 * 60 * 24 * 1000;
				var difference = (date.getTime() - currentDate.getTime()) / dayInMs;
				difference = Math.round(difference);
				return difference;
			} else if (date) {
				return date;
			}
			return '';
		},

		getDateWithDifference: function(difference) {
			var date = null;
			if (!isNaN(difference)) {
				date = new Date();
				date = new Date(date.setDate(date.getDate() + difference));
			}
			return date;
		},

		getVariantsWithType: function(sType) {
			var allVariants = this.getModel('SelectionValuesModel').getProperty('/Variants') || [];
			var variants = allVariants.reduce(function(array, variant) {
				if (variant.VariantType === sType) {
					array.push(variant);
				}
				return array;
			}, []);
			return variants;
		},

		getVariantsWithTypeSelectionList: function(sType) {
			var defaultParametersOption = {
				VariantId: '000',
				Description: this.getResourceBundleText('VARIANT_USE_USER_PARAMETERS')
			};
			var variants = this.getVariantsWithType(sType);
			return [].concat(defaultParametersOption).concat(variants);
		},

		getVariantWithTypeAndName: function(sType, sName) {
			var allVariants = this.getModel('SelectionValuesModel').getProperty('/Variants') || [];
			var foundVariant = false;
			allVariants.some(function(variant) {
				if (variant.VariantType === sType && variant.Description === sName) {
					foundVariant = variant;
					return true;
				}
			});
			return foundVariant;
		},

		getVariantWithTypeAndId: function(sType, sId) {
			var allVariants = this.getModel('SelectionValuesModel').getProperty('/Variants') || [];
			var foundVariant = false;
			allVariants.some(function(variant) {
				if (variant.VariantType === sType && variant.VariantId === sId) {
					foundVariant = variant;
					return true;
				}
			});
			return foundVariant;
		},

		getVariantId: function(variantType) {
			var variants = this.getVariantsWithType(variantType);
			var variantIds = [];
			variants.map(function(variant) {
				variantIds[Number(variant.VariantId)] = true;
			});
			var index = 0;
			for (var i = 1; index === 0; i++) {
				if (!variantIds[i]) {
					index = i;
				}
			}
			var result = index.toString();
			if (result.length < 3) {
				result = result.length === 1 ? '00' + result : '0' + result;
			}
			return result;
		},

		getDefaultVariants: function() {
			var allVariants = this.getModel('SelectionValuesModel').getProperty('/Variants') || [];
			var defaultVariants = {};
			allVariants.map(function(variant) {
				if (variant.IsDefault) {
					defaultVariants[variant.VariantType] = variant.VariantId;
				}
			});
			return defaultVariants;
		},

		insertVariantToList: function(variant) {
			var idProperties = ['VariantType', 'VariantId'];

			if (variant.VariantId !== '000') {
				this.listHasEntryWithMultipleProperties(this.getModel('SelectionValuesModel').getProperty('/Variants'), variant, idProperties) ?
					this.replaceOldListObjectWithMultipleProperties('SelectionValuesModel', idProperties, 'Variants', variant) :
					this.pushObjectToList('SelectionValuesModel', 'Variants', variant);
			}
			if (variant.IsDefault) {
				this.updateVariantDefault(variant);
			}
		},

		updateVariantDefault: function(variant) {
			this.getModel('SelectionValuesModel').setProperty(
				'/Variants',
				this.getModel('SelectionValuesModel').getProperty('/Variants').map(function(object) {
					if (object.VariantType === variant.VariantType && object.VariantId !== variant.VariantId) {
						object.IsDefault = '';
					}
					return object;
				})
			);
		},

		removeVariantFromList: function(variant) {
			if (variant.VariantId !== '000') {
				this.getModel('SelectionValuesModel').setProperty(
					'/Variants',
					this.getModel('SelectionValuesModel').getProperty('/Variants').filter(function(object) {
						return !(object.VariantType === variant.VariantType && object.VariantId === variant.VariantId);
					})
				);
			}
		},

		listHasEntryWithMultipleProperties: function(list, item, aIdProperties) {
			return list.filter(function(object) {
				var matchCount = 0;
				aIdProperties.map(function(idProperty) {
					if (object[idProperty] === item[idProperty]) {
						matchCount = matchCount + 1;
					}
				});
				return matchCount === aIdProperties.length;
			}).length !== 0;
		},

		replaceOldListObjectWithMultipleProperties: function(model, idProperties, property, item) {
			this.getModel(model).setProperty(
				'/' + property,
				this.getModel(model).getProperty('/' + property).map(function(object) {
					var matchCount = 0;
					idProperties.map(function(idProperty) {
						if (object[idProperty] === item[idProperty]) {
							matchCount = matchCount + 1;
						}
					});
					return matchCount === idProperties.length ? item : object;
				})
			);
		},

		getCurrentDate: function() {
			var date = new Date();
			var offsetMs = date.getTimezoneOffset() * 60 * 1000;
			date = new Date(date.getTime() - offsetMs);
			return date;
		},

		getUnixDate: function(date) {
			var unix = '';
			var month = date.getUTCMonth() + 1;
			var day = date.getUTCDate();
			unix = (date.getUTCFullYear() + '') + (month < 10 ? '0' + month : month) + (day < 10 ? '0' + day : day);
			return unix + '';
		},

		handleListFunctionalLocationsSelected: function(channel, eventName, selectedObject) {
			this.addListFunctionalLocationToModel([{
				Floc: selectedObject.Floc,
				InternalId: selectedObject.InternalId
			}]);
		},

		filterDublicateFunctionalLocations: function(functionalLocation, index, array) {
			var stringArray = array.map(function(floc) {
				return JSON.stringify(floc);
			});
			return stringArray.indexOf(JSON.stringify(functionalLocation)) === index;
		}

	});
});