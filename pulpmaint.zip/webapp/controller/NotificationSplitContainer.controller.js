sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.NotificationSplitContainer', {

		onInit: function() {
			this.notificationSplitContainer = this.byId('notificationSplitContainer');

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'tilePageRouteMatched', this.hideMaster.bind(this));

			this.notificationSplitContainer.attachOrientationChange(this.handleOrientationChange.bind(this));
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('notificationSplitContainer', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		detailNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('notificationSplitContainer', 'detailNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		showMaster: function() {
			this.notificationSplitContainer.showMaster();
		},

		hideMaster: function() {
			this.notificationSplitContainer.hideMaster();
		},

		getSplitContainer: function() {
			return this.notificationSplitContainer;
		},

		handleOrientationChange: function(event) {
			if (location.hash.indexOf('Notification') !== -1 && this.isTablet() && !event.getParameter('landscape') && this.notificationSplitContainer.getMode() === 'ShowHideMode') {
				this.notificationSplitContainer.showMaster();
			}
		}

	});
});