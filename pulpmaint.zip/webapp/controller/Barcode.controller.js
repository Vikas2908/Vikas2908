sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.Barcode', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel');
			this.subscribeToEvent('app', 'navigate', this.handleNavigate.bind(this));
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Barcode') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				this.getModel('ViewModel').setProperty('/Code', this.getUrlParameter('code'));
				this.generateBarcode();
			}
		},

		handleNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */


		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		generateBarcode: function() {
			var value = this.getModel('ViewModel').getProperty('/Code') || '';
			var btype = 'code39';
			var renderer = 'css';
			var dimensions = this.getMaxDimensions(value);

			var settings = {
				output: renderer,
				bgColor: '#FFFFFF',
				color: '#000000',
				barWidth: dimensions.barWidth,
				barHeight: dimensions.barHeight
			};

			var id = this.getElementById('barcodeArea').getId();
			window.setTimeout(function() {
				$('#' + id).html('').barcode(value, btype, settings);
			}, 0);
		},

		getMaxDimensions: function(value) {
			var dimensions = {
				barWidth: 3,
				barHeight: 150
			};
			// Code 39: Start and stop character +2
			var length = value.length + 2;
			// Code 39: (separators) + (characters) + (quiet zone)
			length = (length - 1) + (length * 12) + 20;

			var widthRatio = window.innerWidth / length;
			if (widthRatio < 3) {
				dimensions.barWidth = Math.floor(widthRatio);
			}
			var height = window.innerHeight;
			if (height < 200) {
				dimensions.barHeight = 100;
			}

			return dimensions;
		}

	});
});