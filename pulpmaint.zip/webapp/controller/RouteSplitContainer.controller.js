sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.RouteSplitContainer', {

		onInit: function() {
			this.routeSplitContainer = this.byId('routeSplitContainer');

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'tilePageRouteMatched', this.hideMaster.bind(this));
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('routeSplitContainer', 'afterNavigate', {
				toView: navigationEvent.getParameter('to').sViewName,
				fromView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		detailNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('routeSplitContainer', 'detailNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		showMaster: function() {
			this.routeSplitContainer.showMaster();
		},

		hideMaster: function() {
			this.routeSplitContainer.hideMaster();
		},

		getSplitContainer: function() {
			return this.routeSplitContainer;
		}

	});
});