sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.OrderSplitContainer', {

		onInit: function() {
			this.orderSplitContainer = this.byId('orderSplitContainer');

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'tilePageRouteMatched', this.hideMaster.bind(this));

			this.orderSplitContainer.attachOrientationChange(this.handleOrientationChange.bind(this));
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('orderSplitContainer', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		detailNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('orderSplitContainer', 'detailNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		showMaster: function() {
			this.orderSplitContainer.showMaster();
		},

		hideMaster: function() {
			this.orderSplitContainer.hideMaster();
		},

		getSplitContainer: function() {
			return this.orderSplitContainer;
		},

		handleOrientationChange: function(event) {
			if (location.hash.indexOf('Order') !== -1 && this.isTablet() && !event.getParameter('landscape') && this.orderSplitContainer.getMode() === 'ShowHideMode') {
				this.orderSplitContainer.showMaster();
			}
		}

	});
});