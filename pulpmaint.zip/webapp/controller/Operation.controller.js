sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.Operation', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				ItemPath: '',
				PersonsToAssign: [],
				AssignPersonParameters: {},
				ConfirmedTime: '',
				SystemConditionRequiresRevision: false
			};

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));

			this.setModel('ViewModel', initialViewModel);
		},

		onAfterRendering: function() {
			this.removeInvisibleLabels();
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {
				this.getElementById('operationTextInput').rerender();

				this.modifyInputKeyboards();
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Operation') {
				var operationNumber = navigationEvent.getParameter('arguments').Path;

				var operationAssignments = this.getOrderModel()
					.getProperty('/Assignments')
					.filter(function(assignment) {
						return assignment.Activity === this.getModel('NewOperationModel').getProperty('/Activity');
					}.bind(this));

				var operation = this.getModel('NewOperationModel').getProperty('/Activity');
				var orderId = this.getModel('NewOperationModel').getProperty('/Orderid');
				var recordOption = [{
					Orderid: orderId + '/' + operation
				}];

				this.getModel('ViewModel').setProperty('/TimeRecordingOption', recordOption);

				BaseController.prototype.routeMatched.apply(this, arguments);

				setTimeout(this.removeInvisibleLabels, 0);

				this.getModel('ViewModel').setProperty('/SystemConditionRequiresRevision', this.getIsSystemConditionRequired());
				this.getModel('ViewModel').setProperty('/ItemPath', operationNumber || '');
				this.validate(this.getView(), this.removeValueStates.bind(this));
				this.getModel('NewOperationModel').setProperty('/Assignments', operationAssignments);
				this.initialObject = $.extend(true, {}, this.getModel('NewOperationModel').getData());
				this.setAssignPersonDefault();
				delete this.getModel('ViewModel').getData().ConfirmedTime;

				this.getModel('ViewModel').updateBindings(true);
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onSaveButtonPress: function() {
			if (this.validate()) {
				this.handleOperationReady();

				this.onNavBack();
			}
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('OperationActionButtons').openBy(pressEvent.getSource());
		},

		onOpenConfirmWorkingTime: function() {
			this.openSimpleDialog('TimeConfirmation');

			this.getFragmentElementById('TimeConfirmation', 'timeConfirmationInputField')
				.$()
				.children()
				.attr('type', 'Number')
				.attr('step', '0.01');
		},

		onConfirmTimeEntryButtonPress: function() {
			var timeConfirmation = this.getModel('ViewModel').getProperty('/ConfirmedTime');

			if (timeConfirmation) {
				this.onTimeConfirmationCloseButtonPress();

				this.postTimeConfirmation(timeConfirmation);
			}
		},

		onTimeConfirmationCloseButtonPress: function() {
			this.getDialog('TimeConfirmation').close();
		},

		onCompleteOperationPress: function() {
			this.getModel('NewOperationModel').setProperty('/Completed', 'X');

			if (!this.orderIsInEditMode()) {
				this.postCompletion();
			} else {
				this.openInfoPopUpWillBeSaved('OPERATION_WILL_BE_COMPLETED_ON_SAVE');
			}
		},

		onShowBarcodePress: function() {
			this.navTo('Barcode', {
				code: this.getBarcodeCode()
			});
		},

		onScheduleIdValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getScheduleDialogParameters()
			);
		},

		onAddPersonPress: function() {
			this.openSimpleDialog('AssignPerson');

			this.getFragmentElementById('AssignPerson', 'assignPersonHoursInputField')
				.$()
				.children()
				.attr('type', 'Number')
				.attr('step', '0.01');

			this.getAssignablePersons();
		},

		onPersonValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPersonDialogParameters()
			);
		},

		onAssignPersonPress: function() {
			this.getModel('NewOperationModel').setProperty(
				'/Assignments',
				this.getModel('NewOperationModel').getProperty('/Assignments').concat([this.getModel('ViewModel').getProperty('/AssignPersonParameters')])
			);

			this.getModel('NewOperationModel').setProperty('/UpdateAssignments', 'X');

			this.onAssignPersonCloseButtonPress();
		},

		onAssignPersonCloseButtonPress: function() {
			this.getDialog('AssignPerson').close();
		},

		onAssignPersonClose: function() {
			this.setAssignPersonDefault();
		},

		onAssignedPersonDelete: function(pressEvent) {
			var person = pressEvent.getSource().getParent().getBindingContext('NewOperationModel').getObject().Lastname;
			var path = pressEvent.getSource().getParent().getBindingContext('NewOperationModel').getPath();
			var index = path.substring(path.lastIndexOf('/') + 1, path.length);
			var corfirmPopUpProperties = {
				type: 'Warning',
				title: this.getResourceBundleText('CONFIRM_PERSON_DELETION_TITLE'),
				message: this.getResourceBundleText('CONFIRM_PERSON_DELETION_MESSAGE', person),
				onClose: this.handlePersonDeletion.bind(this, index),
				actions: [sap.m.MessageBox.Action.DELETE, sap.m.MessageBox.Action.CANCEL]
			};
			this.showMessageBox(corfirmPopUpProperties);
		},

		handlePersonDeletion: function(index, action) {
			if (action === 'DELETE') {
				this.getModel('NewOperationModel')
					.setProperty(
						'/Assignments',
						this.removeIndexFromArray(this.getModel('NewOperationModel').getProperty('/Assignments'), index)
					);

				this.getModel('NewOperationModel').setProperty('/UpdateAssignments', 'X');
				this.getModel('NewOperationModel').updateBindings(true);
			}
		},

		onTimeRecordingButtonPress: function() {
			var operationNumber = this.getModel('NewOperationModel').getProperty('/Activity');
			var orderId = this.getModel('NewOperationModel').getProperty('/Orderid');
			var shortText = this.getModel('NewOperationModel').getProperty('/Description');
			var recordOption = [{
				Orderid: orderId + '/' + operationNumber,
				ShortText: shortText
			}];
			var recordObject = this.getTimeRecordUtility().getSaveObject();

			if (this.getTimeRecordUtility().isRecordingForObject(recordOption)) {
				this.openTimeRecordConfirmation(recordObject);
			} else if (this.getTimeRecordUtility().isRecording()) {
				this.handleStopTimeRecording(recordObject, recordOption);
			} else {
				this.handleStartRecording(recordOption);
			}
		},

		onNavigateBack: function() {
			this.shouldShowWarningMessage() ?
				this.openNavigationConfimation() :
				this.onNavBack();
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					saveModelName: 'NewOperationModel',
					multiSelect: false
				})
			);
		},

		onSystemConditionChange: function(changeEvent) {
			var object = changeEvent.getParameter('selectedItem').getBindingContext('SelectionValuesModel').getObject();
			this.getModel('NewOperationModel').setProperty('/SystcondDescr', object.SystcondDescr);
			this.getModel('ViewModel').setProperty('/SystemConditionRequiresRevision', !!object && !!object.RevisionRequired);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		getBarcodeCode: function() {
			var prefix = '';
			var suffix = '';
			var plants = this.getModel('SelectionValuesModel').getProperty('/Plants') || [];
			var orderPlant = this.getOrderModel().getProperty('/Planplant') || '';
			if (orderPlant) {
				plants.some(function(plant) {
					if (plant.Plant === orderPlant) {
						prefix = plant.OperBarcodePrefix || '';
						suffix = plant.OperBarcodeSuffix || '';
						return true;
					}
				});
			}
			var order = this.getModel('NewOperationModel').getProperty('/Orderid') || '';
			var activity = this.getModel('NewOperationModel').getProperty('/Activity') || '0010';
			return (prefix + order + activity + suffix);
		},

		modifyInputKeyboards: function() {
			var numberInputs = ['numberOfCapacitiesInputField', 'durationInputField', 'workInputField'];

			var telephoneInputFields = ['startTimeInputField'];

			numberInputs.forEach(this.changeToNumberInput.bind(this));

			telephoneInputFields.forEach(this.changeToTelephoneInput.bind(this));
		},

		handleOperationReady: function() {
			var operationObject = this.getModel('NewOperationModel').getData();
			operationObject.Description = this.getShortText(operationObject.LongText);
			this.publishEvent('operation', 'operationReady', {
				operationObject: operationObject,
				path: this.getModel('ViewModel').getProperty('/ItemPath')
			});
		},

		setAssignPersonDefault: function() {
			this.getModel('ViewModel').setProperty('/AssignPersonParameters', {
				Activity: this.getModel('NewOperationModel').getProperty('/Activity'),
				WorkActivityUnit: 'H'
			});
		},

		getAssignablePersons: function() {
			var operationWorkCenter = this.getModel('NewOperationModel').getProperty('/Workcenter') || this.getOrderModel().getProperty('/Workcenter');
			var persons = this.getSelectionValuesModel().getProperty('/Persons');

			this.getModel('ViewModel').setProperty(
				'/PersonsToAssign',
				persons.filter(function(person) {
					return person.WorkCenters.results.some(function(workcenterObject) {
						return workcenterObject.Workcenter === operationWorkCenter;
					});
				})
			);
		},

		shouldShowWarningMessage: function() {
			return this.orderIsInEditMode() && this.operationDiffersFromOriginal();
		},

		operationDiffersFromOriginal: function() {
			return !this.areObjectsIdentical(
				this.getModel('NewOperationModel').getData(),
				this.initialObject
			);
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.onNavBack();
		},

		openInfoPopUpWillBeSaved: function(textKey) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('INFORMATION_POPUP_TITLE'),
				message: this.getResourceBundleText(textKey)
			});
		},

		postCompletion: function() {
			var postObject = this.getPostObject(this.getOrderModel().getData());
			var postParameters = {
				online: true
			};

			var ItemPath = this.getModel('ViewModel').getProperty('/ItemPath');

			postObject.Operations[ItemPath].Completed = 'X';

			this.getOrderModel().setData(postObject);

			if (this.isOffline()) {
				postObject.NotSync = true;
				postObject.ShortText = this.getShortText(postObject.LongText);
				this.insertOrderToList(postObject);
				this.localStorage.insertOrder(postObject);
				this.handleCreateSuccess();
			} else {
				postObject = this.generateOrderPostObject(postObject);
				this.setAppBusyMode();
				this.oDataUtil.create('WorkOrderSet', postObject, postParameters)
					.done(this.handleCreateSuccess.bind(this, postObject.Operations[ItemPath].Activity))
					.fail(this.handleCreateError.bind(this))
					.always(this.setAppNotBusyMode);
			}
		},

		postTimeConfirmation: function(hours) {
			var operationNumber = this.getModel('NewOperationModel').getProperty('/Activity');
			var orderId = this.getModel('NewOperationModel').getProperty('/Orderid');
			var postObject = {
				ConfirmedTime: hours,
				Activity: operationNumber,
				Orderid: orderId
			};

			this.setAppBusyMode();
			this.handleOperationConfirmation(postObject)
				.done(this.handleTimeConfirmationSuccess.bind(this, operationNumber, hours))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleCreateSuccess: function(operationNumber, response) {
			if (response && response.Orderid) {
				this.insertOrderToList(response);
				this.localStorage.removeOrder(response.Orderid);
			}
			this.openSuccessDialog(
				response && response.Orderid ?
				this.getResourceBundleText('OPERATION_COMPLETED_MESSAGE', operationNumber) :
				this.getResourceBundleText('POST_SAVE_OFFLINE_ORDER_MESSAGE')
			);
		},

		handleCreateError: function(errorEvent) {
			this.getModel('NewOperationModel').setProperty('/Completed', '');

			this.openErrorMessagePopup(errorEvent);
		},

		handleTimeConfirmationSuccess: function(operationNumber, hours) {
			this.openSuccessDialog(
				this.getResourceBundleText('TIME_CONFIRMED_FOR_OPERTAION_MESSAGE', operationNumber)
			);

			if (this.getConfigurationModel().getShowActualWork()) {
				var actualWork = this.getModel('NewOperationModel').getProperty('/ActualWork');
				var personNumber = this.getGlobalModel().getProperty('/PersonNumber');
				var assignments = this.getModel('NewOperationModel').getProperty('/Assignments').map(function(assignment) {
					if (assignment.PersonNumber === personNumber) {
						assignment.ActualWork = parseFloat(assignment.ActualWork || '0') + parseFloat(hours || '0') + '';
					}
					return assignment;
				});
				this.getModel('NewOperationModel').setProperty('/ActualWork', parseFloat(actualWork || '0') + parseFloat(hours || '0') + '');
				this.getModel('NewOperationModel').setProperty('/Assignments', assignments);

				this.handleOperationReady();
			}
		},

		handleStopTimeRecording: function(record, newRecord) {
			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TITLE'),
				message: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TEXT'),
				onClose: this.handleStopTimeRecordQuestionClose.bind(this, record, newRecord),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleStopTimeRecordQuestionClose: function(record, newRecord, action) {
			if (action === 'YES') {
				this.openTimeRecordConfirmation(record);
			} else if (action === 'NO') {
				this.getTimeRecordUtility().finishCurrentRecording();
				this.handleStartRecording(newRecord);
			}
		},

		handleStartRecording: function(record) {
			this.getTimeRecordUtility().startRecording(record);
		},

		openTimeRecordConfirmation: function(record) {
			this.getTimeRecordUtility().finishCurrentRecording();
			this.openDialog('TimeRecordConfirmationDialog', {
				record: record,
				type: 'OPERATION'
			});
		},

		onCompleteWorkButtonPress: function() {
			var operationNumber = this.getModel('NewOperationModel').getProperty('/Activity');
			var orderId = this.getModel('NewOperationModel').getProperty('/Orderid');
			var personNumber = this.getGlobalModel().getProperty('/PersonNumber');
			var postObject = {
				SubActivity: '',
				Activity: operationNumber,
				Orderid: orderId
			};

			this.setAppBusyMode();
			this.oDataUtil.functionImport('WorkOrderOperSetWorkFinished', postObject)
				.done(this.handleCompleteWorkSuccess.bind(this, personNumber))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleCompleteWorkSuccess: function(personNumber) {
			var operationNumber = this.getModel('NewOperationModel').getProperty('/Activity');
			var orderId = this.getModel('NewOperationModel').getProperty('/Orderid');
			var assignments = this.getModel('NewOperationModel').getProperty('/Assignments').map(function(assignment) {
				if (assignment.PersonNumber === personNumber) {
					assignment.WorkFinished = 'X';
				}
				return assignment;
			});

			var myWorks = this.getModel('MyWorksModel').getProperty('/MyWorks').filter(function(listOperation) {
				return !(listOperation.Activity === operationNumber && listOperation.Orderid === orderId);
			});

			this.getModel('NewOperationModel').setProperty('/Assignments', assignments);
			this.getModel('MyWorksModel').setProperty('/MyWorks', myWorks);

			this.handleOperationReady();
		},

		getIsSystemConditionRequired: function() {
			var selectedConditionId = this.getModel('NewOperationModel').getProperty('/Systcond');
			var systemConditions = this.getSelectionValuesModel().getProperty('/SystemConditionValues');

			var selectedCondition = systemConditions.filter(function(condition) {
				return selectedConditionId === condition.Systcond;
			});

			return !!(!!selectedCondition.length && selectedCondition[0].RevisionRequired);
		}

	});
});