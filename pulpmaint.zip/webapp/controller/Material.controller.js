sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.Material', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);
			var that = this;
			var initialViewModel = {
				ItemPath: '',
				MaterialObject: {},
				MaterialIsValid: true,
				MaterialSearchParams: {},
				Batches: [],
				StorageLocations: [],
				GoodsIssueIsFinalDelivery: false
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('functionalLocationSelected', 'CreateOrderMaterial', this.handleTechnicalObjectSelectedFromHierarchy.bind(this));

			this.getElementById('quantityLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Material') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				var material = this.getModel('NewMaterialModel').getProperty('/Material');

				this.getModel('ViewModel').setProperty('/ItemPath', navigationEvent.getParameter('arguments').Path || '');

				this.validate(this.getView(), this.removeValueStates.bind(this));

				this.initialObject = $.extend(true, {}, this.getModel('NewMaterialModel').getData());

				this.getModel('ViewModel').setProperty('/MaterialIsValid', true);

				if (material && this.getConfigurationModel().getEnableBatchSelection()) {
					this.getMaterialDependedValues(material);
					delete this.getModel('ViewModel').getData().GoodsIssueQuantity;
					this.getModel('ViewModel').setProperty('/GoodsIssueIsFinalDelivery', false);
				} else {
					this.getModel('ViewModel').setProperty('/Batches', []);
					this.getModel('ViewModel').setProperty('/StorageLocations', []);
				}
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onPressNavigateToHierarchy: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'CreateOrderMaterial');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', true);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(this.getOrderFunctionalLocation());
		},


		onSaveButtonPress: function() {
			if (this.validate()) {
				this.publishEvent('material', 'materialReady', {
					materialObject: this.getModel('NewMaterialModel').getData(),
					path: this.getModel('ViewModel').getProperty('/ItemPath')
				});
				this.onNavBack();
			}
		},

		onNavigateBack: function() {
			this.shouldShowWarningMessage() ?
				this.openNavigationConfimation() :
				this.onNavBack();
		},

		onMaterialSearchPress: function() {
			var dialogName = this.getConfigurationModel().getEnableTrexSearch() ? 'MaterialSearch' : 'MaterialSearchTrex';
			this.openDialog(dialogName);
		},

		onMaterialChange: function(changeEvent) {
			this.validateMaterial(
				changeEvent.getParameter('newValue').substr(
					0,
					changeEvent.getParameter('newValue').indexOf(' - ') !== -1 ?
					changeEvent.getParameter('newValue').indexOf(' - ') :
					changeEvent.getParameter('newValue').length
				)
			);
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('MaterialActionButtons').openBy(pressEvent.getSource());
		},

		onInstallEquipmentPress: function() {
			this.openDialog('EquipmentToInstallSelection');
		},

		onDismantleEquipmentPress: function() {
			this.openDialog(
				'SearchDialog',
				this.getEquipmenActionDialogParamaters({
					itemPressHandler: this.onEquipmentToDismantleSelect.bind(this),
					pathToModel: '/InstalledEquipments',
					dialogTitle: this.getResourceBundleText('SELECT_EQUIPMENT_TO_DISMANTLE_TITLE')
				})
			);
		},

		onEquipmentToDismantleSelect: function(selectEvent) {
			var selectedEquipment = selectEvent
				.getSource()
				.getBindingContext('ViewModel')
				.getObject()
				.Equnr;

			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('EQUIPMENT_QUESTION_POPUP_TITLE'),
				message: this.getResourceBundleText('EQUIPMENT_DISMANTLE_QUESTION_POPUP_TEXT', selectedEquipment),
				onClose: this.handleEquipmentDismantle.bind(this, selectedEquipment),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		onEquipmentToInstallSelect: function(selectEvent) {
			var selectedEquipment = selectEvent
				.getSource()
				.getBindingContext('ViewModel')
				.getObject()
				.Equnr;

			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('EQUIPMENT_QUESTION_POPUP_TITLE'),
				message: this.getResourceBundleText('EQUIPMENT_INSTALL_QUESTION_POPUP_TEXT', selectedEquipment),
				onClose: this.handleEquipmentInstall.bind(this, selectedEquipment),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		onStorageLocationValueHelp: function() {
			this.openDialog('StorageLocationSelection');
		},

		onGoodsIssueButtonPress: function() {
			var reservationQuantity = this.getModel('NewMaterialModel').getProperty('/RequirementQuantity');

			this.getModel('ViewModel').setProperty('/GoodsIssueQuantity', reservationQuantity);
			this.openSimpleDialog('GoodsIssuePosting');

			this.getFragmentElementById('GoodsIssuePosting', 'goodsIssueQuantityInputField')
				.$()
				.children()
				.attr('type', 'Number')
				.attr('step', '0.01');
		},

		onGoodsPostGoodsIssue: function() {
			this.handleGoodsIssuePost();
		},

		onGoodsIssuePostingClose: function() {
			this.getDialog('GoodsIssuePosting').close();
		},

		onQuantityChange: function() {
			if (this.getConfigurationModel().getEnableBatchSelection()) {
				this.getElementById('batchSelectControl').getBinding('items').refresh(true);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		filterSubOperations: function(operation) {
			return operation && !operation.SubActivity;
		},

		handleScanSuccess: function(result) {
			if (result.text) {
				this.validateMaterial(this.getMaterialNumberFromScanResult(result.text));
			}
		},

		getMaterialDependedValues: function(material) {
			var batchParameters = {
				online: true,
				filters: this.generateFilter('Material', [material])
			};

			var storageLocationParameters = {
				online: true,
				filters: this.generateFilter('Material', [material])
			};

			$.when(
					this.oDataUtil.read('BatchesSet', batchParameters),
					this.oDataUtil.read('StorageLocationSet', storageLocationParameters)
				)
				.done(this.handleGetMaterialDependedValuesSuccess.bind(this));

			this.getStorageLocationDependedValues(material);
		},

		getStorageLocationDependedValues: function(material) {
			var orderFunctionalLocation = this.getOrderFunctionalLocation();
			var storageLocation = this.getModel('NewMaterialModel').getProperty('/StgeLoc');

			var equipmentsToInstallParameters = {
				online: true,
				filters: this.generateFilter('Material', [material]).concat(this.generateFilter('StorageLoc', [storageLocation]))
			};

			var equipmentsToDismantleParameters = {
				online: true,
				filters: this.generateFilter('Material', [material]).concat(this.generateFilter('Funcloc', [orderFunctionalLocation]))
			};

			// get values for dismantiling and installing
			if (this.getModel('NewMaterialModel').getProperty('/ReservNo')) {
				$.when(
						this.oDataUtil.read('EquipmentForExchangeSet', equipmentsToDismantleParameters),
						this.oDataUtil.read('EquipmentForExchangeSet', equipmentsToInstallParameters)
					)
					.done(this.handleGetValuesForInstallingAndDismantlingSuccess.bind(this));
			}
		},

		handleGetMaterialDependedValuesSuccess: function(batches, storageLocations) {
			this.getModel('ViewModel').setProperty('/Batches', batches);
			this.getModel('ViewModel').setProperty('/StorageLocations', storageLocations);
		},

		handleGetValuesForInstallingAndDismantlingSuccess: function(installedEquipments, equipmentsToInstall) {
			this.getModel('ViewModel').setProperty('/InstalledEquipments', installedEquipments);
			this.getModel('ViewModel').setProperty('/EquipmentsToInstall', equipmentsToInstall);
		},

		getMaterialNumberFromScanResult: function(scanResult) {
			return scanResult && scanResult.indexOf(' ') !== -1 ? scanResult.substring(0, scanResult.indexOf(' ')) : scanResult;
		},

		handleTechnicalObjectSelectedFromHierarchy: function(channel, eventName, materialObject) {
			if (this.getConfigurationModel().getEnableBatchSelection()) {
				this.subscribeToEventOnce('app', 'afterNavigate', this.openDialog.bind(this, 'MaterialSearch', {
					Material: materialObject.Component
				}));
			} else {
				this.validateMaterial(materialObject && materialObject.Component, materialObject.Quantity);
			}
		},

		shouldShowWarningMessage: function() {
			return this.materialDiffersFromOriginal();
		},

		materialDiffersFromOriginal: function() {
			return !this.areObjectsIdentical(
				this.getModel('NewMaterialModel').getData(),
				this.initialObject
			);
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.onNavBack();
		},

		validateMaterial: function(materialNumber, quantity) {
			if (materialNumber) {
				this.oDataUtil.read('MaterialsSet(\'' + materialNumber + '\')')
					.done(this.handleMaterialValid.bind(this, quantity))
					.fail(this.handleMaterialNotValid.bind(this, materialNumber));
			} else {
				this.handleMaterialValid({});
			}
		},

		handleMaterialValid: function(quantity, materialObject) {
			var materialModel = this.getModel('NewMaterialModel');

			materialModel.setProperty('/Material', materialObject.Material);
			materialModel.setProperty('/MaterialDescr', materialObject.MaterialDescr);
			materialModel.setProperty('/RequirementQuantityUnit', materialObject.BaseUnit);

			if (quantity) {
				materialModel.setProperty('/RequirementQuantity', quantity);
			}

			if (this.getConfigurationModel().getEnableBatchSelection() && materialObject.Material) {
				materialModel.setProperty('/StgeLoc', materialObject.StgeLoc);
				materialModel.setProperty('/Batch', materialObject.Batch);
				materialModel.setProperty('/AvailableStock', materialObject.AvailableStock);
				materialModel.setProperty('/BinLocation', materialObject.BinLocation);
				this.getMaterialDependedValues(materialObject.Material);
			}

			this.getModel('ViewModel').setProperty('/MaterialIsValid', true);
		},

		handleMaterialNotValid: function(materialNumber) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('MATERIAL_NOT_FOUND_TITLE'),
				message: this.getResourceBundleText('MATERIAL_NOT_FOUND_MESSAGE', materialNumber)
			});

			this.getModel('ViewModel').setProperty('/MaterialIsValid', false);
		},

		handleEquipmentInstall: function(equipmentNumber, action) {
			if (action === 'YES') {
				var reservationNumber = this.getModel('NewMaterialModel').getProperty('/ReservNo');
				var reservationItem = this.getModel('NewMaterialModel').getProperty('/ResItem');

				this.equipmentInstall({
					Equnr: equipmentNumber,
					Funcloc: this.getOrderFunctionalLocation(),
					ReservNo: reservationNumber,
					ResItem: reservationItem
				}, equipmentNumber);
			}
		},

		equipmentInstall: function(importData, equipmentNumber) {
			this.setAppBusyMode();

			this.oDataUtil.functionImport('EquipmentInstall', importData)
				.done(this.handleInstallSuccess.bind(this, equipmentNumber))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleInstallSuccess: function(equipmentNumber) {
			this.openSuccessDialog(
				this.getResourceBundleText('EQUIPMENT_INSTALL_SUCCESS_MESSAGE', equipmentNumber)
			);
		},

		handleEquipmentDismantle: function(equipmentNumber, action) {
			if (action === 'YES') {
				var reservationNumber = this.getModel('NewMaterialModel').getProperty('/ReservNo');
				var reservationItem = this.getModel('NewMaterialModel').getProperty('/ResItem');

				this.equipmentDismantle({
					Equnr: equipmentNumber,
					ReservNo: reservationNumber,
					ResItem: reservationItem
				}, equipmentNumber);
			}
		},

		equipmentDismantle: function(importData, equipmentNumber) {
			this.setAppBusyMode();

			this.oDataUtil.functionImport('EquipmentDismantle', importData)
				.done(this.handleDismantleSuccess.bind(this, equipmentNumber))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handleDismantleSuccess: function(equipmentNumber) {
			this.openSuccessDialog(
				this.getResourceBundleText('EQUIPMENT_DISMANTLED_SUCCESS_MESSAGE', equipmentNumber)
			);
		},

		handleGoodsIssuePost: function() {
			var quantity = this.getModel('ViewModel').getProperty('/GoodsIssueQuantity');
			var isFinalDelivery = this.getModel('ViewModel').getProperty('/GoodsIssueIsFinalDelivery');
			var component = this.getModel('NewMaterialModel').getData();

			var goodsIssue = this.constructGoodsIssue(component, quantity, isFinalDelivery);

			this.postGoodsIssue(goodsIssue);
		},

		constructGoodsIssue: function(component, quantity, isFinalDelivery) {
			var goodsIssueItem = {
				MaterialNumber: component.Material,
				GoodsIssueNumber: '',
				Operation: component.Activity,
				StorageLocation: component.StgeLoc,
				StorageBin: component.BinLocation,
				Batch: component.Batch,
				ReservationItem: component.ResItem,
				Unit: component.RequirementQuantityUnit,
				OpenQty: quantity,
				FinalDelivery: isFinalDelivery ? 'X' : ''
			};
			var goodsIssue = {
				PlantId: component.Plant,
				GoodsIssueNumber: '',
				UnloadingPoint: component.UnloadPt,
				Workorder: '',
				Reservation: component.ReservNo,
				Items: [goodsIssueItem]
			};

			return goodsIssue;
		},

		postGoodsIssue: function(goodsIssue) {
			var busyPath = '/IsGoodsIssueDialogBusy';

			this.setPathBusy(busyPath);

			this.oDataUtil.createGoodsIssue(goodsIssue)
				.done(this.handleGoodsIssuePostSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGoodsIssuePostSuccess: function(response) {
			var component = this.getModel('NewMaterialModel').getData();
			var goodsIssues = this.getOrderModel().getProperty('/GoodsIssues');
			var year = new Date().getFullYear() + '';

			var giItem = response.Items[response.Items.length - 1];
			var document = {
				Orderid: response.GoodsIssueNumber,
				Posteddocitem: giItem.GiItem,
				Posteddocnumber: response.PostedDocNumber,
				Posteddocyear: year,
				Material: giItem.MaterialNumber,
				MaterialDescr: component.MaterialDescr,
				Quantity: giItem.OpenQty,
				QuantityUnit: giItem.Unit,
				StgeLoc: component.StgeLoc,
				BinLocation: component.BinLocation,
				Batch: component.Batch
			};
			this.onGoodsIssuePostingClose();

			this.openSuccessDialog(
				this.getResourceBundleText('GOODS_ISSUE_SUCCESS_MESSAGE', response && response.PostedDocNumber || '')
			);

			goodsIssues = Array.isArray(goodsIssues) ? goodsIssues : [];

			goodsIssues.push(document);

			this.getOrderModel().setProperty('/GoodsIssues', goodsIssues);

			this.getOrderModel().updateBindings(true);
		},

		filterBatches: function(batch) {
			var quantity = this.getModel('NewMaterialModel').getProperty('/RequirementQuantity');
			var hasNegativeQuantity = !!quantity && quantity.indexOf('-') !== -1;
			var isAdded = batch && !!batch.ManuallyAdded;

			return hasNegativeQuantity || !isAdded;
		}

	});
});