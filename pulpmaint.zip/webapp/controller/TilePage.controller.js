sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.TilePage', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.subscribeToEvent('app', 'navigate', this.handleNavigate.bind(this));
			document.addEventListener('NFCRead', this.handleNFCRead.bind(this));

			if (this.isCordova()) {
				// handle NFC startup paramters
				this.subscribeToEvent('app', 'onlineMetadataLoaded', this.readNFCParameters.bind(this));
			}


			this.setModel('ViewModel');
		},

		onAfterRendering: function() {
			if (this.isCordova()) {
				// remove shell color from the top
				$('.sapMShellBrandingBar').remove();
			}
			try {
				this.getView().getAggregation('content').shift().$().find('section').attr('align', 'center');
			} catch (errorEvent) {

			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'TilePage') {
				BaseController.prototype.routeMatched.apply(this, arguments);
			}
		},

		handleNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {

			}
		},

		handleHardwareNavBack: function() {
			!$('#sap-ui-blocklayer-popup').css('visibility') || this.closePopups();
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onUserParametersButtonPress: function() {
			this.navTo('UserParameters');
		},

		onCreateNotificationTilePress: function() {
			var planGroups;

			this.getModel('NewNotificationModel').setData(this.models.getNotificationDefaults());

			planGroups = this.getModel('SelectionValuesModel').getProperty('/PlanGroups');

			if (planGroups && planGroups.length === 1) {
				this.getModel('NewNotificationModel').setProperty('/Plangroup', planGroups[0].Plangroup);
			}

			this.navTo('CreateNotification', {
				Purpose: 'Create'
			});
		},

		onNotificationsTilePress: function() {
			this.navTo('Notifications');
		},

		onCreateOrderTilePress: function() {
			this.getModel('NewOrderModel').setData(this.models.getOrderDefaults());
			this.navTo('CreateOrder', {
				Purpose: 'Create',
				query: {
					Tab: 'Header'
				}
			});
		},

		onOrdersTilePress: function() {
			this.navTo('Orders');
		},

		onRoutesTilePress: function() {
			this.navTo('Routes');
		},

		onMyWorkTilePress: function() {
			this.navTo('MyWorks');
		},

		onEquipmentDismantlingPress: function() {
			this.getMyComponent().setModel(this.models.createNewEquipmentDismantlingModel(), 'NewEquipmentDismantlingModel');
			this.navTo('EquipmentDismantling');
		},

		onWorkFlowApprovalsTilePress: function() {
			this.navTo('WorkFlowApprovals');
		},

		onShutDownButtonPress: function() {
			var currentRecording = this.getTimeRecordUtility().getProperty('/CurrentRecording') || {};
			if (currentRecording.start) {
				var record = this.getTimeRecordUtility().getSaveObject();
				this.showMessageBox({
					type: 'Question',
					title: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TITLE'),
					message: this.getResourceBundleText('STOP_TIME_RECORDING_END_QUESTION_TEXT'),
					onClose: this.handleStopTimeRecordQuestionClose.bind(this, record),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO, sap.m.MessageBox.Action.CANCEL]
				});
			} else {
				this.showMessageBox({
					type: 'Warning',
					title: this.getResourceBundleText('CONFIRM_SHUT_DOWN_TITLE'),
					message: this.getResourceBundleText('CONFIRM_SHUT_DOWN_TEXT'),
					onClose: this.handleCloseApplication.bind(this),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
				});
			}
		},

		handleStopTimeRecordQuestionClose: function(record, action) {
			if (action === 'YES') {
				this.openDialog('TimeRecordConfirmationDialog', {
					record: record,
					type: 'SHUTDOWN'
				});
			} else if (action === 'NO') {
				this.getTimeRecordUtility().finishCurrentRecording();
				this.handleCloseApplication('YES');
			}
		},

		handleShutdownTimeConfirmationSuccess: function() {
			this.getTimeRecordUtility().finishCurrentRecording();
			this.handleCloseApplication('YES');
		},

		onObjectInfoPress: function() {
			this.navTo('TechnicalObjectSelection');
		},

		onMaterialSearchTilePress: function() {
			this.navTo('MaterialSearch');
		},

		onMaterialDetailsTilePress: function() {
			this.navTo('MaterialDetails');
		},

		onSyncPress: function() {
			this.setAppBusyMode();

			this.flushOfflineStore()
				.done(function() {
					this.refreshAllOfflineRequests()
						.always(this.setAppNotBusyMode.bind(this));
				}.bind(this))
				.fail(this.setAppNotBusyMode.bind(this));
		},

		onTimerecordingLinkPress: function() {
			var oData = this.getModel('TimeRecordModel').getData() || {};
			var currentRecording = oData.CurrentRecording || {};
			if (currentRecording.options && currentRecording.options[0].RouteId) {
				// Navigate to route
				this.getModel('EditRouteModel').setData($.extend(true, {}, currentRecording.options[0]));
				this.navTo('Routes', {
					RouteId: currentRecording.object
				});
			} else {
				var parts = currentRecording.object.split('/');
				if (parts[0]) {
					var query = {
						Tab: 'Operations'
					};
					if (parts[1]) {
						query.Activity = parts[1];
					}
					this.navTo('EditMyWork', {
						Purpose: 'Display',
						OrderNumber: parts[0],
						query: query
					});
				}
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handleCloseApplication: function(action) {
			if (action === 'YES') {
				var isMultiUserDevice = window.localStorage.getItem('isMultiUserDevice') === 'true';
				isMultiUserDevice ? this.devapp.devLogon.doLogOut() : this.devapp.devLogon.closeApplication();
			}
		},

		readNFCParameters: function() {
			var technicalObject = this.devapp && this.devapp.nfcTechnicalObject;

			if (!this.hasReadNFCParameters) {
				this.handleNavigationToObjectInfo(technicalObject);
			}

			// change back to empty string, to avoid double navigation
			if (technicalObject) {
				this.devapp.nfcTechnicalObject = '';
			}

			this.hasReadNFCParameters = true;
		},

		handleNFCRead: function(readEvent) {
			if (this.shouldHandleNFCReadEvent(readEvent)) {
				this.handleNavigationToObjectInfo(readEvent.detail.TechnicalObject);
			}
		},

		shouldHandleNFCReadEvent: function(readEvent) {
			var containsTechnicalObject = readEvent && readEvent.detail && readEvent.detail.TechnicalObject;
			var hasSuitableHash = false;

			if (!location.hash) {
				hasSuitableHash = true;
			}
			return containsTechnicalObject && hasSuitableHash;
		},

		handleNavigationToObjectInfo: function(technicalObject) {
			if (technicalObject) {
				this.navTo('TechnicalObject', {
					TechnicalObject: (technicalObject || '').replace(/\//g, '\\'),
					query: {
						Tab: 'Header'
					}
				});
			}
		},

		onTestPress: function() {
			nfc.connect('android.nfc.tech.NfcV')
				.then(function() {
					console.log('Connected successfully');
					// get random number
					nfc.transceive('00 B2 04')
						.then(function(response) {
							console.log(response);
							var uintArray = new Uint8Array(response);
							var randomNum = this.uint8ArrayToByteArray(uintArray.slice(1));
							randomNum = randomNum.concat(randomNum);
							console.log(randomNum);
							var xorPassword = this.getXORBytes(this.getNFCPasswordBytes(), randomNum);
							console.log(xorPassword);

							// set write password
							nfc.transceive('00 B3 04 02' + nfc.bytesToHexString(xorPassword))
								.then(function(response1) {
									console.log(response1);
								}, function(error) {
									console.log(error);
								});
						}.bind(this), function(error) {
							console.log(error);
						});
				}.bind(this), function() {
					console.log('Connecting failed');
				});
		},

		readNfcData: function() {
			nfc.connect('android.nfc.tech.NfcV')
				.then(function() {
					console.log('Connected successfully');
					// read multiple blocks
					nfc.transceive('00 23 00 79')
						.then(function(response) {
							console.log(response);
						}, function(error) {
							console.log(error);
						});
				}, function() {
					console.log('Connecting failed');
				});
		}

	});
});