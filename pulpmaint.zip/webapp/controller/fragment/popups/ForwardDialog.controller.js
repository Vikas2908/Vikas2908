sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.ForwardDialog', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.getElement('forwardReasonInput').rerender();

			this.fragment.open();
		},

		onForwardPress: function() {
			this.parentView.forwardWorkFlow.call(this.parentView);

			this.onDialogCloseButtonPress();
		},

		onForwardToValueHelp: function() {
			this.parentView.openDialog.call(this.parentView, 'PersonSearch');
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'ForwardDialog', element);
		}
	});
});