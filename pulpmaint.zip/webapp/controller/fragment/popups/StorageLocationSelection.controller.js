sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.StorageLocationSelection', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.open();
		},

		onStorageLocationItemPress: function(selectEvent) {
			var storageLocation = selectEvent.getSource().getBindingContext('ViewModel').getObject().StorageLoc;
			var material = this.parentView.getModel('NewMaterialModel').getProperty('/Material');

			this.parentView.getModel('NewMaterialModel').setProperty('/StgeLoc', storageLocation);

			// storage location has an effect on helpers
			this.parentView.getStorageLocationDependedValues(material);

			this.fragment.close();
		},

		onStorageLocationSearchLiveChange: function(changeEvent) {
			var searchValue = changeEvent.getParameter('newValue');

			this.getElement('storageLocationSelectionList')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('StorageLoc', [searchValue], 'Contains')
						.concat(
							this.generateFilter('StorageLocDescr', [searchValue], 'Contains')
						)
					)
				]);
		},

		onStorageLocationSelectionCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'StorageLocationSelection', element);
		},

		onAfterStorageLocationSelectionClose: function() {
			this.getElement('storageLocationSelectionSearchField').setValue('');
		}
	});
});