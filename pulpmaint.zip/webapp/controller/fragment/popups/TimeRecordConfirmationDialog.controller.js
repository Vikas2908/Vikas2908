sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var dialogParameters;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.TimeRecordConfirmationDialog', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;
			dialogParameters = parameters;

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				RecordObject: dialogParameters.record,
				ConfirmedTime: dialogParameters.record.time,
				type: dialogParameters.type
			}), 'DialogModel');
			this.setDefaultOrderSelection();

			this.fragment.open();

			setTimeout(function() {
				this.getElement('timeRecordHourInputField')
					.$()
					.children()
					.attr('type', 'Number')
					.attr('step', '0.01');
			}.bind(this), 0);
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		onConfirmTimeEntryButtonPress: function() {
			var timeConfirmation = this.fragment.getModel('DialogModel').getData();
			var confirmationTarget = timeConfirmation.RecordObject.object.split('/');
			var order = confirmationTarget[0];
			var operation = confirmationTarget[1];
			var type = timeConfirmation.type;
			var busyPath = '/IsTimeRecordDialogBusy';

			this.parentView.setPathBusy(busyPath);

			if (operation) {
				this.parentView.handleOperationConfirmation({
						ConfirmedTime: timeConfirmation.ConfirmedTime,
						Orderid: order,
						Activity: operation
					})
					.done(this.handleDefaultTimeConfirmationSuccess.bind(this, order, operation, type))
					.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
					.always(this.parentView.setPathNotBusy.bind(this.parentView, busyPath));
			} else {
				this.parentView.handleRouteTimeConfirmation({
						ConfirmedTime: timeConfirmation.ConfirmedTime,
						Orderid: order
					})
					.done(this.handleDefaultTimeConfirmationSuccess.bind(this, order, operation, type))
					.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
					.always(this.parentView.setPathNotBusy.bind(this.parentView, busyPath));
			}
		},

		onCoverWorkOrderSelect: function(selectEvent) {
			if (selectEvent.getParameter('selected')) {
				var selectedOrderId = selectEvent.getSource().getBindingContext('DialogModel').getObject().Orderid;

				this.fragment.getModel('DialogModel').setProperty('/RecordObject/object', selectedOrderId);
			}
		},

		handleDefaultTimeConfirmationSuccess: function(order, operation, type) {
			this.onDialogCloseButtonPress();
			if (type === 'SHUTDOWN') {
				this.parentView.handleShutdownTimeConfirmationSuccess();
			} else if (operation) {
				this.parentView.handleOperationTimeConfirmationSuccess(operation);
			} else {
				this.parentView.handleRouteTimeConfirmationSuccess(order);
			}
		},

		handleTimeConfirmationSuccess: function(operation) {
			this.onDialogCloseButtonPress();

			this.parentView.handleOperationTimeConfirmationSuccess(operation);
		},

		handleRouteTimeConfirmationSuccess: function(order) {
			this.onDialogCloseButtonPress();

			this.parentView.handleRouteTimeConfirmationSuccess(order);
		},

		setDefaultOrderSelection: function() {
			var values = this.fragment.getModel('DialogModel').getProperty('/RecordObject/options') || [];
			if (values.length > 1) {
				this.fragment.getModel('DialogModel').setProperty('/RecordObject/object', this.parentView.getLatestRouteOrderId());
			}
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'TimeRecordConfirmationDialog', element);
		}
	});
});