sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var helperDialogProperties;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.AttachmentSelect', {

		init: function(parent, fragment, oParameters) {
			this.parentView = parent;
			this.fragment = fragment;
			helperDialogProperties = oParameters;
			helperDialogProperties.itemSelectFunction = oParameters.itemSelectFunction || $.noop;

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				Attachments: helperDialogProperties.Attachments || []
			}), 'AttachmentDialog');
			this.fragment.open();
		},

		onAttachmentItemPress: function(oEvent) {
			var selectedObject = oEvent.getSource().getBindingContext('AttachmentDialog').getObject();
			if (selectedObject) {
				helperDialogProperties.itemSelectFunction(selectedObject);
				this.onAttachmentDialogClose();
			}
		},

		onAttachmentDialogClose: function() {
			this.fragment.close();
		}
	});
});