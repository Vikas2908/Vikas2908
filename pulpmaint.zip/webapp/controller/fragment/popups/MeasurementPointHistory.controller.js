sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var vizFrameInitialized;
	var dialogParameters;
	var currentUnit;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.MeasurementPointHistory', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;
			dialogParameters = parameters;

			this.parentView.getModel('ViewModel').setProperty('/SelectedMeasurementPoint', '');
			this.parentView.getModel('ViewModel').setProperty('/MeasurementPointHistory', []);
			this.parentView.getModel('ViewModel').setProperty('/IsDownloadingMeasurementPointHistory', false);

			this.bindDialogToModel(parameters);

			this.getNavContainer().backToTop();

			if (!vizFrameInitialized) {
				this.setHistoryChartOptions(this.getElement('trendChart'));
			}

			this.fragment.open();
		},

		bindDialogToModel: function(parameters) {
			var dialogListElement = this.getElement('measurementPointList');
			var dialogListItemElement = this.getElement('measurementPointListItem');


			dialogListItemElement
				.bindProperty('title', parameters.ModelName + '>Description');

			dialogListElement.bindItems({
				path: parameters.ModelName + '>/Measurements',
				template: dialogListItemElement
			});
		},

		onMeasurementPointPress: function(pressEvent) {
			var measurementPoint = pressEvent
				.getSource()
				.getBindingContext(dialogParameters.ModelName)
				.getObject();

			var measurementPointId = measurementPoint.Point;
			var measurementPointDescription = measurementPoint.Description;

			this.parentView.getModel('ViewModel').setProperty('/SelectedMeasurementPoint', measurementPointDescription);

			this.getMeasurementHistory(measurementPointId);

			this.getNavContainer().to(this.getElement('measurementHistoryPage'));
		},

		getMeasurementHistory: function(measurementPoint) {
			this.parentView.getModel('ViewModel').setProperty('/IsDownloadingMeasurementPointHistory', true);

			var parameters = {
				online: true,
				filters: this.generateFilter('Point', [measurementPoint])
			};

			this.parentView.oDataUtil.read('MeasurementDocumentSet', parameters)
				.done(this.handleGetHistoryPointSuccess.bind(this))
				.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
				.always(this.handleGetHistoryPointEnd.bind(this));
		},

		handleGetHistoryPointSuccess: function(measurementHistory) {
			if (Array.isArray(measurementHistory)) {
				currentUnit = measurementHistory[0] && measurementHistory[0].Unit;
			} else {
				currentUnit = '';
			}
			this.parentView.getModel('ViewModel').setProperty(
				'/MeasurementPointHistory',
				measurementHistory.map(function(measurement) {
					measurement.RecordedValue = parseFloat(measurement.RecordedValue.replace(',', '.'));
					measurement.MeasDate = this.formatterUtil.formatDate.call(this, measurement.MeasDate);
					return measurement;
				}.bind(this.parentView))
			);
		},

		handleGetHistoryPointEnd: function() {
			this.parentView.getModel('ViewModel').setProperty('/IsDownloadingMeasurementPointHistory', false);
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onCloseMeasurementPointHistoryPopup: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'MeasurementPointHistory', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		},

		setHistoryChartOptions: function(vizFrame) {
			this.setHistoryChartProperties(vizFrame);
		},

		setHistoryChartProperties: function(vizFrame) {
			vizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: true,
						renderer: this.renderChartLabel.bind(this)
					},
					window: {
						start: null,
						end: null
					}
				},
				valueAxis: {
					title: {
						visible: false
					},
					color: '#ffffff'
				},
				categoryAxis: {
					title: {
						visible: false
					},
					color: '#ffffff'
				},
				title: {
					visible: false
				},
				legend: {
					visible: false
				},
				tooltip: {
					background: {
						color: '#ffffff'
					}
				}
			});
		},

		renderChartLabel: function(domRef) {
			if (currentUnit) {
				domRef.text = domRef.text + ' ' + currentUnit;
			}
		}
	});
});