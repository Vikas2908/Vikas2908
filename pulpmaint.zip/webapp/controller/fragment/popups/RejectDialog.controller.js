sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.RejectDialog', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.getElement('rejectReasonInput').rerender();

			this.fragment.open();
		},

		onRejectPress: function() {
			this.parentView.rejectWorkFlow.call(this.parentView);

			this.onDialogCloseButtonPress();
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'RejectDialog', element);
		}
	});
});