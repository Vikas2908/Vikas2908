sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.NFCReadDialog', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.open();
		},

		onCancelNotificationPress: function() {
			this.fragment.close();
			this.parentView.cancelNotification();
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		handleDialogClose: function() {
			this.parentView.handleNFCReadDialogClose.call(this.parentView);
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'CancelNotification', element);
		}
	});
});