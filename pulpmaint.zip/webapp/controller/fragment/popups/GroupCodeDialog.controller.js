sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var dialogParameters;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.GroupCodeDialog', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				IsBusy: false,
				CatalogId: parameters.catalogId
			}), 'DialogModel');

			this.fragment.attachAfterClose(this.onAfterGroupCodeDialogClose.bind(this));

			this.configureDialog(parameters);

			this.fragment.open();
		},

		configureDialog: function(parameters) {
			dialogParameters = parameters;

			this.getNavContainer().backToTop();

			this.bindDialogToModel();
		},

		bindDialogToModel: function() {
			if (dialogParameters.catalogProfile) {
				var catalogFilters = {
					filters: this.generateFilter('CatalogProfile', [dialogParameters.catalogProfile])
						.concat(this.generateFilter('CatalogId', [dialogParameters.catalogId]))
				};

				this.fragment.getModel('DialogModel').setProperty('/IsBusy', true);
				this.oDataUtil.read('CatalogSet', catalogFilters)
					.done(function(catalogs) {
						this.fragment.getModel('DialogModel').setProperty('/IsBusy', false);
						this.filterGroupList(
							this.generateFilter(
								'CodeGroup',
								catalogs.map(function(catalog) {
									return catalog.CodeGroup;
								})
							)
						);
					}.bind(this));
			} else {
				this.filterGroupList();
			}
		},

		filterGroupList: function(filters) {
			filters = filters || [];
			var items;

			var notifTypeFilter = [];
			if (dialogParameters.notifType) {
				notifTypeFilter = this.generateFilter('Notiftype', [dialogParameters.notifType]);
			}

			this.getElement('groupDialogList')
				.getBinding('items')
				.filter(
					this.generateFilter('CatalogId', [dialogParameters.catalogId])
					.concat(notifTypeFilter, filters)
				);

			items = this.getElement('groupDialogList').getItems();

			if (items && items.length === 1) {
				this.navToCodeSelection(items[0].getBindingContext('SelectionValuesModel').getObject());
			}
		},

		onGroupSearchLiveChange: function() {
			this.applyFiltersToListBinding(
				'CodeGroup',
				'Name',
				'groupDialogList',
				'groupSelectionSearchField'
			);
		},

		onCodeSearchLiveChange: function() {
			this.applyFiltersToListBinding(
				'Code',
				'Name',
				'codeDialogList',
				'codeSelectionSearchField'
			);
		},

		applyFiltersToListBinding: function(valueToFilter, secondValueToFilter, list, searchField) {
			var listBinding = this.getElement(list).getBinding('items');
			var searchBarValue = this.getElement(searchField).getValue();
			var oFirstFilter = new sap.ui.model.Filter(valueToFilter, sap.ui.model.FilterOperator.Contains, searchBarValue);
			var oSecondFilter = new sap.ui.model.Filter(secondValueToFilter, sap.ui.model.FilterOperator.Contains, searchBarValue);
			var oCombinedFilter = new sap.ui.model.Filter([oFirstFilter, oSecondFilter]);
			listBinding.filter([oCombinedFilter], 'Application');
		},

		onGroupItemPress: function(pressEvent) {
			var selectedListItem = pressEvent.getSource().getBindingContext('SelectionValuesModel').getObject();

			this.navToCodeSelection(selectedListItem);
		},

		navToCodeSelection: function(selectedGroup) {
			var saveModel = this.parentView.getModel(dialogParameters.saveModelName);

			saveModel.setProperty('/' + dialogParameters.groupIdProperty, selectedGroup.CodeGroup);
			saveModel.setProperty('/' + dialogParameters.groupDescriptionProperty, selectedGroup.Name);

			this.filterCodeList(selectedGroup.CodeGroup);

			this.getNavContainer().to(this.getElement('codeSelectionDialogPage'));
		},

		filterCodeList: function(group) {
			this.getElement('codeDialogList')
				.getBinding('items')
				.filter(this.generateFilter('CodeGroup', [group]).concat(this.generateFilter('CatalogId', [dialogParameters.catalogId])));
		},

		onCodeItemPress: function(pressEvent) {
			var oSaveModel = this.parentView.getModel(dialogParameters.saveModelName);
			var selectedListItem = pressEvent.getSource().getBindingContext('SelectionValuesModel').getObject();

			oSaveModel.setProperty('/' + dialogParameters.codeIdProperty, selectedListItem.Code);
			oSaveModel.setProperty('/' + dialogParameters.codeDescriptionProperty, selectedListItem.Name);

			this.onGroupCodeDialogCloseButtonPress();
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onGroupCodeDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		onAfterGroupCodeDialogClose: function() {
			this.getElement('groupSelectionSearchField').setValue('');
			this.getElement('codeSelectionSearchField').setValue('');

			dialogParameters = {};
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'GroupCodeDialog', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		},

		hasGroup: function() {
			return !!(this.getGroup());
		},

		getGroup: function() {
			return this.parentView.getModel(dialogParameters.saveModelName).getProperty('/' + dialogParameters.groupIdProperty);
		}
	});
});