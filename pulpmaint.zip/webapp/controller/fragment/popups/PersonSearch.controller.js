sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.PersonSearch', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.getNavContainer().backToTop();

			this.fragment.open();
		},

		onPersonSearch: function() {
			var searchParameters = this.parentView.getModel('ViewModel').getProperty('/PersonSearchParams');

			var parameters = {
				online: true,
				filters: this.generateFilter('UserId', [searchParameters.UserId || ''])
					.concat(this.generateFilter('Lastname', [searchParameters.Lastname || '']), this.generateFilter('Firstname', [searchParameters.Firstname || '']))
			};

			this.parentView.setAppBusyMode();

			this.parentView.oDataUtil.read('UserSet', parameters)
				.done(this.handleGetPersonsSuccess.bind(this))
				.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
				.always(this.parentView.setAppNotBusyMode);
		},

		handleGetPersonsSuccess: function(persons) {
			this.parentView.getModel('ViewModel').setProperty('/Persons', persons);

			this.getNavContainer().to(this.getElement('personSearchListPage'));
		},

		onPersonSearchItemPress: function(pressEvent) {
			var selectedListItem = pressEvent.getSource().getBindingContext('ViewModel').getObject();

			this.parentView.getModel('ViewModel').setProperty('/ForwardTo', selectedListItem.UserId);

			this.onClosePersonSearchPopUp();
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onClosePersonSearchPopUp: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'PersonSearch', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		}
	});
});