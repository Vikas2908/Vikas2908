sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var helperProperties;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.MeasurementPoints', {

		init: function(parent, fragment, oParams) {
			this.parentView = parent;
			this.fragment = fragment;

			this.configureHelperProperties(oParams);
			var aItems = $.extend(true, [], (oParams.Items || []));

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				Items: aItems,
				SaveItems: [],
				CurrentIndex: 0,
				TotalCount: aItems.length,
				MeasurementPoint: {},
				IsManualMeasurement: false
			}), 'MeasurementPoints');

			this.initializeModelData();

			this.fragment.open();
		},

		configureHelperProperties: function(oParameters) {
			helperProperties = oParameters;
		},

		initializeModelData: function() {
			// var oModel = this.getModel();
			// var aItems = oModel.getProperty('/Items') || [];
			var currentIndex = 0;
			if (helperProperties.CurrentIndex) {
				currentIndex = helperProperties.CurrentIndex;
			}
			// aItems.some(function(oItem, nIndex) {
			// 	if (this.itemNotSavedYet(oItem)) {
			// 		currentIndex = nIndex;
			// 		return true;
			// 	}
			// 	return false;
			// }.bind(this));
			this.setMeasurementPointToModel(currentIndex);
		},

		itemNotSavedYet: function(oMeasurementPoint) {
			if (!oMeasurementPoint.OdrCheckPoint && Number(oMeasurementPoint.LastValue)) {
				return false;
			} else if (oMeasurementPoint.OdrCheckPoint && !!oMeasurementPoint.LastValue) {
				return false;
			}
			return true;
		},

		setMeasurementPointToModel: function(nIndex) {
			var oModel = this.getModel();
			var aItems = oModel.getProperty('/Items') || [];
			var oMeasurementPoint = aItems[nIndex];
			oModel.setProperty('/CurrentIndex', nIndex);
			oModel.setProperty('/MeasurementPoint', oMeasurementPoint);
			oModel.setProperty('/IsManualMeasurement', !oMeasurementPoint.OdrCheckPoint);
		},

		/**
		 * Public functions
		 */

		getIsManualMeasurement: function() {
			var oModel = this.getModel();
			return oModel.getProperty('/IsManualMeasurement');
		},

		formatValueState: function(recordedValue, minValueExists, maxValueExists, minValue, maxValue) {
			var valueState = sap.ui.core.ValueState.None;
			maxValue = maxValue ? maxValue.replace(' ', '').replace(',', '.') : '';
			minValue = minValue ? minValue.replace(' ', '').replace(',', '.') : '';
			if ((!minValueExists && !maxValueExists) || (!minValue && !maxValue) || !recordedValue) {
				valueState = sap.ui.core.ValueState.None;
			} else if ((parseFloat(recordedValue) < parseFloat(minValue) || parseFloat(recordedValue) > parseFloat(maxValue))) {
				valueState = sap.ui.core.ValueState.Warning;
			}

			return valueState;
		},

		formatValueStateText: function(recordedValue, minValueExists, maxValueExists, minValue, maxValue) {
			var valueStateText = null;
			maxValue = maxValue ? maxValue.replace(' ', '').replace(',', '.') : '';
			minValue = minValue ? minValue.replace(' ', '').replace(',', '.') : '';
			if ((!minValueExists && !maxValueExists) || (!minValue && !maxValue)) {
				valueStateText = null;
			} else if ((parseFloat(recordedValue) < parseFloat(minValue) || parseFloat(recordedValue) > parseFloat(maxValue))) {
				if (minValueExists && maxValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_NOT_BETWEEN_MIN_AND_MAX_VALUE', [minValue.replace('.', ','), maxValue.replace('.', ',')]);
				} else if (minValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_SMALLER_THAN_MIN_VALUE', [minValue.replace('.', ',')]);
				} else if (maxValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_LARGER_THAN_MIN_VALUE', [maxValue.replace('.', ',')]);
				}
			}

			return valueStateText;
		},

		onRecordedValueChange: function(oEvent) {
			var oModel = this.getModel();
			var obj = oModel.getProperty('/MeasurementPoint') || {};
			var recordedValue = oEvent.getParameter('value');

			oModel.setProperty('/MeasurementPoint/RecordedValue', recordedValue ? parseFloat(recordedValue).toFixed(obj.Decimals) : '');
			oModel.setProperty('/MeasurementPoint/CreateMeasurementDoc', recordedValue ? 'X' : '');
		},

		onDeviationPress: function() {
			// If "IsManualMeasurement" take value from RecordedValue
			// Otherwise "hard coded" "Not OK" value
			if (!this.getIsManualMeasurement()) {
				this.setRecordedValue('NOK');
			}
			this.createSaveItem();
			// postObjectMeasurementReadings (not needed here? done in close?)
			// Navigate to notification creation (done in parent?)
			this.onClosePress(true);
		},

		onOkPress: function() {
			// If "IsManualMeasurement" take value from RecordedValue
			// Otherwise "hard coded" "OK" value
			if (!this.getIsManualMeasurement()) {
				this.setRecordedValue('OK');
			}
			this.createSaveItem();
			// Navigate to next item / close dialog
			if (this.shouldNavigateToNextItem()) {
				this.setMeasurementPointToModel(this.getNextIndex());
			} else {
				this.onClosePress();
			}
		},

		onCancelPress: function() {
			this.onClosePress(false, true);
		},

		onClosePress: function(bIsDeviation, bCancel) {
			if (helperProperties.onClose) {
				var nIndex = this.getModel().getProperty('/CurrentIndex') || 0;
				helperProperties.onClose({
					bIsDeviation: bIsDeviation || false,
                    aItems: this.getModel().getProperty('/Items') || [],
					LeaveIndex: bCancel ? nIndex : nIndex + 1
				});
			}
			this.fragment.close();
		},

		/**
		 * Internal functions
		 */

		setRecordedValue: function(sValue) {
			var valueMap = {
				'OK': 'OK',
				'NOK': 'NOK'
			};
			var oModel = this.getModel();
			oModel.setProperty('/MeasurementPoint/OdrResultCode', valueMap[sValue]);
			oModel.setProperty('/MeasurementPoint/CreateMeasurementDoc', 'X');
		},

		shouldNavigateToNextItem: function() {
			return this.getNextIndex() !== -1;
		},

		getNextIndex: function() {
			var oModel = this.getModel();
			var nIndex = oModel.getProperty('/CurrentIndex') + 1;
			var nTotal = oModel.getProperty('/TotalCount');
			return nIndex < nTotal ? nIndex : -1;
		},

		createSaveItem: function() {
			var oModel = this.getModel();
			var oItem = oModel.getProperty('/MeasurementPoint');
			oModel.setProperty('/SaveItems',
				oModel.getProperty('/SaveItems').concat([oItem])
			);
		},

		getModel: function() {
			return this.fragment.getModel('MeasurementPoints');
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'MeasurementPoints', element);
		}
	});
});