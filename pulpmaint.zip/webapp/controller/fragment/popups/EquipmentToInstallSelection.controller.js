sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.EquipmentToInstallSelection', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.open();
		},

		onEquipmentToInstallItemPress: function(selectEvent) {
			this.parentView.onEquipmentToInstallSelect(selectEvent);

			this.fragment.close();
		},

		onEquipmentInstallationSearchLiveChange: function(changeEvent) {
			var searchValue = changeEvent.getParameter('newValue');

			this.getElement('equipmentInstallationSelectionList')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('Equnr', [searchValue], 'Contains')
						.concat(
							this.generateFilter('EqunrDescr', [searchValue], 'Contains')
						)
					)
				]);
		},

		onEquipmentToInstallCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'EquipmentToInstallSelection', element);
		},

		onAfterEquipmentToInstallSelectionClose: function() {
			this.getElement('equipmentInstallationSelectionSearchField').setValue('');
		}
	});
});