sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var dialogParameters;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.ImageEditor', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;
			dialogParameters = parameters;
			var colors = [{
					key: '#FF0000',
					color: this.parentView.getResourceBundleText('IMAGE_EDITOR_RED')
				},
				{
					key: '#00FF00',
					color: this.parentView.getResourceBundleText('IMAGE_EDITOR_GREEN')
				},
				{
					key: '#0000FF',
					color: this.parentView.getResourceBundleText('IMAGE_EDITOR_BLUE')
				}
			];

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				type: dialogParameters.type || '',
				Colors: colors,
				SelectedColor: '#FF0000',
				Border: 3,
				LineWidth: 3,
				Canvas: '',
				Ctx: '',
				Flag: false,
				DotFlag: false,
				PrevX: 0,
				CurrX: 0,
				PrevY: 0,
				CurrY: 0,
				Img: null,
				History: [],
				Attachments: dialogParameters.Attachments || [],
				EditExisting: ''
			}), 'DialogModel');

			this.fragment.open();
			window.setTimeout(this.setEventListeners.bind(this), 0);
		},

		setEventListeners: function() {
			var model = this.fragment.getModel('DialogModel');
			var canvas = this.getElement('imageEditorCanvas').getDomRef();
			model.setProperty('/Canvas', canvas);
			var ctx = canvas.getContext('2d');
			model.setProperty('/Ctx', ctx);

			this.setCanvasSize({
				width: this.getCanvasFullWidth(canvas),
				height: this.getCanvasFullHeight(canvas)
			});

			canvas.addEventListener('mousemove', function(e) {
				this.findxy.call(this, 'move', e);
			}.bind(this), false);
			canvas.addEventListener('mousedown', function(e) {
				this.findxy.call(this, 'down', e);
			}.bind(this), false);
			canvas.addEventListener('mouseup', function(e) {
				this.findxy.call(this, 'up', e);
			}.bind(this), false);
			canvas.addEventListener('mouseout', function(e) {
				this.findxy.call(this, 'out', e);
			}.bind(this), false);
			canvas.addEventListener('touchmove', function(e) {
				var touch = e.touches[0];
				var mouseEvent = new MouseEvent('mousemove', {
					clientX: touch.clientX,
					clientY: touch.clientY
				});
				this.findxy.call(this, 'touch', mouseEvent);
			}.bind(this));
			canvas.addEventListener('touchstart', function(e) {
				var touch = e.touches[0];
				var mouseEvent = new MouseEvent('mousedown', {
					clientX: touch.clientX,
					clientY: touch.clientY
				});
				this.findxy.call(this, 'down', mouseEvent);
			}.bind(this));
			canvas.addEventListener('touchend', function(e) {
				var touch = e.changedTouches[0];
				var mouseEvent = new MouseEvent('mouseup', {
					clientX: touch.clientX,
					clientY: touch.clientY
				});
				this.findxy.call(this, 'up', mouseEvent);
			}.bind(this));
			this.onClear();
		},

		findxy: function(res, e, skipPrevent) {
			if (!skipPrevent) {
				e.preventDefault();
				e.stopPropagation();
			}
			var model = this.fragment.getModel('DialogModel');
			// Set actions to memory
			model.setProperty('/History',
				(model.getProperty('/History') || []).concat({
					res: res,
					e: $.extend(true, {}, e)
				})
			);
			var modelData = model.getData();
			if (res === 'down' || res === 'touch' || res === 'move' && modelData.Flag) {
				model.setProperty('/PrevX', modelData.CurrX);
				model.setProperty('/PrevY', modelData.CurrY);
				model.setProperty('/CurrX', e.clientX - (modelData.Canvas.getBoundingClientRect().left + modelData.Border));
				model.setProperty('/CurrY', e.clientY - (modelData.Canvas.getBoundingClientRect().top + modelData.Border));
			}

			if (res === 'down') {
				var dotFlag = true;
				model.setProperty('/Flag', true);
				model.setProperty('/DotFlag', dotFlag);
				if (dotFlag) {
					this.drawDot();
				}
			}
			if (res === 'up' || res === 'out') {
				model.setProperty('/Flag', false);
			}
			if (res === 'touch' || res === 'move' && modelData.Flag) {
				this.draw();
			}
		},

		drawDot: function() {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();

			modelData.Ctx.beginPath();
			modelData.Ctx.fillStyle = modelData.SelectedColor || '#FF0000';
			modelData.Ctx.fillRect(modelData.CurrX, modelData.CurrY, modelData.LineWidth, modelData.LineWidth);
			modelData.Ctx.closePath();
			model.setProperty('/DotFlag', false);
		},

		draw: function() {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();

			modelData.Ctx.beginPath();
			modelData.Ctx.moveTo(modelData.PrevX, modelData.PrevY);
			modelData.Ctx.lineTo(modelData.CurrX, modelData.CurrY);
			modelData.Ctx.strokeStyle = modelData.SelectedColor || '#FF0000';
			modelData.Ctx.lineWidth = modelData.LineWidth || 2;
			modelData.Ctx.stroke();
			modelData.Ctx.closePath();
		},

		onClear: function(scaleUp) {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();
			model.setProperty('/History', []);

			if (scaleUp) {
				modelData.Ctx.clearRect(0, 0, modelData.Canvas.width, modelData.Canvas.height);
				if (modelData.Img) {
					modelData.Ctx.drawImage(modelData.Img, 0, 0, modelData.Canvas.width, modelData.Canvas.height);
				}
			} else if (modelData.Img) {
				var imageSize = this.getImageSize();
				this.setCanvasSize(imageSize);
				modelData.Ctx.clearRect(0, 0, modelData.Canvas.width, modelData.Canvas.height);
				modelData.Ctx.drawImage(modelData.Img, 0, 0, imageSize.width, imageSize.height);
			} else {
				this.setCanvasSize({
					width: this.getCanvasFullWidth(modelData.Canvas),
					height: this.getCanvasFullHeight(modelData.Canvas)
				});
				modelData.Ctx.clearRect(0, 0, modelData.Canvas.width, modelData.Canvas.height);
			}
		},

		getImageSize: function() {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();
			var imgX = 0;
			var imgY = 0;

			if (modelData.Img) {
				var aspectRatio = modelData.Img.width / modelData.Img.height;
				var canvasAreaAspectRatio = this.getCanvasFullWidth(modelData.Canvas) / this.getCanvasFullHeight(modelData.Canvas);
				if (canvasAreaAspectRatio > aspectRatio) {
					// aspectRatio is smaller than canvasAreAspectRatio
					// so image is higher in comparision to width
					// --> limit images width
					imgY = this.getCanvasFullHeight(modelData.Canvas);
					imgX = imgY * aspectRatio;
				} else {
					// aspectRatio is higher than cancasAreaAspectRatio
					// so image is wider in comparision to height
					// --> limit images height
					imgX = this.getCanvasFullWidth(modelData.Canvas);
					imgY = imgX / aspectRatio;
				}
			}

			return {
				width: imgX,
				height: imgY
			};
		},

		scaleUp: function() {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();
			var modelDataCopy = $.extend(true, {}, modelData);

			var canvasWidth = modelData.Canvas.width;
			var originalImageWidth;
			if (modelData.Img && modelData.Img.width) {
				originalImageWidth = modelData.Img.width;
			} else {
				originalImageWidth = modelData.Canvas.width;
			}
			var scale = originalImageWidth / canvasWidth;

			this.setCanvasSize({
				width: modelData.Canvas.width * scale,
				height: modelData.Canvas.height * scale
			});
			this.onClear(true);
			modelData.Ctx.scale(scale, scale);

			modelDataCopy.History.map(function(event) {
				this.findxy.call(this, event.res, event.e, true);
			}.bind(this));
		},

		getCanvasFullWidth: function() {
			return window.innerWidth - 25;
		},

		getCanvasFullHeight: function(canvas) {
			return window.innerHeight - (canvas.getBoundingClientRect().top + 75);
		},

		setCanvasSize: function(oParams) {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();

			modelData.Canvas.width = oParams.width || 500;
			modelData.Canvas.height = oParams.height || 500;

			modelData.Canvas.style.border = modelData.Border + 'px solid #bcb';
		},

		onImageEditorClose: function() {
			this.fragment.close();
		},

		onImageEditorSave: function() {
			this.scaleUp();
			var image = this.createImage();
			this.parentView.handleDrawSuccess(image.src);

			var existing = this.fragment.getModel('DialogModel').getProperty('/EditExisting') || '';
			if (existing) {
				this.parentView.handleDeleteExisting(existing);
			}

			this.onImageEditorClose();
		},

		onSelectAttachmentPress: function() {
			this.parentView.openDialog('AttachmentSelect', {
				Attachments: this.fragment.getModel('DialogModel').getProperty('/Attachments'),
				itemSelectFunction: this.onAttachmentItemPress.bind(this)
			});
		},

		onActionsItemPress: function(oEvent) {
			var oItem = oEvent.getParameter('item');
			var id = oItem.getId();
			if (id.indexOf('take-photo') !== -1) {
				this.onAddPictureAttachment();
			} else if (id.indexOf('select-photo') !== -1) {
				this.onGetPictureFromFileSystem();
			} else if (id.indexOf('edit-existing')) {
				this.onSelectAttachmentPress();
			}
		},

		onAttachmentItemPress: function(attachment) {
			if (attachment) {
				this.fragment.getModel('DialogModel').setProperty('/EditExisting', attachment.DocId);
				if (attachment.Url && attachment.Url.startsWith('data:image')) {
					var img = new Image();
					img.src = attachment.Url;
					this.fragment.getModel('DialogModel').setProperty('/Img', img);
					window.setTimeout(function() {
						this.onClear();
					}.bind(this), 0);
				} else {
					this.getFileWithUrl(this.parentView.formatterUtil.formatAttachmentUrl.call(this.parentView, attachment.DocId, attachment.Url));
				}
			}
		},

		onImageLoad: function(oEvent) {
			var model = this.fragment.getModel('DialogModel');

			var file = oEvent.getParameter('files')[0];
			var reader = new FileReader();

			reader.onloadend = function() {
				var img = new Image();
				img.onload = function() {
					model.setProperty('/Img', img);
					this.onClear();
				}.bind(this);
				img.src = reader.result;
			}.bind(this);

			if (file) {
				reader.readAsDataURL(file);
			}
		},

		onAddPictureAttachment: function() {
			this.parentView.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
			navigator.camera.getPicture(
				this.handleCameraSuccess.bind(this),
				this.handleCameraError.bind(this), {
					quality: 25,
					correctOrientation: true
				}
			);
		},

		handleCameraSuccess: function(fileUri) {
			this.getFileWithUrl(fileUri);
		},

		handleCameraError: function() {

		},

		onGetPictureFromFileSystem: function() {
			var options = {
				selectMode: 100,
				maxSelectCount: 1
			};
			this.parentView.getGlobalModel().setProperty('/IsResumingFromPlugin', true);
			window.MediaPicker.getMedias(
				options,
				this.handleGetPictureFromFileSystemSuccess.bind(this),
				this.handleGetPictureFromFileSystemError.bind(this), {
					quality: 15
				}
			);
		},

		handleGetPictureFromFileSystemSuccess: function(fileUris) {
			var fileUri = fileUris[0];
			this.getFileWithUrl(fileUri.path);
		},

		handleGetPictureFromFileSystemError: function() {

		},

		getFileWithUrl: function(fileUri) {
			var request = new XMLHttpRequest();
			request.open('GET', fileUri, true);
			request.responseType = 'blob';
			request.onload = function() {
				var model = this.fragment.getModel('DialogModel');
				var reader = new FileReader();
				reader.onloadend = function() {
					var img = new Image();
					img.onload = function() {
						model.setProperty('/Img', img);
						this.onClear();
					}.bind(this);
					img.src = reader.result;
				}.bind(this);
				reader.readAsDataURL(request.response);
			}.bind(this);
			request.send();
		},

		createImage: function() {
			var model = this.fragment.getModel('DialogModel');
			var modelData = model.getData();

			var image = new Image();
			image.src = modelData.Canvas.toDataURL('image/jpeg');
			return image;
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'ImageEditor', element);
		}
	});
});