sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.MeasurementPointDialog', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.bindDialogToModel(parameters);

			this.preparePreventiveMaintenanceValues(parameters.ModelName);

			this.fragment.open();
		},

		bindDialogToModel: function(parameters) {
			var dialogListElement = this.getElement('measurementPointsTable');
			var dialogListItemElement = this.getElement('measurementPointItem');

			var itemFilters = [];

			if (parameters.FunctionalLocation) {
				itemFilters = itemFilters.concat(this.generateFilter('FunclocInternalId', [parameters.FunctionalLocation]));
			}
			if (parameters.Equipment) {
				itemFilters = itemFilters.concat(this.generateFilter('Equipment', [parameters.Equipment]));
			}

			this.bindInputField(parameters.ModelName);

			this.getElement('measurementPointDescription')
				.bindText(parameters.ModelName + '>Description');

			this.getElement('measurementPointUnit')
				.bindText(parameters.ModelName + '>Unit');

			dialogListElement.bindItems({
				path: parameters.ModelName + '>/Measurements',
				template: dialogListItemElement
			});

			if (parameters.ModelName !== 'EditRouteModel') {
				dialogListElement
					.getBinding('items')
					.filter([
						new sap.ui.model.Filter(itemFilters)
					]);
			}

			this.getElement('measurementDialogCloseButton').setVisible(parameters.ModelName === 'EditRouteModel');
		},

		bindInputField: function(modelName) {
			var inputField = this.getElement('measurementPointInputField');

			inputField.bindProperty('value', modelName + '>RecordedValue');

			inputField.bindProperty('valueState', {
				parts: [{
						path: modelName + '>RecordedValue'
					},
					{
						path: modelName + '>MinValueExists'
					},
					{
						path: modelName + '>MaxValueExists'
					},
					{
						path: modelName + '>MinValue'
					},
					{
						path: modelName + '>MaxValue'
					}
				],
				formatter: this.formatValueState.bind(this)
			});

			inputField.bindProperty('valueStateText', {
				parts: [{
						path: modelName + '>RecordedValue'
					},
					{
						path: modelName + '>MinValueExists'
					},
					{
						path: modelName + '>MaxValueExists'
					},
					{
						path: modelName + '>MinValue'
					},
					{
						path: modelName + '>MaxValue'
					}
				],
				formatter: this.formatValueStateText.bind(this)
			});
		},

		preparePreventiveMaintenanceValues: function(modelName) {
			var measurements = this.parentView.getModel(modelName).getProperty('/Measurements');

			var preparedMeasurements = $.map(measurements, function(value) {
				// Add Max length
				// Remove empty spaces and commas from min and max values
				value.MaxValue = value.MaxValue.replace(' ', '').replace(',', '.');
				value.MinValue = value.MinValue.replace(' ', '').replace(',', '.');
				return value;
			});

			this.parentView.getModel(modelName).setProperty('/Measurements', preparedMeasurements);
		},

		formatValueState: function(recordedValue, minValueExists, maxValueExists, minValue, maxValue) {
			var valueState = sap.ui.core.ValueState.None;
			maxValue = maxValue ? maxValue.replace(' ', '').replace(',', '.') : '';
			minValue = minValue ? minValue.replace(' ', '').replace(',', '.') : '';
			if ((!minValueExists && !maxValueExists) || (!minValue && !maxValue) || !recordedValue) {
				valueState = sap.ui.core.ValueState.None;
			} else if ((parseFloat(recordedValue) < parseFloat(minValue) || parseFloat(recordedValue) > parseFloat(maxValue))) {
				valueState = sap.ui.core.ValueState.Warning;
			}

			return valueState;
		},

		formatValueStateText: function(recordedValue, minValueExists, maxValueExists, minValue, maxValue) {
			var valueStateText = null;
			maxValue = maxValue ? maxValue.replace(' ', '').replace(',', '.') : '';
			minValue = minValue ? minValue.replace(' ', '').replace(',', '.') : '';
			if ((!minValueExists && !maxValueExists) || (!minValue && !maxValue)) {
				valueStateText = null;
			} else if ((parseFloat(recordedValue) < parseFloat(minValue) || parseFloat(recordedValue) > parseFloat(maxValue))) {
				if (minValueExists && maxValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_NOT_BETWEEN_MIN_AND_MAX_VALUE', [minValue.replace('.', ','), maxValue.replace('.', ',')]);
				} else if (minValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_SMALLER_THAN_MIN_VALUE', [minValue.replace('.', ',')]);
				} else if (maxValueExists) {
					valueStateText = this.getResourceBundleText.call(this.parentView, 'MEASUREMENT_VALUE_LARGER_THAN_MIN_VALUE', [maxValue.replace('.', ',')]);
				}
			}

			return valueStateText;
		},

		onRecordedValueChange: function(oEvent) {
			var modelName = 'EditRouteModel';
			if (oEvent.getSource().getBindingContext('NewOrderModel')) {
				modelName = 'NewOrderModel';
			} else if (oEvent.getSource().getBindingContext('ObjectInfoModel')) {
				modelName = 'ObjectInfoModel';
			}
			var obj = oEvent.getSource().getBindingContext(modelName).getObject();
			var path = oEvent.getSource().getBindingContext(modelName).getPath();
			var recordedValue = oEvent.getParameter('value');

			this.parentView.getModel(modelName).setProperty(path + '/RecordedValue', recordedValue ? parseFloat(recordedValue).toFixed(obj.Decimals) : '');
			this.parentView.getModel(modelName).setProperty(path + '/CreateMeasurementDoc', recordedValue ? 'X' : '');
		},

		onOkButtonPress: function() {
			this.parentView.postRoute && this.parentView.postRoute.call(this.parentView);

			this.parentView.postObjectMeasurementReadings && this.parentView.postObjectMeasurementReadings.call(this.parentView);

			this.fragment.close();
		},

		onCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'MeasurementPointDialog', element);
		}
	});
});