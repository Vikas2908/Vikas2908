sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.MaterialSearch', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/Material', '');
			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/MaterialDescr', '');
			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/Manufacturer', '');
			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/SerialNumber', '');
			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/BasicText', '');
			this.getNavContainer().backToTop();

			this.fragment.open();

			if (parameters && parameters.Material) {
				this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/Material', parameters.Material);

				this.getMaterialsFromSap();
			}
		},

		onMaterialSearch: function() {
			this.getMaterialsFromSap();
		},

		getMaterialsFromSap: function() {
			var busyPath = '/IsSearchingForMaterials';
			var material = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/Material');
			var description = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/MaterialDescr');
			var manufacturer = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/Manufacturer');
			var serialNumber = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/SerialNumber');
			var basicText = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/BasicText');
			var filterOperator = 'EQ';

			var parameters = {
				online: true,
				filters: this.generateFilter('Material', [material], filterOperator)
					.concat(this.generateFilter('MaterialDescr', [description], filterOperator), this.generateFilter('Manufacturer', [manufacturer], filterOperator))
					.concat(this.generateFilter('SerialNumber', [serialNumber], filterOperator), this.generateFilter('BasicText', [basicText], filterOperator))
			};

			this.parentView.setPathBusy(busyPath);

			this.parentView.oDataUtil.read('MaterialsSet', parameters)
				.done(this.handleGetMaterialsSuccess.bind(this))
				.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
				.always(this.parentView.setPathNotBusy.bind(this.parentView, busyPath));
		},

		handleGetMaterialsSuccess: function(materials) {
			this.parentView.getModel('ViewModel').setProperty('/Materials', materials);

			this.getNavContainer().to(this.getElement('materialSearchListPage'));
		},

		onMaterialSearchItemPress: function(pressEvent) {
			var selectedListItem = pressEvent.getSource().getBindingContext('ViewModel').getObject();

			this.parentView.handleMaterialValid(null, selectedListItem);

			this.onCloseMaterialSearchPopUp();
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onCloseMaterialSearchPopUp: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'MaterialSearch', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		}
	});
});