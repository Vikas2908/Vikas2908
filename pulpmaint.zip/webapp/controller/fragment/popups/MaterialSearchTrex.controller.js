sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.MaterialSearchTrex', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.parentView.getModel('ViewModel').setProperty('/MaterialSearchParams/TextSearch', '');
			this.getNavContainer().backToTop();

			this.fragment.open();
		},

		onMaterialSearch: function() {
			this.getMaterialsFromTrex();
		},

		getMaterialsFromTrex: function() {
			var searchText = this.parentView.getModel('ViewModel').getProperty('/MaterialSearchParams/TextSearch');

			var parameters = {
				online: true,
				filters: this.generateFilter('SearchTerm', [searchText])
			};

			this.parentView.setAppBusyMode();

			this.parentView.oDataUtil.read('MaterialsSet', parameters)
				.done(this.handleGetMaterialsSuccess.bind(this))
				.fail(this.parentView.openErrorMessagePopup.bind(this.parentView))
				.always(this.parentView.setAppNotBusyMode);
		},

		handleGetMaterialsSuccess: function(materials) {
			this.parentView.getModel('ViewModel').setProperty('/Materials', materials);

			this.getNavContainer().to(this.getElement('materialSearchListPage'));
		},

		onMaterialSearchItemPress: function(pressEvent) {
			var selectedListItem = pressEvent.getSource().getBindingContext('ViewModel').getObject();

			this.parentView.validateMaterial(selectedListItem.Material);

			this.onCloseMaterialSearchPopUp();
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onCloseMaterialSearchPopUp: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'MaterialSearchTrex', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		}
	});
});