sap.ui.define([
	'com/upm/maint/controller/fragment/popups/SearchDialog.controller',
	'sap/ui/core/format/DateFormat'
], function(SearchDialog, DateFormat) {
	return SearchDialog.extend('com.upm.maint.controller.fragment.popups.RevisionDialog', {
		formatDate: function(dateTime, customFormat) {
			var formattedDateTime = '';
			if (dateTime) {
				var dateFormat = DateFormat.getDateTimeInstance({
					pattern: customFormat || 'dd.MM.yyyy'
				});
				formattedDateTime = dateFormat.format(dateTime);
			}

			return formattedDateTime;
		},

		bindFields: function() {
			var oDialogListElement = this.getElement('searchDialogList');
			var oDialogListItemElement = this.getElement('searchDialogListItem');
			var sorter = [new sap.ui.model.Sorter(this.extendHelperDialogproperties.listItemValueKey)];
			this.extendHelperDialogproperties.multiSelect ?
				this.handleMultiSelect() :
				this.handleSingleSelect();
			var firstObjectIdentifier = this.getElement('searchDialogListValue');
			firstObjectIdentifier.bindProperty('title', {
				path: this.extendHelperDialogproperties.configurationModelName + '>' + this.extendHelperDialogproperties.listItemValueKey
			});
			firstObjectIdentifier.bindProperty('text', {
				path: this.extendHelperDialogproperties.configurationModelName + '>' + this.extendHelperDialogproperties.firstAdditionalInfo,
				formatter: this.formatDate
			});
			var secondObjectIdentifier = this.getElement('searchDialogListDescription');
			secondObjectIdentifier.bindProperty('title', {
				path: this.extendHelperDialogproperties.configurationModelName + '>' + this.extendHelperDialogproperties.listItemDescriptionKey
			});
			secondObjectIdentifier.bindProperty('text', {
				path: this.extendHelperDialogproperties.configurationModelName + '>' + this.extendHelperDialogproperties.secondAdditionalInfo,
				formatter: this.formatDate
			});
			oDialogListElement.bindItems({
				path: this.extendHelperDialogproperties.configurationModelName + '>' + this.extendHelperDialogproperties.pathToModel,
				template: oDialogListItemElement,
				sorter: sorter
			});
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'RevisionDialog', element);
		}
	});
});