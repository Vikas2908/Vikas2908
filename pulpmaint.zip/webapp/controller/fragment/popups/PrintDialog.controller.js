sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var dialogParameters;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.PrintDialog', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;
			dialogParameters = parameters;

			var userPrinters = this.handleMultipleParameters(this.getUserParameters.call(this.parentView).Printers, 'Printer');

			var defaultPrinter = userPrinters.length === 1 ? userPrinters[0].Printer : '';
			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				PrinterValues: userPrinters,
				SelectedPrinter: defaultPrinter
			}), 'DialogModel');
			this.getPrinterDescriptions(userPrinters);

			this.fragment.open();
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		onPrintPress: function() {
			var printer = this.fragment.getModel('DialogModel').getProperty('/SelectedPrinter');
			var order = dialogParameters.Orderid;
			var importData = {
				'Printer': printer,
				'Orderid': order
			};

			this.setAppBusyMode();
			this.oDataUtil.functionImport('WorkOrderPrint', importData)
				.done(this.handlePrintSuccess.bind(this, printer, order))
				.fail(this.openErrorMessagePopup.bind(this.parentView))
				.always(this.setAppNotBusyMode);
		},

		handlePrintSuccess: function(printer, order) {
			this.onDialogCloseButtonPress();
			this.showMessageBox({
				type: 'Success',
				title: this.getResourceBundleText.call(this.parentView, 'SUCCESS_DIALOG_TITLE'),
				message: this.getResourceBundleText.call(this.parentView, 'PRINT_SUCCESS_TEXT', [order, printer]),
				actions: [sap.m.MessageBox.Action.OK]
			});
		},

		getPrinterDescriptions: function(userPrinters) {
			var readMethods = userPrinters.map(function(printer) {
				var pinterId = printer.Printer;
				var parameters = {
					online: true
				};
				return this.oDataUtil.read('PrinterSet(\'' + pinterId + '\')', parameters);
			}.bind(this.parentView));
			$.when.apply($, readMethods)
				.done(this.handleGetPrintersSuccess.bind(this));
		},

		handleGetPrintersSuccess: function() {
			var printers = [];
			$.map(arguments, function(printer) {
				if (printer && printer.PrinterId) {
					printers.push({
						Printer: printer.PrinterId,
						PrinterDescription: printer.Location
					});
				}
			});
			this.fragment.getModel('DialogModel').setProperty('/PrinterValues', printers);
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'PrintDialog', element);
		}
	});
});