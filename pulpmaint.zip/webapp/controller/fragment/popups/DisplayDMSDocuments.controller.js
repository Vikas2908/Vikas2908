sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.DisplayDMSDocuments', {

		init: function(parent, fragment, parameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.fragment.setModel(new sap.ui.model.json.JSONModel({
				IsBusy: false,
				DMSDocuments: [],
				DMSFiles: []
			}), 'DialogModel');

			this.getDocuments(parameters.TechnicalObject, parameters.Type, parameters.ObjectId, parameters.ObjectType, parameters.Operations);

			this.fragment.open();
		},

		onNavigateBack: function() {
			this.getNavContainer().back();
		},

		onDMSDocumentPress: function(pressEvent) {
			var selectedListItem = pressEvent.getSource().getBindingContext('DialogModel').getObject();
			var files = selectedListItem && selectedListItem.Files ? selectedListItem.Files.results : [];

			this.fragment.getModel('DialogModel').setProperty('/DMSFiles', files);
			this.getNavContainer().to(this.getElement('DMSFilesPages'));
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		onAfterDialogClose: function() {
			this.getNavContainer().backToTop();
		},

		getDocuments: function(technicalObject, type, objectId, objectType, operations) {
			var readMethods = [];
			var technicalObjectreadParameters = {
				filters: this.generateFilter('SapObjectId', [technicalObject])
					.concat(this.generateFilter('SapObjectType', [type])),
				online: true,
				urlParameters: {
					'$expand': 'Files'
				}
			};
			var objectReadParameters = {
				filters: this.generateFilter('SapObjectId', [objectId])
					.concat(this.generateFilter('SapObjectType', [objectType])),
				online: true,
				urlParameters: {
					'$expand': 'Files'
				}
			};

			readMethods.push(this.oDataUtil.read('DmsDocumentSet', technicalObjectreadParameters));

			if (objectId && objectType) {
				readMethods.push(this.oDataUtil.read('DmsDocumentSet', objectReadParameters));
			}

			if (operations) {
				operations.forEach(function(operation) {
					var operationReadParameters = {
						filters: this.generateFilter('SapObjectId', [operation])
							.concat(this.generateFilter('SapObjectType', ['PMAFVC'])),
						online: true,
						urlParameters: {
							'$expand': 'Files'
						}
					};
					readMethods.push(this.oDataUtil.read('DmsDocumentSet', operationReadParameters));
				}.bind(this));
			}

			this.fragment.getModel('DialogModel').setProperty('/IsBusy', true);

			$.when.apply($, readMethods)
				.done(this.handleGetDocumentsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this.parentView))
				.always(this.setDialogNotBusy.bind(this));
		},

		handleGetDocumentsSuccess: function() {
			var dmsDocuments = [];
			$.map(arguments, function(documents) {
				if (Array.isArray(documents)) {
					dmsDocuments = dmsDocuments.concat(documents);
				}
			});
			this.fragment.getModel('DialogModel').setProperty('/DMSDocuments', dmsDocuments);
		},

		setDialogNotBusy: function() {
			this.fragment.getModel('DialogModel').setProperty('/IsBusy', false);
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'DisplayDMSDocuments', element);
		},

		getNavContainer: function() {
			return this.getElement('navContainer');
		}
	});
});