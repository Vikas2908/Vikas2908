sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	return CommonController.extend('com.upm.maint.controller.fragment.popups.CancelNotification', {

		init: function(parent, fragment) {
			this.parentView = parent;
			this.fragment = fragment;

			this.getElement('cancellationReasonInput').rerender();

			this.fragment.open();
		},

		onCancelNotificationPress: function() {
			this.fragment.close();
			this.parentView.cancelNotification();
		},

		onDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'CancelNotification', element);
		}
	});
});