sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var helperDialogProperties;

	return CommonController.extend('com.upm.maint.controller.fragment.popups.SearchDialog', {

		/* =========================================================== */
		/* Search dialog API	 									   */
		/* =========================================================== */

		/**
		 * Combines setting up search dialog and API request for helper values
		 * @param {string} pathToModel - path to the model
		 * @param {string} saveModelName - model where selected values should be saved
		 * @param {string} listItemValueKey - key of the JSON item object value/id
		 * @param {string} listItemDescriptionKey - key of the JSON item object description
		 * @param {string} firstValueToSave - path where value/id key value should be saved
		 * @param {string=} secondValueToSave - path where description key value should be saved
		 * @param {string=} configurationModelName - name of the configuration model that stores dialog configurations, default value is ViewModel
		 * @param {string=} service - part of the uri, before path to service
		 * @param {string=} pathToService - path to the service
		 * @param {array=} filters - filters for service call
		 * @param {string=} dialogTitle - title of the dialog, default is 'Select value'
		 * @param {boolean=} getValuesAfterEverySearch - determines if call is made to back end after every search. This is handy for large data sets only. Default is false
		 * @param {boolean=} multiSelect - determines if dialog allows multiselection. Default is false
		 */

		init: function(parent, fragment, oParameters) {
			this.parentView = parent;
			this.fragment = fragment;

			this.configureObjectForHelperDialog(oParameters);
			this.getHelperDialogValues(oParameters)
				.done([
					this.changeSearchDialogTitle.bind(this, oParameters.dialogTitle),
					this.bindSearchDialogToModel.bind(this)
				])
				.done(this.openSearchDialog.bind(this));

			if (oParameters.multiSelect) {
				// update state of the select all button
				this.onSearchDialogSelectionChange();
			}
		},

		configureObjectForHelperDialog: function(oParameters) {
			if (!oParameters.configurationModelName) {
				oParameters.configurationModelName = 'ViewModel';
			}
			helperDialogProperties = oParameters;
			this.extendHelperDialogproperties = oParameters;
		},

		getHelperDialogValues: function(oParameters) {
			var deferred = $.Deferred();

			var readParameters = {
				filters: oParameters.filters || []
			};

			if (!oParameters.service || !oParameters.pathToService || oParameters.getValuesAfterEverySearch) {
				deferred.resolve();
			} else {
				this.setAppBusyMode();
				this.oDataUtil.read(oParameters.pathToService, readParameters)
					.done([this.handleHelperDialogValuesSuccess.bind(this), deferred.resolve])
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setAppNotBusyMode);
			}
			return deferred.promise();
		},

		handleHelperDialogValuesSuccess: function(helperDialogData) {
			var oConfigurationModel = this.parentView.getModel(helperDialogProperties.configurationModelName);
			oConfigurationModel.setProperty(helperDialogProperties.pathToModel, helperDialogData);
		},


		openSearchDialog: function() {
			this.fragment.open();
		},

		changeSearchDialogTitle: function(title) {
			this.getElement('searchDialogTitle')
				.setTitle(title || this.getResourceBundleText.call(this.parentView, 'SEARCH_DIALOG_DEFAULT_TITLE'));
		},

		bindSearchDialogToModel: function() {
			this.bindEventHandlers();
			this.bindFields();
		},

		bindFields: function() {
			var oDialogListElement = this.getElement('searchDialogList');
			var oDialogListItemElement = this.getElement('searchDialogListItem');
			helperDialogProperties.multiSelect ?
				this.handleMultiSelect() :
				this.handleSingleSelect();
			this.getElement('searchDialogListValue')
				.bindText(helperDialogProperties.configurationModelName + '>' + helperDialogProperties.listItemValueKey);
			this.getElement('searchDialogListDescription')
				.bindText(helperDialogProperties.configurationModelName + '>' + helperDialogProperties.listItemDescriptionKey);
			this.getElement('searchDialogOptionalColumn').setVisible(!!helperDialogProperties.optionalValueKey);
			this.getElement('searchDialogOptionalColumnValue')
				.bindText(helperDialogProperties.configurationModelName + '>' + helperDialogProperties.optionalValueKey);
			oDialogListElement.bindItems({
				path: helperDialogProperties.configurationModelName + '>' + helperDialogProperties.pathToModel,
				template: oDialogListItemElement,
				sorter: new sap.ui.model.Sorter(helperDialogProperties.listItemValueKey)
			});

			if (!helperDialogProperties.pathToService && helperDialogProperties.filters) {
				oDialogListElement.getBinding('items').filter(helperDialogProperties.filters);
			}
		},

		handleMultiSelect: function() {
			var oDialogListElement = this.getElement('searchDialogList');
			var oDialogListItemElement = this.getElement('searchDialogListItem');
			oDialogListItemElement.bindProperty('selected', {
				parts: [{
					path: helperDialogProperties.configurationModelName + '>' + helperDialogProperties.listItemValueKey
				}, {
					path: helperDialogProperties.saveModelName + '>/' + helperDialogProperties.firstValueToSave
				}],
				formatter: function(idOfItem, selectedItems) {
					return this
						.formatterUtil
						.selectedStateFormatter(helperDialogProperties.listItemValueKey, idOfItem, selectedItems);
				}.bind(this)
			});
			oDialogListElement.setMode('MultiSelect');
			oDialogListElement.setIncludeItemInSelection(true);
			this.getElement('selectAllCheckBoxBar').setVisible(true);

			this.getElement('selectSelectionButton').setVisible(true);
		},

		handleSingleSelect: function() {
			var oDialogListElement = this.getElement('searchDialogList');
			oDialogListElement.setMode('None');
			oDialogListElement.setIncludeItemInSelection(false);
			this.getElement('selectAllCheckBoxBar').setVisible(false);
			this.getElement('selectSelectionButton').setVisible(false);
		},

		bindEventHandlers: function() {
			var listItem = this.getElement('searchDialogListItem');
			helperDialogProperties.getValuesAfterEverySearch ?
				this.handleValuesAfterEverySearch() :
				this.handleValuesAtStart();
			!helperDialogProperties.itemPressHandler || listItem.attachPress(helperDialogProperties.itemPressHandler);
		},

		handleValuesAfterEverySearch: function() {
			var oSearchBarElement = this.getElement('searchDialogSearchField');
			oSearchBarElement.attachSearch(this.onSearchDialogSearch, this);
			oSearchBarElement.detachLiveChange(this.onSearchDialogLiveChange, this);
		},

		handleValuesAtStart: function() {
			var oSearchBarElement = this.getElement('searchDialogSearchField');
			oSearchBarElement.detachSearch(this.onSearchDialogSearch, this);
			oSearchBarElement.attachLiveChange(this.onSearchDialogLiveChange, this);
		},

		onSearchDialogLiveChange: function() {
			this.applyFiltersToListBinding(
				helperDialogProperties.listItemValueKey,
				helperDialogProperties.listItemDescriptionKey
			);
		},

		onSearchDialogSearch: function() {
			var filterValue = this.getElement('searchDialogSearchField').getValue();
			var valueToFilter = /\d/.test(filterValue) ? helperDialogProperties.listItemValueKey : helperDialogProperties.listItemDescriptionKey;
			var filter = this.generateFilter(valueToFilter, [filterValue]);
			this.getSearchedValues(filter);
		},

		getSearchedValues: function(filter) {
			var parameters = {
				filters: filter
			};
			this.setAppBusyMode();
			this.oDataUtil.read(helperDialogProperties.service, helperDialogProperties.pathToService, parameters)
				.done(this.handleHelperDialogValuesSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		applyFiltersToListBinding: function(sValueToFilter, sSecondValueToFilter) {
			var oDialogListBinding = this.getElement('searchDialogList').getBinding('items');
			var oSearchBarElement = this.getElement('searchDialogSearchField');
			var sFilterValue = oSearchBarElement.getValue();
			var oFirstFilter = new sap.ui.model.Filter(sValueToFilter, sap.ui.model.FilterOperator.Contains, sFilterValue);
			var oSecondFilter = new sap.ui.model.Filter(sSecondValueToFilter, sap.ui.model.FilterOperator.Contains, sFilterValue);
			var oCombinedFilter = new sap.ui.model.Filter([oFirstFilter, oSecondFilter]);
			oDialogListBinding.filter([oCombinedFilter], 'Application');
		},

		onSearchDialogItemPress: function(oEvent) {
			var oSaveModel = this.parentView.getModel(helperDialogProperties.saveModelName);
			var selectedListItem = oEvent.getSource().getBindingContext(helperDialogProperties.configurationModelName).getObject();
			var selectedProperty = selectedListItem[helperDialogProperties.listItemValueKey];
			var selectedDescription = selectedListItem[helperDialogProperties.listItemDescriptionKey];
			oSaveModel.setProperty('/' + helperDialogProperties.firstValueToSave, selectedProperty);
			if (helperDialogProperties.secondValueToSave) {
				oSaveModel.setProperty('/' + helperDialogProperties.secondValueToSave, selectedDescription);
			}
			this.onSearchDialogCloseButtonPress();
		},

		onSelectSelectionPress: function() {
			var selectedItemContexts = this.getElement('searchDialogList').getSelectedContexts(true);
			var selectedItems = selectedItemContexts.reduce(function(items, itemContext) {
				return items.concat(itemContext.getObject());
			}, []);
			this.parentView.getModel(helperDialogProperties.saveModelName).setProperty('/' + helperDialogProperties.firstValueToSave, selectedItems);
			this.onSearchDialogCloseButtonPress();
		},

		onSelectAllPress: function(selectEvent) {
			var list = this.getElement('searchDialogList');

			if (selectEvent.getParameter('selected')) {
				list.selectAll();
			} else {
				list.removeSelections(true);
			}
		},

		onSearchDialogSelectionChange: function() {
			setTimeout(function() {
				var list = this.getElement('searchDialogList');

				var allItemsAreSelectedFromList = list.getItems().length && list.getItems().length === list.getSelectedItems().length;

				this.getElement('selectAllCheckBox').setSelected(!!allItemsAreSelectedFromList);
			}.bind(this), 0);
		},

		onSearchDialogCloseButtonPress: function() {
			this.fragment.close();
		},

		/**
		 * This event is fired when search dialog is closed. onSearchDialogCloseButtonPress function doesn't catch events
		 * where user exits without close button.
		 * Is used to reset state of dialog
		 */
		onAfterSearchDialogClose: function() {
			this.getElement('searchDialogSearchField').setValue('');

			!helperDialogProperties.itemPressHandler ||
				this.getElement('searchDialogListItem')
				.detachPress(helperDialogProperties.itemPressHandler);
		},

		getElement: function(element) {
			return this.getFragmentElementById.call(this.parentView, 'SearchDialog', element);
		}
	});
});