sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController',
	'sap/m/TablePersoController',
	'com/upm/maint/util/personalization/MaterialSearchDetailsPersonalization'
], function(CommonController, BaseController, TablePersoController, MaterialSearchDetailsPersonalization) {
	return CommonController.extend('com.upm.maint.controller.MaterialSearchDetails', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */
		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('MaterialDetailsModel');

			this.oTablePersoController = new TablePersoController({
				table: this.getView().byId('materialMovementsTable'),
				persoService: MaterialSearchDetailsPersonalization
			}).activate();
		},

		routeMatched: function(oEvent) {
			if (oEvent.getParameter('name') === 'MaterialSearchDetails') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				var urlParameters = this.getUrlParameters();
				if (urlParameters) {
					var materialNumber = urlParameters.materialNumber;
					var plant = urlParameters.plant;
					var storageLocation = urlParameters.storageLocation;
					if (materialNumber) {
						this.materialSearch(materialNumber, plant, storageLocation);
					}
				}
			}
		},

		/* =========================================================== */
		/* Application Logic     	                                   */
		/* =========================================================== */

		onSortPress: function() {
			this.openSimpleDialog('MaterialSearchDetailsSortDialog');
		},

		handleSort: function(oEvent) {
			if (oEvent) {
				var oTable = this.getElementById('materialMovementsTable');
				var oBinding = oTable.getBinding('items');
				var mParams = oEvent.getParameters();
				var aSorters = [new sap.ui.model.Sorter(mParams.sortItem.getKey(), mParams.sortDescending)];
				oBinding.sort(aSorters);
			}
		},

		onPersonalizationPress: function(oEvent) {
			if (oEvent) {
				this.oTablePersoController.openDialog();
			}
		},

		/* =========================================================== */
		/* oData calls				                          	   */
		/* =========================================================== */

		materialSearch: function(materialNumber, plant, storageLocation) {
			this.openBusyDialog();
			setTimeout(function() {
				this.getMaterialDetails(materialNumber, plant, storageLocation);
			}.bind(this), 0);
		},

		getMaterialDetails: function(materialNumber, plant, storageLocation) {
			var oMaterialDetailsModel = this.getModel('MaterialDetailsModel');
			oMaterialDetailsModel.setData({});
			if (materialNumber && materialNumber.length > 0) {
				var readParams = {
					wmService: 'ZWM_COMMON_SRV'
				};
				var path = 'MaterialMoveHdrSet(MaterialNumber=\'' + materialNumber + '\',PlantId=\'' + plant + '\',StorageLocation=\'' + storageLocation + '\')?$expand=Items';
				$.when(this.oDataUtil.read(path, readParams)
					.done(function(oData) {
						oMaterialDetailsModel.setData(oData);
						var list = this.getElementById('materialMovementsTable');
						this.sortList(list, [{
							propertyName: 'PostingDate',
							desc: true
						}, {
							propertyName: 'PostingTime',
							desc: true
						}, {
							propertyName: 'MaterialDocument',
							desc: true
						}]);
					}.bind(this))
					.fail(function(oError) {
						if (oError) {

						}
					})
					.always(this.closeBusyDialog.bind(this))
				);
			}
		},

		sortList: function(list, sorters, groupBy) {
			var binding = list.getBinding('items');

			// create group function if group given
			var groupFn = null;
			if (groupBy) {
				groupFn = function(oContext) {
					return oContext.getObject() ? oContext.getObject()[groupBy] : '';
				};
			}

			// Sort
			var oSorter = new sap.ui.model.Sorter('', null, groupFn);
			oSorter.fnCompare = function(a, b) {
				if (groupBy && (a[groupBy] < b[groupBy])) {
					return -1;
				} else if (groupBy && (a[groupBy] > b[groupBy])) {
					return 1;
				} else if (!sorters) {
					return 0;
				} else {
					var res = 0;
					$.each(sorters, function(index, sorter) {
						if (a[sorter.propertyName] < b[sorter.propertyName]) {
							res = sorter.desc ? 1 : -1;
							return false;
						} else if (a[sorter.propertyName] > b[sorter.propertyName]) {
							res = sorter.desc ? -1 : 1;
							return false;
						}
					});
					return res;
				}
			};
			binding.sort(oSorter);
		},


		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		specialStockFormatter: function(value) {
			if (value && value === 'X') {
				return 'sap-icon://accept';
			} else {
				return '';
			}
		}
	});
});