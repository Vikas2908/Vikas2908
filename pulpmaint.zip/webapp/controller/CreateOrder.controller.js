sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.CreateOrder', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			var that = this;

			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				Equipments: [],
				FunctionalLocationIsValid: true,
				EquipmentIsValid: true,
				IconTabBarSelectedKey: 'Header',
				Purpose: 'Create',
				ReleasedDuringSession: false,
				CompletedDuringSession: false,
				GoodsIssueCancelDocument: {},
				OperationDefaultStartDate: null,
				OperationDefaultStartTime: null
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('app', 'navigate', this.handleNavigate.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'CreateOrderTechinalObject', this.handleTechnicalObjectSelectedFromHierarchy.bind(this));
			this.subscribeToEvent('operation', 'operationReady', this.insertOperationToModel.bind(this));
			this.subscribeToEvent('material', 'materialReady', this.insertMaterialToModel.bind(this));

			this.getElementById('workCenterLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};

			if (!this.isHybridApplicationUser() && this.isCreateOrderRoute()) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.setDefaultParameters.bind(this));
			}

			this.isMyWork = window.location.hash.indexOf('MyWork') !== -1;
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'CreateOrder' || navigationEvent.getParameter('name') === 'EditMyWork') {
				var navigationArguments = navigationEvent.getParameter('arguments');
				var navigationPurpose = navigationArguments.Purpose;
				var query = navigationArguments['?query'];
				var orderId = navigationArguments.OrderNumber;

				BaseController.prototype.routeMatched.apply(this, arguments);
				this.clearAttachmentDeleteQueue();

				this.getGlobalModel().setProperty('/EditOrder', navigationPurpose === 'Create' || navigationPurpose === 'Edit');

				if (navigationPurpose === 'Create') {
					this.getElementById('orderTypeSelectControl')
						.getBinding('items')
						.filter(
							this.generateFilter('Create', ['X'])
							.concat(this.generateFilter('OrderType', [''], 'NE'))
						);
				} else {
					this.getElementById('orderTypeSelectControl')
						.getBinding('items')
						.filter(
							this.generateFilter('List', ['X'])
							.concat(this.generateFilter('OrderType', [''], 'NE'))
						);

					if (orderId && this.getOrderModel().getProperty('/Orderid') !== orderId) {
						this.getOrderFromSap(orderId)
							.done(this.handleGetNavigatedOrderSuccess.bind(this));
					}
				}

				this.filterActivityTypes(this.getOrderModel().getProperty('/OrderType'));
				this.filterPriorities(this.getOrderModel().getProperty('/OrderType'));

				this.getModel('ViewModel').setProperty(
					'/IconTabBarSelectedKey',
					query && query.Tab || 'Header'
				);

				this.getModel('ViewModel').setProperty('/Purpose', navigationPurpose);

				this.getModel('ViewModel').setProperty('/ReleasedDuringSession', false);
				this.getModel('ViewModel').setProperty('/CompletedDuringSession', false);

				this.getModel('ViewModel').setProperty('/NavigatedFromMyWork', navigationEvent.getParameter('name') === 'EditMyWork');

				this.rerenderTextAreas();

				if (query && query.Activity) {
					this.findOperationPath(query, navigationEvent.getParameter('name'), navigationPurpose);
				}
			}
		},

		handleGetNavigatedOrderSuccess: function(orders) {
			if (orders && orders.length === 1) {
				this.getOrderModel().setData(this.models.getOrderDefaults(orders.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil))[0]));
			}
		},

		handleNavigate: function(channel, eventName, navigationData) {
			if (this.isCorrectController()) {
				if (this.navigatedToOrderCreation(navigationData)) {
					this.validateTechnicalObject(this.getOrderFunctionalLocation())
						.done(this.tehcnicalObjectValid.bind(this, true))
						.fail(this.tehcnicalObjectNotValid.bind(this));

					this.validate(this.getView(), this.removeValueStates.bind(this));
				} else if (this.navigatedToCreateOrderWithReference(navigationData)) {
					this.validateTechnicalObject(this.getOrderFunctionalLocation())
						.done(this.tehcnicalObjectValid.bind(this, false))
						.fail(this.tehcnicalObjectNotValid.bind(this));

					this.validate(this.getView(), this.removeValueStates.bind(this));
				}
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			this.shouldShowWarningMessage() ?
				this.openNavigationConfimation() :
				this.handleNavBack();
		},

		onHardwareNavigateBack: function() {
			if (this.isTablet() && !this.orderIsInEditMode() && !this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			} else {
				this.onNavigateBack();
			}
		},

		onIconTabBarSelectionChange: function(selectEvent) {
			var selectedKey = selectEvent.getParameter('selectedKey');
			if (this.shouldAddDefaultOperation(selectedKey)) {
				this.getOrderModel()
					.setData(
						this.addDefaultOperation(this.getOrderModel().getData())
					);
			}
			this.setSelectedIconTabBar(selectedKey);
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('OrderActionButtons').openBy(pressEvent.getSource());
		},

		onShowErrorMessage: function() {
			this.showMessageBox({
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: this.getOrderModel().getProperty('/ErrorMessage'),
				type: 'Error'
			});
		},

		onDeleteOrderPress: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('CONFIRM_ORDER_DELETION_TEXT'),
				onClose: this.handleOrderDelete.bind(this),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		onCompleteOrderPress: function() {
			this.getModel('ViewModel').setProperty('/CompletedDuringSession', true);

			this.getOrderModel().setProperty('/Completed', 'X');
			this.getOrderModel().setProperty('/Released', '');

			this.orderIsInEditMode() ? this.onSaveButtonPress() : this.postOrder();
		},

		onReleaseOrderPress: function() {
			this.getModel('ViewModel').setProperty('/ReleasedDuringSession', true);

			this.getOrderModel().setProperty('/Released', 'X');

			this.orderIsInEditMode() ? this.onSaveButtonPress() : this.postOrder();
		},

		onPlanningCompletedPress: function() {
			this.getModel('ViewModel').setProperty('/PlanningCompletedDuringSession', true);

			this.getOrderModel().setProperty('/PlanningCompleted', 'X');

			this.orderIsInEditMode() ? this.onSaveButtonPress() : this.postOrder();
		},

		onShowNotificationPress: function() {
			var notificationNumber = this.getOrderModel().getProperty('/NotifNo');

			this.handleNavigateToNotification(notificationNumber);
		},

		onEditButtonPress: function() {
			this.navTo(this.getModel('ViewModel').getProperty('/NavigatedFromMyWork') ? 'EditMyWork' : 'CreateOrder', {
				Purpose: 'Edit',
				OrderNumber: this.getOrderNumber(),
				query: {
					Tab: this.getModel('ViewModel').getProperty('/IconTabBarSelectedKey') || 'Header'
				}
			}, this.isPhone());

			setTimeout(function() {
				this.getOrderModel().updateBindings(true);
			}.bind(this), 0);
		},

		onSaveButtonPress: function() {
			if (this.isValid()) {
				if (!this.getOrderModel().getProperty('/Operations') || this.getOrderModel().getProperty('/Operations').length === 0) {
					this.getOrderModel()
						.setData(
							this.addDefaultOperation(this.getOrderModel().getData())
						);
				}
				this.postOrder();
			} else {
				this.setSelectedIconTabBar('Header');

				this.getModel('ViewModel').updateBindings();
			}
		},

		onOrderTypeChange: function(changeEvent) {
			this.getOrderModel().setProperty('/Pmacttype', '');

			this.filterActivityTypes(changeEvent.getParameter('selectedItem').getProperty('key'));
			this.filterPriorities(changeEvent.getParameter('selectedItem').getProperty('key'));
		},

		onTechnicalObjectInputChange: function(changeEvent) {
			var tehcnicalObject = changeEvent.getParameter('newValue').substr(
				0,
				changeEvent.getParameter('newValue').indexOf(' - ') !== -1 ?
				changeEvent.getParameter('newValue').indexOf(' - ') :
				changeEvent.getParameter('newValue').length
			);
			this.validateTechnicalObject(tehcnicalObject && tehcnicalObject.toUpperCase() || '')
				.done(this.tehcnicalObjectValid.bind(this, true))
				.fail(this.tehcnicalObjectNotValid.bind(this));
		},

		onPressNavigateToHierarchy: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'CreateOrderTechinalObject');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(this.getOrderFunctionalLocation());
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					saveModelName: 'NewOrderModel',
					multiSelect: false,
					itemPressHandler: this.handleWorkCenterSelected.bind(this)
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					saveModelName: 'NewOrderModel',
					multiSelect: false
				})
			);
		},

		onRevisionPress: function() {
			var parameters = this.getRevisionDialogParameters({
				saveModelName: 'NewOrderModel',
				itemPressHandler: this.onRevisionSelect.bind(this)
			});
			this.openDialog('RevisionDialog', parameters);
		},

		onRevisionSelect: function(selectEvent) {
			var selectedRevision = selectEvent
				.getSource()
				.getBindingContext('SelectionValuesModel')
				.getObject();

			this.getModel('ViewModel').setProperty('/OperationDefaultStartDate', selectedRevision.StartDate);
			this.getModel('ViewModel').setProperty('/OperationDefaultStartTime', selectedRevision.StartTime);
		},

		onOperationItemPress: function(pressEvent) {
			var path = pressEvent.getParameter('listItem').getBindingContext('NewOrderModel').getPath();
			this.navigateToOperation(path);
		},

		onOperationsAddButtonPress: function() {
			var order = this.getOrderModel().getData();
			var startTime = this.getModel('ViewModel').getProperty('/OperationDefaultStartTime');
			var startDate = this.getModel('ViewModel').getProperty('/OperationDefaultStartDate');

			if (!this.getOrderModel().getProperty('/Operations').length && !startTime && !startDate) {
				startTime = this.getCurrentTime();
				startDate = new Date();
			}
			var operationProperties = {
				Activity: this.getDefaultItemNumber(
					10,
					(this.getOrderModel().getProperty('/Operations') || [])
					.reduce(this.parseItemNumber.bind(this, 'Activity'), [])
				),
				EarlSchedStartDate: startDate,
				EarlSchedStartTime: startTime,
				WorkcenterPlant: order.WorkcenterPlant,
				Workcenter: order.Workcenter
			};

			this.getModel('NewOperationModel').setData(this.models.getOperationDefaults(operationProperties));

			this.navTo('Operation');
		},

		onOperationDeletePress: function(pressEvent) {
			var operationObject = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getObject();
			var operationNumber = operationObject.Activity;
			var path = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getPath();
			var index = path.substring(path.lastIndexOf('/') + 1, path.length);
			var corfirmPopUpProperties = {
				type: 'Warning',
				title: this.getResourceBundleText('CONFIRM_OPERATION_DELETION_TITLE'),
				message: this.getResourceBundleText('CONFIRM_OPERATION_DELETION_MESSAGE', operationNumber),
				onClose: this.handleOperationDeletion.bind(this, index, operationNumber, operationObject.SubActivity),
				actions: [sap.m.MessageBox.Action.DELETE, sap.m.MessageBox.Action.CANCEL]
			};
			this.showMessageBox(corfirmPopUpProperties);
		},

		handleOperationDeletion: function(index, operationNumber, subActivity, action) {
			if (action === 'DELETE') {
				this.getOrderModel()
					.setProperty(
						'/Operations',
						this.removeIndexFromArray(this.getOrderModel().getProperty('/Operations'), index)
					);
				if (!subActivity) {
					this.getOrderModel()
						.setProperty(
							'/Assignments',
							this.getOrderModel().getProperty('/Assignments').filter(function(assignment) {
								return assignment.Activity !== operationNumber;
							})
						);
					this.getOrderModel().updateBindings(true);
				}
			}
		},

		onMaterialItemPress: function(pressEvent) {
			var path = pressEvent.getParameter('listItem').getBindingContext('NewOrderModel').getPath();
			var materialObject = $.extend(true, {}, this.getOrderModel().getProperty(path));

			this.getModel('NewMaterialModel').setData(this.models.getMaterialDefaults(materialObject));

			this.navTo('Material', {
				Path: path.substring(path.lastIndexOf('/') + 1, path.length)
			});
		},

		onMaterialsAddButtonPress: function() {
			var materialProperties = {
				ItemNumber: this.getDefaultItemNumber(
					10,
					(this.getOrderModel().getProperty('/Components') || [])
					.reduce(this.parseItemNumber.bind(this, 'ItemNumber'), [])
				),
				Activity: this.getOrderModel().getProperty('/Operations').length === 1 ?
					this.getOrderModel().getProperty('/Operations/0/Activity') : ''
			};

			this.getModel('NewMaterialModel').setData(this.models.getMaterialDefaults(materialProperties));

			this.navTo('Material');
		},

		onMaterialDeletePress: function(pressEvent) {
			var material = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getObject().Material;
			var path = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getPath();
			var index = path.substring(path.lastIndexOf('/') + 1, path.length);
			var corfirmPopUpProperties = {
				type: 'Warning',
				title: this.getResourceBundleText('CONFIRM_MATERIAL_DELETION_TITLE'),
				message: this.getResourceBundleText('CONFIRM_MATERIAL_DELETION_MESSAGE', material),
				onClose: this.handleMaterialDeletion.bind(this, index),
				actions: [sap.m.MessageBox.Action.DELETE, sap.m.MessageBox.Action.CANCEL]
			};
			this.showMessageBox(corfirmPopUpProperties);
		},

		handleMaterialDeletion: function(index, action) {
			if (action === 'DELETE') {
				this.getOrderModel()
					.setProperty(
						'/Components',
						this.removeIndexFromArray(this.getOrderModel().getProperty('/Components'), index)
					);
				this.getOrderModel().updateBindings(true);
			}
		},

		onSuccessDialogClose: function() {
			if (this.orderIsInEditMode() || this.isPhone()) {
				this.handleNavBack();
			} else if (!this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			}
		},

		onUploadComplete: function(oEvent) {
			this.handleUploadComplete(oEvent, this.getOrderModel());
		},

		onAttachmentDeleteButtonPress: function(deleteEvent) {
			var deleted = deleteEvent.getParameter('item').getBindingContext('NewOrderModel').getObject();
			if (deleted.LinkId && deleted.DocId) {
				this.addToAttachmentDeleteQueue(deleted);
			}
			this.getOrderModel().setProperty(
				'/Attachments',
				this.getOrderModel().getProperty('/Attachments').filter(function(attachment) {
					return deleted.LinkId !== attachment.LinkId;
				})
			);
		},

		onCreateNotificationToObjectPress: function(pressEvent) {
			var object = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getObject();

			this.getModel('NewNotificationModel').setData(this.models.getNotificationDefaults({
				FunctLocInternalId: object.FunctLocInternalId,
				FunctLoc: object.FunctLoc,
				Equipment: object.Equipment
			}));

			this.navTo('CreateNotification', {
				Purpose: 'Create'
			});
		},

		onCreateMeasurementPointToObjectPress: function(pressEvent) {
			var object = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getObject();

			this.openMeasurementPointDialog(object.FunctLocInternalId, object.Equipment, 'NewOrderModel');
		},

		onPrintOrderPress: function() {
			this.openDialog('PrintDialog', {
				Orderid: this.getOrderModel().getProperty('/Orderid')
			});
		},

		onShowDMSDocumentsPress: function() {
			var equipment = this.getOrderModel().getProperty('/Equipment');
			var functionalLocation = this.getOrderModel().getProperty('/FunctLocInternalId');
			var orderId = this.getOrderModel().getProperty('/Orderid');
			var operationIds = this.getOrderModel().getProperty('/Operations').map(function(operation) {
				return operation.Orderid + '/' + operation.Activity;
			});

			this.openDialog('DisplayDMSDocuments', {
				ObjectId: orderId,
				ObjectType: 'PMAUFK',
				TechnicalObject: equipment || functionalLocation,
				Type: equipment ? 'EQUI' : 'IFLOT',
				Operations: operationIds
			});
		},

		onShowMillSafetyDocuments: function() {
			var plant = this.getUserParameters().Plant;

			this.openDialog('DisplayDMSDocuments', {
				TechnicalObject: plant,
				Type: 'WERKS'
			});
		},

		onCancelGoodsIssuePress: function(pressEvent) {
			var document = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getObject();
			var path = pressEvent.getSource().getParent().getBindingContext('NewOrderModel').getPath();
			var index = path.substring(path.lastIndexOf('/') + 1, path.length);

			document.index = index;
			document.GoodsIssueCancelQuantity = document.Quantity;

			this.getModel('ViewModel').setProperty('/GoodsIssueCancelDocument', document);

			this.openSimpleDialog('GoodsIssueCancellation');

			this.getFragmentElementById('GoodsIssueCancellation', 'goodsIssueCancellationQuantityInputField')
				.$()
				.children()
				.attr('type', 'Number')
				.attr('step', '0.01');
		},

		onGoodsPostGoodsIssueCancellation: function() {
			var document = this.getModel('ViewModel').getProperty('/GoodsIssueCancelDocument');
			if (document.GoodsIssueCancelQuantity > document.Quantity) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('INFORMATION_POPUP_TITLE'),
					message: this.getResourceBundleText('GOODS_ISSUE_CANCELLATION_INFO_MESSAGE'),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else {
				this.handleGoodsIssueCancellation(document.index, document);
			}
		},

		onGoodsIssueCancellationPostingClose: function() {
			this.getDialog('GoodsIssueCancellation').close();
		},

		onGoodsIssueMultiPress: function() {
			var giModel = this.getModel('GoodsIssueMultiModel');
			giModel.setProperty('/Items', []);
			var items = [];
			var oTable = this.getView().byId('materialsTable');
			var rows = oTable.getBinding('items').getCurrentContexts()[0].oModel.oData.Components;
			giModel.setProperty('/PlantId', rows[0].Plant);
			giModel.setProperty('/UnloadingPoint', rows[0].UnloadPt);
			giModel.setProperty('/Reservation', rows[0].ReservNo);
			for (var i = 0; i < rows.length; i++) {
				var obj = {};
				obj.MaterialNumber = rows[i].Material;
				obj.MaterialDescription = rows[i].MaterialDescr;
				obj.Batch = rows[i].Batch;
				obj.Operation = rows[i].Activity;
				obj.StorageLocation = rows[i].StgeLoc;
				obj.StorageBin = rows[i].BinLocation;
				obj.ReservationItem = rows[i].ResItem;
				obj.Unit = rows[i].RequirementQuantityUnit;
				obj.OpenQty = rows[i].RequirementQuantity;
				obj.FinalDelivery = false;
				if (rows[i].isSelected) {
					items.push(obj);
				}
			}
			giModel.setProperty('/Items', items);
			if (items.length > 0) {
				this.openSimpleDialog('GoodsIssuePostingMulti');
			}
		},

		onPostGoodsIssueMulti: function() {
			this.handleGoodsIssueMultiPost();
		},

		onNotificationLinkPress: function() {
			var notification = this.getOrderModel().getProperty('/NotifNo') || '';
			if (notification) {
				this.handleNavigateToNotification(notification);
			}
		},

		onDrawPictureAttachment: function() {
			this.openDialog('ImageEditor', {
				Attachments: this.getOrderModel().getData().Attachments
			});
		},

		onCauseCodeValueHelp: function() {
			var notifType = this.getDefaultNotifType();
			this.openDialog(
				'GroupCodeDialog', {
					saveModelName: 'NewOrderModel',
					catalogId: this.getConfigurationModel().getCauseCodeCatalogId(),
					catalogProfile: this.getOrderModel().getProperty('/CatalogProfile'),
					notifType: notifType || '',
					groupIdProperty: 'CauseCodegrp',
					groupDescriptionProperty: 'CauseCodegrpDescr',
					codeIdProperty: 'CauseCode',
					codeDescriptionProperty: 'CauseCodeDescr'
				}
			);
		},

		onCatalogProfileValueHelp: function() {
			this.openDialog(
				'SearchDialog', {
					pathToModel: '/CatalogProfiles',
					saveModelName: 'NewOrderModel',
					configurationModelName: 'SelectionValuesModel',
					listItemValueKey: 'CatalogProfile',
					listItemDescriptionKey: 'CatalogProfileDescr',
					firstValueToSave: 'CatalogProfile',
					secondValueToSave: 'CatalogProfileDescr',
					dialogTitle: this.getResourceBundleText('SELECT_CATALOG_PROFILE_TITLE')
				}
			);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		setDefaultParameters: function() {
			this.getOrderModel()
				.setData(
					$.extend(true, this.getOrderModel().getData(), this.models.getOrderDefaults())
				);

			this.filterActivityTypes(this.getOrderModel().getProperty('/OrderType'));
			this.filterPriorities(this.getOrderModel().getProperty('/OrderType'));
		},

		handleCameraSuccess: function(fileUri) {
			this.getOrderModel().setProperty(
				'/Attachments',
				this.getOrderModel().getProperty('/Attachments').concat([this.getUploadCollectionItem(fileUri)])
			);
		},

		handleGetPictureFromFileSystemSuccess: function(fileUris) {
			var selectedPictures = fileUris.map(function(fileUri) {
				return this.getUploadCollectionItem(fileUri.path);
			}.bind(this));
			this.getOrderModel().setProperty(
				'/Attachments',
				this.getOrderModel().getProperty('/Attachments').concat(selectedPictures)
			);
		},

		handleDrawSuccess: function(fileUri) {
			var attachment = this.getUploadCollectionItem(fileUri);
			attachment = this.insertTemporaryDocIds(attachment);
			if (this.isHybridApplicationUser()) {
				this.getOrderModel().setProperty(
					'/Attachments',
					this.getOrderModel().getProperty('/Attachments').concat([attachment])
				);
			} else {
				this.getModel('ViewModel').setProperty('/AttachmentsBusy', true);
				this.postAttachment(attachment)
					.done(function(oEvent) {
						this.handleUploadComplete(oEvent, this.getOrderModel());
					}.bind(this))
					.always(function() {
						this.getModel('ViewModel').setProperty('/AttachmentsBusy', false);
					}.bind(this));
			}
		},

		handleDeleteExisting: function(docId) {
			var deleted = {};
			(this.getOrderModel().getProperty('/Attachments') || []).some(function(attachment) {
				if (attachment.DocId === docId) {
					deleted = attachment;
				}
			});
			if (deleted.LinkId && deleted.DocId) {
				this.addToAttachmentDeleteQueue(deleted);
			}
			this.getOrderModel().setProperty(
				'/Attachments',
				this.getOrderModel().getProperty('/Attachments').filter(function(attachment) {
					return docId !== attachment.DocId;
				})
			);
		},

		navigatedToOrderCreation: function(navigationData) {
			return !!(
				this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'CreateOrder') &&
				location.hash.split('/').indexOf('Create') !== -1
			);
		},

		navigatedToCreateOrderWithReference: function(navigationData) {
			return !!(
				this.navigatedToDetailViewFromView(navigationData, 'NotificationSplitContainer', 'CreateOrder') &&
				location.hash.split('/').indexOf('Create') !== -1
			);
		},

		findOperationPath: function(query, navigationName, navigationPurpose, skipSearch) {
			var path = this.getActivityPath(query.Activity);
			var orderNumber = this.getUrlParameter('OrderNumber') || '';
			if (path) {
				this.navTo(navigationName, {
					Purpose: navigationPurpose,
					OrderNumber: orderNumber,
					query: {
						Tab: query.Tab ? query.Tab : ''
					}
				}, true);
				window.setTimeout(this.navigateToOperation.bind(this, path), 0);
			} else if (!skipSearch) {
				this.getOrderFromSap(orderNumber)
					.done(this.handleGetOrderFromSapSuccess.bind(this, query, navigationName, navigationPurpose));
			}
		},

		handleGetOrderFromSapSuccess: function(query, navigationName, navigationPurpose, oData) {
			var orders = this.getModel('OrdersModel').getProperty('/Orders') || [];
			var addedOrders = orders.concat(oData.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
			this.getModel('OrdersModel').setProperty('/Orders', addedOrders);
			this.findOperationPath(query, navigationName, navigationPurpose, true);
		},

		navigateToOperation: function(path) {
			var operationObject = $.extend(true, {}, this.getOrderModel().getProperty(path));

			if (operationObject.ConfirmedTime === '0.0') {
				delete operationObject.ConfirmedTime;
			}

			operationObject.EarlSchedStartDate = this.generateDateObject(operationObject.EarlSchedStartDate);
			operationObject.EarlSchedStartTime = this.generateTimeObject(operationObject.EarlSchedStartTime);

			this.getModel('NewOperationModel').setData(this.models.getOperationDefaults(operationObject));

			this.navTo('Operation', {
				Path: path.substring(path.lastIndexOf('/') + 1, path.length)
			});
		},

		isCreateOrderRoute: function() {
			return location.hash.indexOf('CreateOrder/Create') !== -1;
		},

		handleScanSuccess: function(result) {
			if (result.text) {
				this.validateTechnicalObject(result.text || '')
					.done(this.tehcnicalObjectValid.bind(this, true))
					.fail(this.tehcnicalObjectNotValid.bind(this));
			}
		},

		tehcnicalObjectValid: function(inheritWorkCenter, tehcnicalObject) {
			if (tehcnicalObject) {
				tehcnicalObject.hasOwnProperty('Equnr') ?
					this.equipmentValid(inheritWorkCenter, tehcnicalObject) :
					this.functionalLocationValid(inheritWorkCenter, tehcnicalObject);
			} else {
				this.equipmentValid();
				this.functionalLocationValid();
			}
		},

		tehcnicalObjectNotValid: function() {
			this.equipmentNotValid();
			this.functionalLocationNotValid();
		},

		handleTechnicalObjectSelectedFromHierarchy: function(channel, eventName, selectedObject) {
			if (this.isCorrectController()) {
				if (selectedObject.type === 'Equipment') {
					this.validateEquipment(selectedObject.InternalId)
						.done(this.equipmentValid.bind(this, true))
						.fail(this.equipmentNotValid.bind(this));
				} else {
					this.getOrderModel().setProperty('/Equipment', '');
					this.getOrderModel().setProperty('/EquipmentDescr', '');

					this.validateFunctionalLocation(selectedObject.InternalId)
						.done(this.functionalLocationValid.bind(this, true))
						.fail(this.functionalLocationNotValid.bind(this));
				}
			}
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.handleNavBack();
		},

		handleNavBack: function() {
			if (!this.isPhone() && this.isEditingExsistingOrder()) {
				this.getOrderNumberFromUrlParameters();
			}
			this.getView().mAggregations.content[0].scrollTo(0);
			this.onNavBack();
		},

		rerenderTextAreas: function() {
			setTimeout(function() {
				this.getElementById('orderLontTextInput') && this.getElementById('orderLontTextInput').rerender();
			}.bind(this), this.isPhone() ? 500 : 0);
		},

		isEditingExsistingOrder: function() {
			return !!(this.getOrderNumber() &&
				(this.getOrderNumber().charAt(0) !== '%' || this.getOrderModel().getProperty('/NotSync')) &&
				this.orderIsInEditMode()
			);
		},

		setSelectedIconTabBar: function(tabBarKey) {
			this.navTo(this.getModel('ViewModel').getProperty('/NavigatedFromMyWork') ? 'EditMyWork' : 'CreateOrder', {
				Purpose: tabBarKey === 'Objects' ? 'Edit' : this.getModel('ViewModel').getProperty('/Purpose'),
				OrderNumber: this.getOrderNumber() || '',
				query: {
					Tab: tabBarKey
				}
			}, !(this.getGlobalModel('/EditOrder') && tabBarKey === 'Objects'));

			if (tabBarKey === 'Objects') {
				setTimeout(function() {
					this.getOrderModel().updateBindings(true);
				}.bind(this), 0);
			}
		},

		filterActivityTypes: function(orderType) {
			this.getElementById('pmActivityTypeSelectControl')
				.getBinding('items')
				.filter(this.generateFilter('OrderType', [orderType]));
		},

		filterPriorities: function(orderType) {
			this.getElementById('prioritySelectControl')
				.getBinding('items')
				.filter(
					this.generateFilter('Ordertype', [orderType])
					.concat(this.generateFilter('PriorityId', [''], 'NE'))
				);
		},

		openOperationsMissingDialog: function() {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('OPERATION_MISSING_TITLE'),
				message: this.getResourceBundleText('OPERATION_MISSING_TEXT'),
				actions: [sap.m.MessageBox.Action.OK]
			});
		},

		functionalLocationValid: function(inheritWorkCenter, functionalLocationObject) {
			if (functionalLocationObject) {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);

				this.getOrderModel().setProperty('/FunctLocInternalId', functionalLocationObject.InternalId);
				this.getOrderModel().setProperty('/FunctLoc', functionalLocationObject.Floc);
				this.getOrderModel().setProperty('/FunctLocDescr', functionalLocationObject.Descr);

				if (inheritWorkCenter && functionalLocationObject.Workcenter) {
					this.getOrderModel().setProperty('/Workcenter', functionalLocationObject.Workcenter);
				}
			} else {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);
				this.getOrderModel().setProperty('/FunctLocInternalId', '');
				this.getOrderModel().setProperty('/FunctLoc', '');
				this.getOrderModel().setProperty('/FunctLocDescr', '');
			}
			this.getOrderModel().updateBindings(true);
		},

		functionalLocationNotValid: function() {
			this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', false);
		},

		equipmentValid: function(inheritWorkCenter, equipmentObject) {
			if (equipmentObject) {
				this.getModel('ViewModel').setProperty('/EquipmentIsValid', true);

				this.getOrderModel().setProperty('/Equipment', equipmentObject.Equnr);
				this.getOrderModel().setProperty('/EquipmentDescr', equipmentObject.Descr);

				if (inheritWorkCenter && equipmentObject.Workcenter) {
					this.getOrderModel().setProperty('/Workcenter', equipmentObject.Workcenter);
				}

				this.validateFunctionalLocation(equipmentObject.SupflocInternalId)
					.done(this.functionalLocationValid.bind(this, false))
					.fail(this.functionalLocationNotValid.bind(this));
			} else {
				this.getModel('ViewModel').setProperty('/EquipmentIsValid', true);
				this.getOrderModel().setProperty('/Equipment', '');
				this.getOrderModel().setProperty('/EquipmentDescr', '');
			}
			this.getOrderModel().updateBindings(true);
		},

		equipmentNotValid: function() {
			this.getModel('ViewModel').setProperty('/EquipmentIsValid', false);
		},

		handleWorkCenterSelected: function() {
			setTimeout(function() {
				var workCenter = this.getOrderModel().getProperty('/Workcenter');
				if (this.shouldInsertWorkCenterToFirstOperation()) {
					this.getOrderModel().setProperty('/Operations/0/Workcenter', workCenter);
				}
			}.bind(this), 0);
		},

		shouldInsertWorkCenterToFirstOperation: function() {
			return !!((this.getOrderModel().getProperty('/Operations') || []).length !== 0 && !this.getOrderModel().getProperty('/Released'));
		},

		shouldAddDefaultOperation: function(selectedKey) {
			return !!(
				(this.getOrderModel().getProperty('/Operations') || []).length === 0 &&
				this.orderIsInEditMode() &&
				(selectedKey === 'Operations' || selectedKey === 'Materials')
			);
		},

		addDefaultOperation: function(orderObject) {
			if (this.isCorrectController()) {
				var startTime = this.getModel('ViewModel').getProperty('/OperationDefaultStartTime');
				var startDate = this.getModel('ViewModel').getProperty('/OperationDefaultStartDate');
				if (!orderObject.Operations || orderObject.Operations.length === 0) {
					var operationObject = this.models.createNewOperationModel({
						Activity: '0010',
						Description: this.getShortText(orderObject.LongText),
						LongText: orderObject.LongText,
						EarlSchedStartDate: startDate || new Date(),
						EarlSchedStartTime: startTime || this.getCurrentTime(),
						WorkcenterPlant: orderObject.WorkcenterPlant,
						Workcenter: orderObject.Workcenter
					}).getData();
					delete operationObject.Assignments;
					orderObject.Operations = [operationObject];
				}
				return orderObject;
			}
		},

		insertOperationToModel: function(channel, eventName, navigationParameters) {
			if (this.isCorrectController()) {
				var operationsArray = this.getOrderModel().getProperty('/Operations');
				var operationObject = navigationParameters.operationObject;
				var assignments = $.extend(true, [], operationObject.Assignments);
				var arrayIndex = navigationParameters.path ?
					navigationParameters.path :
					false;

				delete operationObject.Assignments;

				arrayIndex ? operationsArray[arrayIndex] = operationObject : operationsArray.push(operationObject);
				this.getOrderModel().setProperty('/Operations', operationsArray);

				this.getOrderModel().updateBindings(true);

				this.getOrderModel().setProperty(
					'/Assignments',
					(this.getOrderModel().getProperty('/Assignments') || [])
					.filter(function(assignment) {
						return assignment.Activity !== operationObject.Activity;
					})
					.concat(assignments)
				);
			}
		},

		filterDublicateAssignments: function(assignment, index, array) {
			return this.filterDublicatedListObjectsTwoIds('Activity', 'PersonNumber', assignment, index, array);
		},

		insertMaterialToModel: function(channel, eventName, navigationParameters) {
			if (this.isCorrectController()) {
				var materialsArray = this.getOrderModel().getProperty('/Components');
				var arrayIndex = navigationParameters.path ?
					navigationParameters.path :
					false;

				arrayIndex ? materialsArray[arrayIndex] = navigationParameters.materialObject : materialsArray.push(navigationParameters.materialObject);
				this.getOrderModel().setProperty('/Components', materialsArray);

				this.getOrderModel().updateBindings(true);
			}
		},

		isValid: function() {
			return !!(
				this.validate(this.getView(), this.scrollToElement.bind(this, 20)) &&
				this.getModel('ViewModel').getProperty('/FunctionalLocationIsValid')
			);
		},

		postOrder: function() {
			var postObject = this.getOrderPostObject();
			var postParameters = {
				online: true
			};

			if (this.formatterUtil.isReleasable(postObject.Released, postObject.OrderType, postObject.Completed)) {
				postObject.Released = 'X';
				this.getModel('ViewModel').setProperty('/ReleasedDuringSession', true);
			}

			this.getOrderModel().setData(postObject);

			if (this.isOffline()) {
				postObject.NotSync = true;
				postObject.ShortText = this.getShortText(postObject.LongText);
				this.insertOrderToList(postObject);
				this.localStorage.insertOrder(postObject);
				this.handleCreateSuccess();
			} else {
				postObject = this.generateOrderPostObject(postObject);
				this.removeAttachmentQueueItems();

				this.setAppBusyMode();
				this.oDataUtil.create('WorkOrderSet', postObject, postParameters)
					.done(this.handleCreateSuccess.bind(this, postObject.Orderid))
					.fail(this.handleCreateError.bind(this))
					.always(this.setAppNotBusyMode);
			}
		},

		getOrderPostObject: function() {
			var order = this.getPostObject(this.getOrderModel().getData());

			if (!this.isHybridApplicationUser()) {
				(Array.isArray(order && order.Attachments) ? order.Attachments : []).map(this.getAttachmentPostObject.bind(this));
			}

			return order;
		},

		handleCreateSuccess: function(orderNumber, response) {
			var attachments = $.extend(true, [], Array.isArray(response && response.Attachments) ? response.Attachments : []);

			if (!this.isHybridApplicationUser()) {
				response.Attachments = (Array.isArray(response && response.Attachments) ? response.Attachments : []).filter(this.filterDummyAttachments.bind(this));
			} else {
				(Array.isArray(response && response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));
			}

			this.getModel('ViewModel').setProperty('/ReleasedDuringSession', false);
			this.getModel('ViewModel').setProperty('/CompletedDuringSession', false);

			if (response && response.Orderid) {
				this.removeListObject('Orders', orderNumber);
				this.insertOrderToList(response);
				this.localStorage.removeOrder(orderNumber);
				this.publishEvent('order', 'orderChanged', response);
			}
			this.handleOrderReferenceToNotification(response);
			this.openSuccessDialog(
				response && response.Orderid ?
				this.getResourceBundleText((orderNumber === response.Orderid ? 'EDIT_SUCCESS_ORDER_MESSAGE' : 'POST_SUCCESS_ORDER_MESSAGE'), response.Orderid) :
				this.getResourceBundleText('POST_SAVE_OFFLINE_ORDER_MESSAGE')
			);

			if (this.shouldPostAttachments(response)) {
				this.postAttachments(attachments);
			}
		},

		handleCreateError: function(errorEvent) {
			if (this.getModel('ViewModel').getProperty('/ReleasedDuringSession')) {
				this.getOrderModel().setProperty('/Released', '');
			}
			if (this.getModel('ViewModel').getProperty('/CompletedDuringSession')) {
				this.getOrderModel().setProperty('/Completed', '');
				this.getOrderModel().setProperty('/Released', 'X');
			}
			if (this.getModel('ViewModel').getProperty('/PlanningCompletedDuringSession')) {

			}


			this.getModel('ViewModel').setProperty('/ReleasedDuringSession', false);
			this.getModel('ViewModel').setProperty('/CompletedDuringSession', false);
			this.getModel('ViewModel').setProperty('/PlanningCompletedDuringSession', false);

			this.openErrorMessagePopup(errorEvent);
		},

		shouldPostAttachments: function(response) {
			return response && response.Orderid && response.Attachments && response.Attachments.length;
		},

		shouldShowWarningMessage: function() {
			return !!(
				this.orderIsInEditMode() &&
				this.orderHasBeenEdited()
			);
		},

		orderHasBeenEdited: function() {
			return !!(
				this.isEditingExsistingOrder() ?
				this.orderDiffersFromOriginal() :
				this.orderDiffersFromDefault()
			);
		},

		orderDiffersFromOriginal: function() {
			return !this.areObjectsIdentical(
				this.getOrder(this.getOrderNumber()),
				this.getOrderModel().getData()
			);
		},

		orderDiffersFromDefault: function() {
			return !this.areObjectsIdentical(
				this.removeProperties(this.models.createNewOrderModel().getData()),
				this.removeProperties(this.getOrderModel().getData())
			);
		},

		removeProperties: function(notificationObject) {
			notificationObject = $.extend(true, {}, notificationObject);
			delete notificationObject.Workcenter;
			delete notificationObject.WorkcenterDescr;
			delete notificationObject.FunctLocDescr;
			delete notificationObject.Orderid;
			return notificationObject;
		},

		getCurrentTime: function() {
			return new this.customTypesUtil.InputTime().parseValue(new Date().getHours() + ':' + new Date().getMinutes(), 'string');
		},

		handleOrderDelete: function(action) {
			if (action === 'OK') {
				var orderNumber = this.getOrderModel().getProperty('/Orderid');

				this.localStorage.removeOrder(orderNumber);
				this.removeListObject('Orders', orderNumber);

				this.onNavBack();

				//phone requires 1 history navigation, other devices 2
				if (!this.isPhone()) {
					this.onNavBack();
				}
			}
		},

		handleGoodsIssueCancellation: function(index, document) {
			var busyPath = '/IsCancellingGoodsIssue';
			var postObject = {
				Posteddocnumber: document.Posteddocnumber,
				Posteddocitem: document.Posteddocitem,
				Quantity: document.GoodsIssueCancelQuantity,
				QuantityUnit: document.QuantityUnit,
				Posteddocyear: document.Posteddocyear
			};

			this.setPathBusy(busyPath);
			this.oDataUtil.functionImport('GoodsIssueCancel', postObject)
				.done(this.handleGoodsIssueCancellationSuccess.bind(this, index, document))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGoodsIssueCancellationSuccess: function(index, document) {
			var leftOverQuantity = document.Quantity - document.GoodsIssueCancelQuantity + '';
			if (leftOverQuantity === '0') {
				this.getOrderModel()
					.setProperty(
						'/GoodsIssues',
						this.removeIndexFromArray(this.getOrderModel().getProperty('/GoodsIssues'), index)
					);
			} else {
				this.getOrderModel()
					.setProperty(
						'/GoodsIssues/' + index + '/Quantity',
						leftOverQuantity
					);
			}

			this.onGoodsIssueCancellationPostingClose();

			this.getOrderModel().updateBindings(true);
		},
		handleGoodsIssueMultiPost: function() {
			/*	var quantity = this.getModel('ViewModel').getProperty('/GoodsIssueQuantity');
				var isFinalDelivery = this.getModel('ViewModel').getProperty('/GoodsIssueIsFinalDelivery');
				var component = this.getModel('NewMaterialModel').getData();*/

			var goodsIssue = this.constructGoodsIssueMulti();

			this.postGoodsIssueMulti(goodsIssue);
		},
		onGoodsIssuePostingMultiClose: function() {
			this.getDialog('GoodsIssuePostingMulti').close();
		},
		constructGoodsIssueMulti: function() {
			/*	var goodsIssueItem = {
					MaterialNumber: component.Material,
					GoodsIssueNumber: '',
					Operation: component.Activity,
					StorageLocation: component.StgeLoc,
					StorageBin: component.BinLocation,
					Batch: component.Batch,
					ReservationItem: component.ResItem,
					Unit: component.RequirementQuantityUnit,
					OpenQty: quantity,
					FinalDelivery: isFinalDelivery ? 'X' : ''
				};
				var goodsIssue = {
					PlantId: component.Plant,
					GoodsIssueNumber: '',
					UnloadingPoint: component.UnloadPt,
					Workorder: '',
					Reservation: component.ReservNo,
					Items: [goodsIssueItem]
				};*/
			var giModel = this.getModel('GoodsIssueMultiModel');
			var items = giModel.getProperty('/Items');

			var rows = items.length;
			for (var x = 0; x < rows; x++) {
				if (items[x].FinalDelivery === 'true') {
					items[x].FinalDelivery = 'X';
				} else {
					items[x].FinalDelivery = '';
				}
			}
			var goodsIssue = {
				PlantId: giModel.getProperty('/PlantId'),
				GoodsIssueNumber: '',
				UnloadingPoint: giModel.getProperty('/UnloadingPoint'),
				Workorder: '',
				Reservation: giModel.getProperty('/Reservation'),
				Items: items
			};

			//var goodsIssue = this.getModel('GoodsIssueMultiModel');
			return goodsIssue;
		},

		postGoodsIssueMulti: function(goodsIssue) {
			var busyPath = '/IsGoodsIssueDialogBusy';

			this.setPathBusy(busyPath);

			this.oDataUtil.createGoodsIssue(goodsIssue)
				.done(this.handleGoodsIssuePostMultiSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handleGoodsIssuePostMultiSuccess: function(response) {
			// var component = this.getModel('NewMaterialModel').getData();
			var goodsIssues = this.getOrderModel().getProperty('/GoodsIssues');
			var year = new Date().getFullYear() + '';

			//var giItem = response.Items[response.Items.length - 1];
			goodsIssues = Array.isArray(goodsIssues) ? goodsIssues : [];
			var x = response.Items.length;
			for (var i = 0; i < x; i++) {
				var giItem = response.Items[i];
				if (giItem.GiItem !== '') {
					var document = {
						Orderid: response.GoodsIssueNumber,
						Posteddocitem: giItem.GiItem,
						Posteddocnumber: response.PostedDocNumber,
						Posteddocyear: year,
						Material: giItem.MaterialNumber,
						MaterialDescr: giItem.MaterialDescription,
						Quantity: giItem.OpenQty,
						QuantityUnit: giItem.Unit,
						StgeLoc: giItem.StorageLocation,
						BinLocation: giItem.StorageBin,
						Batch: giItem.Batch
					};
					goodsIssues.push(document);
				}
			}

			this.onGoodsIssuePostingMultiClose();

			this.openSuccessDialog(
				this.getResourceBundleText('GOODS_ISSUE_SUCCESS_MESSAGE', response && response.PostedDocNumber || '')
			);

			//goodsIssues = Array.isArray(goodsIssues) ? goodsIssues : [];

			//goodsIssues.push(document);

			this.getOrderModel().setProperty('/GoodsIssues', goodsIssues);

			this.getOrderModel().updateBindings(true);
		},

		formatOrderSaveButtonText: function(isReleased, orderType, isCompleted) {
			return this.getResourceBundleText(this.formatterUtil.isReleasable(isReleased, orderType, isCompleted) ? 'RELEASE_BUTTON_LABEL' : 'SAVE_BUTTON_TEXT');
		},

		formatOrderSaveButtonIcon: function(isReleased, orderType, isCompleted) {
			return this.formatterUtil.isReleasable(isReleased, orderType, isCompleted) ? 'sap-icon://flag' : 'sap-icon://save';
		},

		isCorrectController: function() {
			var navigatedToMyWork = this.getModel('ViewModel').getProperty('/NavigatedFromMyWork');
			return (this.isMyWork && navigatedToMyWork) || (!this.isMyWork && !navigatedToMyWork);
		},

		getDefaultNotifType: function() {
			var notifType = this.getOrderModel().getProperty('/NotifType') || '';
			if (notifType) {
				return notifType;
			} else {
				var orderType = this.getOrderModel().getProperty('/OrderType') || '';
				var orderTypes = this.getModel('SelectionValuesModel').getProperty('/OrderTypeValues') || [];
				var defaultNotifType = '';
				orderTypes.some(function(type) {
					if (type.OrderType === orderType) {
						defaultNotifType = type.NotiftypeDefault || '';
						return true;
					}
				});
				return defaultNotifType;
			}
		}

	});
});