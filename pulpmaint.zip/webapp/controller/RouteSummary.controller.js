sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.RouteSummary', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));

			this.setModel('ViewModel');
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'RouteSummary') {
				BaseController.prototype.routeMatched.apply(this, arguments);
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {
				var notificationTable = this.getElementById('notificationsCreatedDuringRouteTable');
				notificationTable.getBinding('visible').refresh(true);

				this.modifyInputKeyboards();
				this.setDefaultOrderSelection();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNotificationPress: function(pressEvent) {
			var notificationNumber = pressEvent
				.getParameter('listItem')
				.getBindingContext('GlobalPropertiesModel')
				.getObject()
				.NotifNo;

			this.handleNavigateToNotification(notificationNumber);
		},

		onCoverWorkOrderSelect: function(selectEvent) {
			if (selectEvent.getParameter('selected')) {
				var selectedOrderId = selectEvent.getSource().getBindingContext('GlobalPropertiesModel').getObject().Orderid;

				this.getGlobalModel().setProperty('/RouteTimeRecord/object', selectedOrderId);
			}
		},

		onSaveButtonPress: function() {
			var timeConfirmation = this.getGlobalModel().getProperty('/RouteTimeRecord');
			var busyPath = '/IsRouteSummaryBusy';
			if (this.validate()) {
				this.setPathBusy(busyPath);
				this.handleRouteTimeConfirmation({
						ConfirmedTime: timeConfirmation.time,
						Orderid: timeConfirmation.object
					})
					.done(this.handleOperationTimeConfirmationSuccess.bind(this, timeConfirmation.object))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setPathNotBusy.bind(this, busyPath));
			}
		},

		onContinueButtonPress: function() {
			this.onSuccessDialogClose();
		},

		onSuccessDialogClose: function() {
			window.history.go(this.isPhone() ? -2 : -1);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handleOperationTimeConfirmationSuccess: function(orderId) {
			this.getTimeRecordUtility().finishCurrentRecording();
			this.openSuccessDialog(
				this.getResourceBundleText('TIME_CONFIRMED_FOR_ROUTE_MESSAGE', orderId)
			);
		},

		modifyInputKeyboards: function() {
			var numberInputs = ['recordedTimeInputControl'];
			numberInputs.forEach(this.changeToNumberInput.bind(this));
		},

		setDefaultOrderSelection: function() {
			var values = this.getGlobalModel().getProperty('/RouteWorkCoverOrders') || [];
			if (values.length > 1) {
				this.getGlobalModel().setProperty('/RouteTimeRecord/object', this.getLatestRouteOrderId());
			}
		}

	});
});