sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.Orders', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				IsOrderList: true,
				IsMyWorkList: false,
				IsNotificationList: false,
				SelectedOrder: '',
				FilterParameters: {},
				SaveVariantDialog: {
					CreateNew: false,
					IsDefault: false,
					IsBusy: false
				},
				Variants: [],
				OriginalFilterParameters: {},
				SelectedVariant: ''
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'AdvancedSearchOrderListFunctionalLocations', this.handleListFunctionalLocationsSelected.bind(this));
			this.subscribeToEvent('userParameters', 'update', this.getFilterParameters.bind(this));
			this.subscribeToEvent('root', 'variantsUpdated', this.setVariantsToModel.bind(this));

			this.getElementById('orderSearchField')._getValueHelpIcon().setSrc(this.isScannerAvailable() ? 'sap-icon://camera' : 'sap-icon://refresh');

			this.getFilterParameters();

			if (!this.isHybridApplicationUser() && (this.isOrdersRoute() || this.isDisplayOrderRoute())) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.getFilterParameters.bind(this));
				this.getOrdersForBrowser();
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Orders') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getGlobalModel().setProperty('/EditOrder', false);

				this.getModel('ViewModel').setProperty('/SelectedOrder', '');
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.isOrdersRoute() && this.navigatedFrom(navigationData.fromView, 'FunctionalLocationHierarchy')) {
				this.onAdvancedSearchPress();
			} else if (this.shouldShowMaster(navigationData)) {
				this.getModel('ViewModel').setProperty('/SelectedOrder', '');
				this.getParentController().showMaster();
			} else if (this.shouldHideMaster(navigationData)) {
				this.getParentController().hideMaster();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			this.onNavBack();
		},

		onMasterListItemPress: function(pressEvent) {
			var orderObject = pressEvent
				.getParameter('listItem')
				.getBindingContext('OrdersModel')
				.getObject();

			this.getModel('ViewModel').setProperty('/SelectedOrder', orderObject.Orderid);

			this.getModel('NewOrderModel').setData(this.models.getOrderDefaults(orderObject));

			this.navTo('CreateOrder', {
				Purpose: 'Display',
				OrderNumber: orderObject.Orderid
			}, this.getModel('Device').getProperty('/isNoPhone'));
			this.getParentController().hideMaster();
			setTimeout(function() {
				this.getMyComponent().getEventBus().publish('ordersMasterList', 'displayOrder');
			}.bind(this), 0);
		},

		onAdvancedSearchPress: function() {
			if (!this.getDialog('AdvancedSearch')) {
				var advancedSearch = this.initializeFragment('AdvancedSearch');
				var listFunctionalLocationInputControl = this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl');

				listFunctionalLocationInputControl.addValidator(this.functionalLocationListValidator.bind(this));

				this.isHybridApplicationUser() && this.renderSuggestionInput(listFunctionalLocationInputControl);

				advancedSearch.open();
			} else {
				this.openSimpleDialog('AdvancedSearch');
			}

			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
		},

		onAdvancedSearch: function() {
			this.getFilteredOrders();
			this.getDialog('AdvancedSearch').close();
		},

		onListFunctionalLocationsValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'AdvancedSearchOrderListFunctionalLocations');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onNotificationTypeValueHelp: function() {
			this.openDialog('SearchDialog', this.getOrderTypeDialogParameters());
		},

		onListFunctionalLocationTokensAdd: function(tokensToAdd, action) {
			this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl').setValue('');

			if (action === 'OK') {
				this.addListFunctionalLocationToModel(tokensToAdd);
			}
		},

		onOrderTypeValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getOrderTypeDialogParameters()
			);
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'FilterParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'FilterParameters/Plangroups'
				})
			);
		},

		onSystemConditionChange: function(changeEvent) {
			if (!changeEvent.getParameters().selectedItem.getKey()) {
				this.getModel('ViewModel').setProperty('/FilterParameters/SystemCondition', '');
			}
		},

		onPartnerSuggestionItemSelected: function(selectEvent) {
			var selectedPerson = selectEvent.getParameter('selectedRow').getBindingContext().getObject();

			this.getModel('ViewModel').setProperty('/FilterParameters/PersonNumber', selectedPerson.PersonNumber);
			this.getModel('ViewModel').setProperty('/FilterParameters/Fullname', selectedPerson.Fullname);
		},

		onCloseAdvancedSearch: function() {
			this.getDialog('AdvancedSearch').close();
		},

		onOpenErrorInformationPopover: function(pressEvent) {
			this.initializeFragment('ErrorMessages').openBy(pressEvent.getSource());
		},

		onOrderLiveSearch: function(searchEvent) {
			this.filterOrders(searchEvent.getParameter('newValue'));
		},

		onOrderSearchChange: function(searchEvent) {
			var visibleItems = this.getElementById('orderListContainer').getVisibleItems().length;
			if (visibleItems === 0) {
				var searchValue = searchEvent.getParameter('value') || '';
				if (searchValue) {
					this.openBusyDialog({
						service: 'WorkOrderSet'
					});
					this.getOrderFromSap(searchValue)
						.done(this.handleGetOrderFromSapSuccess.bind(this, searchValue))
						.fail(this.openErrorMessagePopup.bind(this))
						.always(this.closeBusyDialog.bind(this));
				}
			}
		},

		handleGetOrderFromSapSuccess: function(searchValue, oData) {
			var orders = this.getModel('OrdersModel').getProperty('/Orders') || [];
			var addedOrders = orders.concat(oData.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
			this.getModel('OrdersModel').setProperty('/Orders', addedOrders);
			this.filterOrders(searchValue);
		},

		onOrderPullToRefresh: function() {
			this.handleListRefresh();
		},

		onSearchBarValueHelpPress: function() {
			this.isHybridApplicationUser() ? this.onPressScanId() : this.handleListRefresh();
		},

		onSortButtonPress: function() {
			this.openSimpleDialog('OrderSort');
		},

		onSortConfirm: function(confirmEvent) {
			this.handleSort(confirmEvent, this.getElementById('orderListContainer'));
		},

		onSaveVariantButtonPress: function() {
			this.setVariantSaveDefaults();
			this.openSimpleDialog('SaveVariant');
		},

		onSaveVariant: function() {
			var variantInfo = this.validateVariantNaming('ORDERS');
			if (variantInfo) {
				this.setVariantDialogBusy(true);
				var viewModel = this.getModel('ViewModel');
				this.saveVariant(
						variantInfo.VariantId,
						'ORDERS',
						variantInfo.Description,
						viewModel.getProperty('/FilterParameters'),
						viewModel.getProperty('/SaveVariantDialog/IsDefault')
					)
					.done(function() {
						this.setVariantsToModel();
						this.onCloseSaveVariant();
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setVariantDialogBusy.bind(this, false));
			}
		},

		onSelectedVariantChange: function() {
			var selectedId = this.getModel('ViewModel').getProperty('/SelectedVariant');
			if (selectedId === '000') {
				var originalFilterParameters = this.getModel('ViewModel').getProperty('/OriginalFilterParameters');
				this.getModel('ViewModel').setProperty('/FilterParameters', this.generateFilterParametersCopy(originalFilterParameters));
			} else {
				var selectedVariant = this.getVariantWithTypeAndId('ORDERS', selectedId);
				var oFilterParameters = this.generateFilterParametersObject(JSON.parse(selectedVariant.Data));
				this.getModel('ViewModel').setProperty('/FilterParameters', oFilterParameters);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		getFilterParameters: function() {
			var filterParameters = this.getUserParameters();

			var workCenterParameters = {
				filters: this.generateFilter('Workcenter', filterParameters.Workcenters && filterParameters.Workcenters.split(',') || [''])
			};
			var planGroupParameters = {
				filters: this.generateFilter('Plangroup', filterParameters.Plangroups && filterParameters.Plangroups.split(',') || [''])
			};

			var defaultSystemConditions = [{
				StatusInt: 'I0001'
			}, {
				StatusInt: 'I0002'
			}];

			var endDate = this.getListSelectionEndDate();

			if (filterParameters.FunctLocs) {
				this.tokensAreValid(filterParameters.FunctLocs.toUpperCase().split(',').map(this.removeWhiteSpace))
					.done(this.addListFunctionalLocationToModel.bind(this))
					.fail(function() {
						this.getModel('ViewModel').setProperty('/FilterParameters/FunctLocs', []);
					}.bind(this));
			}

			this.getModel('ViewModel').setProperty('/FilterParameters', {
				Plant: filterParameters.Plant,
				Workcenters: [],
				Plangroups: [],
				FunctLocs: [],
				WorkOrderTypes: [],
				SystemCondition: defaultSystemConditions
			});

			this.getModel('ViewModel').setProperty('/FilterParameters/ReferenceStartDate', new Date());
			this.getModel('ViewModel').setProperty('/FilterParameters/ReferenceEndDate', endDate);

			if (this.getConfigurationModel().isVariantEnabled()) {
				this.setVariantsToModel();
			}

			$.when(
					this.oDataUtil.read('WorkCenterSet', workCenterParameters),
					this.oDataUtil.read('PlanningGroupSet', planGroupParameters)
				)
				.done(this.handleUserParametersObjectsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
		},

		handleUserParametersObjectsSuccess: function(workcenters, planGroups) {
			this.getModel('ViewModel').setProperty('/FilterParameters/Workcenters', workcenters);
			this.getModel('ViewModel').setProperty('/FilterParameters/Plangroups', planGroups);

			this.initialFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));

			var filterParams = this.getModel('ViewModel').getProperty('/FilterParameters');
			this.getModel('ViewModel').setProperty('/OriginalFilterParameters', this.generateFilterParametersCopy(filterParams));
			this.setDefaultVariant();
		},

		handleListRefresh: function() {
			this.areObjectsIdentical(
				this.getModel('ViewModel').getProperty('/FilterParameters'),
				this.initialFilterParameters
			) ? this.refreshOfflineOrders() : this.getFilteredOrders();
		},

		refreshOfflineOrders: function() {
			if (this.isHybridApplicationUser()) {
				this.setAppBusyMode();

				this.refreshOrders()
					.always(function() {
						if (this.getElementById('pullToRefresh')) {
							this.getElementById('pullToRefresh').hide();
						}
						this.setAppNotBusyMode();
					}.bind(this));
			} else {
				this.getOrdersForBrowser();
			}
		},

		getOrdersForBrowser: function() {
			var parameters = {
				recordOperation: true,
				urlParameters: {
					'$expand': this.getConfigurationModel().getOrderURLParameters()
				}
			};

			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}
			this.getOrders(parameters);
		},

		getFilteredOrders: function() {
			var parameters = {
				online: true,
				filters: this.constructFilterArray(),
				recordOperation: true,
				urlParameters: {
					'$expand': this.getConfigurationModel().getOrderURLParameters()
				}
			};

			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}

			this.getOrders(parameters);
		},

		getOrders: function(parameters) {
			this.openBusyDialog({
				service: 'WorkOrderSet'
			});

			parameters = parameters || {};
			parameters.returnSapMessages = true;
			this.oDataUtil.read('WorkOrderSet', parameters)
				.done(this.handleGetOrdersSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(function() {
					if (this.getElementById('pullToRefresh')) {
						this.getElementById('pullToRefresh').hide();
					}
					this.closeBusyDialog();
				}.bind(this));
		},

		handleGetOrdersSuccess: function(orders, sapMessages) {
			if (orders) {
				this.getModel('OrdersModel').setProperty('/Orders', orders.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
			}
			if (sapMessages) {
				this.checkIfAllResultsDisplayed(sapMessages);
			}
		},

		handleScanSuccess: function(result) {
			this.getElementById('orderSearchField').setValue(result.text || '');

			this.filterOrders(result.text || '');
		},

		filterOrders: function(searchValue) {
			this.getElementById('orderListContainer')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('ShortText', [searchValue], 'Contains')
						.concat(
							this.generateFilter('FunctLoc', [searchValue.toUpperCase()], 'Contains'),
							this.generateFilter('FunctLocDescr', [searchValue.toUpperCase()], 'Contains'),
							this.generateFilter('Equipment', [searchValue.toUpperCase()], 'Contains'),
							this.generateFilter('EquipmentDescr', [searchValue.toUpperCase()], 'Contains'),
							this.generateFilter('Orderid', [searchValue.toUpperCase()], 'Contains')
						)
					)
				]);
		},

		shouldShowMaster: function(navigationData) {
			return !!(
				this.isOrdersRoute() &&
				(this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'Orders') ||
					this.navigatedToDetailViewFromView(navigationData, 'CreateOrder', 'Orders') ||
					this.navigatedToDetailViewFromView(navigationData, 'CreateNotification', 'Orders'))
			);
		},

		shouldHideMaster: function(navigationData) {
			return !!(this.navigatedToDetailViewFromView(navigationData, 'NotificationSplitContainer', 'CreateOrder'));
		},

		isOrdersRoute: function() {
			return location.hash.split('/').pop() === 'Orders';
		},

		isDisplayOrderRoute: function() {
			return location.hash.split('/').indexOf('CreateOrder') !== -1 &&
				(location.hash.split('/').indexOf('Display') !== -1 || location.hash.split('/').indexOf('Edit') !== -1);
		},

		addListFunctionalLocationToModel: function(functionalLocations) {
			this.getModel('ViewModel').setProperty(
				'/FilterParameters/FunctLocs',
				this.getModel('ViewModel').getProperty('/FilterParameters/FunctLocs')
				.concat(functionalLocations)
				.filter(this.filterDublicateFunctionalLocations)
			);
		},

		constructFilterArray: function() {
			var filterObject = this.getModel('ViewModel').getProperty('/FilterParameters');

			var arrayOfValues = [
				filterObject.Plant, filterObject.FunctLocs, filterObject.WorkOrderTypes,
				filterObject.Priority, filterObject.Workcenters, filterObject.Plangroups,
				filterObject.SystemCondition, filterObject.Revision
			];
			var arrayOfDateValues = [
				[filterObject.ReferenceStartDate, filterObject.ReferenceEndDate]
			];

			return this.createArray(arrayOfValues, arrayOfDateValues);
		},

		createArray: function(arrayOfValues, arrayOfDateValues) {
			var arrayParametersToIndecies = {
				'FunctLocInternalId': 1,
				'Workcenter': 4,
				'Plangroup': 5,
				'OrderType': 2,
				'SystemStatus': 6
			};

			var arrayOfProperties = [
				'WorkcenterPlant', 'FunctLocInternalId', 'OrderType',
				'Priority', 'Workcenter', 'Plangroup',
				'SystemStatus', 'Revision'
			];

			var servicePropertyToObjectKey = {
				'FunctLocInternalId': 'InternalId',
				'Workcenter': 'Workcenter',
				'Plangroup': 'Plangroup',
				'OrderType': 'OrderType',
				'SystemStatus': 'StatusInt'
			};

			var arrayOfDateProperties = ['ReferenceDate'];

			var filterArray = arrayOfProperties.reduce(function(array, value, index) {
				var parameter = '';

				if (arrayParametersToIndecies[value]) {
					parameter = (arrayOfValues[arrayParametersToIndecies[value]] || []).map(function(parameterObject) {
						return parameterObject[servicePropertyToObjectKey[value]];
					}).join(',');
				} else {
					parameter = arrayOfValues[index];
				}
				return parameter ? array.concat(this.generateFilter(value, parameter.split(','))) : array;
			}.bind(this), []);

			filterArray = arrayOfDateValues.reduce(function(array, value, i) {
				return value[1] && value[0] ? array.concat(new sap.ui.model.Filter(arrayOfDateProperties[i], sap.ui.model.FilterOperator.BT, value[1].setHours(12), value[0].setHours(12))) : array;
			}, filterArray);

			return filterArray;
		},

		setVariantsToModel: function() {
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/Existing', this.getVariantsWithType('ORDERS'));
			this.getModel('ViewModel').setProperty('/Variants', this.getVariantsWithTypeSelectionList('ORDERS'));
		},

		setDefaultVariant: function() {
			var defaults = this.getDefaultVariants();
			var defaultVariant = '000';
			if (defaults['ORDERS']) {
				defaultVariant = defaults['ORDERS'];
			}
			this.getModel('ViewModel').setProperty('/SelectedVariant', defaultVariant);
			this.onSelectedVariantChange();
		}

	});
});