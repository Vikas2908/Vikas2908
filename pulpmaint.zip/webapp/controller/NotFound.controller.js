sap.ui.define([
	'com/upm/maint/controller/BaseController'

], function(BaseController) {
	'use strict';
	return BaseController.extend('com.upm.maint.controller.NotFound', {
		onInit: function() {}
	});
});