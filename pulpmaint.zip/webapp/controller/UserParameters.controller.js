sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.UserParameters', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			var that = this;

			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel', {
				UserParameters: {},
				FunctionalLocationTokenValue: '',
				PeronsMyWorkTokenValue: '',
				PrinterTokenValue: '',
				FunctionalLocationIsValid: true,
				IsScanningFunctionalLocationForList: false,
				PushNotificationState: false
			});
			this.setModel('VariantSelection', {});

			this.subscribeToEvent('app', 'navigate', this.handleNavigate.bind(this));
			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'UserParameterFunctionalLocation', this.handleFunctionalLocationSelected.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'UserParameterListFunctionalLocations', this.handleListFunctionalLocationsSelected.bind(this));

			this.getElementById('functionalLocationLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};

			if (!this.isHybridApplicationUser()) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.getUserParameterObject.bind(this));
			}
		},

		onAfterRendering: function() {
			this.renderInputs();
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'UserParameters') {
				var isMissingRequiredParameters = !!navigationEvent.getParameter('arguments').MissingRequiredParamaters;

				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getModel('ViewModel').setProperty('/NavigatedToEnterRequiredParameters', isMissingRequiredParameters);

				this.getModel('ViewModel').updateBindings(true);
			}
		},

		handleNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView) && !this.navigatedToViewFromView(navigationData, 'FunctionalLocationHierarchy')) {
				this.getUserParameterObject();
			} else if (!this.navigatedToViewFromView(navigationData, 'TilePage') && this.navigatedToCurrentView('TilePage') && !this.isHybridApplicationUser()) {
				this.getUserParameterObject();
			} else if (this.navigatedToViewFromView(navigationData, 'EditVariants')) {
				this.setVariantSelectionLists();
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToCurrentView(navigationData.toView)) {
				this.removeInvisibleLabels();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			if (this.hasRequiredParameters()) {
				this.shouldShowWarningMessage() ?
					this.openNavigationConfimation() :
					this.onNavBack();
			} else {
				this.openEnterRequiredParameters();
			}
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('UserParametersActionButtons').openBy(pressEvent.getSource());
		},

		onLogOutPress: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('CONFIRM_LOG_OUT_TEXT'),
				onClose: this.handleLogOutConfirmPopUpClose.bind(this),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		onRefreshOfflineStorePress: function() {
			this.setAppBusyMode();

			this.refreshAllOfflineRequests()
				.done(this.getUserParameterObject.bind(this))
				.always(this.setAppNotBusyMode);
		},

		onPushOfflineChangesPress: function() {
			this.setAppBusyMode();

			this.flushOfflineStore()
				.always(this.setAppNotBusyMode);
		},

		onPlantValueHelp: function() {
			this.openDialog('SearchDialog', this.getPlantDialogParameters());
		},

		onFunctionalLocationInputChange: function(oEvent) {
			var functionalLocation = oEvent.getParameter('newValue').substr(
				0,
				oEvent.getParameter('newValue').indexOf(' - ') !== -1 ?
				oEvent.getParameter('newValue').indexOf(' - ') :
				oEvent.getParameter('newValue').length
			);
			this.validateFunctionalLocation(functionalLocation.toUpperCase())
				.done(this.functionalLocationValid.bind(this))
				.fail(this.functionalLocationNotValid.bind(this));
		},

		onFunctionalLocationValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'UserParameterFunctionalLocation');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onListFunctionalLocationsValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'UserParameterListFunctionalLocations');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onListFunctionalLocationSuggestionItemSelected: function(selectEvent) {
			this.handleFunctionalLocationSuggestionItemSelected(selectEvent, '/UserParameters/FunctLocs');
		},

		onListFunctionalLocationTokensAdd: function(tokensToAdd, action) {
			if (action === 'OK') {
				this.addListFunctionalLocationToModel(tokensToAdd);
			}

			this.getModel('ViewModel').setProperty('/FunctionalLocationTokenValue', '');
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'UserParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'UserParameters/Plangroups'
				})
			);
		},

		onRouteValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getRouteDialogParameters({
					firstValueToSave: 'UserParameters/Routes'
				})
			);
		},

		onMyWorkPersonsValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPersonDialogParameters({
					firstValueToSave: 'UserParameters/Persons',
					secondValueToSave: '',
					configurationModelName: 'SelectionValuesModel',
					pathToModel: '/Persons',
					multiSelect: true
				})
			);
		},

		onPartnerSuggestionItemSelected: function(selectEvent) {
			var selectedPerson = selectEvent.getParameter('selectedRow').getBindingContext().getObject();

			this.getModel('ViewModel').setProperty('/UserParameters/PersonNumber', selectedPerson.PersonNumber);
			this.getModel('ViewModel').setProperty('/UserParameters/Fullname', selectedPerson.Fullname);
		},

		onMyWorkPersonSuggestionItemSelected: function(selectEvent) {
			var selectedPerson = selectEvent.getParameter('selectedRow').getBindingContext().getObject();

			this.getModel('ViewModel').setProperty(
				'/UserParameters/Persons',
				this.getModel('ViewModel').getProperty('/UserParameters/Persons')
				.concat([selectedPerson])
			);

			setTimeout(function(storedSelectEvent) {
				this.getModel('ViewModel').setProperty('/PeronsMyWorkTokenValue', '');
				storedSelectEvent.getSource()._oPopupInput && storedSelectEvent.getSource()._oPopupInput.setValue('');
			}.bind(this, $.extend(true, {}, selectEvent)), 0);
		},

		onSaveButtonPress: function() {
			this.hasValidUserParameters() ?
				this.postUserParameters(this.isHybridApplicationUser() ? this.refreshListValues.bind(this) : this.refreshUserParameters.bind(this)) :
				this.getModel('ViewModel').updateBindings();
		},

		onPressScanFunctionalLocationForList: function() {
			this.getModel('ViewModel').setProperty('/IsScanningFunctionalLocationForList', true);

			this.onPressScanTechnicalObject();
		},

		onPressScanFunctionalLocation: function() {
			this.getModel('ViewModel').setProperty('/IsScanningFunctionalLocationForList', false);

			this.onPressScanTechnicalObject();
		},

		onFunctionalLocationTokenUpdate: function(updateEvent) {
			this.onTokenUpdate(updateEvent);

			updateEvent.getSource().setValueState && updateEvent.getSource().setValueState('None');

			this.getModel('ViewModel').setProperty('/FunctionalLocationTokenValue', '');
		},

		onUserInfoButtonPress: function(pressEvent) {
			this.initializeFragment('UserInfo').openBy(pressEvent.getSource());
		},

		onUserDialogCloseButtonPress: function() {
			this.getDialog('UserInfo').close();
		},

		onIsMultiUserDevicePress: function(selectEvent) {
			var isMultiUserDevice = selectEvent.getParameter('selected');

			window.localStorage.setItem('isMultiUserDevice', isMultiUserDevice ? 'true' : 'false');
			this.getGlobalModel('/IsMultiUserDevice', isMultiUserDevice);
		},

		onEditOrderVariants: function() {
			this.navTo('EditVariants', {
				type: 'ORDERS'
			});
		},

		onEditNotificationVariants: function() {
			this.navTo('EditVariants', {
				type: 'NOTIFS'
			});
		},

		onEditMyWorkVariants: function() {
			this.navTo('EditVariants', {
				type: 'MYWORKS'
			});
		},

		onEditRouteVariants: function() {
			this.navTo('EditVariants', {
				type: 'ROUTES'
			});
		},

		onOrderDefaultVariantChange: function() {
			var selectionValue = this.getModel('VariantSelection').getProperty('/Selections/ORDERS');
			this.setVariantSelectBusy('ORDERS', true);
			this.variantSetDefault(selectionValue, 'ORDERS')
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setVariantSelectBusy.bind(this, 'ORDERS', false));
		},

		onNotificationDefaultVariantChange: function() {
			var selectionValue = this.getModel('VariantSelection').getProperty('/Selections/NOTIFS');
			this.setVariantSelectBusy('NOTIFS', true);
			this.variantSetDefault(selectionValue, 'NOTIFS')
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setVariantSelectBusy.bind(this, 'NOTIFS', false));
		},

		onMyWorkDefaultVariantChange: function() {
			var selectionValue = this.getModel('VariantSelection').getProperty('/Selections/MYWORKS');
			this.setVariantSelectBusy('MYWORKS', true);
			this.variantSetDefault(selectionValue, 'MYWORKS')
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setVariantSelectBusy.bind(this, 'MYWORKS', false));
		},

		onRouteDefaultVariantChange: function() {
			var selectionValue = this.getModel('VariantSelection').getProperty('/Selections/ROUTES');
			this.setVariantSelectBusy('ROUTES', true);
			this.variantSetDefault(selectionValue, 'ROUTES')
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setVariantSelectBusy.bind(this, 'ROUTES', false));
		},

		onPushNotificationsStateChange: function() {
			// var bState = this.getModel('ViewModel').getProperty('/UserParameters/PushNotifsDisabled');
			// this.pushNotificationStatusChange(!bState);
		},

		onDateRangeChange: function() {
			var value = this.getModel('ViewModel').getProperty('/UserParameters/DateRange') || '';
			if (value) {
				this.getModel('ViewModel').setProperty('/UserParameters/MaxResults', '');
			}
		},

		onMaxResultsChange: function() {
			var value = this.getModel('ViewModel').getProperty('/UserParameters/MaxResults') || '';
			if (value) {
				this.getModel('ViewModel').setProperty('/UserParameters/DateRange', '');
			}
		},

		onAlternativeLabelCategoryChange: function(selectEvent) {
			var busyPath = '/isDownloadingFunctionalLocations';
			var userParameterProperties = this.getUserParameterPropertieCodes();
			var userParameterProperty = Object.keys(userParameterProperties).filter(function(key) {
				return userParameterProperties[key] === 'AlternativeLabelCategory';
			});
			var object = selectEvent.getParameter('selectedItem').getBindingContext('SelectionValuesModel').getObject();

			this.setPathBusy(busyPath);
			this.postUserParameter(userParameterProperty[0], object.Id)
				.done(function() {
					this.refreshFunctionalLocationValues()
						.done(this.changeFunctionalLocationLabels.bind(this))
						.always(this.setPathNotBusy.bind(this, busyPath));
				}.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		renderInputs: function() {
			if (this.isHybridApplicationUser()) {
				this.renderSuggestionInput(this.getElementById('functionalLocationInputField'));
				this.renderSuggestionInput(this.getElementById('listFunctionalLocationInputControl'));
			}

			this.getElementById('listFunctionalLocationInputControl')
				.addValidator(this.functionalLocationListValidator.bind(this));
			this.getElementById('printerMultiInputControl')
				.addValidator(this.printerValidator.bind(this));
		},

		handleScanSuccess: function(result) {
			if (this.getModel('ViewModel').getProperty('/IsScanningFunctionalLocationForList')) {
				this.validateFunctionalLocation(result.text)
					.done(function(response) {
						this.addListFunctionalLocationToModel([{
							Floc: response.Floc,
							InternalId: response.InternalId
						}]);
					});
			} else {
				this.validateFunctionalLocation(result.text)
					.done(this.functionalLocationValid.bind(this))
					.fail(this.functionalLocationNotValid.bind(this));
			}
		},

		handleLogOutConfirmPopUpClose: function(action) {
			action !== 'OK' || this.devapp.devLogon.doLogOut();
		},

		openEnterRequiredParameters: function() {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('ENTER_REQUIRED_PARAMETERS_TITLE'),
				message: this.getResourceBundleText('ENTER_REQUIRED_PARAMETERS_TEXT')
			});
		},

		getUserParameterObject: function() {
			var userParameters = this.getUserParameters();

			var workCenterParameters = {
				filters: this.generateFilter('Workcenter', userParameters.Workcenters && userParameters.Workcenters.split(',') || [''])
			};
			var planGroupParameters = {
				filters: this.generateFilter('Plangroup', userParameters.Plangroups && userParameters.Plangroups.split(',') || [''])
			};

			if (!userParameters.DateRange && !userParameters.MaxResults) {
				userParameters.DateRange = userParameters.DateRange || '0090';
			}

			if (!userParameters.AlternativeLabelCategory) {
				userParameters.AlternativeLabelCategory = this.getDefaultCategory();
			}

			if (userParameters.FunctLocInternalId) {
				this.validateFunctionalLocationInternalId(userParameters.FunctLocInternalId)
					.done(function(response) {
						this.getModel('ViewModel').setProperty('/UserParameters/FunctLoc', response.Floc);
						this.getModel('ViewModel').setProperty('/UserParameters/FunctLocDescr', response.Descr);
					}.bind(this));
			}

			this.getModel('ViewModel').setProperty('/UserParameters', $.extend(true, {}, userParameters, {
				Workcenters: [],
				Plangroups: [],
				FunctLocs: [],
				Persons: this.handleMultipleParameters(userParameters.Persons, 'PersonNumber'),
				Routes: this.handleMultipleParameters(userParameters.Routes, 'RouteId'),
				Printers: this.handleMultipleParameters(userParameters.Printers, 'Printer'),
				Warehouse: userParameters.Warehouse || '',
				PushNotifsDisabled: userParameters.PushNotifsDisabled || ''
			}));

			if (userParameters.FunctLocs) {
				this.tokensAreValid(userParameters.FunctLocs.toUpperCase().split(',').map(this.removeWhiteSpace))
					.done(this.addListFunctionalLocationToModel.bind(this))
					.fail(function() {
						this.getModel('ViewModel').setProperty('/UserParameters/FunctLocs', []);
					}.bind(this));
			}

			$.when(
					this.oDataUtil.read('WorkCenterSet', workCenterParameters),
					this.oDataUtil.read('PlanningGroupSet', planGroupParameters)
				)
				.done(this.handleUserParametersObjectsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));

			this.setVariantSelectionLists();
		},

		handleUserParametersObjectsSuccess: function(workcenters, planGroups) {
			this.getModel('ViewModel').setProperty('/UserParameters/Workcenters', workcenters);
			this.getModel('ViewModel').setProperty('/UserParameters/Plangroups', planGroups);

			this.initialUserParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/UserParameters'));

			this.getModel('ViewModel').updateBindings();

			this.publishEvent('userParameters', 'update');
		},

		handlePlantSelected: function() {
			setTimeout(function() {
				var plant = this.getModel('ViewModel').getProperty('/UserParameters/Plant');
				this.getModel('ViewModel').setProperty('/UserParameters', {
					Plant: plant,
					FunctLoc: '',
					Workcenters: [],
					Plangroups: [],
					FunctLocs: [],
					Persons: [],
					Routes: [],
					Printers: Array.isArray(this.getModel('ViewModel').getProperty('/UserParameters/Printers')) ? this.getModel('ViewModel').getProperty('/UserParameters/Printers') : [],
					DateRange: this.getModel('ViewModel').getProperty('/UserParameters/DateRange') || '',
					Warehouse: ''
				});
				this.postUserParameters(this.isHybridApplicationUser() ? this.refreshPlantSpecificValues.bind(this) : this.handlePlantSaved.bind(this));
			}.bind(this), 0);
		},

		shouldShowWarningMessage: function() {
			return !this.areObjectsIdentical(
				this.getModel('ViewModel').getProperty('/UserParameters'),
				this.initialUserParameters
			);
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.onNavBack();
		},

		hasValidUserParameters: function() {
			var userParameters = this.getModel('ViewModel').getProperty('/UserParameters');
			var requiredKeys = [
				['Plant', 'plantInputField']
			];

			var invalidProperties = requiredKeys.reduce(function(invalidInputs, key) {
				return (!userParameters[key[0]] || Array.isArray(userParameters[key[0]]) && userParameters[key[0]].length === 0) ?
					invalidInputs.concat(key[1]) :
					invalidInputs;
			}, []);

			if ((!userParameters['Workcenters'] || userParameters['Workcenters'].length === 0) && (!userParameters['Plangroups'] && userParameters['Plangroups'].length === 0) && this.isHybridApplicationUser()) {
				invalidProperties.push('workCenterInputField');
			}

			if (invalidProperties.length) {
				invalidProperties = invalidProperties.map(this.getControl.bind(this));
				invalidProperties.forEach(this.changeValueStates.bind(this));
				invalidProperties.forEach(this.removeValueStateOnChange.bind(this));

				this.scrollToElement(20, invalidProperties);
			}

			return !invalidProperties.length;
		},

		getControl: function(controlId) {
			return this.getElementById(controlId);
		},

		changeValueStates: function(control) {
			control.setValueState('Error');
		},

		removeValueStateOnChange: function(control) {
			control.attachEventOnce('valueHelpRequest', this.hideControlError.bind(this, control));
			control.attachEventOnce('change', this.hideControlError.bind(this, control));
		},

		hideControlError: function(control) {
			control.setValueState('None');
		},

		postUserParameters: function(successHandler) {
			this.setAppBusyMode();

			$.when.apply(this, this.getUpdateMethods())
				.done(this.handlePostUserParametersSuccess.bind(this, successHandler))
				.fail(this.openErrorMessagePopup.bind(this), this.setAppNotBusyMode);
		},

		getUpdateMethods: function() {
			var userParameterPropertieCodes = this.getUserParameterPropertieCodes();
			var userParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/UserParameters'));
			var arrayUserParameters = {
				'03': 'InternalId',
				'04': 'Workcenter',
				'05': 'Plangroup',
				'23': 'PersonNumber',
				'24': 'RouteId',
				'41': 'Printer'
			};
			return Object.keys(userParameterPropertieCodes).map(function(propertyToPost) {
				var userParameter = '';
				if (arrayUserParameters[propertyToPost]) {
					userParameter = (Array.isArray(userParameters[userParameterPropertieCodes[propertyToPost]]) ? userParameters[userParameterPropertieCodes[propertyToPost]] : []).map(function(userParameterObject) {
						return userParameterObject[arrayUserParameters[propertyToPost]];
					}).join(',');
				} else {
					userParameter = userParameters[userParameterPropertieCodes[propertyToPost]] || '';
				}
				return this.postUserParameter(propertyToPost, userParameter);
			}.bind(this));
		},

		postUserParameter: function(propertyToPost, userParameter) {
			return this.oDataUtil.update('UserParamSet(UserId=\'' + this.getUserId() + '\',ParamType=\'' + propertyToPost + '\')', {
				ParamType: propertyToPost,
				UserId: this.getUserId(),
				UserParameter: userParameter
			}, {
				online: true
			});
		},

		handlePostUserParametersSuccess: function(successHandler) {
			successHandler()
				.done(function() {
					if (this.hasRequiredParameters() && this.getModel('ViewModel').getProperty('/NavigatedToEnterRequiredParameters')) {
						this.publishEvent('userParameters', 'update');

						this.onNavBack();
					} else if (this.hasRequiredParameters()) {
						this.publishEvent('userParameters', 'update');
					}
					this.initialUserParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/UserParameters'));
				}.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		handlePlantSaved: function() {
			this.setAppNotBusyMode();

			this.getModel('ViewModel').setProperty('/IsDownloadingPlatSpecificValues', true);

			this.refreshPlantSpecificValues()
				.done(function() {
					this.getModel('ViewModel').setProperty('/UserParameters/AlternativeLabelCategory', this.getDefaultCategory());
				}.bind(this))
				.always(function() {
					this.getModel('ViewModel').setProperty('/IsDownloadingPlatSpecificValues', false);
				}.bind(this));

			return this.refreshUserParameters();
		},

		changeFunctionalLocationLabels: function() {
			var selectedFunctionalLocation = this.getUserParameters().FunctLoc;

			if (selectedFunctionalLocation) {
				this.validateFunctionalLocationInternalId(selectedFunctionalLocation)
					.done(function(response) {
						this.getModel('ViewModel').setProperty('/UserParameters/FunctLoc', response.Floc);
						this.getModel('ViewModel').setProperty('/UserParameters/FunctLocDescr', response.Descr);
					}.bind(this));
			}
		},

		functionalLocationValid: function(functionalLocationObject) {
			if (functionalLocationObject) {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);

				this.getModel('ViewModel').setProperty('/UserParameters/FunctLocInternalId', functionalLocationObject.InternalId);
				this.getModel('ViewModel').setProperty('/UserParameters/FunctLoc', functionalLocationObject.Floc);
				this.getModel('ViewModel').setProperty('/UserParameters/FunctLocDescr', functionalLocationObject.Descr);
			} else {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);
				this.getModel('ViewModel').setProperty('/UserParameters/FunctLocInternalId', '');
				this.getModel('ViewModel').setProperty('/UserParameters/FunctLoc', '');
				this.getModel('ViewModel').setProperty('/UserParameters/FunctLocDescr', '');
			}
		},

		functionalLocationNotValid: function() {
			this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', false);
		},

		handleFunctionalLocationSelected: function(channel, eventName, selectedObject) {
			this.validateFunctionalLocation(selectedObject.InternalId)
				.done(this.functionalLocationValid.bind(this))
				.fail(this.functionalLocationNotValid.bind(this));
		},

		addListFunctionalLocationToModel: function(functionalLocations) {
			this.getModel('ViewModel').setProperty(
				'/UserParameters/FunctLocs',
				this.getModel('ViewModel').getProperty('/UserParameters/FunctLocs')
				.concat(functionalLocations)
				.filter(this.filterDublicateFunctionalLocations)
			);
		},

		printerValidator: function(token) {
			var busyPath = '/IsValidatingPrinter';
			var printer = token.text;
			var parameters = {
				online: true
			};
			this.setPathBusy(busyPath);

			this.oDataUtil.read('PrinterSet(\'' + printer + '\')', parameters)
				.done(this.handlePrinterValidationSuccess.bind(this))
				.fail(this.handlePrinterValidationError.bind(this, printer))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		handlePrinterValidationSuccess: function(printer) {
			this.getModel('ViewModel').setProperty(
				'/UserParameters/Printers',
				this.getModel('ViewModel').getProperty('/UserParameters/Printers')
				.concat([{
					Printer: printer.PrinterId,
					PrinterDescription: printer.Location
				}])
			);

			this.getModel('ViewModel').setProperty('/PrinterTokenValue', '');

			if (this.getElementById('printerMultiInputControl')._oPopupInput) {
				this.getElementById('printerMultiInputControl')._oPopupInput.setValue('');
			}

			this.getElementById('printerMultiInputControl').getBinding('value').refresh(true);
			this.getElementById('printerMultiInputControl').getBinding('tokens').refresh(true);
		},

		handlePrinterValidationError: function(printer) {
			this.showMessageBox({
				type: 'Info',
				title: this.getResourceBundleText('PRINTER_NOT_FOUND_TITLE'),
				message: this.getResourceBundleText('PRINTER_NOT_FOUND_MESSAGE', printer)
			});
		},

		AdGroupTextFactory: function(id, bindingContext) {
			var group = bindingContext.getObject();
			var groupName = group && group.split(',').shift() || '';
			var shortenedGroupName = groupName.replace('CN=GLO Apps SAP Cloud Platform ', '');
			return new sap.m.Text(id, {
				text: shortenedGroupName
			});
		},

		setVariantSelectionLists: function() {
			var defaultVariants = this.getDefaultVariants();
			var orderVariants = this.getVariantsWithTypeSelectionList('ORDERS');
			var notifVariants = this.getVariantsWithTypeSelectionList('NOTIFS');
			var myWorkVariants = this.getVariantsWithTypeSelectionList('MYWORKS');
			var routeVariants = this.getVariantsWithTypeSelectionList('ROUTES');


			this.getModel('VariantSelection').setData({
				Selections: defaultVariants,
				Orders: orderVariants,
				Notifs: notifVariants,
				MyWorks: myWorkVariants,
				Routes: routeVariants,
				IsBusy: {}
			});
		},

		setVariantSelectBusy: function(sType, bBusy) {
			this.getModel('VariantSelection').setProperty('/IsBusy/' + sType, bBusy);
		}

	});
});