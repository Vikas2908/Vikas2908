sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController',
	'com/upm/maint/util/GroupHeaderListItem'
], function(CommonController, BaseController, GroupHeaderListItem) {
	return CommonController.extend('com.upm.maint.controller.Routes', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				FilterParameters: {},
				HasSelectedRoutes: false,
				SaveVariantDialog: {
					CreateNew: false,
					IsDefault: false,
					IsBusy: false
				},
				Variants: [],
				OriginalFilterParameters: {},
				SelectedVariant: ''
			};

			this.setModel('ViewModel', initialViewModel);
			this.getModel('ViewModel').setSizeLimit(9999);

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));

			this.subscribeToEvent('userParameters', 'update', this.getFilterParameters.bind(this));
			this.subscribeToEvent('root', 'variantsUpdated', this.setVariantsToModel.bind(this));

			this.getElementById('routeSearchField')._getValueHelpIcon().setSrc(this.isScannerAvailable() ? 'sap-icon://camera' : 'sap-icon://refresh');

			this.getFilterParameters();

			if (!this.isHybridApplicationUser() && this.isRoutesRoute()) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.getFilterParameters.bind(this));
				this.getRoutesForBrowser();
			}
		},

		onAfterRendering: function() {
			if (this.isTablet()) {
				this.getParentController().showMaster();
			}
			var scrollContainer = this.getElementById('routeListContainer').getParent();
			$('#' + scrollContainer.getId() + '-Flexible').scroll(this.listScrollHandling.bind(this));
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Routes') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				window.setTimeout(this.sortRoutes.bind(this), 0);
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.shouldShowMaster(navigationData)) {
				this.getParentController().showMaster();
				this.setCurrentPM12RouteWork();
				var routeId = this.getUrlParameter('RouteId') || '';
				if (routeId) {
					this.onHandleRouteObjectNavigation(routeId);
				}
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onRouteIdChange: function() {
			setTimeout(function() {
				this.filterRouteList(this.getElementById('routeSearchField').getValue());
			}.bind(this), 0);
		},

		onRouteIdValueChange: function() {
			var routeIdValue = this.getModel('ViewModel').getProperty('/RouteIdValue') || '';
			routeIdValue = routeIdValue.toUpperCase();
			routeIdValue = routeIdValue.split(' - ')[0];
			var routeIds = '';
			var selectedRoute = {};

			if (routeIdValue) {
				var routes = this.getModel('ViewModel').getProperty('/FilteredRoutes') || [];
				var hasWildCard = routeIdValue.endsWith('*');
				if (hasWildCard) {
					routeIdValue = routeIdValue.replace(/\*/g, '');
				}
				routes.map(function(route) {
					if (hasWildCard && (route.Orderid || '').indexOf(routeIdValue) > -1) {
						routeIds = routeIds ? routeIds + ',' + (route.Orderid || '') : (route.Orderid || '');
					} else if (!hasWildCard && routeIdValue.indexOf(route.Orderid) > -1) {
						routeIds = routeIds ? routeIds + ',' + route.Orderid : route.Orderid;
						selectedRoute = route;
					}
				});
			}
			this.getModel('ViewModel').setProperty('/RouteId', routeIds ? routeIds : routeIdValue);
			if (routeIds.split(',').length < 2 && selectedRoute.RouteId) {
				this.getModel('ViewModel').setProperty('/RouteIdValue', this.formatterUtil.formatInputValue(selectedRoute.RouteId, selectedRoute.RouteDescr));
			}
			this.onRouteIdChange();
		},

		onRouteSuggestion: function(oEvent) {
			oEvent.getSource().getBinding('suggestionRows').filter([
				new sap.ui.model.Filter(
					this.generateFilter('RouteId', [oEvent.getParameter('suggestValue')], 'Contains')
					.concat(this.generateFilter('RouteDescr', [oEvent.getParameter('suggestValue')], 'Contains'))
				)
			]);
		},

		onListSelectionChange: function() {
			setTimeout(function() {
				var list = this.getElementById('routeListContainer');

				var allItemsAreSelectedFromList = list.getItems().length && list.getItems().length === list.getSelectedItems().length;

				var itemsAreSelected = list.getSelectedItems().length !== 0;

				this.getModel('ViewModel').setProperty('/HasSelectedRoutes', itemsAreSelected);

				this.getElementById('selectAllCheckBox').setSelected(allItemsAreSelectedFromList);
			}.bind(this), 0);
		},

		onSelectAllButtonPress: function() {
			this.getModel('ViewModel').getProperty('/HasSelectedRoutes') ?
				this.getElementById('routeListContainer').selectAll() :
				this.getElementById('routeListContainer').removeSelections(true);
		},

		onSelectAllPress: function(selectEvent) {
			var list = this.getElementById('routeListContainer');

			if (selectEvent.getParameter('selected')) {
				list.selectAll();
			} else {
				list.removeSelections(true);
			}

			this.getModel('ViewModel').setProperty('/HasSelectedRoutes', selectEvent.getParameter('selected'));
		},

		onMasterListItemPress: function(pressEvent) {
			var routeObject = pressEvent
				.getParameter('listItem')
				.getBindingContext('RoutesModel')
				.getObject();

			this.onRouteObjectPress(routeObject);
		},

		onHandleRouteObjectNavigation: function(orderId) {
			var routes = this.getModel('RoutesModel').getProperty('/Routes') || [];
			var matchingRoutes = [];
			var pm12Routes = [];
			routes.map(function(route) {
				if (route.Orderid === orderId) {
					matchingRoutes.push(route);
					if (route.OrderType === 'PM12') {
						pm12Routes.push(route);
					}
				}
			});
			var routeObject = false;
			if (pm12Routes.length) {
				routeObject = pm12Routes[0];
			} else if (matchingRoutes.length) {
				routeObject = matchingRoutes[0];
			}
			if (routeObject) {
				this.onRouteObjectPress(routeObject);
			}
		},

		onRouteObjectPress: function(routeObject) {
			var routeName = routeObject.RouteId;

			if (!this.routeIsInProgress(routeName)) {
				this.setRouteWorksForProcessing(routeObject);
			} else {
				this.setRouteInProgressIndex(routeObject);
			}

			this.getModel('EditRouteModel').setData($.extend(true, {}, routeObject));
			this.setLatestRouteOrderId(routeObject.Orderid || '');

			this.navTo('EditRoute', {
				Purpose: 'Display',
				RouteNumber: routeObject.Orderid
			}, this.getModel('Device').getProperty('/isNoPhone'));
			this.getParentController().hideMaster();
		},

		onAdvancedSearchPress: function() {
			if (!this.getDialog('RoutesAdvancedSearch')) {
				this.initializeFragment('RoutesAdvancedSearch').open();
			} else {
				this.openSimpleDialog('RoutesAdvancedSearch');
			}

			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
		},

		onAdvancedSearch: function() {
			this.getFilteredRoutes();
			this.getDialog('RoutesAdvancedSearch').close();
			this.setFilterAbleRoutes(this.getModel('ViewModel').getProperty('/FilterParameters/Routes').map(function(route) {
				return route.RouteId;
			}));

			this.getModel('ViewModel').setProperty('/RouteId', '');

			this.getElementById('routeSearchField').setValue('');

			this.filterRouteList('');
		},

		onOrderTypeValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getOrderTypeDialogParameters({
					filters: this.generateFilter('Route', ['X']).concat(this.generateFilter('OrderType', [''], 'NE'))
				})
			);
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'FilterParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'FilterParameters/Plangroups'
				})
			);
		},

		onRouteValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getRouteDialogParameters({
					firstValueToSave: 'FilterParameters/Routes'
				})
			);
		},

		onCloseAdvancedSearch: function() {
			this.getDialog('RoutesAdvancedSearch').close();
		},

		onRouteLiveSearch: function(searchEvent) {
			this.filterRouteList(searchEvent.getParameter('newValue'));
		},

		onRoutePullToRefresh: function() {
			this.handleListRefresh();
		},

		onCompleteButtonPress: function() {
			var selectedItems = this.getElementById('routeListContainer').getSelectedItems();
			var selectedObjects = selectedItems.map(function(selectedItem) {
				var routeObject = selectedItem
					.getBindingContext('RoutesModel')
					.getObject();
				// routeObject.Completed = 'X';
				routeObject.ProcessInd = 'X';
				if (this.isOffline()) {
					routeObject.NotSync = true;
					this.insertRouteToList(routeObject);
					this.localStorage.insertRoute(routeObject);
				}
				return routeObject;
			}.bind(this));
			var busyPath = '/IsRouteListBusy';
			if (this.isOffline()) {
				this.handleRoutesSavedOffline();
			} else {
				this.setPathBusy(busyPath);
				this.postRoutes(selectedObjects)
					.always(this.setPathNotBusy.bind(this, busyPath), this.handleRoutesPosted.bind(this));
			}
		},

		onSearchBarValueHelpPress: function() {
			this.isHybridApplicationUser() ? this.onPressScanId() : this.handleListRefresh();
		},

		onSaveVariantButtonPress: function() {
			this.setVariantSaveDefaults();
			this.openSimpleDialog('SaveVariant');
		},

		onSaveVariant: function() {
			var variantInfo = this.validateVariantNaming('ROUTES');
			if (variantInfo) {
				this.setVariantDialogBusy(true);
				var viewModel = this.getModel('ViewModel');
				this.saveVariant(
						variantInfo.VariantId,
						'ROUTES',
						variantInfo.Description,
						viewModel.getProperty('/FilterParameters'),
						viewModel.getProperty('/SaveVariantDialog/IsDefault')
					)
					.done(function() {
						this.setVariantsToModel();
						this.onCloseSaveVariant();
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setVariantDialogBusy.bind(this, false));
			}
		},

		onSelectedVariantChange: function() {
			var selectedId = this.getModel('ViewModel').getProperty('/SelectedVariant');
			if (selectedId === '000') {
				var originalFilterParameters = this.getModel('ViewModel').getProperty('/OriginalFilterParameters');
				this.getModel('ViewModel').setProperty('/FilterParameters', this.generateFilterParametersCopy(originalFilterParameters));
			} else {
				var selectedVariant = this.getVariantWithTypeAndId('ROUTES', selectedId);
				var oFilterParameters = this.generateFilterParametersObject(JSON.parse(selectedVariant.Data));
				this.getModel('ViewModel').setProperty('/FilterParameters', oFilterParameters);
			}
		},

		onCurrentPM12RouteWorkPress: function() {
			var currentPM12Route = this.getModel('ViewModel').getProperty('/CurrentPM12RouteWork');
			this.onRouteObjectPress(currentPM12Route);
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		getRouteGroupHeader: function(oGroup) {
			var fragment = null;
			if (!this.customFragment) {
				fragment = sap.ui.xmlfragment('FragmentRouteGroupHeader', 'com.upm.maint.view.fragment.embedded.FragmentRouteGroupHeader', this);
				this.customFragment = fragment.clone();
			} else {
				fragment = this.customFragment.clone();
			}
			fragment.setModel(new sap.ui.model.json.JSONModel(oGroup.groupItem), 'GroupHeaderFragmentModel');
			var groupHeaderListItem = new GroupHeaderListItem({
				fragment: fragment
			});
			// add fragment as dependent to the group header list item so that it's resources are freed properly
			groupHeaderListItem.addDependent(fragment);
			return groupHeaderListItem;
		},

		sortRoutes: function() {
			var aSorters = this.getRoutesSorter(true);
			this.getElementById('routeListContainer').getBinding('items').sort(aSorters);
			aSorters = this.getRoutesSorter(false);
			this.getElementById('routeListContainer').getBinding('items').sort(aSorters);
		},

		getRoutesSorter: function(bDesc) {
			var aSorters = [];
			var fGrouper = function fGrouper(oContext) {
				var object = oContext.getObject();
				var groupItem = $.extend(true, {}, object);
				var group = object.Orderid || '';
				var groupLabel = object.Orderid;
				return {
					key: group,
					groupItem: groupItem,
					label: groupLabel
				};
			};

			// The Sorter, with a custom compare function, and the Grouper
			var oSorter = new sap.ui.model.Sorter('', null, fGrouper);
			oSorter.fnCompare = function fnCompareFunc(a, b) {
				// Determine the group and group order
				var agroup = a.Orderid || '';
				var bgroup = b.Orderid || '';

				if (agroup < bgroup) {
					return !bDesc ? -1 : 1;
				} else if (agroup > bgroup) {
					return !bDesc ? 1 : -1;
				} else {
					return 0;
				}
			};
			aSorters.push(oSorter);
			return aSorters;
		},

		// handleRoutePostSuccess: function(routeId) {
		handleRoutePostSuccess: function() {
			// this.removeListObject('Routes', routeId);
			// this.localStorage.removeRoute(routeId);
		},

		handleRoutePostError: function(routeId, errorEvent) {
			var errorMessage = this.formatterUtil.oDataErrorToErrorString(errorEvent);

			this.localStorage.insertRouteErrorMessage(routeId, errorMessage);

			this.getModel('RoutesModel').setProperty(
				'/Routes',
				(this.getModel('RoutesModel').getProperty('/Routes') || []).map(function(object) {
					if (object['Orderid'] === routeId) {
						object.ErrorMessage = errorMessage;
					}
					return object;
				})
			);
		},

		handleRoutePostEnd: function() {
			this.setAppNotBusyMode();

			this.getElementById('routeListContainer').removeSelections(true);
			this.getElementById('selectAllCheckBox').setSelected(false);
		},

		handleRoutesPosted: function() {
			this.openSuccessDialog(this.getResourceBundleText('ROUTES_POSTED_SUCCESS_MESSAGE'));

			this.refreshRouteWorks();
		},

		handleRoutesSavedOffline: function() {
			this.openSuccessDialog(this.getResourceBundleText('POST_SAVE_OFFLINE_ROUTES_MESSAGE'));
		},

		onSuccessDialogClose: function() {
			this.handleRoutePostEnd();
		},

		getFilterParameters: function() {
			var filterParameters = this.getUserParameters();

			var planGroupParameters = {
				filters: this.generateFilter('Plangroup', filterParameters.Plangroups && filterParameters.Plangroups.split(',') || [''])
			};

			var sundayOfTheWeek = new Date(
				new Date().setDate(
					7 - new Date().getDay() + new Date().getDate()
				)
			);

			this.getModel('ViewModel').setProperty('/FilterParameters', {
				Plant: filterParameters.Plant,
				Workcenters: filterParameters.Workcenters ? filterParameters.Workcenters.split(',').map(function(sValue) {
					return {
						Workcenter: sValue
					};
				}) : [],
				Plangroups: [],
				WorkOrderTypes: [],
				EndStartDate: sundayOfTheWeek,
				StartStartDate: null,
				Routes: this.handleMultipleParameters(filterParameters.Routes, 'RouteId')
			});

			if (!this.isRafMaintUser()) {
				this.setVariantsToModel();
			}

			$.when(
					this.oDataUtil.read('PlanningGroupSet', planGroupParameters)
				)
				.done(this.handleUserParametersObjectsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));

			this.setFilterAbleRoutes(filterParameters.Routes && filterParameters.Routes.split(',') || []);
		},

		handleUserParametersObjectsSuccess: function(planGroups) {
			this.getModel('ViewModel').setProperty('/FilterParameters/Plangroups', planGroups);

			this.initialFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));

			var filterParams = this.getModel('ViewModel').getProperty('/FilterParameters');
			this.getModel('ViewModel').setProperty('/OriginalFilterParameters', this.generateFilterParametersCopy(filterParams));
			this.setDefaultVariant();
		},

		setFilterAbleRoutes: function(routeIds) {
			var routeParameters = {
				filters: this.generateFilter('RouteId', Array.isArray(routeIds) ? routeIds : [])
			};

			this.oDataUtil.read('RouteSet', routeParameters)
				.done(this.handleFilterAbleRoutesSuccess.bind(this));
		},

		handleFilterAbleRoutesSuccess: function(routes) {
			var emptyRouteId = {
				Plant: '',
				RouteId: '',
				RouteDescr: '',
				Plangroup: '',
				Workcenter: ''
			};

			routes.unshift(emptyRouteId);

			this.getModel('ViewModel').setProperty('/FilterRoutes', routes);
			this.handleRoutesWithoutWorkOrders();
		},

		handleListRefresh: function() {
			this.areObjectsIdentical(
				this.getModel('ViewModel').getProperty('/FilterParameters'),
				this.initialFilterParameters
			) ? this.refreshOfflineRoutes() : this.getFilteredRoutes();
		},

		refreshOfflineRoutes: function() {
			var busyPath = '/IsRouteListBusy';
			if (this.isHybridApplicationUser()) {
				this.setPathBusy(busyPath);

				this.refreshRouteWorks()
					.always(function() {
						if (this.getElementById('pullToRefresh')) {
							this.getElementById('pullToRefresh').hide();
						}
						this.setPathNotBusy(busyPath);
					}.bind(this));
			} else {
				this.getRoutesForBrowser();
			}
		},

		getRoutesForBrowser: function() {
			this.getRoutes({
				recordOperation: true,
				urlParameters: {
					'$expand': 'Measurements,Objects'
				}
			});
		},

		getFilteredRoutes: function() {
			this.getRoutes({
				online: true,
				filters: this.constructFilterArray(),
				recordOperation: true,
				urlParameters: {
					'$expand': 'Measurements,Objects'
				}
			});
		},

		getRoutes: function(parameters) {
			this.openBusyDialog({
				service: 'RouteWorkSet'
			});

			parameters = parameters || {};
			// parameters.filters = (parameters.filters || []).concat(this.createODRFilter());
			parameters.filters = (parameters.filters || []);
			this.oDataUtil.read('RouteWorkSet', parameters)
				.done(this.handleRoutesSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(function() {
					if (this.getElementById('pullToRefresh')) {
						this.getElementById('pullToRefresh').hide();
					}
					window.setTimeout(this.sortRoutes.bind(this), 0);
					this.closeBusyDialog();
				}.bind(this));
		},

		handleRoutesSuccess: function(routes) {
			if (routes) {
				routes.sort(function(a, b) {
					var returnInteger = 0;
					if (a.RouteSequence === b.RouteSequence) {
						if (a.Orderid > b.Orderid) {
							returnInteger = -1;
						} else {
							returnInteger = 1;
						}
					} else {
						returnInteger = a.RouteSequence < b.RouteSequence ? -1 : 1;
					}
					return returnInteger;
				});
				routes = routes.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil));
				// Route/WorkOrder - WorkOrder/Object manipulation
				routes = this.constructObjectListArray(routes);

				this.getModel('RoutesModel').setProperty('/Routes', routes);
				this.handleRoutesWithoutWorkOrders();
				window.setTimeout(this.sortRoutes.bind(this), 0);
			}
		},

		constructObjectListArray: function(aRoutes) {
			var routes = $.extend(true, [], aRoutes);
			var objectList = [];
			routes.map(function(route) {
				if (route.Objects.length === 0) {
					objectList.push(route);
				} else {
					route.Objects.map(function(object) {
						var routeCopy = $.extend(true, {}, route);
						// These new properties fail on the save, remember to delete in post object creation
						routeCopy.Counter = object.Counter;
						routeCopy.ObjectFunctLocInternalId = object.FunctLocInternalId;
						routeCopy.ObjectFunctLocLabelSystem = object.FunctLocLabelSystem;
						routeCopy.ObjectFunctLoc = object.FunctLoc;
						routeCopy.ObjectFunctLocDescr = object.FunctLocDescr;
						routeCopy.ObjectEquipment = object.Equipment;
						routeCopy.ObjectEquipmentDescr = object.EquipmentDescr;
						routeCopy.ProcessInd = object.ProcessInd;
						objectList.push(routeCopy);
					});
				}
			});
			return objectList;
		},

		constructFilterArray: function() {
			var filterObject = this.getModel('ViewModel').getProperty('/FilterParameters');

			var arrayOfValues = [
				filterObject.Plant, filterObject.MaintPlan, filterObject.WorkOrderTypes,
				filterObject.Routes, filterObject.Workcenters, filterObject.Plangroups,
				filterObject.SystemCondition
			];
			var arrayOfDateValues = [
				[filterObject.StartStartDate, filterObject.EndStartDate]
			];

			return this.createArray(arrayOfValues, arrayOfDateValues);
		},

		createArray: function(arrayOfValues, arrayOfDateValues) {
			var arrayParametersToIndecies = {
				'Workcenter': 4,
				'Plangroup': 5,
				'OrderType': 2,
				'RouteId': 3
			};

			var arrayOfProperties = [
				'WorkcenterPlant', 'MaintPlan', 'OrderType',
				'RouteId', 'Workcenter', 'Plangroup',
				'Systcond'
			];

			var servicePropertyToObjectKey = {
				'Workcenter': 'Workcenter',
				'Plangroup': 'Plangroup',
				'OrderType': 'OrderType',
				'RouteId': 'RouteId'
			};

			var arrayOfDateProperties = ['StartDate'];

			var filterArray = arrayOfProperties.reduce(function(array, value, index) {
				var parameter = '';

				if (arrayParametersToIndecies[value]) {
					parameter = (arrayOfValues[arrayParametersToIndecies[value]] || []).map(function(parameterObject) {
						return parameterObject[servicePropertyToObjectKey[value]];
					}).join(',');
				} else {
					parameter = arrayOfValues[index];
				}
				return parameter ? array.concat(this.generateFilter(value, parameter.split(','))) : array;
			}.bind(this), []);

			filterArray = arrayOfDateValues.reduce(function(array, value, i) {
				return value[1] && value[0] ? array.concat(new sap.ui.model.Filter(arrayOfDateProperties[i], sap.ui.model.FilterOperator.BT, value[1].setHours(12), value[0].setHours(12))) : array;
			}, filterArray);

			return filterArray;
		},

		createODRFilter: function() {
			return this.generateFilter('ShortText', ['ODR']);
		},

		shouldShowMaster: function(navigationData) {
			return !!(
				this.isRoutesRoute() &&
				(this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'Routes') ||
					this.navigatedToDetailViewFromView(navigationData, 'EditRoute', 'Routes'))
			);
		},

		isRoutesRoute: function() {
			// return location.hash.split('/').pop() === 'Routes';
			return location.hash.indexOf('/Routes/') !== -1;
		},

		handleScanSuccess: function(result) {
			this.getElementById('routeSearchField').setValue(result.text || '');

			this.filterRouteList(result.text || '');
		},

		filterRouteList: function(filterValue) {
			var routeFilter = this.getModel('ViewModel').getProperty('/RouteId') ?
				new sap.ui.model.Filter(this.generateFilter('Orderid', this.getModel('ViewModel').getProperty('/RouteId').split(','))) :
				null;

			var searchFilter = new sap.ui.model.Filter(
				this.generateFilter('ShortText', [filterValue], 'Contains')
				.concat(
					this.generateFilter('FunctLoc', [filterValue.toUpperCase()], 'Contains'),
					this.generateFilter('FunctLocDescr', [filterValue.toUpperCase()], 'Contains'),
					this.generateFilter('Equipment', [filterValue.toUpperCase()], 'Contains'),
					this.generateFilter('EquipmentDescr', [filterValue.toUpperCase()], 'Contains'),
					this.generateFilter('Orderid', [filterValue], 'Contains'),
					this.generateFilter('RouteId', [filterValue], 'Contains'),
					this.generateFilter('FunctLocSortField', [filterValue], 'Contains'),
					this.generateFilter('EquipmentSortField', [filterValue], 'Contains'),
					this.generateFilter('EquipmentTechIdentNum', [filterValue], 'Contains')
				)
			);

			var filter = routeFilter ? new sap.ui.model.Filter([searchFilter].concat(routeFilter), true) : searchFilter;

			this.getElementById('routeListContainer')
				.getBinding('items')
				.filter(filter);
		},

		routeIsInProgress: function(routeName) {
			var currentRoutes = this.getGlobalModel().getProperty('/RouteWorksInProgress');

			return Array.isArray(currentRoutes) && routeName && currentRoutes[0] && currentRoutes[0].Orderid === routeName;
		},

		setRouteWorksForProcessing: function(routeObject) {
			var routeName = routeObject.Orderid;
			var filterAbleRoutes = this.getModel('ViewModel').getProperty('/FilterRoutes');
			var routeWorks = this.getModel('RoutesModel').getProperty('/Routes');
			var coverOrders = [];
			var isOdrRoute = filterAbleRoutes.some(function(route) {
				return route.Orderid === routeName && route.IsOdrRoute;
			});
			var routeIndex = 0;

			var routeOrders = routeWorks.filter(function(routeWork) {
				var isFromCorrectRoute = routeWork.Orderid === routeName;
				if (routeObject.Counter === routeWork.Counter && routeObject.Orderid === routeWork.Orderid) {
					// save index of the current route for later use
					this.getGlobalModel().setProperty('/RouteWorkIndexInProgress', routeIndex);
				} else if (isFromCorrectRoute) {
					routeIndex += 1;
				}

				if (isFromCorrectRoute && routeWork.OrderType !== 'PM13') {
					coverOrders.push(routeWork);
				}

				return isFromCorrectRoute;
			}.bind(this));

			// remove duplicate coverOrders
			var foundOrders = [];
			coverOrders = coverOrders.filter(function(order) {
				if (foundOrders.indexOf(order.Orderid) === -1) {
					foundOrders.push(order.Orderid);
					return true;
				}
				return false;
			});
			// fallback if all coverorders are completed in previous session
			if (!coverOrders.length) {
				coverOrders = routeOrders[0].CoverWorkOrder;
			}

			this.getGlobalModel().setProperty('/RouteTimeRecord', {});
			this.getGlobalModel().setProperty('/RouteWorksInProgress', routeOrders);
			this.getGlobalModel().setProperty('/RouteWorkCoverOrders', coverOrders);
			this.getGlobalModel().setProperty('/IsOdrRoute', isOdrRoute);
			this.getGlobalModel().setProperty('/NotificationsCreatedDuringRoute', []);
			this.setCurrentPM12RouteWork(routeOrders);
		},

		setRouteInProgressIndex: function(routeObject) {
			var routeWorksInProgress = this.getGlobalModel().getProperty('/RouteWorksInProgress');
			var routeIndex;

			routeWorksInProgress.forEach(function(routeWork, index) {
				if (routeObject.Orderid === routeWork.Orderid) {
					routeIndex = index;
				}
			});

			this.getGlobalModel().setProperty('/RouteWorkIndexInProgress', routeIndex || 0);
			this.setCurrentPM12RouteWork(routeWorksInProgress);
		},

		lastItemIsCurrentRoute: function(list, route) {
			var listItems = list.getItems();
			var lastListItem = listItems[listItems.length - 1];
			var growingInfo = list._oGrowingDelegate.getInfo();
			var canGrow = growingInfo.actual < growingInfo.total;

			var lastListItemObject = lastListItem.getBindingContext('RoutesModel').getObject();

			return canGrow && lastListItemObject && lastListItemObject.RouteId && lastListItemObject.RouteId === route;
		},

		handleRoutesWithoutWorkOrders: function() {
			// var routes = this.getModel('ViewModel').getProperty('/FilterRoutes') || [];
			var routeWorks = this.getModel('RoutesModel').getProperty('/Routes') || [];
			var filteredRoutes = [];
			var filtered = [];
			routeWorks.map(function(route) {
				if (filtered.indexOf(route.Orderid) === -1) {
					filtered.push(route.Orderid);
					filteredRoutes.push(route);
				}
			});
			// routes.map(function(route) {
			// 	var routeWorkFound = routeWorks.some(function(routeWork) {
			// 		if (routeWork.Orderid === route.Orderid) {
			// 			return true;
			// 		}
			// 	});
			// 	if (routeWorkFound) {
			// 		filteredRoutes.push(route);
			// 	}
			// });
			filteredRoutes.unshift({});
			this.getModel('ViewModel').setProperty('/FilteredRoutes', filteredRoutes);
		},

		setCurrentPM12RouteWork: function(routeWorksInProgress) {
			var currentPM12Work = {};
			if (routeWorksInProgress && routeWorksInProgress.length) {
				var aPM12Works = routeWorksInProgress.reduce(function(array, work) {
					return work.OrderType === 'PM12' ? array.concat(work) : array;
				}, []);
				if (aPM12Works.length > 0) {
					currentPM12Work = aPM12Works[0];
				}
			}
			this.getModel('ViewModel').setProperty('/CurrentPM12RouteWork', currentPM12Work);
		},

		setVariantsToModel: function() {
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/Existing', this.getVariantsWithType('ROUTES'));
			this.getModel('ViewModel').setProperty('/Variants', this.getVariantsWithTypeSelectionList('ROUTES'));
		},

		setDefaultVariant: function() {
			var defaults = this.getDefaultVariants();
			var defaultVariant = '000';
			if (defaults['ROUTES']) {
				defaultVariant = defaults['ROUTES'];
			}
			this.getModel('ViewModel').setProperty('/SelectedVariant', defaultVariant);
			this.onSelectedVariantChange();
		},

		listScrollHandling: function() {
			var table = this.getElementById('routeListContainer');
			var scrollDelegate = table.getParent().getScrollDelegate();
			var visibleItems = table.getVisibleItems();
			// Get Table items heights
			var visibleItemsHeights = [];
			visibleItems.map(function(item, index) {
				visibleItemsHeights.push({
					height: $('#' + item.getId())[0].clientHeight,
					index: index
				});
			});
			// Get Item on the top of the screen
			var scrollPosition = scrollDelegate._scrollY || 0;
			var topIndex = 0;
			var totalHeight = 0;
			visibleItemsHeights.some(function(height) {
				totalHeight += height.height;
				if (totalHeight > scrollPosition) {
					topIndex = height.index;
					return true;
				}
			});
			// Get Route id of the top row
			var routeName = '';
			if (visibleItems[topIndex] && visibleItems[topIndex].getBindingContext('RoutesModel')) {
				routeName = visibleItems[topIndex].getBindingContext('RoutesModel').getObject().Orderid;
			}
			// Get PM12 orders of that route
			var routeWorks = this.getModel('RoutesModel').getProperty('/Routes');
			var routeOrders = routeWorks.filter(function(routeWork) {
				var isFromCorrectRoute = routeWork.Orderid === routeName;
				if (isFromCorrectRoute && routeWork.OrderType === 'PM12') {
					return isFromCorrectRoute;
				}
			});
			// Set "Sticky" PM12 header
			this.setCurrentPM12RouteWork(routeOrders);
		}

	});
});