sap.ui.define([
	'sap/ui/core/mvc/Controller',

	// SAPUI5 controls
	'sap/ui/core/routing/History',

	// Utils
	'com/upm/maint/util/formatter',
	'com/upm/maint/util/customTypes',
	'com/upm/maint/util/messagebox',
	'com/upm/maint/util/oData',
	'com/upm/maint/util/validation',
	'com/upm/maint/model/models',
	'com/upm/maint/dev/devapp',
	'com/upm/maint/util/localStorage',
	'com/upm/maint/util/CordovaCamera',

	// Plugins
	'com/upm/maint/plugins/jquery-barcode.min'
	// 'com/upm/maint/plugins/barcode'
], function(
	Controller,

	// SAPUI5 controls
	History,

	// Utils
	formatterUtil,
	customTypesUtil,
	messageBoxUtil,
	oDataUtil,
	validationUtil,
	models,
	devapp,
	LocalStorage,
	cordovaCameraUtil,

	// Plugins
	barcodePlugin
) {
	'use strict';

	return Controller.extend('com.upm.maint.controller.BaseController', {

		// Utils
		formatterUtil: formatterUtil,
		customTypesUtil: customTypesUtil,
		messageBoxUtil: messageBoxUtil,
		oDataUtil: oDataUtil,
		validationUtil: validationUtil,
		models: models,
		devapp: devapp,
		localStorage: new LocalStorage(),
		cordovaCameraUtil: cordovaCameraUtil,

		// Plugins
		barcodePlugin: barcodePlugin,

		onInit: function() {
			var that = this;
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function() {
				that.routeMatched.apply(that, arguments);
			});
		},

		routeMatched: function(oEvent) {
			var parameters = oEvent.getParameter('arguments');

			if (parameters && !$.isEmptyObject(parameters)) {
				var decodeArr = parameters['?query'] ? parameters['?query'] : parameters;
				$.each(decodeArr, function(key, value) {
					decodeArr[key] = typeof value === 'string' ? decodeURIComponent(decodeURI(value)) : value;
				});
			}

			this.setUrlParameters(parameters);
		},

		/* =========================================================== */
		/* Common helpers                                              */
		/* =========================================================== */

		getMyComponent: function() {
			return sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
		},

		getRootControl: function() {
			return this.getMyComponent().getAggregation('rootControl') && this.getMyComponent().getAggregation('rootControl').getController();
		},

		/**
		 * @param {string} sElementId - ID of UI element
		 * @returns {object} the element object
		 */
		getElementById: function(sElementId) {
			return this.getView().byId(sElementId);
		},

		/**
		 * @param {string=} sFragmentName - name of fragment
		 * @param {string} sElementId - ID of UI element
		 * @returns {object} the element object
		 */
		getFragmentElementById: function(sFragmentName, sElementId) {
			return sap.ui.core.Fragment.byId(this.getViewName() + this.getRootControl().getSessionId() + sFragmentName, sElementId);
		},

		removeInvisibleLabels: function() {
			$('.invisibleLabel').parent().remove();
		},

		setUrlParameters: function(parameters) {
			this.urlParameters = parameters;
		},

		getUrlParameters: function() {
			return this.urlParameters;
		},

		getUrlParameter: function(parameterName) {
			return this.urlParameters[parameterName] || null;
		},

		/**
		 * @param {string} sTextToGet - text property from i18n
		 * @returns {string} the translated text
		 */
		getResourceBundleText: function(sTextToGet, aPlaceHolders) {
			return this.getModel('i18n').getResourceBundle().getText(sTextToGet, aPlaceHolders);
		},

		/**
		 * Convenience method for getting model by name in every controller of the application.
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName) || this.getMyComponent().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @param {string} sName the model name
		 * @param {object} oData the model data
		 * @param {function} fOnChange the model onChange function
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(sName, oData, fOnChange) {
			var oModel = new sap.ui.model.json.JSONModel();
			if (oData) {
				oModel.setData(oData);
			}

			var createdModel = this.getView().setModel(oModel, sName);

			if (fOnChange) {
				var binding = new sap.ui.model.Binding(oModel, '/', oModel.getContext('/'));
				binding.attachChange(function() {
					fOnChange();
				});
			}

			return createdModel;
		},

		setGlobalModel: function(sName, oData, fOnChange) {
			var oModel = new sap.ui.model.json.JSONModel();
			if (oData) {
				oModel.setData(oData);
			}

			var createdModel = this.getMyComponent().setModel(oModel, sName);

			if (fOnChange) {
				var binding = new sap.ui.model.Binding(oModel, '/', oModel.getContext('/'));
				binding.attachChange(function() {
					fOnChange();
				});
			}

			return createdModel;
		},

		/**
		 * Generated filter that can be passed to back end call
		 * @param {string} sValueToFilter - key of the value that should be filtered
		 * @param {array} aFilterValues - value or values that operator should be applied
		 * @param {sOperator=} sOperator - operator of filter, default is EQ
		 * @returns {array} multiSelect - determines if dialog allows multiselection. Default is false
		 */
		generateFilter: function(sValueToFilter, aFilterValues, sOperator) {
			sOperator = sOperator || 'EQ';
			var sFilterOperator = {
				EQ: sap.ui.model.FilterOperator.EQ,
				Contains: sap.ui.model.FilterOperator.Contains,
				NE: sap.ui.model.FilterOperator.NE,
				StartsWith: sap.ui.model.FilterOperator.StartsWith
			} [sOperator];
			var aFilterArray = aFilterValues.map(function(sFilterValue) {
				return new sap.ui.model.Filter(sValueToFilter || '', sFilterOperator, sFilterValue);
			});
			return aFilterArray;
		},


		/**
		 * Finds array index that contains object with given key value pair
		 * @param {string} sIdValue - value which should be found
		 * @param {string} sProperty - key of the value
		 * @param {array} aValuesToLookFrom
		 * @returns {integer} index of object with key value pair
		 */
		findRightArrayIndexById: function(sIdValue, sProperty, aValuesToLookFrom) {
			var rightIndex = false;
			aValuesToLookFrom.map(function(object, i) {
				if (object[sProperty] === sIdValue) {
					rightIndex = i;
					return;
				}
			});
			return rightIndex;
		},

		/**
		 * @param {array} arr
		 * @param {integer} index
		 * @returns {array}
		 */
		removeIndexFromArray: function(arr, index) {
			arr.splice(index, 1);
			return arr;
		},

		filterDublicatedListObjects: function(idProperty, object, index, array) {
			var firstIndex;
			for (var i = 0; i < array.length; i++) {
				var item = array[i];
				if (object[idProperty] === item[idProperty]) {
					firstIndex = i;
					break;
				}
			}

			return firstIndex === index;
		},

		filterDublicatedListObjectsTwoIds: function(firstKey, secondKey, object, index, array) {
			var firstIndex;
			for (var i = 0; i < array.length; i++) {
				var item = array[i];
				if (object[firstKey] === item[firstKey] && object[secondKey] === item[secondKey]) {
					firstIndex = i;
					break;
				}
			}

			return firstIndex === index;
		},

		combineArraysByIdProperty: function(array, arrayToExtend, idProperty) {
			return arrayToExtend.map(function(item) {
				var extension = array.filter(function(itemToExtend) {
					return itemToExtend[idProperty] === item[idProperty];
				});
				return extension.length === 1 ? extension.shift() : item;
			});
		},

		areObjectsIdentical: function(firstObject, secondObject) {
			return JSON.stringify(firstObject) === JSON.stringify(secondObject);
		},

		getViewName: function() {
			return this.getView().sViewName.split('.').pop();
		},

		getParentViewName: function() {
			return this.getView().getParent().getParent().getParent().sViewName.split('.').pop();
		},

		getParentController: function() {
			return this.getView().getParent().getParent().getParent().getController();
		},

		onTokenDelete: function(deletionPressEvent) {
			var tokenPath = deletionPressEvent.getSource().getBindingContext('ViewModel').getPath();
			var lastIndexOfSlashOnTokenPath = tokenPath.lastIndexOf('/');
			var tokenArray = this.getModel('ViewModel').getProperty(tokenPath.substring(0, lastIndexOfSlashOnTokenPath));
			this.getModel('ViewModel')
				.setProperty(
					tokenPath.substring(0, lastIndexOfSlashOnTokenPath),
					this.removeIndexFromArray(tokenArray, tokenPath.substring(lastIndexOfSlashOnTokenPath + 1))
				);
		},

		publishEvent: function(channel, eventName, parameters) {
			this.getMyComponent()
				.getEventBus()
				.publish(channel, eventName, parameters);
		},

		subscribeToEvent: function(channel, eventName, eventHandler) {
			this.getMyComponent()
				.getEventBus()
				.subscribe(channel, eventName, eventHandler);
		},

		subscribeToEventOnce: function(channel, eventName, eventHandler) {
			this.getMyComponent()
				.getEventBus()
				.subscribeOnce(channel, eventName, eventHandler);
		},

		/* =========================================================== */
		/* Routing			 										   */
		/* =========================================================== */

		/**
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return this.getMyComponent().getRouter();
		},

		/**
		 * @returns {string} Launchpad user id
		 */
		getUserId: function() {
			return sap.ushell.Container.getUser().getId();
		},

		onNavBack: function() {
			// Can be used by controllers to add custom functionality to navBack
			!this.beforeNavBack || this.beforeNavBack();

			window.history.go(-1);
		},

		onNavToLaunchpad: function() {
			var crossAppNavigation = sap.ushell.Container.getService('CrossApplicationNavigation');
			crossAppNavigation.toExternal({
				target: {
					shellHash: '#'
				}
			});
		},

		// Navigates to given view; ie. this.navTo('Menu');
		navTo: function(routeName, parameters, replace) {
			var router = sap.ui.core.UIComponent.getRouterFor(this);

			if (parameters && !$.isEmptyObject(parameters)) {
				var encodeArr = parameters.query ? parameters.query : parameters;
				$.each(encodeArr, function(key, value) {
					encodeArr[key] = typeof value === 'string' ? encodeURIComponent(encodeURI(value)) : value;
				});
			}

			router.navTo(
				routeName,
				parameters || {},
				replace || false
			);
		},

		navigatedToViewFromView: function(navigationData, fromView) {
			return this.navigatedToCurrentView(navigationData.toView) &&
				this.navigatedFrom(navigationData.fromView, fromView);
		},

		navigatedToDetailViewFromView: function(navigationData, fromView, currentView) {
			return this.navigatedToParentView(navigationData.toView) &&
				this.navigatedFrom(navigationData.fromView, fromView) &&
				location.hash.split('/').indexOf(currentView) !== -1;
		},

		/**
		 * @param {string} viewName
		 * @returns {boolean}
		 */
		navigatedFrom: function(viewPath, viewName) {
			return viewPath && viewPath.indexOf(viewName) !== -1;
		},

		/**
		 * @param {string} viewName
		 * @returns {boolean}
		 */
		navigatedToCurrentView: function(viewName) {
			return this.getViewName() === viewName.split('.').pop();
		},

		navigatedToParentView: function(viewName) {
			return this.getParentViewName() === viewName.split('.').pop();
		},

		/* =========================================================== */
		/* DOM Manipulations                                           */
		/* =========================================================== */

		/** Shows busy indicator, default delay is 0 second. This is used for busy states that requires no message
		 * @param {integer=} milliseconds - time of delay
		 */
		showBusyIndicator: function(milliseconds) {
			var delay = milliseconds || 0;
			sap.ui.core.BusyIndicator.show(delay);
		},

		hideBusyIndicator: function() {
			sap.ui.core.BusyIndicator.hide();
		},

		/** Shows busy indicator, default delay is 1 second. This is used for busy states that requires no message
		 * @param {object=} arguments object - possible values: {text, title, cancelButtonText, showCancelButton, customIcon, customIconRotationSpeed, customIconDensityAware, customIconWidth, customIconHeight}
		 */
		openBusyDialog: function(parameters) {
			parameters = parameters || {};

			this.busyDialog = new sap.m.BusyDialog({
				title: parameters.title || this.getResourceBundleText('BUSY_DIALOG_TITLE'),
				text: parameters.text || this.getResourceBundleText('BUSY_DIALOG_TEXT'),
				showCancelButton: true,
				close: this.handleBusyDialogClose.bind(this, parameters.service)
			});

			this.busyDialog.open();
		},

		handleBusyDialogClose: function(service, closeEvent) {
			if (closeEvent.getParameter('cancelPressed')) {
				this.oDataUtil.abortService(service);
			}
		},

		getBusyDialog: function() {
			return this.busyDialog;
		},

		closeBusyDialog: function() {
			this.busyDialog && this.busyDialog.close();
		},

		setAppBusyMode: function(iDelay) {
			iDelay = iDelay || 0;
			sap.ui.core.BusyIndicator.show(iDelay);
		},

		setAppNotBusyMode: function() {
			sap.ui.core.BusyIndicator.hide();
		},

		/**
		 * @param {integer} spaceAboveElement - manually make function to scroll certain pixels higher
		 * @param {sap.ui.core.Control || array} control - single control or array of controls, if array of controls is passed highest one will be target for scrolling
		 */
		scrollToElement: function(spaceAboveElement, control) {
			control = Number.isInteger(spaceAboveElement) ? control : spaceAboveElement;
			spaceAboveElement = spaceAboveElement || 0;
			control = Array.isArray(control) ? this.getHighestDomElement(control) : control;
			var pageElement = this.getView().mAggregations.content[0];
			// scroll to position of control, need to reduce header offset and label height to get right position
			pageElement.scrollTo(
				pageElement.getScrollDelegate().getScrollTop() +
				$('#' + control.getId()).offset() ? $('#' + control.getId()).offset().top -
				$('#' + this.getView().getId()).find('section').first().offset().top -
				spaceAboveElement : 0, 1000
			);
		},

		/**
		 * @param {array} controls
		 * @returns {sap.ui.core.Control} highest DOM element
		 */
		getHighestDomElement: function(controls) {
			return controls.reduce(function(highestElement, currentElement) {
				return !highestElement && currentElement ||
					$('#' + highestElement.getId()).offset() && $('#' + highestElement.getId()).offset().top < $('#' + currentElement.getId()).offset().top ?
					highestElement :
					currentElement;
			});
		},

		openSimpleDialog: function(fragmentName) {
			this.initializeFragment(fragmentName).open();
		},

		openDialog: function(fragmentName, parameters) {
			var fragmentController = sap.ui.controller('com.upm.maint.controller.fragment.popups.' + fragmentName) || this;

			fragmentController.init(this, this.initializeFragment.call(this, fragmentName, fragmentController), parameters);
		},

		initializeFragment: function(fragmentName, controller) {
			var fragmentId = this.getViewName() + this.getRootControl().getSessionId() + fragmentName;

			if (!this[fragmentId]) {
				this[fragmentId] = sap.ui.xmlfragment(
					fragmentId,
					'com.upm.maint.view.fragment.popups.' + fragmentName,
					controller || this);
				this.getView().addDependent(this[fragmentId]);
			}

			return this[fragmentId];
		},

		getDialog: function(fragmentName) {
			return this[this.getViewName() + this.getRootControl().getSessionId() + fragmentName];
		},

		closePopups: function() {
			$('#sap-ui-blocklayer-popup').siblings('div').control().forEach(this.closePopup);
			$('#sap-ui-blocklayer-popup').css('visibility', 'hidden');
		},

		closePopup: function(popup) {
			popup && popup.close && popup.close();
		},

		/* =========================================================== */
		/* Validation functions                                        */
		/* =========================================================== */

		/**
		 * @param {sap.ui.core.Control=} control - control that should be validated recursively, default is current view
		 * @param {function=} functionToCallOnInvalidElements - function that gets array of invalid elements as argument
		 * @returns {boolean} indicates if invalid controls were found
		 */

		validate: function(control, functionToCallOnInvalidElements) {
			functionToCallOnInvalidElements = functionToCallOnInvalidElements || $.noop;
			this.validationUtil.controlValidationResults = [];
			this.validationUtil.validateControlType(control || this.getView());
			!this.validationUtil.controlValidationResults.length || functionToCallOnInvalidElements.call(this, this.validationUtil.controlValidationResults);
			return this.validationUtil.controlValidationResults.length === 0;
		},

		removeValueStates: function(controls) {
			setTimeout(function() {
				(controls || []).forEach(function(control) {
					control.setValueState('None');
				});
			}, 0);
		},

		/* =========================================================== */
		/* Message handler helper                                      */
		/* =========================================================== */

		/**
		 * Open message box (Info, Success, Error, Warning, Confirm)
		 * @param  {object} parameters
		 */
		showMessageBox: function(parameters) {
			messageBoxUtil.show(parameters);
		},

		/* =========================================================== */
		/* Error handler helpers                                       */
		/* =========================================================== */

		/**
		 * @param {string=} error - error event passed from service
		 * @param {string=} i18nKey - key of the text from i18n
		 */
		openErrorMessagePopup: function(oErrEvt, i18nKey) {
			if (!(oErrEvt && oErrEvt.message === 'Request aborted')) {
				i18nKey = i18nKey || 'ERROR_MESSAGE_ERROR_LOADING_DATA';
				var parsedErrorObject = this.parseErrorObject(oErrEvt);
				var errorMessage = oErrEvt && formatterUtil.oDataErrorToErrorString(oErrEvt);

				var additionalErrorMessages = [errorMessage].concat(
					(parsedErrorObject && parsedErrorObject.error && parsedErrorObject.error.innererror && parsedErrorObject.error.innererror.errordetails || [])
					.map(function(errorDetailObject) {
						return errorDetailObject.message;
					})
				);
				var messageBoxParameters = {
					type: 'Error',
					title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
					message: errorMessage ?
						this.getResourceBundleText(i18nKey, errorMessage) : this.getResourceBundleText('COMMON_ERROR_TITLE'),
					details: additionalErrorMessages.length ?
						this.generateStringFromAdditionalMessages(
							this.removeIndexFromArray(
								additionalErrorMessages.filter(this.removeDuplicates.bind(this)),
								0
							)
						) : false
				};
				messageBoxUtil.show(messageBoxParameters);
			}
		},

		parseErrorObject: function(error) {
			var errorObject;
			try {
				errorObject = JSON.parse(error.response ? error.response.body : error.responseText);
			} catch (e) {
				errorObject = null;
			}

			return errorObject;
		},

		generateStringFromAdditionalMessages: function(aAdditionalMessages) {
			return aAdditionalMessages.reduce(function(messageString, currentMessage) {
				return messageString ? messageString + ',\n' + currentMessage : currentMessage;
			}, '');
		},

		removeDuplicates: function(value, index, array) {
			return array.indexOf(value) === index;
		},

		/* =========================================================== */
		/* List Helpers     	                                       */
		/* =========================================================== */

		/**
		 * Filter list with given list and filters
		 * @param  {sapui5 list element} list
		 * @param  {array} filters - example:
		 * [{
				path: 'PropertyName1',
				operator: sap.ui.model.FilterOperator.Contains,
				value1: 'filterValue'
			}, {
				path: 'PropertyName2',
				operator: sap.ui.model.FilterOperator.Contains,
				value1: filterValue
			}]
		 *
		 */
		filterList: function(list, filters) {
			var binding = list.getBinding('items');

			var filtersArray = [];
			$.map(filters, function(filter) {
				filtersArray.push(new sap.ui.model.Filter(filter));
			});

			var combinedFilter = new sap.ui.model.Filter(filtersArray, false);

			binding.filter(combinedFilter, 'Application');
			binding.refresh(true);
		}
	});
});