sap.ui.define([
	'sap/ui/base/Object',
	'sap/ui/model/resource/ResourceModel',
	'com/upm/maint/model/models',
	'com/upm/maint/dev/devapp',
	'com/upm/maint/util/timeRecordUtility',
	'com/upm/maint/model/configurationModel'
], function(Object, ResourceModel, models, devapp, TimeRecordUtility, ConfigurationModel) {
	'use strict';

	return Object.extend('com.upm.maint.controller.Application', {

		constructor: function(component) {
			this.component = component;
		},

		init: function(navigatedToGeneralApplication) {
			this.setCommonModels(navigatedToGeneralApplication);

			if (navigatedToGeneralApplication) {
				this.setGeneralODataModel();
			} else {
				this.setODataModels();
			}

			this.setNotificationModels();
			this.setOrderModels();
			this.setOperationModel();
			this.setMaterialModel();
			this.setRouteModels();
			this.setEquipmentDismantlingModel();
			this.setApprovalsModels();
			this.setGoodsIssueMultiModel();

			this.attachTypeValidation();
		},

		setODataModels: function() {
			var offlineModel = models.createOfflineODataModel();

			this.component.setModel(offlineModel);
			devapp.offlineModel = offlineModel;

			offlineModel.attachEventOnce('metadataLoaded', function() {
				// add delay to online model creation to avoid SAML collusion
				setTimeout(function() {
					var onlineModel = models.createOnlineODataModel();
					this.component
						.getEventBus()
						.publish('app', 'offlineMetadataLoaded');
					this.component.setModel(onlineModel, 'OnlineModel');
					devapp.onlineModel = onlineModel;

					onlineModel.attachEventOnce('metadataLoaded', function() {
						this.component
							.getEventBus()
							.publish('app', 'onlineMetadataLoaded');
					}.bind(this));

					onlineModel.attachEvent('metadataFailed', function(errorEvent) {
						this.component
							.getEventBus()
							.publish('app', 'onlineMetadataFailed', errorEvent);
					}.bind(this));
				}.bind(this), 200);
			}.bind(this));
		},

		setGeneralODataModel: function() {
			var onlineModel = models.createGeneralODataModel();

			this.component.setModel(onlineModel, 'OnlineModel');
			devapp.onlineModel = onlineModel;
		},

		setCommonModels: function(navigatedToGeneralApplication) {
			var deviceModel = models.createDeviceModel();
			var timeRecordUtility = new TimeRecordUtility();
			var configurationModel = new ConfigurationModel();
			var globalProperties = {
				NavigatedToGeneralApplication: !!navigatedToGeneralApplication
			};

			this.component.setModel(timeRecordUtility, 'TimeRecordModel');
			this.component.setModel(deviceModel, 'Device');
			this.component.setModel(models.createGlobalPropertiesModel(globalProperties), 'GlobalPropertiesModel');
			this.component.setModel(models.createSelectionValuesModel(), 'SelectionValuesModel');
			this.component.setModel(models.createUserPreferencesModel(), 'UserPreferences');
			this.component.setModel(models.createObjectInfoModel(), 'ObjectInfoModel');
			this.component.setModel(configurationModel, 'ConfigurationModel');

			models.setTimeRecordModel(timeRecordUtility);
			models.setConfigurationModelModel(configurationModel);

			devapp.deviceModel = deviceModel;
		},

		setNotificationModels: function() {
			this.component.setModel(models.createNotificationsModel(), 'NotificationsModel');
			this.component.setModel(models.createNewNotificationModel(), 'NewNotificationModel');
		},

		setOrderModels: function() {
			this.component.setModel(models.createNewOrderModel(), 'NewOrderModel');
			this.component.setModel(models.createOrdersModel(), 'OrdersModel');
			this.component.setModel(models.createMyWorksModel(), 'MyWorkOrdersModel');
			this.component.setModel(models.createMyWorksModel(), 'MyWorksModel');
		},

		setRouteModels: function() {
			this.component.setModel(models.createEditRouteModel(), 'EditRouteModel');
			this.component.setModel(models.createRoutesModel(), 'RoutesModel');
		},

		setGoodsIssueMultiModel: function() {
			this.component.setModel(models.createNewGoodsIssueMultiModel(), 'GoodsIssueMultiModel');
		},

		setOperationModel: function() {
			this.component.setModel(models.createNewOperationModel(), 'NewOperationModel');
		},

		setMaterialModel: function() {
			this.component.setModel(models.createNewMaterialModel(), 'NewMaterialModel');
		},

		setEquipmentDismantlingModel: function() {
			this.component.setModel(models.createNewEquipmentDismantlingModel(), 'NewEquipmentDismantlingModel');
		},

		setApprovalsModels: function() {
			this.component.setModel(models.createNewApprovalModel(), 'NewWorkFlowApproval');
			this.component.setModel(models.createApprovalsModel(), 'WorkFlowApprovalsModel');
		},

		attachTypeValidation: function() {
			this.component.attachParseError(this.showElementError);
			this.component.attachValidationError(this.showElementError);
			this.component.attachValidationSuccess(this.hideElementError);
		},

		showElementError: function(oEvent) {
			var element = oEvent.getParameter('element');
			element.setValueState ?
				element.setValueState(sap.ui.core.ValueState.Error) :
				element.addStyleClass('selectError');
			!element.setValueStateText || !oEvent.getParameter('message') || element.setValueStateText(oEvent.getParameter('message'));
		},

		hideElementError: function(oEvent) {
			var element = oEvent.getParameter('element') || oEvent.getSource();
			element.setValueState ?
				element.setValueState(sap.ui.core.ValueState.None) :
				element.removeStyleClass && element.removeStyleClass('selectError');
		}
	});
});