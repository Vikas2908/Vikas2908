sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	var isRendered;
	return CommonController.extend('com.upm.maint.controller.EditRoute', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				IsDownloadingHistoryMeasurements: false,
				MeasurementPointState: null
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
		},

		onAfterRendering: function() {
			this.removeInvisibleLabels();

			if (!this.getIsRendered()) {
				this.setIsRendered(true);
				setTimeout(this.handleTimeRecording.bind(this), 500);
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'EditRoute') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				setTimeout(this.removeInvisibleLabels, 0);

				this.validate(this.getView(), this.removeValueStates.bind(this));

				this.getModel('ViewModel').setData({
					IsDownloadingHistoryMeasurements: false,
					MeasurementPointState: this.getModel('ViewModel').getProperty('/MeasurementPointState')
				});
				
				this.rerenderTextAreas();
				
				if (this.getIsRendered()) {
					if (this.isPhone()) {
						// mobile has to navigate separetly to detail view
						setTimeout(this.handleTimeRecording.bind(this), 500);
					} else {
						this.handleTimeRecording();
					}
				}
				
				this.handleMeasurementPointState();
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedFromRouteSummary(navigationData) && this.isTablet() && !this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onHardwareNavigateBack: function() {
			if (this.isTablet() && !this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			} else {
				this.onNavigateBack();
			}
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('EditRouteActionButtons').openBy(pressEvent.getSource());
		},

		onCreateNotification: function() {
			var routeObject = this.getModel('EditRouteModel').getData();
			this.getModel('NewNotificationModel')
				.setData(this.models.getNotificationDefaults({
					FunctLoc: routeObject.ObjectFunctLoc,
					FunctLocInternalId: routeObject.ObjectFunctLocInternalId,
					Equipment: routeObject.ObjectEquipment,
					WorkOrderNo: routeObject.Orderid,
					RouteId: routeObject.RouteId
				}));

			this.navTo('CreateNotification', {
				Purpose: 'Create'
			});
		},

		onOpenMeasurementDocument: function(oEvent, nIndex) {
			var routeObject = this.getModel('EditRouteModel').getData();

			// this.openMeasurementPointDialog(routeObject.FunctLoc, routeObject.Equipment, 'EditRouteModel');

			var aItems = routeObject.Measurements.filter(function(oMeasurement) {
				if (oMeasurement.FunclocInternalId === routeObject.ObjectFunctLocInternalId && oMeasurement.Equipment === routeObject.ObjectEquipment) {
					return true;
				}
			});
			this.openDialog('MeasurementPoints', {
				Items: aItems,
				CurrentIndex: nIndex || 0,
				onClose: this.handleMeasurementPointClose.bind(this)
			});
		},

		handleMeasurementPointState: function() {
			var measurementPointState = this.getModel('ViewModel').getProperty('/MeasurementPointState');
			if (measurementPointState) {
				this.onOpenMeasurementDocument(null, measurementPointState.LeaveIndex || 0);
				this.getModel('ViewModel').setProperty('/MeasurementPointState', null);
			}
		},

		handleMeasurementPointClose: function(oParams) {
			var bItemChanged = false;
			if (oParams.aItems) {
				bItemChanged = oParams.aItems.some(function(oItem) {
					if (oItem.CreateMeasurementDoc) {
						return true;
					}
				});
				// set recorded values etc to data
				var routeObject = this.getModel('EditRouteModel').getData();
				routeObject.Measurements = routeObject.Measurements.map(function(oMeasurement) {
					oParams.aItems.some(function(oItem) {
						if (oMeasurement.Point === oItem.Point) {
							oMeasurement.CreateMeasurementDoc = oItem.CreateMeasurementDoc;
							oMeasurement.OdrResultCode = oItem.OdrResultCode;
							oMeasurement.RecordedValue = oItem.RecordedValue;
							return true;
						}
					});
					return oMeasurement;
				});
			}
			if (oParams.bIsDeviation) {
				// TODO: save current measurement point state
				this.getModel('ViewModel').setProperty('/MeasurementPointState', {
					LeaveIndex: oParams.LeaveIndex || 0
				});
				// save current progress
				this.postRouteBackGround();
				// this.postRoute();
				// navigate to notification creation
				this.onCreateNotification();
			} else if (bItemChanged) {
				this.postRouteBackGround();
			}
		},

		onOpenConfirmWorkingTime: function() {
			this.openSimpleDialog('TimeConfirmation');

			this.getFragmentElementById('TimeConfirmation', 'timeConfirmationInputField')
				.$()
				.children()
				.attr('type', 'Number')
				.attr('step', '0.01');
		},

		onConfirmTimeEntryButtonPress: function() {
			var timeConfirmation = this.getModel('ViewModel').getProperty('/ConfirmedTime');
			var busyPath = '/IsRouteBusy';
			var order = this.getModel('EditRouteModel').getProperty('/Orderid');

			if (timeConfirmation) {
				var confirmation = {
					ConfirmedTime: timeConfirmation,
					Orderid: order
				};
				this.onTimeConfirmationCloseButtonPress();

				this.setPathBusy(busyPath);
				this.handleRouteTimeConfirmation(confirmation)
					.done(this.handleRouteTimeConfirmationSuccess.bind(this, order))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setPathNotBusy.bind(this, busyPath));
			}
		},

		onTimeConfirmationCloseButtonPress: function() {
			this.getDialog('TimeConfirmation').close();
		},

		onCompleteRoutePress: function() {
			this.getModel('EditRouteModel').setProperty('/Completed', 'X');

			this.postRoute();
		},

		onShowErrorMessage: function() {
			this.showMessageBox({
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: this.getModel('EditRouteModel').getProperty('/ErrorMessage'),
				type: 'Error'
			});
		},

		onNavigateBack: function() {
			this.onNavBack();
		},

		onNextButtonPress: function() {
			// var completeText = this.getResourceBundleText('COMPLETE_BUTTON_TEXT');
			this.handleCompletionAndNavigationToNextRoute();
			// if (this.getModel('EditRouteModel').getProperty('/OrderType') === 'PM13') {
			// 	this.handleCompletionAndNavigationToNextRoute();
			// } else {
			// 	this.showMessageBox({
			// 		type: 'Warning',
			// 		title: this.getResourceBundleText('WARNING_TITLE'),
			// 		message: this.getResourceBundleText('COVER_WORKORDER_COMPLETE_WARNING_TEXT'),
			// 		onClose: this.handleCoverWorkOrderWarningClose.bind(this),
			// 		actions: [completeText, sap.m.MessageBox.Action.CANCEL]
			// 	});
			// }
		},

		onNextWithoutCompletionButtonPress: function() {
			var oGlobalModel = this.getModel('GlobalPropertiesModel');
			var index = oGlobalModel.getProperty('/RouteWorkIndexInProgress');
			var count = oGlobalModel.getProperty('/RouteWorksInProgress') || [];
			if ((index + 1) >= count.length) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TITLE'),
					message: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TEXT'),
					onClose: this.handleCompleteRouteMessageBoxClose.bind(this),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
				});
			} else {
				// this.postRouteBackGround();
				this.navigateToNextRoute();
			}
		},

		onOpenMeasurementHistory: function() {
			var parameters = {
				ModelName: 'EditRouteModel'
			};
			this.openDialog('MeasurementPointHistory', parameters);
		},

		onTimeRecordingButtonPress: function() {
			var coverWorkOrders = this.getGlobalModel().getProperty('/RouteWorkCoverOrders');
			var recordObject = this.getTimeRecordUtility().getSaveObject();
			if (this.getTimeRecordUtility().isRecordingForObject(coverWorkOrders)) {
				this.navigateToRouteSummary();
			} else if (this.getTimeRecordUtility().isRecording()) {
				this.handleStopTimeRecording(recordObject, coverWorkOrders);
			} else {
				this.handleStartRecording(coverWorkOrders);
			}
		},

		onRouteDelete: function() {
			var orderNumber = this.getModel('EditRouteModel').getProperty('/Orderid');

			this.localStorage.removeRoute(orderNumber);
			this.removeListObject('Routes', orderNumber);

			this.onNavBack();

			//phone requires 1 history navigation, other devices 2
			if (!this.isPhone()) {
				this.onNavBack();
			}
		},

		onShowDMSDocumentsPress: function() {
			var equipment = this.getModel('EditRouteModel').getProperty('/Equipment');
			var functionalLocation = this.getModel('EditRouteModel').getProperty('/FunctLoc');
			var orderId = this.getModel('EditRouteModel').getProperty('/Orderid');

			this.openDialog('DisplayDMSDocuments', {
				ObjectId: orderId,
				ObjectType: 'PMAUFK',
				TechnicalObject: equipment || functionalLocation,
				Type: equipment ? 'EQUI' : 'IFLOT'
			});
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		rerenderTextAreas: function() {
			setTimeout(function() {
				this.getElementById('routeDescriptionTextArea') && this.getElementById('routeDescriptionTextArea').rerender();
			}.bind(this), this.isPhone() ? 500 : 0);
		},

		postRouteBackGround: function() {
			var postObject = this.getModel('EditRouteModel').getData();

			if (this.isOffline()) {
				postObject.NotSync = true;
				this.insertRouteToList(postObject);
				this.localStorage.insertRoute(postObject);
			} else {
				this.generateRoutePostMethodBackGround(postObject);
			}

			this.insertRouteToInProgressRoutes(postObject);
		},

		postRoute: function() {
			var postObject = this.getModel('EditRouteModel').getData();
			var busyPath = '/IsRouteBusy';

			if (this.isOffline()) {
				postObject.NotSync = true;
				this.insertRouteToList(postObject);
				this.localStorage.insertRoute(postObject);

				this.handleRouteSavedOffline();
			} else {
				this.setPathBusy(busyPath);

				this.generateRoutePostMethod(postObject)
					.always(this.setPathNotBusy.bind(this, busyPath));
			}
		},

		handleRoutePostSuccess: function(routeId) {
			var route = this.getModel('EditRouteModel').getData();

			if (routeId === route.Orderid) {
				// remove measurement doc creation to avoid double document
				route.Measurements = route.Measurements.map(function(measurementPoint) {
					measurementPoint.CreateMeasurementDoc = '';
					return measurementPoint;
				});

				this.getModel('EditRouteModel').setData(route);
			}

			this.openSuccessDialog(
				this.getResourceBundleText('ROUTE_EDIT_SUCCESS_MESSAGE', routeId)
			);

			// this.localStorage.removeRoute(routeId);

			// if (this.getModel('EditRouteModel').getProperty('/Completed')) {
			// 	this.removeListObject('Routes', routeId);
			// }
		},

		// handleRoutePostSuccessBackGround: function(routeId) {
		handleRoutePostSuccessBackGround: function() {
			// this.localStorage.removeRoute(routeId);

			// this.removeListObject('Routes', routeId);
		},

		handleRoutePostError: function(routeId, errorEvent) {
			this.openErrorMessagePopup(errorEvent);
		},

		handleRouteSavedOffline: function() {
			this.openSuccessDialog(this.getResourceBundleText('POST_SAVE_OFFLINE_ROUTE_MESSAGE'));
		},

		onSuccessDialogClose: function() {
			if (this.getModel('EditRouteModel').getProperty('/Completed')) {
				if (this.isPhone()) {
					this.onNavBack();
				} else if (!this.getParentController().getSplitContainer().isMasterShown()) {
					this.getParentController().showMaster();
				} else {
					this.navTo('EmptyRoute', {}, true);
				}
			}
		},

		shouldShowWarningMessage: function() {
			return this.operationDiffersFromOriginal();
		},

		operationDiffersFromOriginal: function() {
			return !this.areObjectsIdentical(
				this.getModel('EditRouteModel').getData(),
				this.originalObject
			);
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.onNavBack();
		},

		handleCoverWorkOrderWarningClose: function(action) {
			if (action !== 'CANCEL') {
				this.handleCompletionAndNavigationToNextRoute();
			}
		},

		handleCompletionAndNavigationToNextRoute: function() {
			var oGlobalModel = this.getModel('GlobalPropertiesModel');
			var index = oGlobalModel.getProperty('/RouteWorkIndexInProgress');
			var count = oGlobalModel.getProperty('/RouteWorksInProgress') || [];
			if ((index + 1) >= count.length) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TITLE'),
					message: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TEXT'),
					onClose: this.handleCompleteRouteMessageBoxClose.bind(this),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
				});
			} else {
				// this.getModel('EditRouteModel').setProperty('/Completed', (index + 1) >= count.length ? 'X' : '');
				this.getModel('EditRouteModel').setProperty('/ProcessInd', 'X');
				this.postRouteBackGround();

				this.navigateToNextRoute();
			}
		},

		handleCompleteRouteMessageBoxClose: function(oAction) {
			if (oAction === 'YES') {
				this.getModel('EditRouteModel').setProperty('/Completed', 'X');
			}
			this.postRouteBackGround();
			this.navigateToNextRoute();
		},

		navigateToNextRoute: function() {
			var nextRoute;
			this.getModel('ViewModel').setData({
				IsDownloadingHistoryMeasurements: false,
				MeasurementPointState: null

			});
			if (this.hasUnCompletedRoutes() && this.hasRoutesLeft()) {
				nextRoute = this.getNextRoute();

				this.getModel('EditRouteModel').setData(nextRoute);

				this.rerenderTextAreas();
			// } else if (this.hasUnCompletedRoutes()) {
			// 	this.showMessageBox({
			// 		type: 'Info',
			// 		title: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TITLE'),
			// 		message: this.getResourceBundleText('NOT_COMPLETED_ROUTES_TEXT'),
			// 		onClose: this.handleNotCompletedRoutesMessageBoxClose.bind(this),
			// 		actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			// 	});
			} else {
				this.navigateToRouteSummary();
			}
		},

		insertRouteToInProgressRoutes: function(currentRoute) {
			var currentRouteIndex = this.getGlobalModel().getProperty('/RouteWorkIndexInProgress');

			this.getGlobalModel().setProperty('/RouteWorksInProgress/' + currentRouteIndex, currentRoute);
		},

		hasRoutesLeft: function() {
			var currentRouteIndex = this.getGlobalModel().getProperty('/RouteWorkIndexInProgress');
			var routesInProgress = this.getGlobalModel().getProperty('/RouteWorksInProgress');

			var hasUnCompletedRoutesLeft = routesInProgress.some(function(route, index) {
				return !route.Completed && currentRouteIndex < index;
			});

			return hasUnCompletedRoutesLeft;
		},

		getNextRoute: function() {
			var currentRouteIndex = this.getGlobalModel().getProperty('/RouteWorkIndexInProgress');
			var routesInProgress = this.getGlobalModel().getProperty('/RouteWorksInProgress');
			var nextRouteIndex = currentRouteIndex + 1;

			while (routesInProgress[nextRouteIndex].Completed) {
				nextRouteIndex += 1;
			}

			this.getGlobalModel().setProperty('/RouteWorkIndexInProgress', nextRouteIndex);

			return routesInProgress[nextRouteIndex];
		},

		getFirstNotCompletedRoute: function() {
			var routesInProgress = this.getGlobalModel().getProperty('/RouteWorksInProgress');

			return routesInProgress.filter(function(route) {
				return !route.Completed;
			}).shift();
		},

		hasUnCompletedRoutes: function() {
			return this.getGlobalModel().getProperty('/RouteWorksInProgress').some(function(route) {
				return !route.Completed;
			});
		},

		getRouteIndex: function(routeId) {
			var routesInProgress = this.getGlobalModel().getProperty('/RouteWorksInProgress');
			var index;
			for (var i = 0; i < routesInProgress.length; i++) {
				if (routesInProgress[i].Orderid === routeId) {
					index = i;
					break;
				}
			}
			return index || 0;
		},

		handleNotCompletedRoutesMessageBoxClose: function(action) {
			if (action === 'YES') {
				var nextRoute = this.getFirstNotCompletedRoute();
				if (nextRoute) {
					var routeIndex = this.getRouteIndex(nextRoute.Orderid);
					this.getGlobalModel().setProperty('/RouteWorkIndexInProgress', routeIndex);
					this.getModel('EditRouteModel').setData(nextRoute);

					this.rerenderTextAreas();
				}
			} else {
				this.navigateToRouteSummary();
			}
		},

		handleTimeRecording: function() {
			var coverWorkOrders = this.getGlobalModel().getProperty('/RouteWorkCoverOrders');
			var recordObject = this.getTimeRecordUtility().getSaveObject();
			if (this.getTimeRecordUtility().isRecording() && !this.getTimeRecordUtility().isRecordingForObject(coverWorkOrders)) {
				this.handleStopTimeRecordingBeforeRoute(recordObject, coverWorkOrders);
			}
		},

		handleStopTimeRecordingBeforeRoute: function(record, newRecord) {
			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TITLE'),
				message: this.getResourceBundleText('STOP_TIME_RECORDING_BEFORE_ROUTE_QUESTION_TEXT'),
				onClose: this.handleStopTimeRecordBeforeRouteQuestionClose.bind(this, record, newRecord),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleStopTimeRecordBeforeRouteQuestionClose: function(record, newRecord, action) {
			this.getTimeRecordUtility().finishCurrentRecording();

			if (action === 'YES') {
				this.openDialog('TimeRecordConfirmationDialog', {
					record: record,
					type: 'ROUTE'
				});
			}
		},

		handleStopTimeRecording: function(record, newRecord) {
			this.showMessageBox({
				type: 'Question',
				title: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TITLE'),
				message: this.getResourceBundleText('STOP_TIME_RECORDING_QUESTION_TEXT'),
				onClose: this.handleStopTimeRecordQuestionClose.bind(this, record, newRecord),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO]
			});
		},

		handleStopTimeRecordQuestionClose: function(record, newRecord, action) {
			if (action === 'YES') {
				this.getTimeRecordUtility().finishCurrentRecording();
				this.openDialog('TimeRecordConfirmationDialog', {
					record: record,
					type: 'ROUTE'
				});
			} else if (action === 'NO') {
				this.getTimeRecordUtility().finishCurrentRecording();
				this.handleStartRecording(newRecord);
			}
		},

		handleStartRecording: function(record) {
			this.getTimeRecordUtility().startRecording(record);
		},

		navigateToRouteSummary: function() {
			var routeTimeRecord = this.getTimeRecordUtility().getSaveObject();
			var coverWorkOrders = this.getGlobalModel().getProperty('/RouteWorkCoverOrders');

			if (!routeTimeRecord.start && this.getGlobalModel().getProperty('/PlantLevelShowStartAndStopButton')) {
				this.getTimeRecordUtility().startRecording(coverWorkOrders);

				routeTimeRecord = this.getTimeRecordUtility().getSaveObject();
			}

			this.getGlobalModel().setProperty('/RouteTimeRecord', routeTimeRecord);

			this.getTimeRecordUtility().finishCurrentRecording();

			this.navTo('RouteSummary');
		},

		getIsRendered: function() {
			return isRendered;
		},

		setIsRendered: function(rendered) {
			isRendered = rendered;
		},

		navigatedFromRouteSummary: function(navigationData) {
			return !!(
				this.navigatedToDetailViewFromView(navigationData, 'RouteSummary', 'EditRoute')
			);
		}

	});
});