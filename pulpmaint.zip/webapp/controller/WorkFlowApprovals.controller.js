sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.WorkFlowApprovals', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				FilterParameters: {}
			};

			this.setModel('ViewModel', initialViewModel);

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'afterNavigate', this.handleAfterNavigate.bind(this));

			if (!this.isHybridApplicationUser()) {
				this.getApprovals();
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'WorkFlowApprovals') {
				BaseController.prototype.routeMatched.apply(this, arguments);
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.shouldShowMaster(navigationData)) {
				this.getParentController().showMaster();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onMasterListItemPress: function(pressEvent) {
			var approvalObject = pressEvent
				.getParameter('listItem')
				.getBindingContext('WorkFlowApprovalsModel')
				.getObject();

			this.getModel('NewWorkFlowApproval').setData(this.oDataUtil.handleResultsObjects.call(this.oDataUtil, approvalObject));

			this.navTo('WorkFlowApproval', {
				ApprovalNumber: approvalObject.Orderid || approvalObject.EntrySheetNo || approvalObject.PreqNo
			}, this.getModel('Device').getProperty('/isNoPhone'));
			this.getParentController().hideMaster();
		},

		onApprovalsLiveSearch: function(searchEvent) {
			this.filterApprovalList(searchEvent.getParameter('newValue'));
		},

		onApprovalPullToRefresh: function() {
			this.handleListRefresh();
		},

		onListRefresh: function(refreshEvent) {
			refreshEvent.getParameter('refreshButtonPressed') && this.handleListRefresh();
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handleListRefresh: function() {
			this.getApprovals();
		},

		getApprovals: function() {
			this.openBusyDialog({
				service: 'WfApprovalItemSet'
			});

			this.getWorkFlowApprovals()
				.done(this.handleGetApprovalsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(function() {
					if (this.getElementById('pullToRefresh')) {
						this.getElementById('pullToRefresh').hide();
					}
					this.closeBusyDialog();
				}.bind(this));
		},

		handleGetApprovalsSuccess: function(approvals) {
			this.getModel('WorkFlowApprovalsModel').setProperty('/Approvals', approvals);
		},

		shouldShowMaster: function(navigationData) {
			return !!(
				this.isWorkFlowApprovalRoute() &&
				(this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'WorkFlowApprovals') ||
					this.navigatedToDetailViewFromView(navigationData, 'WorkFlowApproval', 'WorkFlowApprovals'))
			);
		},

		isWorkFlowApprovalRoute: function() {
			return location.hash.split('/').pop() === 'WorkFlowApprovals';
		},

		filterApprovalList: function(filterValue) {
			this.getElementById('approvalListContainer')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('Orderid', [filterValue], 'Contains')
						.concat(
							this.generateFilter('Initiator', [filterValue], 'Contains'),
							this.generateFilter('PreqNo', [filterValue], 'Contains'),
							this.generateFilter('EntrySheetNo', [filterValue], 'Contains'),
							this.generateFilter('PoNumber', [filterValue], 'Contains')
						)
					)
				]);
		}

	});
});