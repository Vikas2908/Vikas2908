sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.WorkFlowApproval', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			var that = this;

			BaseController.prototype.onInit.apply(this, arguments);

			this.setModel('ViewModel', {
				ReasonForRejection: '',
				ReasonForForwarding: '',
				ForwardTo: '',
				PersonSearchParams: {},
				Persons: []
			});

			this.getElementById('workCenterLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};

			this.getElementById('requisitionerLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'WorkFlowApproval') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getModel('ViewModel').setProperty('/ReasonForRejection', '');
				this.getModel('ViewModel').setProperty('/ReasonForForwarding', '');
				this.getModel('ViewModel').setProperty('/ForwardTo', '');
				this.getModel('ViewModel').setProperty('/PersonSearchParams', {});
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onHardwareNavigateBack: function() {
			if (this.isTablet() && !this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			} else {
				this.onNavBack();
			}
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('WorkFlowActionButtons').openBy(pressEvent.getSource());
		},

		onApproveWorkFlowButtonPress: function() {
			this.showMessageBox({
				type: 'Confirm',
				title: this.getResourceBundleText('APPROVE_CONFIRMATION_DIALOG_TITLE'),
				message: this.getResourceBundleText('APPROVE_CONFIRMATION_DIALOG_TEXT'),
				onClose: this.handleApproveConfirmPopUpClose.bind(this),
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL]
			});
		},

		onRejectWorkFlowButtonPress: function() {
			this.openDialog('RejectDialog');
		},

		onForwardWorkFlowButtonPress: function() {
			this.openDialog('ForwardDialog');
		},

		onSuccessDialogClose: function() {
			if (this.isPhone()) {
				this.onNavBack();
			} else if (!this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			} else if (!this.isTouch()) {
				this.navTo('EmptyWorkFlowApproval', {}, true);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		handleApproveConfirmPopUpClose: function(action) {
			if (action === 'YES') {
				this.postAction('WfItemApprove', this.getPostObject());
			}
		},

		rejectWorkFlow: function() {
			var postObject = this.getPostObject();
			var reasonForRejection = this.getModel('ViewModel').getProperty('/ReasonForRejection');

			postObject.Reason = reasonForRejection;

			this.postAction('WfItemReject', postObject);
		},

		forwardWorkFlow: function() {
			var postObject = this.getPostObject();
			var reasonForForwarding = this.getModel('ViewModel').getProperty('/ReasonForForwarding');
			var forwardTo = this.getModel('ViewModel').getProperty('/ForwardTo');

			postObject.Reason = reasonForForwarding;
			postObject.ForwardTo = forwardTo;

			this.postAction('WfItemForward', postObject);
		},

		postAction: function(functionImportName, importData) {
			this.setAppBusyMode();

			this.oDataUtil.functionImport(functionImportName, importData)
				.done(this.handlePostSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		getPostObject: function() {
			var approvalObject = this.getModel('NewWorkFlowApproval').getData();

			return {
				EntrySheetNo: approvalObject.EntrySheetNo,
				Orderid: approvalObject.Orderid,
				ItemType: approvalObject.ItemType,
				WiId: approvalObject.WiId
			};
		},

		handlePostSuccess: function() {
			this.openSuccessDialog(
				this.getResourceBundleText('WORKFLOW_POSTED_SUCCESSFULLY')
			);

			this.removeApprovalFromList();
		},

		removeApprovalFromList: function() {
			var postObject = this.getPostObject();

			this.getModel('WorkFlowApprovalsModel').setProperty(
				'/Approvals',
				this.getModel('WorkFlowApprovalsModel').getProperty('/Approvals').filter(function(object) {
					return !(object.EntrySheetNo === postObject.EntrySheetNo && object.WiId === postObject.WiId && object.Orderid === postObject.Orderid && object.ItemType === postObject.ItemType);
				})
			);
		},

		isAcceptedComparator: function(a, b) {
			if (!a) {
				return -1;
			} else if (!b) {
				return 1;
			} else {
				return 0;
			}
		}

	});
});