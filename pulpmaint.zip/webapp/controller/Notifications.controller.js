sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.Notifications', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			this.initialFilterParameters = {};
			this.lastSearchFilterParameters = {};

			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				IsOrderList: false,
				IsMyWorkList: false,
				IsNotificationList: true,
				SelectedNotification: '',
				FunctionalLocationTokenValue: '',
				FilterParameters: {},
				SaveVariantDialog: {
					CreateNew: false,
					IsDefault: false,
					IsBusy: false
				},
				Variants: [],
				OriginalFilterParameters: {},
				SelectedVariant: ''
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('app', 'afterNavigate', this.handleAfterNavigate.bind(this));
			this.subscribeToEvent('functionalLocationSelected', 'AdvancedSearchNotificationsListFunctionalLocations', this.handleListFunctionalLocationsSelected.bind(this));

			this.subscribeToEvent('userParameters', 'update', this.getFilterParameters.bind(this));
			this.subscribeToEvent('root', 'variantsUpdated', this.setVariantsToModel.bind(this));

			this.getElementById('notificationSearchField')._getValueHelpIcon().setSrc(this.isScannerAvailable() ? 'sap-icon://camera' : 'sap-icon://refresh');

			this.getFilterParameters();

			if (!this.isHybridApplicationUser() && (this.isNotificationsRoute() || this.isDisplayNotificationRoute())) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.getFilterParameters.bind(this));
				this.getNotificationsForBrowser();
			}
		},

		onAfterRendering: function() {
			if (!this.getGlobalModel().getProperty('/EditNotification')) {
				this.getParentController().showMaster();
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'Notifications') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				this.getGlobalModel().setProperty('/EditNotification', false);

				this.getModel('ViewModel').setProperty('/SelectedNotification', '');
			}
		},

		handleAfterNavigate: function(channel, eventName, navigationData) {
			if (this.isNotificationsRoute() && this.navigatedFrom(navigationData.fromView, 'FunctionalLocationHierarchy')) {
				this.onAdvancedSearchPress();
			} else if (this.shouldShowMaster(navigationData)) {
				this.getModel('ViewModel').setProperty('/SelectedNotification', '');
				this.getParentController().showMaster();
			} else if (this.shouldHideMaster(navigationData)) {
				this.getParentController().hideMaster();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			this.onNavBack();
		},

		onMasterListItemPress: function(pressEvent) {
			var notificationObject = pressEvent
				.getParameter('listItem')
				.getBindingContext('NotificationsModel')
				.getObject();

			this.getModel('ViewModel').setProperty('/SelectedNotification', notificationObject.NotifNo);

			this.getModel('NewNotificationModel').setData(this.models.getNotificationDefaults(notificationObject));

			this.navTo('CreateNotification', {
				Purpose: 'Display',
				NotificationNumber: notificationObject.NotifNo
			}, this.getModel('Device').getProperty('/isNoPhone'));
			this.getParentController().hideMaster();
		},

		onAdvancedSearchPress: function() {
			if (!this.getDialog('AdvancedSearch')) {
				var advancedSearch = this.initializeFragment('AdvancedSearch');
				var listFunctionalLocationInputControl = this.getFragmentElementById('AdvancedSearch', 'listFunctionalLocationInputControl');

				listFunctionalLocationInputControl.addValidator(this.functionalLocationListValidator.bind(this));

				this.isHybridApplicationUser() && this.renderSuggestionInput(listFunctionalLocationInputControl);

				advancedSearch.open();
			} else {
				this.openSimpleDialog('AdvancedSearch');
			}

			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
		},

		onAdvancedSearch: function() {
			this.getFilteredNotifications();
			this.getDialog('AdvancedSearch').close();
		},

		onListFunctionalLocationsValueHelp: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'AdvancedSearchNotificationsListFunctionalLocations');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', false);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy();
		},

		onListFunctionalLocationTokensAdd: function(tokensToAdd, action) {
			if (action === 'OK') {
				this.addListFunctionalLocationToModel(tokensToAdd);
			}

			this.getModel('ViewModel').setProperty('/FunctionalLocationTokenValue', '');
		},

		onNotificationTypeValueHelp: function() {
			this.openDialog('SearchDialog', this.getNotificationTypeDialogParameters());
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					firstValueToSave: 'FilterParameters/Workcenters'
				})
			);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					firstValueToSave: 'FilterParameters/Plangroups'
				})
			);
		},

		onCloseAdvancedSearch: function() {
			this.getDialog('AdvancedSearch').close();

			this.getModel('ViewModel').setProperty('/FilterParameters', this.lastSearchFilterParameters);
		},

		onOpenErrorInformationPopover: function(pressEvent) {
			this.initializeFragment('ErrorMessages').openBy(pressEvent.getSource());
		},

		onNotificationLiveSearch: function(searchEvent) {
			this.filterNotificationList(searchEvent.getParameter('newValue'));
		},

		onNotificationPullToRefresh: function() {
			this.handleListRefresh();
		},

		onSearchBarValueHelpPress: function() {
			this.isHybridApplicationUser() ? this.onPressScanId() : this.handleListRefresh();
		},

		onSortButtonPress: function() {
			this.openSimpleDialog('NotificationSort');
		},

		onSortConfirm: function(confirmEvent) {
			this.handleSort(confirmEvent, this.getElementById('notificationListContainer'));
		},

		onSystemConditionChange: function(changeEvent) {
			if (!changeEvent.getParameters().selectedItem.getKey()) {
				this.getModel('ViewModel').setProperty('/FilterParameters/SystemCondition', '');
			}
		},

		onSaveVariantButtonPress: function() {
			this.setVariantSaveDefaults();
			this.openSimpleDialog('SaveVariant');
		},

		onSaveVariant: function() {
			var variantInfo = this.validateVariantNaming('NOTIFS');
			if (variantInfo) {
				this.setVariantDialogBusy(true);
				var viewModel = this.getModel('ViewModel');
				this.saveVariant(
						variantInfo.VariantId,
						'NOTIFS',
						variantInfo.Description,
						viewModel.getProperty('/FilterParameters'),
						viewModel.getProperty('/SaveVariantDialog/IsDefault')
					)
					.done(function() {
						this.setVariantsToModel();
						this.onCloseSaveVariant();
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(this.setVariantDialogBusy.bind(this, false));
			}
		},

		onSelectedVariantChange: function() {
			var selectedId = this.getModel('ViewModel').getProperty('/SelectedVariant');
			if (selectedId === '000') {
				var originalFilterParameters = this.getModel('ViewModel').getProperty('/OriginalFilterParameters');
				this.getModel('ViewModel').setProperty('/FilterParameters', this.generateFilterParametersCopy(originalFilterParameters));
			} else {
				var selectedVariant = this.getVariantWithTypeAndId('NOTIFS', selectedId);
				var oFilterParameters = this.generateFilterParametersObject(JSON.parse(selectedVariant.Data));
				this.getModel('ViewModel').setProperty('/FilterParameters', oFilterParameters);
			}
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		getFilterParameters: function() {
			var filterParameters = this.getUserParameters();

			var workCenterParameters = {
				filters: this.generateFilter('Workcenter', filterParameters.Workcenters && filterParameters.Workcenters.split(',') || [''])
			};
			var planGroupParameters = {
				filters: this.generateFilter('Plangroup', filterParameters.Plangroups && filterParameters.Plangroups.split(',') || [''])
			};

			var endDate = this.getListSelectionEndDate();

			var defaultSystemConditions = [{
				StatusInt: 'I0068'
			}, {
				StatusInt: 'I0070'
			}];

			if (filterParameters.FunctLocs) {
				this.tokensAreValid(filterParameters.FunctLocs.toUpperCase().split(',').map(this.removeWhiteSpace))
					.done(this.addListFunctionalLocationToModel.bind(this))
					.fail(function() {
						this.getModel('ViewModel').setProperty('/FilterParameters/FunctLocs', []);
					}.bind(this));
			}

			this.getModel('ViewModel').setProperty('/FilterParameters', {
				Plant: filterParameters.Plant,
				Workcenters: [],
				Plangroups: [],
				FunctLocs: [],
				NotificationTypes: [],
				SystemCondition: defaultSystemConditions
			});

			this.getModel('ViewModel').setProperty('/FilterParameters/NotificationStartDate', new Date());
			this.getModel('ViewModel').setProperty('/FilterParameters/NotificationEndDate', endDate);

			if (this.getConfigurationModel().isVariantEnabled()) {
				this.setVariantsToModel();
			}

			$.when(
					this.oDataUtil.read('WorkCenterSet', workCenterParameters),
					this.oDataUtil.read('PlanningGroupSet', planGroupParameters)
				)
				.done(this.handleUserParametersObjectsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
		},

		handleUserParametersObjectsSuccess: function(workcenters, planGroups) {
			this.getModel('ViewModel').setProperty('/FilterParameters/Workcenters', workcenters);
			this.getModel('ViewModel').setProperty('/FilterParameters/Plangroups', planGroups);

			this.initialFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));
			this.lastSearchFilterParameters = $.extend(true, {}, this.getModel('ViewModel').getProperty('/FilterParameters'));

			var filterParams = this.getModel('ViewModel').getProperty('/FilterParameters');
			this.getModel('ViewModel').setProperty('/OriginalFilterParameters', this.generateFilterParametersCopy(filterParams));
			this.setDefaultVariant();
		},

		handleListRefresh: function() {
			this.areObjectsIdentical(
				this.getModel('ViewModel').getProperty('/FilterParameters'),
				this.initialFilterParameters
			) ? this.refreshOfflineNotifications() : this.getFilteredNotifications();
		},

		refreshOfflineNotifications: function() {
			if (this.isHybridApplicationUser()) {
				this.setAppBusyMode();

				this.refreshNotifications()
					.always(function() {
						if (this.getElementById('pullToRefresh')) {
							this.getElementById('pullToRefresh').hide();
						}
						this.setAppNotBusyMode();
					}.bind(this));
			} else {
				this.getNotificationsForBrowser();
			}
		},

		getNotificationsForBrowser: function() {
			var parameters = {
				recordOperation: true,
				urlParameters: {
					'$expand': 'Attachments'
				}
			};
			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}
			this.getNotifications(parameters);
		},

		getFilteredNotifications: function() {
			var parameters = {
				online: true,
				filters: this.constructFilterArray(),
				recordOperation: true,
				urlParameters: {
					'$expand': 'Attachments'
				}
			};
			var maxResults = this.getTopValue();
			if (maxResults) {
				parameters.urlParameters['$top'] = maxResults;
			}
			this.getNotifications(parameters);
		},

		getNotifications: function(parameters) {
			this.openBusyDialog({
				service: 'NotifSet'
			});

			parameters = parameters || {};
			parameters.returnSapMessages = true;
			this.oDataUtil.read('NotifSet', parameters)
				.done(this.handleGetNotificationsSuccess.bind(this))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(function() {
					if (this.getElementById('pullToRefresh')) {
						this.getElementById('pullToRefresh').hide();
					}
					this.closeBusyDialog();
				}.bind(this));
		},

		handleGetNotificationsSuccess: function(notifications, sapMessages) {
			if (notifications) {
				this.getModel('NotificationsModel').setProperty('/Notifications', notifications.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil)));
			}
			if (sapMessages) {
				this.checkIfAllResultsDisplayed(sapMessages);
			}
		},

		shouldShowMaster: function(navigationData) {
			return !!(
				this.isNotificationsRoute() &&
				(this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'Notifications') ||
					this.navigatedToDetailViewFromView(navigationData, 'CreateNotification', 'Notifications'))
			);
		},

		shouldHideMaster: function(navigationData) {
			return !!(this.navigatedToDetailViewFromView(navigationData, 'OrderSplitContainer', 'CreateNotification'));
		},

		isNotificationsRoute: function() {
			return location.hash.split('/').pop() === 'Notifications';
		},

		isDisplayNotificationRoute: function() {
			return location.hash.split('/').indexOf('CreateNotification') !== -1 &&
				(location.hash.split('/').indexOf('Display') !== -1 || location.hash.split('/').indexOf('Edit') !== -1);
		},

		handleScanSuccess: function(result) {
			this.getElementById('notificationSearchField').setValue(result.text || '');

			this.filterNotificationList(result.text || '');
		},

		filterNotificationList: function(filterValue) {
			this.getElementById('notificationListContainer')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('ShortText', [filterValue], 'Contains')
						.concat(
							this.generateFilter('FunctLoc', [filterValue.toUpperCase()], 'Contains'),
							this.generateFilter('FunctLocDescr', [filterValue.toUpperCase()], 'Contains'),
							this.generateFilter('Equipment', [filterValue.toUpperCase()], 'Contains'),
							this.generateFilter('EquipmentDescr', [filterValue.toUpperCase()], 'Contains'),
							this.generateFilter('NotifNo', [filterValue], 'Contains')
						)
					)
				]);
		},

		addListFunctionalLocationToModel: function(functionalLocations) {
			this.getModel('ViewModel').setProperty(
				'/FilterParameters/FunctLocs',
				this.getModel('ViewModel').getProperty('/FilterParameters/FunctLocs')
				.concat(functionalLocations)
				.filter(this.filterDublicateFunctionalLocations)
			);
		},

		constructFilterArray: function() {
			var filterObject = this.getModel('ViewModel').getProperty('/FilterParameters');
			var createdBy = filterObject.Createdby ? this.getUserId() : '';

			var arrayOfValues = [
				filterObject.Plant, filterObject.FunctLocs, filterObject.NotificationTypes,
				filterObject.Priority, filterObject.Workcenters, filterObject.Plangroups,
				filterObject.SystemCondition, createdBy
			];
			var arrayOfDateValues = [
				[filterObject.NotificationStartDate, filterObject.NotificationEndDate]
			];

			return this.createArray(arrayOfValues, arrayOfDateValues);
		},

		createArray: function(arrayOfValues, arrayOfDateValues) {
			var arrayParametersToIndecies = {
				'FunctLocInternalId': 1,
				'Workcenter': 4,
				'Plangroup': 5,
				'NotifType': 2,
				'SystemStatuses': 6
			};

			var arrayOfProperties = [
				'WorkcenterPlant', 'FunctLocInternalId', 'NotifType',
				'Priority', 'Workcenter', 'Plangroup',
				'SystemStatuses', 'Createdby'
			];

			var servicePropertyToObjectKey = {
				'FunctLocInternalId': 'InternalId',
				'Workcenter': 'Workcenter',
				'Plangroup': 'Plangroup',
				'NotifType': 'Notiftype',
				'SystemStatuses': 'StatusInt'
			};

			var arrayOfDateProperties = ['NotifDate'];

			var filterArray = arrayOfProperties.reduce(function(array, value, index) {
				var parameter = '';

				if (arrayParametersToIndecies[value]) {
					parameter = (arrayOfValues[arrayParametersToIndecies[value]] || []).map(function(parameterObject) {
						return parameterObject[servicePropertyToObjectKey[value]];
					}).join(',');
				} else {
					parameter = arrayOfValues[index];
				}
				return parameter ? array.concat(this.generateFilter(value, parameter.split(','))) : array;
			}.bind(this), []);

			filterArray = arrayOfDateValues.reduce(function(array, value, i) {
				return value[1] && value[0] ? array.concat(new sap.ui.model.Filter(arrayOfDateProperties[i], sap.ui.model.FilterOperator.BT, value[1].setHours(12), value[0].setHours(12))) : array;
			}, filterArray);

			return filterArray;
		},

		setVariantsToModel: function() {
			this.getModel('ViewModel').setProperty('/SaveVariantDialog/Existing', this.getVariantsWithType('NOTIFS'));
			this.getModel('ViewModel').setProperty('/Variants', this.getVariantsWithTypeSelectionList('NOTIFS'));
		},

		setDefaultVariant: function() {
			var defaults = this.getDefaultVariants();
			var defaultVariant = '000';
			if (defaults['NOTIFS']) {
				defaultVariant = defaults['NOTIFS'];
			}
			this.getModel('ViewModel').setProperty('/SelectedVariant', defaultVariant);
			this.onSelectedVariantChange();
		}

	});
});