sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.CreateNotification', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			var that = this;

			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {
				Equipments: [],
				FunctionalLocationIsValid: true,
				EquipmentIsValid: true,
				CancelledDuringSession: false,
				ShowCatalogProfile: true,
				DisplayNotificationCoding: true
			};

			this.setModel('ViewModel', initialViewModel);

			this.subscribeToEvent('app', 'navigate', this.handleNavigate.bind(this));

			this.subscribeToEvent('functionalLocationSelected', 'CreateNotificationTechinalObject', this.handleTechnicalObjectSelectedFromHierarchy.bind(this));

			this.getElementById('workCenterLabel').onAfterRendering = function() {
				if (sap.m.Label.onAfterRendering) {
					sap.m.Label.onAfterRendering.apply(this, arguments);
				}

				that.removeInvisibleLabels();
			};

			if (!this.isHybridApplicationUser() && this.isCreateNotificationRoute()) {
				this.subscribeToEvent('root', 'initialDownLoaddone', this.setDefaultParameters.bind(this));
			}
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'CreateNotification') {
				var navigationArguments = navigationEvent.getParameter('arguments');
				var navigationPurpose = navigationArguments.Purpose;
				var notificationId = navigationArguments.NotificationNumber;

				BaseController.prototype.routeMatched.apply(this, arguments);
				this.clearAttachmentDeleteQueue();

				this.getGlobalModel().setProperty('/EditNotification', navigationPurpose === 'Create' || navigationPurpose === 'Edit');

				if (navigationPurpose === 'Create') {
					this.getElementById('notificationTypeSelectControl')
						.getBinding('items')
						.filter(
							this.generateFilter('Create', ['X'])
							.concat(this.generateFilter('Notiftype', [''], 'NE'))
						);
				} else {
					if (navigationPurpose === 'Display') {
						this.validateTechnicalObject(this.getFunctionalLocation())
							.done(this.tehcnicalObjectValid.bind(this, true, true))
							.fail(this.tehcnicalObjectNotValid.bind(this));

						this.setShowNotificationCoding();
					}

					if (notificationId && this.getNotificationModel().getProperty('/NotifNo') !== notificationId) {
						this.getNotificationFromSap(notificationId)
							.done(this.handleGetNavigatedNotificationSuccess.bind(this));
					}

					this.getElementById('notificationTypeSelectControl')
						.getBinding('items')
						.filter(
							this.generateFilter('List', ['X'])
							.concat(this.generateFilter('Notiftype', [''], 'NE'))
						);
				}

				this.filterPriorities(this.getNotificationModel().getProperty('/NotifType'));

				this.getModel('ViewModel').setProperty('/CancelledDuringSession', false);

				this.rerenderTextAreas();
			}
		},

		handleGetNavigatedNotificationSuccess: function(notifications) {
			if (notifications && notifications.length === 1) {
				this.getNotificationModel().setData(this.models.getNotificationDefaults(notifications.map(this.oDataUtil.handleResultsObjects.bind(this.oDataUtil))[0]));
			}
		},

		handleNavigate: function(channel, eventName, navigationData) {
			if (this.navigatedToNotificationCreation(navigationData)) {
				this.validateTechnicalObject(this.getFunctionalLocation())
					.done(this.tehcnicalObjectValid.bind(this, false, false))
					.fail(this.tehcnicalObjectNotValid.bind(this));
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavigateBack: function() {
			this.shouldShowWarningMessage() ?
				this.openNavigationConfimation() :
				this.handleNavBack();
		},

		onHardwareNavigateBack: function() {
			if (this.isTablet() && !this.notificationIsInEditMode() && !this.getParentController().getSplitContainer().isMasterShown()) {
				this.getParentController().showMaster();
			} else {
				this.onNavigateBack();
			}
		},

		onActionsButtonPress: function(pressEvent) {
			this.initializeFragment('NotificationActionButtons').openBy(pressEvent.getSource());
		},

		onCompleteNotificationPress: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('CONFIRM_NOTIFICATION_COMPLETE_TEXT'),
				onClose: this.onHandleNotificationComplete.bind(this),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		onHandleNotificationComplete: function(action) {
			if (action === 'OK') {
				var notif = this.getNotificationModel().getProperty('/NotifNo');
				this.handleNotificationComplete(notif)
					.done(this.handleNotificationCompleteSuccess.bind(this));
			}
		},

		handleNotificationCompleteSuccess: function() {
			this.getNotificationModel().setProperty('/Completed', 'X');
		},

		onCreateWorkOrderPress: function() {
			if (this.notificationIsInEditMode()) {
				this.isValid() ? this.postNotification(this.handleCreateWorkOrderWithReferenceToNotification.bind(this)) : this.getModel('ViewModel').updateBindings();
			} else {
				this.handleCreateWorkOrderWithReferenceToNotification();
			}
		},

		onShowOrderPress: function() {
			var orderNumber = this.getNotificationModel().getProperty('/WorkOrderNo');
			this.handleNavigateToOrder(orderNumber);
		},

		onCancelNotificationPress: function() {
			this.openDialog('CancelNotification');
		},

		onShowErrorMessage: function() {
			this.showMessageBox({
				title: this.getResourceBundleText('COMMON_ERROR_TITLE'),
				message: this.getNotificationModel().getProperty('/ErrorMessage'),
				type: 'Error'
			});
		},

		onDeleteNotificationPress: function() {
			this.showMessageBox({
				type: 'Warning',
				title: this.getResourceBundleText('WARNING_TITLE'),
				message: this.getResourceBundleText('CONFIRM_NOTIFICATION_DELETION_TEXT'),
				onClose: this.handleNotificationDelete.bind(this),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL]
			});
		},

		onEditButtonPress: function() {
			this.navTo('CreateNotification', {
				Purpose: 'Edit',
				NotificationNumber: this.getNotificationNumber()
			}, this.isPhone());
		},

		onSaveButtonPress: function() {
			this.isValid() ? this.postNotification(this.handleCreateSuccess.bind(this, this.getNotificationNumber())) : this.getModel('ViewModel').updateBindings();
		},

		onTechnicalObjectInputChange: function(oEvent) {
			var tehcnicalObject = oEvent.getParameter('newValue').substr(
				0,
				oEvent.getParameter('newValue').indexOf(' - ') !== -1 ?
				oEvent.getParameter('newValue').indexOf(' - ') :
				oEvent.getParameter('newValue').length
			);
			this.validateTechnicalObject(tehcnicalObject && tehcnicalObject.toUpperCase() || '')
				.done(this.tehcnicalObjectValid.bind(this, false, false))
				.fail(this.tehcnicalObjectNotValid.bind(this));
		},

		onPressNavigateToHierarchy: function() {
			this.getGlobalModel().setProperty('/HierarchySelectionEvent', 'CreateNotificationTechinalObject');
			this.getGlobalModel().setProperty('/HierarchyGetEquipments', true);
			this.getGlobalModel().setProperty('/HierarchyGetMaterials', false);
			this.getGlobalModel().setProperty('/HierarchyGetFunctionalLocations', true);
			this.getGlobalModel().setProperty('/HierarchyDisableMaterialSelection', false);

			this.navigateToHierarchy(this.getFunctionalLocation());
		},

		onNotificationTypeChange: function(changeEvent) {
			var object = changeEvent.getParameter('selectedItem').getBindingContext('SelectionValuesModel').getObject();
			this.getNotificationModel().setProperty('/WoType', object.OrdertypeDefault || '');
			this.getModel('ViewModel').setProperty('/DisplayNotificationCoding', !!object.ShowNotificationCoding);

			this.getNotificationModel().setProperty('/Priority', '');
			this.filterPriorities(object.Notiftype);
		},

		onWorkCenterValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getWorkCenterDialogParameters({
					saveModelName: 'NewNotificationModel',
					multiSelect: false,
					itemPressHandler: this.onWorkCenterSelected.bind(this)
				})
			);
		},

		onWorkCenterSelected: function(selectEvent) {
			var selectedWorkCenter = selectEvent.getSource().getBindingContext('SelectionValuesModel').getObject();
			this.getNotificationModel().setProperty('/WorkcenterPlant', selectedWorkCenter.Plant);
		},

		onPlanGroupValueHelp: function() {
			this.openDialog(
				'SearchDialog',
				this.getPlannerGroupDialogParameters({
					saveModelName: 'NewNotificationModel',
					multiSelect: false
				})
			);
		},

		onCatalogProfileValueHelp: function() {
			var catalogProfile = this.getNotificationModel().getProperty('/CatalogProfile');
			this.openDialog(
				'SearchDialog',
				this.getCatalogProfileDialogParameters({
					itemPressHandler: this.handleCatalogProfileSelected.bind(this, catalogProfile)
				})
			);
		},

		onObjectPartValueHelp: function() {
			this.openDialog(
				'GroupCodeDialog', {
					saveModelName: 'NewNotificationModel',
					catalogId: this.getConfigurationModel().getObjectPartCodeCatalogId(),
					notifType: this.getNotificationModel().getProperty('/NotifType'),
					catalogProfile: this.getNotificationModel().getProperty('/CatalogProfile'),
					groupIdProperty: 'DlCodegrp',
					groupDescriptionProperty: 'DlCodegrpDescr',
					codeIdProperty: 'DlCode',
					codeDescriptionProperty: 'DlCodeDescr'
				}
			);
		},

		onTaskValueHelp: function() {
			this.openDialog(
				'GroupCodeDialog', {
					saveModelName: 'NewNotificationModel',
					catalogId: this.getConfigurationModel().getTaskCodeCatalogId(),
					notifType: this.getNotificationModel().getProperty('/NotifType'),
					catalogProfile: this.getNotificationModel().getProperty('/CatalogProfile'),
					groupIdProperty: 'TaskCodegrp',
					groupDescriptionProperty: 'TaskCodegrpDescr',
					codeIdProperty: 'TaskCode',
					codeDescriptionProperty: 'TaskCodeDescr'
				}
			);
		},

		onDamageCodeValueHelp: function() {
			this.openDialog(
				'GroupCodeDialog', {
					saveModelName: 'NewNotificationModel',
					catalogId: this.getConfigurationModel().getDamageCodeCatalogId(),
					notifType: this.getNotificationModel().getProperty('/NotifType'),
					catalogProfile: this.getNotificationModel().getProperty('/CatalogProfile'),
					groupIdProperty: 'DCodegrp',
					groupDescriptionProperty: 'DCodegrpDescr',
					codeIdProperty: 'DCode',
					codeDescriptionProperty: 'DCodeDescr'
				}
			);
		},

		onCauseCodeValueHelp: function() {
			this.openDialog(
				'GroupCodeDialog', {
					saveModelName: 'NewNotificationModel',
					catalogId: this.getConfigurationModel().getCauseCodeCatalogId(),
					notifType: this.getNotificationModel().getProperty('/NotifType'),
					catalogProfile: this.getNotificationModel().getProperty('/CatalogProfile'),
					groupIdProperty: 'CauseCodegrp',
					groupDescriptionProperty: 'CauseCodegrpDescr',
					codeIdProperty: 'CauseCode',
					codeDescriptionProperty: 'CauseCodeDescr'
				}
			);
		},

		onSuccessDialogClose: function() {
			var workOrder = this.getModel('ViewModel').getProperty('/SuccessDialogWorkOrder');
			if (!workOrder) {
				if (this.notificationIsInEditMode() || this.isPhone()) {
					this.handleNavBack();
				} else if (!this.getParentController().getSplitContainer().isMasterShown()) {
					this.getParentController().showMaster();
				}
			}
			this.getModel('ViewModel').setProperty('/SuccessDialogWorkOrder', '');
		},

		onUploadComplete: function(oEvent) {
			this.handleUploadComplete(oEvent, this.getNotificationModel());
		},

		onAttachmentDeleteButtonPress: function(deleteEvent) {
			var deleted = deleteEvent.getParameter('item').getBindingContext('NewNotificationModel').getObject();
			if (deleted.LinkId && deleted.DocId) {
				this.addToAttachmentDeleteQueue(deleted);
			}
			this.getNotificationModel().setProperty(
				'/Attachments',
				this.getNotificationModel().getProperty('/Attachments').filter(function(attachment) {
					return deleted.LinkId !== attachment.LinkId;
				})
			);
		},

		onShowDMSDocumentsPress: function() {
			var equipment = this.getNotificationModel().getProperty('/Equipment');
			var functionalLocation = this.getNotificationModel().getProperty('/FunctLocInternalId');
			var notification = this.getNotificationNumber();

			this.openDialog('DisplayDMSDocuments', {
				ObjectId: notification,
				ObjectType: 'PMQMEL',
				TechnicalObject: equipment || functionalLocation,
				Type: equipment ? 'EQUI' : 'IFLOT'
			});
		},

		onWorkOrderLinkPress: function() {
			var workOrder = this.getNotificationModel().getProperty('/WorkOrderNo') || '';
			if (workOrder) {
				this.handleNavigateToOrder(workOrder);
			}
		},

		onDrawPictureAttachment: function() {
			this.openDialog('ImageEditor', {
				Attachments: this.getNotificationModel().getData().Attachments
			});
		},

		onCreateWorkOrderChange: function() {
			var createWO = this.getModel('NewNotificationModel').getProperty('/CreateWo');
			if (createWO) {
				this.getModel('NewNotificationModel').setProperty('/CreateWo', '');
				// Get default order type from NotifTypeSet
				var orderType = this.getModel('NewNotificationModel').getProperty('/WoType');
				this.openDialog('SearchDialog', {
					configurationModelName: 'SelectionValuesModel',
					pathToModel: '/PMActivityTypes',
					saveModelName: 'NewNotificationModel',
					listItemValueKey: 'PmactType',
					listItemDescriptionKey: 'Name',
					optionalValueKey: orderType ? '' : 'OrderType',
					firstValueToSave: 'WoPmacttype',
					dialogTitle: this.getResourceBundleText('CREATE_NOTIFICATION_PMACTTYPE_SELECT'),
					filters: orderType ? this.generateFilter('OrderType', [orderType]) : [],
					itemPressHandler: this.onPMActTypeSelected.bind(this),
					multiSelect: false
				});
			} else {
				this.getNotificationModel().setProperty('/WoPmacttype', '');
			}
		},

		onPMActTypeSelected: function(oEvent) {
			this.getNotificationModel().setProperty('/CreateWo', 'X');
			var object = oEvent.getSource().getBindingContext('SelectionValuesModel').getObject() || {};
			this.getNotificationModel().setProperty('/WoType', object.OrderType || '');
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		setDefaultParameters: function() {
			var planGroups;

			this.getNotificationModel()
				.setData(
					$.extend(true, this.getNotificationModel().getData(), this.models.getNotificationDefaults())
				);

			this.filterPriorities(this.getNotificationModel().getProperty('/NotifType'));
			this.setDefaultWoType(this.getNotificationModel().getProperty('/NotifType'));

			planGroups = this.getModel('SelectionValuesModel').getProperty('/PlanGroups');

			// set plan group, if only one returned from service
			if (planGroups && planGroups.length === 1) {
				this.getNotificationModel().setProperty('/Plangroup', planGroups[0].Plangroup);
			}
		},

		setDefaultWoType: function(notifType) {
			var notificationTypes = this.getModel('SelectionValuesModel').getProperty('/NotificationTypeValues') || [];
			var defaultWoType = '';
			notificationTypes.some(function(type) {
				if (type.NotifType === notifType) {
					defaultWoType = type.OrdertypeDefault || '';
					return true;
				}
			});
			this.getNotificationModel().setProperty('/WoType', defaultWoType);
		},

		handleCameraSuccess: function(fileUri) {
			this.getNotificationModel().setProperty(
				'/Attachments',
				this.getNotificationModel().getProperty('/Attachments').concat([this.getUploadCollectionItem(fileUri)])
			);
		},

		handleGetPictureFromFileSystemSuccess: function(fileUris) {
			var selectedPictures = fileUris.map(function(fileUri) {
				return this.getUploadCollectionItem(fileUri.path);
			}.bind(this));
			this.getNotificationModel().setProperty(
				'/Attachments',
				this.getNotificationModel().getProperty('/Attachments').concat(selectedPictures)
			);
		},

		handleDrawSuccess: function(fileUri) {
			var attachment = this.getUploadCollectionItem(fileUri);
			attachment = this.insertTemporaryDocIds(attachment);
			if (this.isHybridApplicationUser()) {
				this.getNotificationModel().setProperty(
					'/Attachments',
					this.getNotificationModel().getProperty('/Attachments').concat([attachment])
				);
			} else {
				this.getModel('ViewModel').setProperty('/AttachmentsBusy', true);
				this.postAttachment(attachment)
					.done(function(oEvent) {
						this.handleUploadComplete(oEvent, this.getNotificationModel());
					}.bind(this))
					.always(function() {
						this.getModel('ViewModel').setProperty('/AttachmentsBusy', false);
					}.bind(this));
			}
		},

		handleDeleteExisting: function(docId) {
			var deleted = {};
			(this.getNotificationModel().getProperty('/Attachments') || []).some(function(attachment) {
				if (attachment.DocId === docId) {
					deleted = attachment;
				}
			});
			if (deleted.LinkId && deleted.DocId) {
				this.addToAttachmentDeleteQueue(deleted);
			}
			this.getNotificationModel().setProperty(
				'/Attachments',
				this.getNotificationModel().getProperty('/Attachments').filter(function(attachment) {
					return docId !== attachment.DocId;
				})
			);
		},

		navigatedToNotificationCreation: function(navigationData) {
			return !!(
				(
					this.navigatedToDetailViewFromView(navigationData, 'RouteSplitContainer', 'CreateNotification') ||
					this.navigatedToDetailViewFromView(navigationData, 'OrderSplitContainer', 'CreateNotification') ||
					this.navigatedToDetailViewFromView(navigationData, 'ObjectInfo', 'CreateNotification') ||
					this.navigatedToDetailViewFromView(navigationData, 'TilePage', 'CreateNotification')
				) &&
				location.hash.split('/').indexOf('Create') !== -1
			);
		},

		rerenderTextAreas: function() {
			setTimeout(function() {
				this.getElementById('inputTextArea') && this.getElementById('inputTextArea').rerender();
				this.getElementById('inputTextArea') && this.getElementById('displayTextArea').rerender();
			}.bind(this), this.isPhone() ? 500 : 0);
		},

		filterPriorities: function(notifType) {
			this.getElementById('prioritySelectControl')
				.getBinding('items')
				.filter(
					this.generateFilter('Notiftype', [notifType])
					.concat(this.generateFilter('PriorityId', [''], 'NE'))
				);
		},

		handleScanSuccess: function(result) {
			if (result.text) {
				this.validateTechnicalObject(result.text || '')
					.done(this.tehcnicalObjectValid.bind(this, false, false))
					.fail(this.tehcnicalObjectNotValid.bind(this));
			}
		},

		tehcnicalObjectValid: function(dontSetCatalogProfile, dontSetWorkCenter, tehcnicalObject) {
			if (tehcnicalObject) {
				tehcnicalObject.hasOwnProperty('Equnr') ?
					this.equipmentValid(dontSetCatalogProfile, dontSetWorkCenter, tehcnicalObject) :
					this.functionalLocationValid(dontSetCatalogProfile, dontSetWorkCenter, tehcnicalObject);
			} else {
				this.equipmentValid();
				this.functionalLocationValid();
			}
		},

		tehcnicalObjectNotValid: function() {
			this.equipmentNotValid();
			this.functionalLocationNotValid();
		},

		handleTechnicalObjectSelectedFromHierarchy: function(channel, eventName, selectedObject) {
			if (selectedObject.type === 'Equipment') {
				this.validateEquipment(selectedObject.InternalId)
					.done(this.equipmentValid.bind(this, false, false))
					.fail(this.equipmentNotValid.bind(this));
			} else {
				this.getNotificationModel().setProperty('/Equipment', '');
				this.getNotificationModel().setProperty('/EquipmentDescr', '');

				this.validateFunctionalLocation(selectedObject.InternalId)
					.done(this.functionalLocationValid.bind(this, false, false))
					.fail(this.functionalLocationNotValid.bind(this));
			}
		},

		handleConfirmPopUpClose: function(action) {
			action !== 'OK' || this.handleNavBack();
		},

		handleNavBack: function() {
			if (!this.isPhone() && this.isEditingExsistingNotification()) {
				this.getNotificationNumberFromUrlParameters();
			}
			this.getView().mAggregations.content[0].scrollTo(0);
			this.onNavBack();
		},

		isEditingExsistingNotification: function() {
			return !!(this.getNotificationNumber() &&
				(this.getNotificationNumber().charAt(0) !== '%' || this.getNotificationModel().getProperty('/NotSync')) &&
				this.notificationIsInEditMode()
			);
		},

		isCreateNotificationRoute: function() {
			return location.hash.indexOf('CreateNotification/Create') !== -1;
		},

		functionalLocationValid: function(dontSetCatalogProfile, dontSetWorkCenter, functionalLocationObject) {
			if (functionalLocationObject) {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);

				this.getNotificationModel().setProperty('/FunctLocInternalId', functionalLocationObject.InternalId);
				this.getNotificationModel().setProperty('/FunctLoc', functionalLocationObject.Floc);
				this.getNotificationModel().setProperty('/FunctLocDescr', functionalLocationObject.Descr);

				if (functionalLocationObject.Workcenter && !dontSetWorkCenter) {
					this.getNotificationModel().setProperty('/Workcenter', functionalLocationObject.Workcenter);
				}

				dontSetCatalogProfile || this.setCatalogProfile(functionalLocationObject.CatalogProfile);
			} else {
				this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', true);
				this.getNotificationModel().setProperty('/FunctLocInternalId', '');
				this.getNotificationModel().setProperty('/FunctLoc', '');
				this.getNotificationModel().setProperty('/FunctLocDescr', '');
			}
			this.getNotificationModel().updateBindings(true);
		},

		functionalLocationNotValid: function() {
			this.getModel('ViewModel').setProperty('/FunctionalLocationIsValid', false);
		},

		equipmentValid: function(dontSetCatalogProfile, dontSetWorkCenter, equipmentObject) {
			if (equipmentObject) {
				this.getModel('ViewModel').setProperty('/EquipmentIsValid', true);

				this.getNotificationModel().setProperty('/Equipment', equipmentObject.Equnr);
				this.getNotificationModel().setProperty('/EquipmentDescr', equipmentObject.Descr);

				if (equipmentObject.Workcenter && !dontSetWorkCenter) {
					this.getNotificationModel().setProperty('/Workcenter', equipmentObject.Workcenter);
				}

				dontSetCatalogProfile || this.setCatalogProfile(equipmentObject.CatalogProfile);

				this.validateFunctionalLocation(equipmentObject.SupflocInternalId)
					.done(this.functionalLocationValid.bind(this, !!equipmentObject.CatalogProfile, true))
					.fail(this.functionalLocationNotValid.bind(this));
			} else {
				this.getModel('ViewModel').setProperty('/EquipmentIsValid', true);
				this.getNotificationModel().setProperty('/Equipment', '');
				this.getNotificationModel().setProperty('/EquipmentDescr', '');
			}
			this.getNotificationModel().updateBindings(true);
		},

		equipmentNotValid: function() {
			this.getModel('ViewModel').setProperty('/EquipmentIsValid', false);
		},

		isValid: function() {
			return !!(
				this.validate(this.getView(), this.scrollToElement.bind(this, 20)) &&
				this.getModel('ViewModel').getProperty('/FunctionalLocationIsValid')
			);
		},

		setCatalogProfile: function(catalogProfile) {
			if (catalogProfile) {
				var currentCatalogProfile = this.getNotificationModel().getProperty('/CatalogProfile');
				this.oDataUtil.read('CatalogProfilesSet(\'' + catalogProfile + '\')')
					.done(function(catalogProfileObject) {
						this.getNotificationModel().setProperty('/CatalogProfile', catalogProfileObject.CatalogProfile);
						this.getNotificationModel().setProperty('/CatalogProfileDescr', catalogProfileObject.CatalogProfileDescr);

						this.handleCatalogProfileChange(currentCatalogProfile, catalogProfileObject.CatalogProfile);
					}.bind(this))
					.fail(this.emptyCatalogProfile.bind(this));
			} else {
				this.emptyCatalogProfile();
			}
		},

		emptyCatalogProfile: function() {
			this.getNotificationModel().setProperty('/CatalogProfile', '');
			this.getNotificationModel().setProperty('/CatalogProfileDescr', '');
		},

		postNotification: function(successHandler) {
			var postObject = this.getNotificationPostObject();
			var postParameters = {
				online: true
			};

			if (this.isOffline()) {
				postObject.NotSync = true;
				this.insertNotificationToList(postObject);
				this.localStorage.insertNotification(postObject);
				if (postObject.RouteId) {
					this.handleNotificationCreatedDuringRoute(postObject);
				}
				successHandler();
			} else {
				postObject = this.generateNotificationPostObject(postObject);
				this.removeAttachmentQueueItems();

				this.setAppBusyMode();
				this.oDataUtil.create('NotifSet', postObject, postParameters)
					.done(successHandler)
					.fail(this.handleCreateError.bind(this))
					.always(this.setAppNotBusyMode);
			}
		},

		getNotificationPostObject: function() {
			var notification = this.getPostObject(this.getNotificationModel().getData());

			if (!this.isHybridApplicationUser()) {
				(Array.isArray(notification && notification.Attachments) ? notification.Attachments : []).map(this.getAttachmentPostObject.bind(this));
			}

			return notification;
		},

		handleCreateSuccess: function(notificationNumber, response) {
			var attachments = $.extend(true, [], Array.isArray(response && response.Attachments) ? response.Attachments : []);


			if (!this.isHybridApplicationUser()) {
				response.Attachments = (Array.isArray(response && response.Attachments) ? response.Attachments : []).filter(this.filterDummyAttachments.bind(this));
			} else {
				(Array.isArray(response && response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));
			}

			if (response && response.NotifNo) {
				this.removeListObject('Notifications', notificationNumber);
				this.insertNotificationToList(response);
				this.localStorage.removeNotification(notificationNumber);
				this.publishEvent('notification', 'notificationChanged', response);
			}
			this.openSuccessDialog(
				response && response.NotifNo ?
				this.getResourceBundleText((notificationNumber === response.NotifNo ? 'EDIT_SUCCESS_MESSAGE' : 'POST_SUCCESS_MESSAGE'), response.NotifNo) :
				this.getResourceBundleText('POST_SAVE_OFFLINE_MESSAGE'),
				response && response.WorkOrderNo ? response.WorkOrderNo : ''
			);

			if (this.shouldPostAttachments(response)) {
				this.postAttachments(attachments);
			}

			if (response && response.RouteId) {
				this.handleNotificationCreatedDuringRoute(response, notificationNumber);
			}
		},

		handleCreateError: function(errorEvent) {
			if (this.getModel('ViewModel').getProperty('/CancelledDuringSession')) {
				this.getNotificationModel().setProperty('/Cancelled', '');
			}

			this.getModel('ViewModel').setProperty('/CancelledDuringSession', false);

			this.openErrorMessagePopup(errorEvent);
		},

		shouldPostAttachments: function(response) {
			return response && response.NotifNo && response.Attachments && response.Attachments.length;
		},

		handleCreateWorkOrderWithReferenceToNotification: function(response) {
			var notification = response || $.extend(true, {}, this.getNotificationModel().getData());
			var workOrderProperties = {
				NotifNo: notification.NotifNo,
				Priority: notification.Priority,
				LongText: notification.ShortText + '\\n' + notification.LongText,
				FunctLocInternalId: notification.FunctLocInternalId,
				FunctLoc: notification.FunctLoc,
				FunctLocDescr: notification.FunctLocDescr,
				Equipment: notification.Equipment,
				EquipmentDescr: notification.EquipmentDescr,
				Workcenter: notification.Workcenter,
				WorkcenterDescr: notification.WorkcenterDescr,
				Plangroup: notification.Plangroup,
				SafetyRelated: notification.SafetyRelated,
				NotifType: notification.NotifType,
				CauseCodegrp: notification.CauseCodegrp,
				CauseCodegrpDescr: notification.CauseCodegrpDescr,
				CauseCode: notification.CauseCode,
				CauseCodeDescr: notification.CauseCodeDescr,
				CatalogProfile: notification.CatalogProfile,
				CatalogProfileDescr: notification.CatalogProfileDescr
			};

			this.getModel('NewOrderModel').setData(this.models.getOrderDefaults(workOrderProperties));

			this.navTo('CreateOrder', {
				Purpose: 'Create'
			});
		},

		cancelNotification: function() {
			this.getModel('ViewModel').setProperty('/CancelledDuringSession', true);

			this.getNotificationModel().setProperty('/Cancelled', 'X');
			this.postNotification(this.handleCancellationSuccess.bind(this));
		},

		handleCancellationSuccess: function(response) {
			var attachments = $.extend(true, [], Array.isArray(response && response.Attachments) ? response.Attachments : []);

			(Array.isArray(response && response.Attachments) ? response.Attachments : []).map(this.insertTemporaryDocIds.bind(this));

			if (this.getModel('ViewModel').getProperty('/CancelledDuringSession')) {
				response.Completed = 'X';
			}

			this.getModel('ViewModel').setProperty('/CancelledDuringSession', false);

			if (response && response.NotifNo) {
				this.insertNotificationToList(response);
				this.localStorage.removeNotification(response.NotifNo);
			}

			this.openSuccessDialog(
				response && response.NotifNo ?
				this.getResourceBundleText('CANCEL_SUCCESS_MESSAGE', response.NotifNo) :
				this.getResourceBundleText('POST_SAVE_OFFLINE_MESSAGE')
			);
			if (this.shouldPostAttachments(response)) {
				this.postAttachments(attachments);
			}
		},

		shouldShowWarningMessage: function() {
			return !!(
				this.notificationIsInEditMode() &&
				this.notificationHasBeenEdited()
			);
		},

		notificationHasBeenEdited: function() {
			return !!(
				this.isEditingExsistingNotification() ?
				this.notificationDiffersFromOriginal() :
				this.notificationDiffersFromDefault()
			);
		},

		notificationDiffersFromOriginal: function() {
			return !this.areObjectsIdentical(
				this.getNotification(this.getNotificationNumber()),
				this.getNotificationModel().getData()
			);
		},

		notificationDiffersFromDefault: function() {
			return !this.areObjectsIdentical(
				this.removeProperties(this.models.createNewNotificationModel().getData()),
				this.removeProperties(this.getNotificationModel().getData())
			);
		},

		removeProperties: function(notificationObject) {
			notificationObject = $.extend(true, {}, notificationObject);
			delete notificationObject.Desstdate;
			delete notificationObject.Workcenter;
			delete notificationObject.WorkcenterDescr;
			delete notificationObject.FunctLocDescr;
			delete notificationObject.NotifNo;
			delete notificationObject.CatalogProfile;
			delete notificationObject.CatalogProfileDescr;
			delete notificationObject.Plangroup;
			return notificationObject;
		},

		handleNotificationDelete: function(action) {
			if (action === 'OK') {
				var notificationNumber = this.getNotificationModel().getProperty('/NotifNo');

				this.localStorage.removeNotification(notificationNumber);
				this.removeListObject('Notifications', notificationNumber);

				this.onNavBack();

				//phone requires 1 history navigation, other devices 2
				if (!this.isPhone()) {
					this.onNavBack();
				}
			}
		},

		handleCatalogProfileSelected: function(currentCatalogProfile, selectEvent) {
			var selectedCatalogProfile = selectEvent.getSource().getBindingContext('SelectionValuesModel').getObject();
			var selectedCatalogProfileId = selectedCatalogProfile && selectedCatalogProfile.CatalogProfile;
			this.handleCatalogProfileChange(currentCatalogProfile, selectedCatalogProfileId);
		},

		handleCatalogProfileChange: function(currentCatalogProfile, selectedCatalogProfile) {
			if (currentCatalogProfile !== selectedCatalogProfile) {
				this.getNotificationModel().setProperty('/DCodegrp', '');
				this.getNotificationModel().setProperty('/DCodegrpDescr', '');
				this.getNotificationModel().setProperty('/DCode', '');
				this.getNotificationModel().setProperty('/DCodeDescr', '');

				this.getNotificationModel().setProperty('/CauseCodegrp', '');
				this.getNotificationModel().setProperty('/CauseCodegrpDescr', '');
				this.getNotificationModel().setProperty('/CauseCode', '');
				this.getNotificationModel().setProperty('/CauseCodeDescr', '');

				if (this.getConfigurationModel().shouldShowTaskField()) {
					this.getNotificationModel().setProperty('/TaskCodegrp', '');
					this.getNotificationModel().setProperty('/TaskCodegrpDescr', '');
					this.getNotificationModel().setProperty('/TaskCode', '');
					this.getNotificationModel().setProperty('/TaskCodeDescr', '');
				}
				if (this.getConfigurationModel().shouldObjectPartField()) {
					this.getNotificationModel().setProperty('/DlCodegrp', '');
					this.getNotificationModel().setProperty('/DlCodegrpDescr', '');
					this.getNotificationModel().setProperty('/DlCode', '');
					this.getNotificationModel().setProperty('/DlCodeDescr', '');
				}
			}
		},

		setShowNotificationCoding: function() {
			var selectedNotificationType = this.getNotificationModel().getProperty('/NotifType');
			var notificationTypes = this.getSelectionValuesModel().getProperty('/NotificationTypeValues');

			if (notificationTypes) {
				var notificationType = notificationTypes.filter(function(type) {
					return type.Notiftype === selectedNotificationType;
				});

				this.getModel('ViewModel').setProperty('/DisplayNotificationCoding', notificationType.length !== 0 ? !!notificationType[0].ShowNotificationCoding : true);
			}
		}

	});
});