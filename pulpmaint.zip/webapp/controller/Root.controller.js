sap.ui.define([
	'com/upm/maint/controller/CommonController'
], function(CommonController) {
	var userParametersAreSet;
	var onlineMetadatIsLoaded;
	var offlineMetadataIsLoaded;

	return CommonController.extend('com.upm.maint.controller.Root', {

		onInit: function() {
			var navigatedToGeneralApplication = this.getGlobalModel().getProperty('/NavigatedToGeneralApplication');
			this.rootControl = this.byId('rootControl');

			this.customTypesUtil.setI18n(this.getModel('i18n').getResourceBundle());

			if (this.isHybridApplicationUser()) {
				// override language setting to prevent framework from changing the set language
				sap.ui.getCore().getConfiguration().setLanguage = $.noop;

				this.attachOnlineEvent();

				this.modifyHardwareBackNavigation();

				this.subscribeToEvent('app', 'offlineMetadataLoaded', this.handleOfflineMetadataLoaded.bind(this));

				this.subscribeToEvent('app', 'onlineMetadataLoaded', this.handleOnlineMetadataLoaded.bind(this));

				this.subscribeToEvent('app', 'onlineMetadataFailed', this.handleOnlineMetadataFailed.bind(this));

				// refresh SAML token every 5 minutes
				setInterval(this.doSamlAuth.bind(this), 300000);

				document.addEventListener('resume', this.handleResumeEvent.bind(this), false);
				document.addEventListener('pause', this.handlePauseEvent.bind(this), false);

				// handle rendering of busyindicator at startup instead of on the first real case of opening it
				sap.ui.core.BusyIndicator.show();
				sap.ui.core.BusyIndicator.hide();
			} else if (!navigatedToGeneralApplication) {
				this.getGlobalModel().setProperty('/isDownLoadingHelperValues', true);

				this.getUserGroups();

				this.getPlantSpecificValues()
					.done(function() {
						this.publishEvent('root', 'initialDownLoaddone');
					}.bind(this))
					.fail(this.openErrorMessagePopup.bind(this))
					.always(function() {
						this.getGlobalModel().setProperty('/isDownLoadingHelperValues', false);
					}.bind(this));
			}

			// use this sessionId to avoid launchpad dialog destroyment bug
			this.sessionId = Math.random().toString().substr(2, 5);
		},

		onAfterRendering: function() {
			if (!this.isHybridApplicationUser()) {
				if ($('.sapUshellHeadTitle')) {
					setTimeout(function() {
						var title = this.getResourceBundleText('APP_TITLE');
						$('.sapUshellHeadTitle').text(title);
						document.title = title;
					}.bind(this), 500);
				}
				$('#shell-cntnt') && $('#shell-cntnt').attr('x-ms-format-detection', 'none');
			}
		},

		onExit: function() {
			$('#shell-cntnt') && $('#shell-cntnt').removeAttr('x-ms-format-detection');
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'afterNavigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		navigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'navigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		handleOfflineMetadataLoaded: function() {
			this.setOfflineMetadataLoaded(true);

			this.getHelperValues();
		},

		handleOnlineMetadataLoaded: function() {
			this.setOnlineMetadataLoaded(true);

			this.refreshUserGroups();

			if (this.getConfigurationModel().isApprovalEnabled() && this.isHybridApplicationUser()) {
				this.getWorkFlowApprovals()
					.done(this.handleGetApprovalsSuccess.bind(this));
			}

			this.attachPush();

			if (this.getOfflineMetadataLoaded()) {
				this.handleMultiUser();
			} else {
				this.subscribeToEvent('app', 'offlineMetadataLoaded', this.handleMultiUser.bind(this));
			}

			this.flushOfflineStore();
		},

		handleOnlineMetadataFailed: function(channel, event, errorEvent) {
			var statusCode = errorEvent && errorEvent.getParameter('statusCode');

			if (statusCode === 403) {
				this.showMessageBox({
					type: 'Info',
					title: this.getResourceBundleText('LAST_USER_FORGOT_TO_SIGNOUT_POPUP_TITLE'),
					message: this.getResourceBundleText('LAST_USER_FORGOT_TO_SIGNOUT_POPUP_TEXT'),
					actions: [sap.m.MessageBox.Action.OK],
					onClose: this.devapp.devLogon.resetApplication.bind(this.devapp.devLogon)
				});
			}
		},

		handleResumeEvent: function() {
			this.getGlobalModel().setProperty('/IsPaused', false);

			if (!this.isResumingFromPlugin()) {
				this.doSamlAuth();
			}

			this.getGlobalModel().setProperty('/IsResumingFromPlugin', false);
		},

		handlePauseEvent: function() {
			this.getGlobalModel().setProperty('/IsPaused', true);

			if (!this.isResumingFromPlugin()) {
				setTimeout(function() {
					if (this.getGlobalModel().getProperty('/IsPaused')) {
						this.refreshListValues();

						if (this.getConfigurationModel().isApprovalEnabled() && this.isHybridApplicationUser()) {
							this.getWorkFlowApprovals()
								.done(this.handleGetApprovalsSuccess.bind(this));
						}
					}
				}.bind(this), 5000);
			}
		},

		doSamlAuth: function() {
			if (sap.Logon && !this.isOffline() && !this.isResumingFromPlugin()) {
				sap.Logon.performSAMLAuth();
			}
		},

		getHelperValues: function() {
			var deferred = $.Deferred();

			$.when(
					this.getPlantSpecificValues(),
					this.getListValues()
				)
				.done(this.handleHelperValuesSuccess.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		handleHelperValuesSuccess: function() {
			if (this.navigatedToObject('CreateNotification')) {
				this.getNotificationNumberFromUrlParameters();
			} else if (this.navigatedToObject('CreateOrder')) {
				this.getOrderNumberFromUrlParameters();
			}
		},

		getPlantSpecificValues: function() {
			var deferred = $.Deferred();

			var readMethods = this.getConfigurationModel()
				.getPlantDependedServices()
				.map(function(configuration) {
					return this.oDataUtil.read(configuration.service, configuration.parameters);
				}.bind(this));

			$.when.apply($, readMethods)
				.done(this.handlePlantSpecificValuesSuccess.bind(this), deferred.resolve)
				.fail(deferred.reject);

			return deferred.promise();
		},

		handlePlantSpecificValuesSuccess: function(userParameters, plants, planGroups, workCenters, notificationTypes, orderTypes, priorities, catalogProfiles, codeGroups, codes, systemStatuses, activityTypes, systemConditions, persons, routes, scheduleIds, dateRanges, authorizations, variants, alternativeLabelCategories) {
			routes = routes || [];
			scheduleIds = scheduleIds || [];
			dateRanges = dateRanges || [];
			authorizations = authorizations || [];
			variants = variants || [];
			var emptyPriority = {
				PriorityId: '',
				Name: '',
				Notiftype: '11'
			};
			var emptyNotificationType = {
				Notiftype: '',
				Notiftypetext: '',
				Create: 'X'
			};
			var emptyOrderType = {
				OrderType: '',
				Name: '',
				Create: 'X'
			};
			var emptyRouteId = {
				Plant: '',
				RouteId: '',
				RouteDescr: '',
				Plangroup: '',
				Workcenter: ''
			};

			var emptySchedyleId = {
				ScheduleId: '',
				Planplant: '',
				StartDate: '',
				StartTime: '',
				EndDate: '',
				EndTime: '',
				Description: ''
			};

			var emptySystemCondition = {
				Systcond: '',
				SystcondDescr: ''
			};

			var systemStatusFilters = systemStatuses.filter(function(systemStatus) {
				return systemStatus.StatusInt === 'I0001' || systemStatus.StatusInt === 'I0002' || systemStatus.StatusInt === 'I0045';
			});

			var notificationSystemStatusFilters = systemStatuses.filter(function(systemStatus) {
				return systemStatus.StatusInt === 'I0068' || systemStatus.StatusInt === 'I0070' || systemStatus.StatusInt === 'I0072';
			});

			priorities.unshift(emptyPriority);
			notificationTypes.unshift(emptyNotificationType);
			orderTypes.unshift(emptyOrderType);
			routes.unshift(emptyRouteId);
			scheduleIds.unshift(emptySchedyleId);
			systemConditions.unshift(emptySystemCondition);

			this.setUserParameters(userParameters, authorizations);

			[].slice.call(arguments)
				.map(function(argument) {
					return Array.isArray(argument) ? argument : [];
				});

			this.getModel('SelectionValuesModel').setData({
				Plants: plants,
				PlanGroups: planGroups,
				WorkCenters: workCenters,
				NotificationTypeValues: notificationTypes,
				OrderTypeValues: orderTypes,
				PriorityValues: priorities,
				CatalogProfiles: catalogProfiles,
				CodeGroups: codeGroups,
				CodingCodes: codes,
				ScheduleIds: scheduleIds,
				PMActivityTypes: activityTypes,
				SystemConditionValues: systemConditions,
				SystemStatusFilterValues: systemStatusFilters,
				NotificationSystemStatusFilterValues: notificationSystemStatusFilters,
				RouteIds: routes,
				Persons: persons,
				DateRanges: dateRanges,
				Variants: variants,
				AlternativeLabelingCategories: alternativeLabelCategories
			});

			this.formatterUtil.setStatusMap(systemStatuses);

			userParameters && userParameters.length && !this.hasRequiredParameters() && this.navTo('UserParameters', {
				MissingRequiredParamaters: 'true'
			});

			if (Array.isArray(persons) && persons.length) {
				var currentUser = persons.filter(function(person) {
					return !!person.IsCurrentUser;
				})[0];

				if (currentUser) {
					this.getGlobalModel().setProperty('/PersonNumber', currentUser.PersonNumber);
				}
			}
			this.insertVariants(variants);
		},

		getListValuesWithUserParameters: function() {
			var deferred = $.Deferred();

			$.when(
					this.getUserPreferences(),
					this.getListValues()
				)
				.done(this.handleGetListValueWithUserParametersSuccess.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		handleGetListValueWithUserParametersSuccess: function() {

		},

		getUserPreferences: function() {
			var deferred = $.Deferred();
			var readMethods = this.getConfigurationModel()
				.getUserPreferenceServices()
				.map(function(configuration) {
					return this.oDataUtil.read(configuration.service, configuration.parameters);
				}.bind(this));

			$.when.apply($, readMethods)
				.done(this.setUserParameters.bind(this), deferred.resolve)
				.fail(deferred.reject);

			return deferred.promise();
		},

		setUserParameters: function(userParameters, authorizations) {
			var parsedUserParameters = this.parseUserParameters(Array.isArray(userParameters) ? userParameters : []) || {};
			var parsedAuthorizations = this.parseAuthorizations(Array.isArray(authorizations) ? authorizations : []) || {};
			var userId = userParameters[0] && userParameters[0].UserId;

			if (userId) {
				this.getGlobalModel().setProperty('/UserId', userId);
				window.localStorage.setItem('LoggedUser', userId);
			}
			if (parsedUserParameters.Plant) {
				this.setPlantLevelSettings(parsedUserParameters.Plant);
			}

			this.getModel('UserPreferences').setData(parsedUserParameters);

			this.getGlobalModel().setProperty('/ShowEquipmentExchange', parsedAuthorizations.HasEquipmentExchangeRole);

			userParametersAreSet = true;
			this.publishEvent('root', 'userParametersAreSet');
		},

		setPlantLevelSettings: function(plantId) {
			this.oDataUtil.read('PlantsSet(\'' + plantId + '\')')
				.done(this.handlePlantSuccess.bind(this));
		},

		handlePlantSuccess: function(plant) {
			var isBarcodeScanOptionAvailable = plant && plant.BarcodeEnabled;
			var isNFCScanOptionAvailable = plant && plant.NfcEnabled;
			var isRFIDScanOptionAvailable = plant && plant.RfidEnabled;
			var scanOptions = [];
			var barCodeOption = {
				key: 'BARCODE',
				text: this.getResourceBundleText('SCAN_OPTION_BARCODE_TEXT')
			};
			var nfcOption = {
				key: 'NFC',
				text: this.getResourceBundleText('SCAN_OPTION_NFC_TEXT')
			};
			var rfidOption = {
				key: 'RFID',
				text: this.getResourceBundleText('SCAN_OPTION_RFID_TEXT')
			};

			isBarcodeScanOptionAvailable && scanOptions.push(barCodeOption);
			isNFCScanOptionAvailable && scanOptions.push(nfcOption);
			isRFIDScanOptionAvailable && scanOptions.push(rfidOption);

			scanOptions.length === 0 && scanOptions.push(barCodeOption);

			this.getGlobalModel().setProperty('/PlantLevelFunctionalLocation', plant ? plant.RootFloc : '');
			this.getGlobalModel().setProperty('/PlantLevelShowTimeConfirmation', plant && !!plant.TimeConfirmActive);
			this.getGlobalModel().setProperty('/PlantLevelShowStartAndStopButton', plant && !!plant.RouteTimeRecActive);
			this.getGlobalModel().setProperty('/PlantLevelScanOptions', scanOptions);

			this.getTimeRecordUtility().setTimeRecordMaxTime(plant && plant.RouteMaxTimerec);
		},

		getListValues: function() {
			var readMethods = [this.getNotifications(), this.getOrders()];

			if (this.getConfigurationModel().isRouteEnabled()) {
				readMethods.push(this.getRouteWorks());
			}
			return $.when.apply($, readMethods);
		},

		getNotifications: function() {
			var deferred = $.Deferred();
			var notificationSetUrlParameters = {
				urlParameters: {
					'$expand': 'Attachments'
				}
			};
			var maxResults = this.getTopValue();
			if (maxResults) {
				notificationSetUrlParameters.urlParameters['$top'] = maxResults;
			}

			this.oDataUtil.read('NotifSet', notificationSetUrlParameters)
				.done(this.insertNotifications.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		insertNotifications: function(notifications) {
			this.getModel('NotificationsModel').setProperty(
				'/Notifications',
				(this.localStorage.getProperty('/Notifications') || [])
				.concat((notifications || []).map(this.modifyNotification.bind(this)))
				.filter(this.filterDublicateNotifications.bind(this))
			);
		},

		getOrders: function() {
			var deferred = $.Deferred();
			var orderUrlParameters = {
				urlParameters: {
					'$expand': this.getConfigurationModel().getOrderURLParameters()
				}
			};

			var maxResults = this.getTopValue();
			if (maxResults) {
				orderUrlParameters.urlParameters['$top'] = maxResults;
			}

			this.oDataUtil.read('WorkOrderSet', orderUrlParameters)
				.done(this.insertOrders.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		insertOrders: function(orders) {
			var orderListObjects = (this.localStorage.getProperty('/Orders') || [])
				.concat((orders || []).map(this.modifyOrder.bind(this)))
				.filter(this.filterDublicateOrders.bind(this));

			setTimeout(function() {
				var myWorksOrders = $.extend(true, [], orderListObjects);
				this.getModel('MyWorkOrdersModel').setProperty('/MyWorks', orderListObjects);
				this.getModel('OrdersModel').setProperty('/Orders', orderListObjects);
				// user parameters are needed for my work setting
				if (this.areUserParametersSet()) {
					this.setMyWorks(myWorksOrders);
				} else {
					this.subscribeToEvent('root', 'userParametersAreSet', this.setMyWorks.bind(this, myWorksOrders));
				}
			}.bind(this));
		},

		setMyWorks: function(myWorkOrders) {
			this.getModel('MyWorksModel').setProperty('/MyWorks', this.getMyWorkRelevantOperations(myWorkOrders));
		},

		getRouteWorks: function() {
			var deferred = $.Deferred();
			var sorter = [
				new sap.ui.model.Sorter('RouteId', false),
				new sap.ui.model.Sorter('RouteSequence', false),
				new sap.ui.model.Sorter('Orderid', true)
			];
			var routeWorkUrlParameters = {
				urlParameters: {
					'$expand': 'Measurements,Objects'
				},
				sorters: sorter
			};

			this.oDataUtil.read('RouteWorkSet', routeWorkUrlParameters)
				.done(this.insertRoutes.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		insertRoutes: function(routes) {
			this.getModel('RoutesModel').setProperty(
				'/Routes',
				(this.localStorage.getProperty('/Routes') || [])
				.concat((routes || []).map(this.modifyRoute.bind(this)))
				.filter(this.filterDublicateRoutes.bind(this))
			);
		},

		getVariants: function() {
			var deferred = $.Deferred();

			this.oDataUtil.read('VariantSet')
				.done(this.insertVariants.bind(this), deferred.resolve)
				.fail(this.openErrorMessagePopup.bind(this), deferred.reject);

			return deferred.promise();
		},

		insertVariants: function(variants) {
			this.getModel('SelectionValuesModel').setProperty(
				'/Variants',
				(this.localStorage.getProperty('/Variants') || [])
				.concat((variants || []).map(this.modifyVariants.bind(this)))
				.filter(this.filterDublicateVariants.bind(this))
			);
			this.publishEvent('root', 'variantsUpdated');
		},

		modifyRoute: function(route) {
			return this.oDataUtil.handleResultsObjects.call(this.oDataUtil, route);
		},

		modifyNotification: function(notification) {
			return this.oDataUtil.handleResultsObjects.call(this.oDataUtil, notification);
		},

		modifyOrder: function(order) {
			return this.oDataUtil.handleResultsObjects.call(this.oDataUtil, order);
		},

		modifyVariants: function(variant) {
			return this.oDataUtil.handleResultsObjects.call(this.oDataUtil, variant);
		},

		navigatedToObject: function(routeName) {
			var hashArray = location.hash.split('/');
			return hashArray.indexOf(routeName) !== -1 && hashArray.filter(this.hasObjectId).length;
		},

		hasObjectId: function(idString) {
			return /\d+/.test(idString);
		},

		modifyHardwareBackNavigation: function() {
			document.addEventListener('backbutton', function() {
				var currentViewController = this.getMyComponent()
					.getAggregation('rootControl')
					.getController()
					.byId('rootControl')
					.getCurrentPage()
					.getController();

				currentViewController = currentViewController.getSplitContainer ?
					currentViewController.getSplitContainer().getCurrentPage().getController() :
					currentViewController;

				currentViewController.handleHardwareNavBack.call(currentViewController);
			}.bind(this), false);
		},

		filterDublicateNotifications: function(notification, index, array) {
			return this.filterDublicatedListObjects('NotifNo', notification, index, array);
		},

		filterDublicateOrders: function(order, index, array) {
			return this.filterDublicatedListObjects('Orderid', order, index, array);
		},

		filterDublicateRoutes: function(order, index, array) {
			return this.filterDublicatedListObjects('Orderid', order, index, array);
		},

		filterDublicateVariants: function(variant, index, array) {
			return this.filterDublicatedListObjectsTwoIds('VariantId', 'VariantType', variant, index, array);
		},

		attachOnlineEvent: function() {
			$(document).one('online', function() {
				if (sap.Logon) {
					sap.Logon.performSAMLAuth(
						function() {
							this.models.createOnlineODataModel();
							this.flushOfflineStore()
								.always(this.attachOnlineEvent.bind(this));

							this.publishEvent('root', 'networkFound');
						}.bind(this),
						function() {
							this.attachOnlineEvent.call(this);
						}.bind(this)
					);
				} else {
					this.attachOnlineEvent();
				}
			}.bind(this));
		},

		refreshUserGroups: function() {
			var appContext = this.devapp.devLogon.appContext;
			var urlParts = appContext && appContext.applicationEndpointURL.split('/');

			if (urlParts) {
				urlParts[urlParts.length - 1] = 'authcheck/attributes?multiValuesAsArrays=true';

				$.getJSON(urlParts.join('/'))
					.done(function(authToken) {
						var hasMaintenanceRole = this.models.authTokenHasMaintenanceGroup(authToken);
						this.getGlobalModel().setProperty('/HasMaintenanceRole', hasMaintenanceRole);
						this.getGlobalModel().setProperty('/UserInfo', authToken);
						window.localStorage.setItem('HasMaintenanceRole', hasMaintenanceRole ? 'true' : 'false');
						window.localStorage.setItem('UserInfo', JSON.stringify(authToken));

						$.getJSON('../webapp/dev/version.json')
							.done(function(appConfiguration) {
								var appVersion = appConfiguration && appConfiguration.appVersion || '';

								this.getGlobalModel().setProperty('/UserInfo/appVersion', appVersion);
							}.bind(this));
					}.bind(this));
			}
		},

		getUserGroups: function() {
			$.getJSON('/services/userapi/attributes?multiValuesAsArrays=true')
				.done(function(authToken) {
					this.getGlobalModel().setProperty('/HasMaintenanceRole', this.models.authTokenHasMaintenanceGroup(authToken));
					this.getGlobalModel().setProperty('/UserInfo', authToken);
				}.bind(this));
		},

		getSessionId: function() {
			return this.sessionId;
		},

		areUserParametersSet: function() {
			return userParametersAreSet;
		},

		attachPush: function() {
			if (sap.Push) {
				if (window.localStorage.getItem('isPushRegistered') === 'true') {
					this.initPush();
				} else {
					window.localStorage.setItem('isPushRegistered', 'false');
					this.registerForPush();
				}
			}
		},

		detachPush: function() {
			if (sap.Push) {
				this.unregisterForPush();
			}
		},

		registerForPush: function() {
			var nTypes = sap.Push.notificationType.SOUNDS || sap.Push.notificationType.ALERT;
			sap.Push.registerForNotificationTypes(nTypes, this.pushRegistrationSuccess.bind(this), this.pushRegistrationFailure.bind(this), this.processNotification.bind(this), '379513211832');
		},

		initPush: function() {
			sap.Push.initPush(this.processNotification.bind(this));
		},

		unregisterForPush: function() {
			sap.Push.unregisterForNotificationTypes(this.pushUnregistrationCallback.bind(this));
		},

		pushRegistrationSuccess: function() {
			window.localStorage.setItem('isPushRegistered', 'true');
		},

		pushRegistrationFailure: function(errorInfo) {
			console.log('EventLogging: pushRegistrationFailure  ' + JSON.stringify(errorInfo));
		},

		pushUnregistrationCallback: function() {
			window.localStorage.setItem('isPushRegistered', 'false');
		},

		processNotification: function(notification) {
			var notificationText = notification.title || notification.alert;
			if (sap.Push && sap.Push.setPushFeedbackStatus && notification.additionalData) {
				sap.Push.setPushFeedbackStatus('consumed', notification.additionalData.notificationId, $.noop, $.noop);
			}
			if (!notification.additionalData || notification.additionalData && !notification.additionalData.foreground) {

			} else {
				var data = notification.additionalData.data ? notification.additionalData.data : null;
				this.openPushNotificationDialog(notificationText, data);
			}
		},

		handleMultiUser: function() {
			var lastLoggedUser = window.localStorage.getItem('LoggedUser');
			this.devapp.devLogon.getUserName()
				.done(function(userName) {
					var busyPath = '/IsDownloadingUserSpecificValues';
					if (lastLoggedUser && userName && lastLoggedUser.toUpperCase() !== userName.toUpperCase()) {
						window.localStorage.setItem('isMultiUserDevice', 'true');
						this.getGlobalModel('/IsMultiUserDevice', true);
						this.showMessageBox({
							type: 'Info',
							title: this.getResourceBundleText('DIFFERENT_LOGGED_USER_POPUP_TITLE'),
							message: this.getResourceBundleText('DIFFERENT_LOGGED_USER_POPUP_TEXT'),
							actions: [sap.m.MessageBox.Action.OK]
						});
						this.setPathBusy(busyPath);
						this.refreshUserSpecificValues()
							.always(this.setPathNotBusy.bind(this, busyPath));
					}
				}.bind(this));
		},

		setOfflineMetadataLoaded: function(loaded) {
			offlineMetadataIsLoaded = loaded;
		},

		getOfflineMetadataLoaded: function() {
			return offlineMetadataIsLoaded;
		},

		setOnlineMetadataLoaded: function(loaded) {
			onlineMetadatIsLoaded = loaded;
		},

		getOnlineMetadataLoaded: function() {
			return onlineMetadatIsLoaded;
		}

	});
});