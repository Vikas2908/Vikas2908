sap.ui.define([
	'com/upm/maint/controller/CommonController',
	'com/upm/maint/controller/BaseController'
], function(CommonController, BaseController) {
	return CommonController.extend('com.upm.maint.controller.FunctionalLocationHierarchy', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function() {
			BaseController.prototype.onInit.apply(this, arguments);

			var initialViewModel = {};

			this.setModel('ViewModel', initialViewModel);
		},

		onAfterRendering: function() {
			this.handleButtonFormatting();
		},

		routeMatched: function(navigationEvent) {
			if (navigationEvent.getParameter('name') === 'FunctionalLocationHierarchy') {
				BaseController.prototype.routeMatched.apply(this, arguments);

				var navigationArguments = navigationEvent.getParameter('arguments')['?query'];
				var functionalLocation = navigationArguments && navigationArguments.SuperiorFunctionalLocation;

				functionalLocation === this.getGlobalModel().getProperty('/PlantLevelFunctionalLocation') || !functionalLocation ?
					this.setViewForPlantLevel() :
					this.setHierarchyForHierarchyLevel(navigationArguments);

				this.getElementById('technicalObjectSearchField').setValue('');

				this.onTechnicalObjectLiveSearch();
			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onTechnicalObjectLiveSearch: function(searchEvent) {
			var searchValue = searchEvent ? searchEvent.getParameter('newValue') : '';
			this.getModel('ViewModel').setProperty('/HierarcyThrottler', searchValue);
			var minimiumLengthToStartSearching = 3;
			if (searchValue.length >= minimiumLengthToStartSearching) {
				// Use set timeout to skip some of the unnecessary Hierarchy calls.
				window.setTimeout(function() {
					var throttler = this.getModel('ViewModel').getProperty('/HierarcyThrottler');
					if (throttler === searchValue) {
						this.getHierarchyWithFilter(searchValue);
					}
				}.bind(this), 300);
			}
		},

		onNavigateBackHierarchy: function() {
			var navigateToObject = this.getModel('ViewModel').getProperty('/CurrentFunctionalLocation');

			if (navigateToObject && !navigateToObject.SupflocInternalId && navigateToObject.Structurenode && navigateToObject.Structnodetype !== 'MATNR') {
				if (navigateToObject.Structnodetype === 'EQUI') {
					navigateToObject.type = 'Equipment';
				} else if (navigateToObject.Structnodetype === 'FLOC') {
					delete navigateToObject.type;
				}
				navigateToObject.SupflocInternalId = navigateToObject.Structurenode;
			} else if (navigateToObject && navigateToObject.SupflocInternalId && navigateToObject.type) {
				delete navigateToObject.type;
			}

			if (navigateToObject && navigateToObject.SupflocInternalId) {
				// go one step up
				navigateToObject.InternalId = navigateToObject.SupflocInternalId;
				this.navigateToHierarchy(navigateToObject);
			} else {
				this.onExitButtonPress();
			}
		},

		onStructureItemPress: function(oEvent) {
			var selectedObject = oEvent.getSource().getBindingContext('ViewModel').getObject();
			if (this.shouldNavigateToHierarchy(selectedObject)) {
				this.navigateToHierarchy(selectedObject);
			} else {
				this.navigateToMainView(selectedObject);
			}
		},

		onAddObjectPress: function(oEvent) {
			this.navigateToMainView(oEvent.getSource().getBindingContext('ViewModel').getObject());
		},

		onExitButtonPress: function() {
			this.onNavBack();
		},


		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		setHierarchyForHierarchyLevel: function(navigationArguments) {
			var setFunction = {
				Equipment: this.setViewForEquipment.bind(this, navigationArguments.SuperiorFunctionalLocation),
				Material: this.setViewForMaterial.bind(this, navigationArguments)
			} [navigationArguments && navigationArguments.type] || this.setViewForFunctionalLocation.bind(this, navigationArguments.SuperiorFunctionalLocation);

			setFunction();
		},

		setViewForFunctionalLocation: function(functionalLocation) {
			this.getSuperiorFunctionalLocationObject(functionalLocation, this.getGlobalModel().getProperty('/HierarchyGetMaterials'))
				.done(function(functionalLocationObject) {
					if (functionalLocationObject.Floc) {
						this.getModel('ViewModel').setProperty('/SuperiorFunctionalLocation', functionalLocationObject.Floc);
						this.getModel('ViewModel').setProperty('/CurrentFunctionalLocation', functionalLocationObject);
						this.getHierarchy(functionalLocationObject);
					} else {
						this.setViewForPlantLevel();
					}
				}.bind(this))
				.fail(this.setViewForPlantLevel.bind(this));
		},

		setViewForEquipment: function(equipmentNumber) {
			this.validateEquipment(equipmentNumber)
				.done(function(equipment) {
					var modifiedEquipment = this.modifyEquipment(equipment);
					this.getModel('ViewModel').setProperty('/SuperiorFunctionalLocation', modifiedEquipment.InternalId);
					this.getModel('ViewModel').setProperty('/CurrentFunctionalLocation', modifiedEquipment);
					this.getHierarchy(modifiedEquipment);
				}.bind(this))
				.fail(this.setViewForPlantLevel.bind(this));
		},

		setViewForMaterial: function(bomItem) {
			this.validateBOM(bomItem)
				.done(function(material) {
					if (material) {
						var modifiedMaterial = this.modifyMaterial(material);
						this.getModel('ViewModel').setProperty('/SuperiorFunctionalLocation', modifiedMaterial.InternalId);
						this.getModel('ViewModel').setProperty('/CurrentFunctionalLocation', modifiedMaterial);
						this.getHierarchy(modifiedMaterial);
					}
				}.bind(this))
				.fail(this.setViewForPlantLevel.bind(this));
		},

		setViewForPlantLevel: function() {
			this.getModel('ViewModel').setProperty('/SuperiorFunctionalLocation', this.getUserParameters().Plant);
			this.getModel('ViewModel').setProperty('/CurrentFunctionalLocation', {});
			this.getHierarchy({
				InternalId: this.getGlobalModel().getProperty('/PlantLevelFunctionalLocation')
			});
		},

		filterList: function(searchValue) {
			this.getElementById('technicalObjectListContainer')
				.getBinding('items')
				.filter([
					new sap.ui.model.Filter(
						this.generateFilter('Floc', [searchValue], 'Contains')
						.concat(
							this.generateFilter('Descr', [searchValue.toUpperCase()], 'Contains')
						)
					)
				]);
		},

		getHierarchyWithFilter: function(searchValue) {
			var busyPath = '/IsGettingHierarchy';
			this.setPathBusy(busyPath);

			this.getModel('ViewModel').setProperty('/HierarcyBouncer', searchValue);
			$.when.apply(this, this.generateGetMethodsWithFilter(searchValue.toUpperCase()))
				.done(this.handleGetHierarchySuccess.bind(this, searchValue))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setPathNotBusy.bind(this, busyPath));
		},

		generateGetMethodsWithFilter: function(searchValue) {
			var plant = this.getUserParameters().Plant;
			var plantFilter = this.generateFilter('Planplant', [plant]);
			var descriptionFilter = this.generateFilter('Descr', [searchValue], 'Contains');
			var equipmentFilter = this.generateFilter('Equnr', [searchValue], 'Contains');
			var functionalLocationFilter = this.generateFilter('Floc', [searchValue], 'Contains');
			var functionalLocationFilterParameters = {
				filters: [new sap.ui.model.Filter({
					filters: functionalLocationFilter
						.concat(descriptionFilter),
					and: false
				})]
			};
			var equipmentFilterParameters = {
				filters: [new sap.ui.model.Filter({
					filters: equipmentFilter
						.concat(descriptionFilter),
					and: false
				})]
			};
			if (!this.isHybridApplicationUser()) {
				equipmentFilterParameters = {
					filters: [new sap.ui.model.Filter({
						filters: equipmentFilter
							.concat(plantFilter, descriptionFilter),
						and: true
					})]
				};
				functionalLocationFilterParameters = {
					filters: [new sap.ui.model.Filter({
						filters: functionalLocationFilter
							.concat(plantFilter, descriptionFilter),
						and: true
					})]
				};
			}

			var getMethodsPromiseArray = [];

			getMethodsPromiseArray.push(this.oDataUtil.read('FuncLocSet', functionalLocationFilterParameters));

			if (this.getGlobalModel().getProperty('/HierarchyGetEquipments')) {
				getMethodsPromiseArray.push(this.oDataUtil.read('EquipmentSet', equipmentFilterParameters));
			}

			return getMethodsPromiseArray;
		},

		getHierarchy: function(functionalLocationObject) {
			this.setAppBusyMode(200);

			this.getModel('ViewModel').setProperty('/HierarcyBouncer', '');
			$.when.apply(this, this.generateGetMethods(functionalLocationObject))
				.done(this.handleGetHierarchySuccess.bind(this, ''))
				.fail(this.openErrorMessagePopup.bind(this))
				.always(this.setAppNotBusyMode);
		},

		generateGetMethods: function(functionalLocationObject) {
			var structureNodeType = this.getStructureNodeType(functionalLocationObject && functionalLocationObject.type);

			var filterParameters = {
				filters: this.generateFilter('SupflocInternalId', [functionalLocationObject.InternalId])
			};

			var plantFilter = [];
			if (functionalLocationObject.Plant || functionalLocationObject.PlanPlant) {
				plantFilter = this.generateFilter('Plant', [functionalLocationObject.PlanPlant ? functionalLocationObject.PlanPlant : functionalLocationObject.Plant]);
			}

			var materialFilterParameters = {
				filters: [new sap.ui.model.Filter({
					filters: this.generateFilter('Structurenode', [functionalLocationObject.InternalId])
						.concat(this.generateFilter('Structnodetype', [structureNodeType]), plantFilter),
					and: true
				})]
			};

			var getMethodsPromiseArray = [];

			getMethodsPromiseArray.push(this.oDataUtil.read('FuncLocSet', filterParameters));

			if ((functionalLocationObject.HasBomitems || functionalLocationObject.HasSubitems || functionalLocationObject.HasEquipment || (functionalLocationObject.Floc && functionalLocationObject.Floc.length === 4)) && this.getGlobalModel().getProperty('/HierarchyGetEquipments')) {
				getMethodsPromiseArray.push(this.oDataUtil.read('EquipmentSet', filterParameters));
			}
			if ((functionalLocationObject.HasBomitems || functionalLocationObject.HasSubitems) && this.getGlobalModel().getProperty('/HierarchyGetMaterials')) {
				getMethodsPromiseArray.push(this.oDataUtil.read('BomItemsSet', materialFilterParameters));
			}

			return getMethodsPromiseArray;
		},

		getStructureNodeType: function(technicalObjectType) {
			return {
				Material: 'MATNR',
				Equipment: 'EQUI'
			} [technicalObjectType] || 'FLOC';
		},

		handleGetHierarchySuccess: function(searchValue, functionalLocations, equipments, materials) {
			var bouncer = this.getModel('ViewModel').getProperty('/HierarcyBouncer');
			if (searchValue === bouncer) {
				functionalLocations = functionalLocations || [];
				this.getModel('ViewModel')
					.setProperty('/HierarchyStructure', functionalLocations.concat(this.modifyEquipmentArray(equipments), this.modifyMaterialArray(materials)));
			}
			this.handleButtonFormatting();
		},

		modifyEquipmentArray: function(equipments) {
			equipments = equipments || [];
			return equipments.map(this.modifyEquipment);
		},

		modifyEquipment: function(equipment) {
			equipment.Floc = equipment['Equnr'];
			equipment.InternalId = equipment['Equnr'];
			equipment.type = 'Equipment';
			return equipment;
		},

		modifyMaterialArray: function(materials) {
			materials = materials || [];
			return materials.map(this.modifyMaterial);
		},

		modifyMaterial: function(material) {
			material.Floc = material['Component'];
			material.InternalId = material['Component'];
			material.type = 'Material';
			return material;
		},

		shouldNavigateToHierarchy: function(selectedObject) {
			return !!(
				selectedObject['HasChildren'] ||
				(selectedObject['HasEquipment'] && this.getGlobalModel().getProperty('/HierarchyGetEquipments')) ||
				((selectedObject['HasBomitems'] || selectedObject['HasSubitems']) && this.getGlobalModel().getProperty('/HierarchyGetMaterials'))
			);
		},

		navigateToHierarchy: function(selectedObject) {
			this.navTo('FunctionalLocationHierarchy', {
				query: {
					SuperiorFunctionalLocation: selectedObject.InternalId || '',
					type: selectedObject.type || '',
					Bom: selectedObject.Bom || '',
					Item: selectedObject.Item || '',
					Structnodetype: selectedObject.Structnodetype || ''
				}
			}, true);
			setTimeout(function() {
				this.getView().mAggregations.content[0].scrollTo(0);
			}.bind(this), 0);
		},

		navigateToMainView: function(selectedObject) {
			this.onNavBack();

			setTimeout(this.publishEvent.bind(this, 'functionalLocationSelected', this.getGlobalModel().getProperty('/HierarchySelectionEvent'), selectedObject), 0);
		},

		handleButtonFormatting: function() {
			$('.sapMListTblCell:has(.largeButton)').addClass('largeButtonCell');
		},

		positionComparator: function(a, b) {
			// for functional location and equipments this sorting is irrelevant
			if (!a && !b) {
				return 0;
			}
			var firstPosition = Number(a);
			var secondPosition = Number(b);
			if (firstPosition < secondPosition) {
				return -1;
			} else if (firstPosition > secondPosition) {
				return 1;
			} else {
				return 0;
			}
		}

	});
});