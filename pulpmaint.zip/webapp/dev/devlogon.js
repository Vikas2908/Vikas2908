sap.ui.define([
	'sap/m/BusyDialog',
	'sap/m/MessageBox',
	'sap/ui/thirdparty/datajs'
], function(BusyDialog, MessageBox) {
	'use strict';

	return {
		appContext: null,
		appOfflineStore: {},
		devapp: null,
		isRefreshingStore: false,

		/********************************************************************
		 * Initialize the application
		 * In this case, it will check first of the application has already
		 * registered with the SMP server. If not, it will register the app
		 * then proceed to manage the logon process.
		 * @param{Object} context SMP/HCPms logon input context
		 * @param{String} appId SMP/HCPms application ID
		 ********************************************************************/
		doLogonInit: function(context, appId) {
			//set offline store attribute first
			this.appOfflineStore.appID = appId;
			this.appOfflineStore.interval = 300000;

			//Make call to Logon's Init method to get things registered and all setup
			if (this.devapp.definedStore && this.devapp.offline) {
				this.openStore = true;
			}
			var that = this;
			sap.Logon.init(
				function(logonContext) {
					var language = that.getUserLanguage();

					//Make sure Logon returned a context for us to work with
					if (logonContext) {
						//Store the context away to be used later if necessary
						that.appContext = logonContext;
						if (that.openStore && that.isSupportedLanguage(language)) {
							//open offline store
							that.openAppOfflineStore(language);
							that.openStore = false;
						} else if (that.openStore) {
							new sap.m.Dialog({
								title: 'Select language',
								content: that.getSelectLanguageDialogContent()
							}).open();
						} else if (!that.devapp.isLoaded) {
							//start app
							$('html') && $('html').css('font-size', '');
							that.devapp.startApp();
							that.devapp.isLoaded = true;
						}
					}
				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					} else {
						MessageBox.alert('logon failed.');
					}
				}, appId, context);
		},

		isSupportedLanguage: function(language) {
			return /^fi|^es|^en/.test(language);
		},

		getSelectLanguageDialogContent: function() {
			var list = new sap.m.List({
				items: this.getLanguageListItems()
			});

			list.attachItemPress(this.handleLanguageSelected.bind(this));

			return list;
		},

		getLanguageListItems: function() {
			var languages = ['Finnish', 'Spanish', 'English'];
			var languageListItems = languages.map(function(language) {
				return new sap.m.StandardListItem({
					title: language,
					type: 'Active'
				});
			});

			return languageListItems;
		},

		handleLanguageSelected: function(pressEvent) {
			var languageToLanguageCodeMap = {
				Finnish: 'fi-FI',
				Spanish: 'es-ES',
				English: 'en-EN'
			};
			var language = pressEvent
				.getParameter('listItem')
				.getTitle();

			var languageCode = languageToLanguageCodeMap[language];

			window.localStorage.setItem('UserSelectedLanguage', languageCode);

			sap.ui.getCore().getConfiguration().setLanguage(languageCode);

			pressEvent.getSource().getParent().close();

			this.openAppOfflineStore(languageCode);
		},

		doLogOut: function() {
			this.appOfflineStore.store.close(this.handleLogOut.bind(this), this.handleLogOut.bind(this));
		},

		handleLogOut: function() {
			sap.Logon.core.deleteRegistration(
				function() {
					sap.Logon.core.reset();
					this.closeApplication();
				}.bind(this),
				function() {
					sap.Logon.core.reset();
					this.closeApplication();
				}.bind(this)
			);
		},

		resetApplication: function() {
			this.appOfflineStore.store.close(this.handleApplicationReset.bind(this), this.handleApplicationReset.bind(this));
		},

		handleApplicationReset: function() {
			sap.Logon.core.deleteRegistration(sap.Logon.core.reset, sap.Logon.core.reset);
		},

		unRegisterPushNotifications: function() {
			if (sap.Push) {
				sap.Push.unregisterForNotificationTypes($.noop);
				window.localStorage.setItem('isPushRegistered', 'false');
			}
		},

		/********************************************************************
		 * Delete the application's registration information
		 * Disconnects the app from the SMP server
		 ********************************************************************/
		doDeleteRegistration: function() {
			var that = this;
			if (this.appContext) {
				//Call logon's deleteRegistration method
				sap.Logon.core.deleteRegistration(
					function() {
						that.appContext = null;
						//reset the app to its original packaged version
						//(remove all updates retrieved by the AppUpdate plugin)
						sap.AppUpdate.reset();
					},
					function(errObj) {
						if (errObj) {
							MessageBox.alert(JSON.stringify(errObj));
						}
					});
			}
		},

		/********************************************************************
		 * Lock the DataVault
		 ********************************************************************/
		doLogonLock: function() {
			sap.Logon.lock(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				});
		},

		/********************************************************************
		 * Unlock the DataVault
		 ********************************************************************/
		doLogonUnlock: function() {
			sap.Logon.unlock(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				});
		},

		/********************************************************************
		 * Show the application's registration information
		 ********************************************************************/
		doLogonShowRegistrationData: function() {
			sap.Logon.showRegistrationData(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				});
		},

		/********************************************************************
		 * Update the DataVault password for the user
		 ********************************************************************/
		doLogonChangePassword: function() {
			sap.Logon.changePassword(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				});
		},

		/********************************************************************
		 * Change the DataVaule passcode
		 ********************************************************************/
		doLogonManagePasscode: function() {
			sap.Logon.managePasscode(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				});
		},

		/********************************************************************
		 * Write values from the DataVault
		 * @param{String} theKey the key to store the provided object on
		 * @param{Object} theValue the object to be set on the given key. Must be JSON serializable (cannot contain circular references).
		 ********************************************************************/
		doLogonSetDataVaultValue: function(key, value) {
			//Write the values to the DataVault
			sap.Logon.set(
				function() {

				},
				function(errObj) {
					if (errObj) {
						MessageBox.alert(JSON.stringify(errObj));
					}
				}, key, value);
		},

		/********************************************************************
		 * Read values from the DataVault
		 * @param{String}} theKey the key with which to query the DataVault.
		 ********************************************************************/
		doLogonGetDataVaultValue: function(key) {
			var deferred = $.Deferred();
			sap.Logon.get(
				function(value) {
					deferred.resolve(value);
				},
				function() {
					deferred.reject();
				}, key);
			return deferred.promise();
		},

		/********************************************************************
		 * Creates a new OfflineStore object.
		 * Need to be online in the first time when the store is created.
		 * The store will be available for offline access only after it is open successfully.
		 ********************************************************************/
		openAppOfflineStore: function(language) {
			if (!this.appOfflineStore.store) {
				var that = this;

				var reqObj = that.devapp.definedStore;
				var properties = {
					'name': 'PulpMaintOffline' + '21',
					'storeEncryptionKey': 'UPM4MAINT',
					'host': that.appContext.registrationContext.serverHost,
					'port': that.appContext.registrationContext.serverPort,
					'https': that.appContext.registrationContext.https,
					'serviceRoot': that.appContext.applicationEndpointURL + that.devapp.basePath + that.devapp.hybridOfflinePath,
					'definingRequests': reqObj,
					'customHeaders': {
						'Accept-Language': language.substring(0, 2) || 'en',
						'Accept-Encoding': 'gzip, deflate, br'
					}
				};

				that.appOfflineStore.store = sap.OData.createOfflineStore(properties);

				if (/^zh/.test(language)) {
					language = 'zh';
				} else if (/^es/.test(language)) {
					language = 'es';
				}

				var translaTions = {
					'fi-FI': ['Valmistellaan sovellusta', 'Offline-toiminnot'],
					'es': ['Preparando aplicación', 'Habilitando funciones offline']
				} [language] || ['Preparing application', 'Enabling offline capabilities'];

				var busyDL = new BusyDialog({
					title: translaTions[0],
					text: translaTions[1]
				});

				busyDL.open();

				that.appOfflineStore.store.open(
					function() {
						$('html') && $('html').css('font-size', '');
						busyDL.close();
						//set offline client
						sap.OData.applyHttpClient();
						that.devapp.startApp();
						that.devapp.isLoaded = true;
					},
					function(e) {
						console.log(e);
						busyDL.close();
						if (e) {
							MessageBox.alert(
								'Failed to open offline store: ' + JSON.stringify(e), {
									onClose: that.closeApplication
								});
						} else {
							MessageBox.alert(
								'Failed to open offline store.', {
									onClose: that.closeApplication
								});
						}
					}
				);
			}
		},

		getUserName: function() {
			var deferred = $.Deferred();

			sap.Settings.getConfigProperty(function(value) {
				deferred.resolve(value);
			}, function() {
				deferred.resolve();
			}, 'UserName');

			return deferred.promise();
		},

		getUserLanguage: function() {
			var language;
			try {
				language = sap.ui.getCore().getConfiguration().getLanguage();
			} catch (error) {
				language = 'en-EN';
			}

			if (!this.isSupportedLanguage(language)) {
				language = window.localStorage.getItem('UserSelectedLanguage');
			}

			return language;
		},

		closeApplication: function() {
			navigator.app.exitApp();
		},

		/********************************************************************
		 * refresh offline store, synchronize data from server
		 * need to be online
		 ********************************************************************/
		refreshAppOfflineStore: function(options) {
			var deferred = $.Deferred();
			if (!this.appOfflineStore.store) {
				deferred.resolve();
			} else {
				var oEventBus = sap.ui.getCore().getEventBus();
				var that = this;
				if (this.devapp.isOnline && !this.isRefreshingStore) {
					this.isRefreshingStore = true;
					this.appOfflineStore.store.refresh(
						function() {
							//reset
							that.devapp.refreshing = false;
							that.isRefreshingStore = false;
							//publish ui5 offlineStore Synced event
							oEventBus.publish('OfflineStore', 'Synced');
							deferred.resolve();
						},
						function(errorEvent) {
							//reset
							that.devapp.refreshing = false;
							that.isRefreshingStore = false;
							//save the error
							that.appOfflineStore.callbackError = errorEvent;
							//publish ui5 offlineStore Synced event
							oEventBus.publish('OfflineStore', 'Synced');
							deferred.reject();
						}, options);
				} else {
					deferred.resolve();
				}
			}
			return deferred.promise();
		},

		/********************************************************************
		 * flush offline store, push changed data to server, need to be online
		 * if Products.dev.devapp.refreshing is set to true,
		 * application will continue to call refreshAppOfflineStore() to refresh the offline store.
		 ********************************************************************/
		flushAppOfflineStore: function() {
			var deferred = $.Deferred();
			if (!this.appOfflineStore.store || !this.devapp.isOnline) {
				deferred.resolve();
			} else {
				this.appOfflineStore.store.flush(
					function() {
						this.readOfflineErrorArchieve();

						deferred.resolve();
					}.bind(this),
					function(errorEvent) {
						this.appOfflineStore.callbackError = errorEvent;
						this.readOfflineErrorArchieve();

						deferred.reject();
					}.bind(this));
			}
			return deferred.promise();
		},

		/********************************************************************
		 * read offline store archieve error message after flush/refresh operation
		 ********************************************************************/
		readOfflineErrorArchieve: function() {
			//clean ErrorArive row url
			this.appOfflineStore.errorArchiveRowURL = null;
			var oEventBus = sap.ui.getCore().getEventBus();
			var that = this;
			this.devapp.offlineModel.read('/ErrorArchive', null, null, true,
				function(rtData) {
					var bStop = false;
					if (rtData && rtData.results && rtData.results.length > 0) {
						that.devapp.deviceModel.setProperty('/errorNum', rtData.results.length);
						var i;
						for (i = 0; i < rtData.results.length; i++) {
							var errObj = rtData.results[i];

							//get ErrorArchive one row URL, can be any row
							if (!that.appOfflineStore.errorArchiveRowURL && errObj.__metadata &&
								errObj.__metadata.uri && errObj.__metadata.uri.indexOf('ErrorArchive') > 0) {
								that.appOfflineStore.errorArchiveRowURL = '/ErrorArchive' + errObj.__metadata.uri.split('ErrorArchive')[1];
							}

							if (errObj.RequestMethod.toLowerCase() !== 'delete') {
								bStop = true;
								if (that.appOfflineStore.errorArchiveRowURL) {
									//if errorArchiveRowURL is set, then exit loop
									break;
								}
							}
						}
					} else {
						//reset the error count
						that.devapp.deviceModel.setProperty('/errorNum', 0);
					}

					if (bStop) {
						//stop refreshing
						that.devapp.refreshing = false;
						//publish ui5 offlineStore Synced event
						oEventBus.publish('OfflineStore', 'Synced');
					} else if (that.devapp.refreshing) {
						//continue refreshing
						that.refreshAppOfflineStore();
					} else {
						//publish ui5 offlineStore Synced event
						oEventBus.publish('OfflineStore', 'Synced');
					}
				},
				function() {
					//reset the error count
					that.devapp.deviceModel.setProperty('/errorNum', 0);

					if (that.devapp.refreshing) {
						//continue refreshing
						that.refreshAppOfflineStore();
					} else {
						//publish ui5 offlineStore Synced event
						oEventBus.publish('OfflineStore', 'Synced');
					}
				}
			);
		},

		/********************************************************************
		 * read offline store archieve error count and set to device model
		 ********************************************************************/
		getErrorArchiveCount: function() {
			var that = this;
			this.devapp.offlineModel.read('/ErrorArchive', null, null, true,
				function(rtData) {
					if (rtData && rtData.results && rtData.results.length > 0) {
						that.devapp.deviceModel.setProperty('/errorNum', rtData.results.length);

						var i;
						for (i = 0; i < rtData.results.length; i++) {
							var errObj = rtData.results[i];
							//get ErrorArchive one row URL, can be any row
							if (!that.appOfflineStore.errorArchiveRowURL && errObj.__metadata &&
								errObj.__metadata.uri && errObj.__metadata.uri.indexOf('ErrorArchive') > 0) {
								that.appOfflineStore.errorArchiveRowURL = '/ErrorArchive' + errObj.__metadata.uri.split('ErrorArchive')[1];
								break;
							}
						}
					}
				}
			);
		},

		getEncryptionKey: function() {
			var deferred = $.Deferred();

			this.doLogonGetDataVaultValue('encryptionKey')
				.always(function(value) {
					var generatedEncryptionKey = this.generateEnctyptionKey();

					deferred.resolve(value || generatedEncryptionKey);

					if (!value) {
						this.doLogonSetDataVaultValue('encryptionKey', generatedEncryptionKey);
					}
				}.bind(this));

			return deferred.promise();
		},

		generateEnctyptionKey: function() {
			var key = '';
			for (var i = 0; i < 6; i++) {
				key += Math.floor((1 + Math.random()) * 0x100000000).toString(36).substring(1);
			}
			return key;
		}
	};
});