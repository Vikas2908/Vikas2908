sap.ui.define([
	'sap/m/Shell',
	'sap/ui/core/ComponentContainer',
	'sap/m/MessageBox',
	'com/upm/maint/dev/devlogon'
], function(Shell, ComponentContainer, MessageBox, devlogon) {
	'use strict';

	return {
		smpInfo: {},
		isLoaded: false,
		isOnline: false,
		definedStore: {},
		errorArchive: [],
		devLogon: devlogon,
		nfcTechnicalObject: '',
		nfcReadSuccessHandler: $.noop,
		basePath: '/sap/opu/odata/sap',
		hybridOfflinePath: '/ZGW_PM_PULPMAINT_OFFLINE_SRV/',

		//Application Constructor
		initialize: function() {
			this.bindEvents();
		},

		//========================================================================
		// Bind Event Listeners
		//========================================================================
		bindEvents: function() {
			document.addEventListener('deviceready', jQuery.proxy(this.onDeviceReady, this), false);
			document.addEventListener('online', jQuery.proxy(this.deviceOnline, this), false);
			document.addEventListener('offline', jQuery.proxy(this.deviceOffline, this), false);
		},

		//========================================================================
		//Cordova Device Ready
		//========================================================================
		onDeviceReady: function() {
			if (window.sap_webide_FacadePreview || window.sap_webide_companion) {
				this.startApp();
			} else {
				this.handleNFC();
				var that = this;

				StatusBar && StatusBar.backgroundColorByHexString('#51a00b');

				//get offline definingRequests
				$.getJSON('manifest.json', function(desData) {
					var def = desData['sap.mobile']['definingRequests'];
					for (var o in def) {
						if (o) {
							that.definedStore[o] = def[o];
						}
					}

					$.getJSON('dev/service.json', function(data) {
						if (data) {
							if (data.logon) {
								that.smpInfo.server = data.host;
								that.smpInfo.port = data.port;
								that.smpInfo.appID = data.appID;
							}
							if (data.network) {
								that.offline = true;
								if (navigator.connection.type !== Connection.NONE) {
									that.isOnline = true;
								}
							} else {
								that.offline = false;
								MessageBox.alert('Cordova network plugin is not selected. Offline function is disabled.');
							}
						}

						if (that.smpInfo.server && that.smpInfo.server.length > 0) {
							var context = {
								'serverHost': that.smpInfo.server,
								'https': data.https,
								'serverPort': that.smpInfo.port,
								'multiUser': true,
								'auth': [{
									'type': 'saml2.web.post',
									'config': {
										'saml2.web.post.authchallengeheader.name': 'com.sap.cloud.security.login',
										'saml2.web.post.finish.endpoint.uri': '/SAMLAuthLauncher',
										'saml2.web.post.finish.endpoint.redirectparam': 'finishEndpointParam'
									}
								}],
								'custom': {
									'disablePasscode': true
								}
							};
							that.devLogon.devapp = that;
							that.devLogon.doLogonInit(context, that.smpInfo.appID);
						} else {
							that.startApp();
						}
					});
				});
			}
		},

		getAuthenticationToken: function() {
			return $.ajax({
				url: 'https://api.eu1.hana.ondemand.com/oauth2/apitoken/v1?grant_type=client_credentials',
				type: 'POST',
				dataType: 'json',
				beforeSend: function(xhr) {
					xhr.setRequestHeader('Authorization', 'Basic ' + btoa('8f507d11-b349-33e9-8e27-9290a2015625' + ':' + 'ca70527c-68bf-3b0d-8333-36295d31c767'));
				}
			});
		},

		handleNFC: function() {
			var successHandler = this.onNfc.bind(this);

			this.setNFCReadSuccessFunction(successHandler);
			nfc.addNdefListener(successHandler, $.noop, $.noop);
			nfc.addMimeTypeListener('text/any', successHandler, $.noop, $.noop);
			nfc.addNdefFormatableListener(successHandler, $.noop, $.noop);
		},

		onNfc: function(readEvent) {
			var tagText = '';
			try {
				tagText = JSON.parse(nfc.bytesToString(readEvent.tag.ndefMessage[1].payload));
			} catch (err) {
				tagText = '';
			}

			var event = new CustomEvent('NFCRead', {
				detail: tagText
			});

			document.dispatchEvent(event);

			this.nfcTechnicalObject = tagText && tagText.TechnicalObject;
		},

		getNFCReadSuccessFunction: function() {
			return this.nfcReadSuccessHandler;
		},

		setNFCReadSuccessFunction: function(successHandler) {
			this.nfcReadSuccessHandler = successHandler;
		},

		//========================================================================
		//Cordova deviceOnline event handler
		//========================================================================
		deviceOnline: function() {
			if (this.isLoaded && this.deviceModel) {
				this.deviceModel.setProperty('/isOffline', false);
			}
			this.isOnline = true;
		},

		//========================================================================
		//Cordova deviceOffline event handler
		//========================================================================
		deviceOffline: function() {
			if (this.isLoaded && this.deviceModel) {
				this.deviceModel.setProperty('/isOffline', true);
			}
			this.isOnline = false;
		},

		/**
		 * find parameter name from page URL
		 * @param{String} sParam parameter name
		 * @returns {boolean}} if finding the assigned name or not
		 */
		findUrlParameterName: function(sParam) {
			var sPageURL = window.location.search.substring(1);
			var sURLVariables = sPageURL.split('&');
			for (var i = 0; i < sURLVariables.length; i++) {
				var sParameterName = sURLVariables[i].split('=');
				if (sParameterName[0] === sParam) {
					return true;
				}
			}
			return false;
		},

		//========================================================================
		//start application
		//========================================================================
		startApp: function() {
			sap.ui.getCore().attachInit(function() {
				new Shell({
					app: new ComponentContainer({
						height: '100%',
						name: 'com.upm.maint'
					})
				}).placeAt('content');
			});
		}
	};
});