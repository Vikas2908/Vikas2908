sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createGIModels: function() {
			App.setModel(new JSONModel({
				movementType: "",
				prevMovType: "",
				movTypeAssigment: "",
				moveReasonNeeded: false,
				showMoveReason: false,
				costCenter: "",
				postDate: new Date(),
				docDate: new Date(),
				reverseSelected: false,
				vendor: "",
				vendorId: "",
				docHeaderText: "",
				orderNo: "",
				showPlantStg: true,
				plant: "",
				stgloc: "",
				stglocText: "",
				barcodeScanEnabled: false
			}), "params");

			App.setModel(new JSONModel({}), "order");
			App.setModel(new JSONModel([]), "materials");
			App.setModel(new JSONModel([]), "vendors");
			App.setModel(new JSONModel([]), "movementReasons");
		}

	};
});