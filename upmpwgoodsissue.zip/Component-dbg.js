sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/upm/pw/z_wh_postgi/model/models",
	"sap/ui/model/json/JSONModel",
	"com/upm/pw/z_wh_postgi/include/sync",
	"sap/m/Dialog"
], function(UIComponent, Device, models, JSONModel, Sync, Dialog) {
	"use strict";
	return UIComponent.extend("com.upm.pw.z_wh_postgi.Component", {
		metadata: {
			manifest: 'json'
		},
		init: function() {
			window.App = this;
			UIComponent.prototype.init.apply(this, arguments);
			this.predefineFunction();
		},
		predefineFunction: function() {
			App.sync = Sync;
			App.loader = new sap.m.BusyDialog({
				text: "",
				title: "",
				showCancelButton: false
			});
			
			App.showLoader = function() {
				App.loader.open();
			};
			App.hideLoader = function() {
				App.loader.close();
			};
			App.setLanguage = function(lang) {
				var i18nModel = new sap.ui.model.resource.ResourceModel({
					bundleName: "com.upm.pw.z_wh_postgi.i18n.i18n",
					bundleLocale: lang
				});
				App.setModel(i18nModel, "i18n");
				App.getModel("i18n").refresh(true);
			};
			var lang = sap.ui.getCore().getConfiguration().getLanguage() ? sap.ui.getCore().getConfiguration().getLanguage() : "en";
			App.setLanguage(lang);
			App.getTran = function(tran, args) {
				return App.getModel("i18n").getResourceBundle().getText(tran, args ? args : "");
			};
			models.createGIModels();
			this.prepareData();
		},
		prepareData: function() {
			var self = this;
			App.sync.getMovementTypes().done(function(response) {
				var movements = response.results.filter(function(mv){
					return mv.Reversal.length === 0;
				});
				var groups = [];
				var movtypes = {};
				var finalMovements = [];
				movements.forEach(function(mov) {
					movtypes[mov.Mvttype] = mov;
					if (movtypes.hasOwnProperty(mov.MvttypeNext)) {
						var group = movtypes[mov.MvttypeNext].group;
						group.push(mov);
						mov.group = group;
					} else {
						var group = [mov];
						mov.group = group;
						groups.push(group);
					}
				});
				groups.forEach(function(gr) {
					for (var i in gr) {
						var grp = gr[i];
						finalMovements.push({
							text: grp.Btext + " (" + grp.Mvttype + "/" + grp.MvttypeNext + ")",
							mvtype: grp.Mvttype,
							mvtypeNext: grp.MvttypeNext,
							assignment: grp.Assignment,
							movementReasonNeeded: ((grp.ReasonControl  == "" || grp.ReasonControl == "." || grp.ReasonControl == "-") ? false : true),
							movementReasonShow: (grp.ReasonControl == "-" ? false : true)
						});
						break;
					}
				});
				App.setModel(new JSONModel(finalMovements), "movementTypes");
				if (finalMovements.length > 0) {
					var found = finalMovements.find(function(mvt) {
						return mvt.assignment == "O";
					});
					if (!found)
						found = finalMovements[0];
						
					App.getModel("params").setProperty("/movTypeAssigment", found.assignment);
					App.getModel("params").setProperty("/movementType", found.mvtype);
					App.getModel("params").setProperty("/prevMovType", found.mvtype);
					App.getModel("params").setProperty("/moveReasonNeeded", found.movementReasonNeeded);
					App.getModel("params").setProperty("/showMoveReason", found.movementReasonShow);
				}
			}).fail(function(e) {
				self.showMessageDialog("Error", e.title, "", e.message, function() {});
			});
			App.sync.getCostCenters().done(function(response) {
				App.setModel(new JSONModel(response.results), "costCenters");
			}).fail(function(e) {
				self.showMessageDialog("Error", e.title, "", e.message, function() {});
			});
			App.sync.getUserPlant().done(function(response) {
				App.setModel(new JSONModel(response.results), "plants");
				App.getModel("params").setProperty("/plant", response.results[0] ? response.results[0].Plant : "");
			}).fail(function(e) {
				self.showMessageDialog("Error", e.title, "", e.message, function() {});
			});
			App.sync.getPlantStorLocs().done(function(response) {
				var params = App.getModel("params");
				var selectedPlant = params.getProperty("/plant");
				var plantStorLocs = response.results.filter(function(item) {
					return item.Plant == selectedPlant;
				});
				params.setProperty("/stgloc", plantStorLocs[0] ? plantStorLocs[0].Storloc : "");
				params.setProperty("/stglocText", plantStorLocs[0] ? plantStorLocs[0].StoreLocDesc : "");
				App.setModel(new JSONModel(response.results), "stglocs");
				App.gi.getMovementReasons(params.getProperty("/movementType"), App.getModel("movementTypes") && App.getModel("movementTypes").getData() ? App.getModel("movementTypes").getData()[0] : {});
			}).fail(function(e) {
				self.showMessageDialog("Error", e.title, "", e.message, function() {});
			});
		},
		showMessageDialog: function(state, title, icon, message, callback) {
			var dialog = new Dialog({
				state: state,
				title: title,
				icon: icon,
				content: new sap.m.Text({text: message}),
				beginButton: new sap.m.Button({
					text: App.getTran("close"),
					press: function() {
						dialog.close();
						if (callback)
							callback();
						
					}
				})
			}).addStyleClass("oMsgDialog");
			dialog.open();
        }
	});
});