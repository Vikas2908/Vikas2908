sap.ui.jsview("com.upm.pw.z_wh_postgi.view.App", {
	getControllerName: function() {
		return "com.upm.pw.z_wh_postgi.controller.App";
	},
	createContent: function(oController) {
		var self = this;
		this.setDisplayBlock(true);
		
		var oPage = new sap.m.Page({
			title: "{i18n>postGI}",
			showHeader: false,
			showNavButton: false,
			navButtonPress: [oController.handleBack, oController],
			content: [
				self.getFirstForm(oController),
				self.getSecondForm(oController),
				self.getThirdForm(oController),
				self.getToolbar(oController),
				self.getTable(oController)
				],
			footer: self.getFooter(oController)
		});

		this.app = new sap.m.App(this.createId("app"), {
			pages: [oPage]
		}).addStyleClass("gi");
		return this.app;
	},
	getFirstForm: function(oController) {
		return new sap.ui.layout.HorizontalLayout({
			width: "100%",
			allowWrapping: true,
			content: [
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Toolbar({
							content: [
								new sap.m.Label({
									//width: "30%",
									text: "{i18n>movementType}:",
									labelFor: "movementType"
								}),
								new sap.m.Select(this.createId("movementType"), {
									change: [oController.movementTypeSelect, oController],
									selectedKey: "{params>/movementType}",
									//width: "60%"
								}).bindAggregation("items", "movementTypes>/", new sap.ui.core.Item({
									key: "{movementTypes>mvtype}",
									text: "{movementTypes>text}"
								}))
							]
						}).addStyleClass("noBottomBorder")
					]
				}).addStyleClass("oPaddingRight"),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Toolbar({
							visible: {path: "params>/movTypeAssigment", formatter: oController.formatter.isMoveTypeO},
							content: [
								new sap.m.Label({
									width: "45%",
									text: "{i18n>orderNumber}:",
									labelFor: "orderNumber"
								}),
								new sap.m.SearchField(this.createId("orderNumber"), {
									search: [oController.searchOrder, oController],
									value: "{params>/orderNo}"
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Toolbar({
							visible: {path: "params>/movTypeAssigment", formatter: oController.formatter.isMoveTypeO},
							content: [
								new sap.m.Text({
									text: "{order>/Ordertext}"
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Toolbar({
							visible: {path: "params>/movTypeAssigment", formatter: oController.formatter.isMoveTypeCS},
							content: [
								new sap.m.Label({
									width: "80px",
									text: "{i18n>costCenter}:",
									labelFor: "costCenter"
								}),
								new sap.m.Input(this.createId("costCenter"), {
									width: "100%",
									value: {path:'params>/', formatter: oController.formatter.getCostCenter},
									showValueHelp: true,
									valueHelpRequest: [oController.showCostCenters, oController]
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.Toolbar({
							visible: {path: "params>/movTypeAssigment", formatter: oController.formatter.isMoveTypeV},
							content: [
								new sap.m.Label({
									width: "65px",
									text: "{i18n>vendor}:",
									labelFor: "vendor"
								}),
								new sap.m.Input(this.createId("vendor"), {
									value: "{params>/vendor}",
									showValueHelp: true,
									valueHelpRequest: [oController.showVendors, oController]
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				})
			]
		}).addStyleClass("oFullWidth");
	},
	getSecondForm: function(oController) {
		return new sap.ui.layout.HorizontalLayout({
			allowWrapping: true,
			content: [
				new sap.ui.layout.VerticalLayout({
					width: "25%",
					content: [
						new sap.m.Toolbar({
							height: "auto",
							visible: {path: 'params>/showPlantStg', formatter: oController.formatter.getPlantVisible},
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
											text: "{i18n>plant}:",
											labelFor: "headerPlant"
										}),
										new sap.m.Select(this.createId("headerPlant"), {
											width: "100%",
											selectedKey: "{params>/plant}",
											change: [oController.headerPlantChange, oController]
										}).bindAggregation("items", "plants>/", new sap.ui.core.Item({
											key: "{plants>Plant}",
											text: "{plants>Name}"
										}))
									]
								})
	
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					width: "25%",
					content: [
						new sap.m.Toolbar({
							height: "auto",
							visible: {path: 'params>/showPlantStg', formatter: oController.formatter.getPlantVisible},
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
										//	width: "20%",
											text: "{i18n>storageLocation}:",
											labelFor: "headerStg"
										}),
										new sap.m.Input(this.createId("headerStg"), {
											showValueHelp: true,
											valueHelpRequest: [oController.showStorageLocations, oController],
											value: "{params>/stglocText}"
										})
									]
								})
	
							]
						}).addStyleClass("noBottomBorder")
				]
				}),
				new sap.ui.layout.VerticalLayout({
					width: "25%",
					content: [
						new sap.m.Toolbar({
							height: "auto",
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
											text: "{i18n>documentDate}:",
											labelFor: "documentDate"
										}),
										new sap.m.DatePicker(this.createId("documentDate"), {
											dateValue: "{params>/docDate}",
											displayFormat: "dd.MM.yyyy",
											change: [oController.validateDate, oController]
										})
									]
								})
	
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					width: "25%",
					content: [
						new sap.m.Toolbar({
							height: "auto",
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
											text: "{i18n>postingDate}:",
											labelFor: "postingDate"
										}),
										new sap.m.DatePicker(this.createId("postingDate"), {
											dateValue: "{params>/postDate}",
											displayFormat: "dd.MM.yyyy",
											change: [oController.validateDate, oController]
										})
									]
								})
	
							]
						}).addStyleClass("noBottomBorder")
					]
				})
			]
		}).addStyleClass("oFullWidth");
	},
	getThirdForm: function(oController) {
		return new sap.ui.layout.HorizontalLayout({
			allowWrapping: true,
			content: [
					new sap.ui.layout.VerticalLayout({
						width: "25%",
						content: [
						new sap.m.Toolbar({
							height: "auto",
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
											text: "{i18n>documentHeaderText}:",
											labelFor: "documentHeaderText"
										}),
										new sap.m.Input(this.createId("documentHeaderText"), {
											value: "{params>/docHeaderText}",
											type: "Text"
										})
									]
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				}),
				new sap.ui.layout.VerticalLayout({
					width: "25%",
					content: [
						new sap.m.Toolbar({
							height: "auto",
							content: [
								new sap.m.VBox({
									width: "75%",
									items: [
										new sap.m.Label({
											text: "{i18n>reverseGoodsMovement}:",
											labelFor: "reverseGoodsMovement"
										}),
										new sap.m.CheckBox(this.createId("reverseGoodsMovement"), {
											select: [oController.reverseSelect, oController],
											selected: "{params>/reverseSelected}"
										})
									]
								})
							]
						}).addStyleClass("noBottomBorder")
					]
				})
			]
		}).addStyleClass("oFullWidth");
	},
	getToolbar: function(oController) {
		return new sap.m.Toolbar({
			height: "auto",
			content: [
				new sap.m.Label(this.createId("itemCount"), {
					text: "{i18n>items}"
				}),
				new sap.m.ToolbarSpacer({
					width: "50%" 
				}).addStyleClass("sapMTBSpacerFlex"),
				new sap.m.Button(this.createId("cameraBtn"), {
					visible: '{params>/barcodeScanEnabled}',
					icon: "sap-icon://camera",
					press: [oController.scanBarcode, oController]
				}),
				new sap.m.SearchField(this.createId("matSearch"), {
					width: "30%",
					placeholder: "{i18n>enterMaterialId}",
					search: [oController.materialSearch, oController]
				}),
				new sap.m.Button({
					icon: "sap-icon://delete",
					type: "Transparent",
					press: [oController.deleteRow, oController]
				})
			]
		}).addStyleClass("oTblHeader");
	},
	getTable: function(oController) {
		var self = this;
		return new sap.m.Table(this.createId("oTbl"), {
			mode: "MultiSelect",
			select: [oController.refreshItemsCount, oController], 
			columns: [
				new sap.m.Column({
					width: "5%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>item}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					minScreenWidth: "Tablet",
					width: "20%",
					header : new sap.m.Label({
						text : "{i18n>material}"
					})
				}),
				new sap.m.Column({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeT},
					width: "13%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					hAlign: "Begin",
					header : new sap.m.Label({
						text : "{i18n>targetPlant}"
					})
				}),
				new sap.m.Column({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeT},
					width: "17%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>targetStorageLocation}"
					})
				}),
				new sap.m.Column({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeM},
					width: "17%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>targetMaterial}"
					})
				}),
				new sap.m.Column({
					width: "12%",
					hAlign: "Center",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>quantity}"
					})
				}),
				new sap.m.Column({
					demandPopin: true,
					width: "10%",
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>unit}"
					})
				}),
				new sap.m.Column({
					width: "10%",
					visible: {path: 'materials>/', formatter: oController.formatter.checkValTypeAvailability},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>valuationType}"
					})
				}),
				new sap.m.Column({
					visible: "{params>/showMoveReason}",
					demandPopin: true,
					width: "15%",
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>reasonForMovement}"
					})
				}),
				new sap.m.Column({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeV},
					demandPopin: true,
					width: "9%",
					minScreenWidth: "Tablet",
					header : new sap.m.Label({
						text : "{i18n>reference}"
					})
				})
			]
		}).bindAggregation("items", "materials>/", self.getTableTmpl(oController)).addStyleClass("oTbl");
	},
	getTableTmpl: function(oController) {
		return new sap.m.ColumnListItem({
			unread: false,
			cells: [
				new sap.m.Text({
					text: {path: 'materials>line', formatter: oController.formatter.getLineNumber}
				}),
				new sap.m.ObjectIdentifier({
					title: "{materials>MatlDesc}",
					text: "{materials>Material}"
				}),
				new sap.m.Select({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeT},
					selectedKey: "{materials>Plant}",
					change: [oController.plantChange, oController]
				}).bindAggregation("items", "destLocations>/", new sap.ui.core.Item({
					key: "{destLocations>Plant}",
					text: "{destLocations>Name}"
				})),
				new sap.m.Input({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeT},
					showValueHelp: true,
					valueHelpRequest: [oController.showStorageLocations, oController],
					value: "{materials>StoreLocDesc}"
				}),
				new sap.m.SearchField({
					placeholder: '{i18n>targetMaterial}',
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeM},
					search: [oController.handleSearchTargetMaterial, oController],
					value: '{materials>DestMaterial}'
				}),
				new sap.ui.layout.HorizontalLayout({
					content: [
						new sap.m.Button({
							icon: "sap-icon://less",
							press: [oController.decrease, oController]
						}).addStyleClass("oQuantityActions"), 
						new sap.m.Input({
							liveChange: [oController.validateQtyField, oController],
							value: "{materials>Quantity}"
						}).addStyleClass("oQuantityActions"), 
						new sap.m.Button({
							icon: "sap-icon://add",
							press: [oController.increase, oController]
						}).addStyleClass("oQuantityActions")
					]
				}).addStyleClass("oQuantityBox"),
				new sap.m.Select({
					selectedKey: "{materials>Uom}"
				}).bindAggregation("items", "materials>units/", new sap.ui.core.Item({
					text: "{materials>Unitlangu}",
					key: "{materials>Unitlangu}"
				})).addStyleClass("oSelectActions"),
				new sap.m.Select({
					visible: {path: 'materials>valTypes', formatter: oController.formatter.checkValtype},
					selectedKey: "{materials>ValType}"
				}).bindAggregation("items", "materials>valTypes/", new sap.ui.core.Item({
					text: "{materials>ValType}",
					key: "{materials>ValType}"
				})).addStyleClass("oSelectActions"),
				new sap.m.Select({
					forceSelection: false,
					visible: {path: 'params>/showMoveReason', formatter: oController.formatter.getMoveReasonVisible},
					selectedKey: "{materials>MoveReas}"
				}).bindAggregation("items", "movementReasons>/", new sap.ui.core.Item({
					text: "{movementReasons>ValueName}",
					key: "{movementReasons>ValueCode}"
				})).addStyleClass("oSelectActions"),
				new sap.m.Text({
					visible: {path: 'params>/movTypeAssigment', formatter: oController.formatter.isMoveTypeV},
					text: "{materials>MatDoc}"
				})
			]
			
		});
	},
	getFooter: function(oController) {
		return new sap.m.Bar({
			contentRight: [
				new sap.m.Button({
					type: "Reject",
					text: "{i18n>reset}",
					press: [oController.cancelGI, oController]
				}),
				new sap.m.Button({
					type: "Accept",
					text: "{i18n>postGI}",
					press: [oController.postGI, oController]
				})
			]
		});
	}
});