sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'com/upm/pw/z_wh_postgi/include/formatter',
    'sap/ui/core/BusyIndicator',
    'sap/ui/model/json/JSONModel',
    'sap/m/Dialog'
], function(Controller, Formatter, BusyIndicator, JSONModel, Dialog) {
    return Controller.extend("com.upm.pw.z_wh_postgi.controller.BaseController", {
        formatter: Formatter,
        showMessageDialog: function(state, title, icon, message, callback) {
        		var dialog = new Dialog({
        			state: state,
        			title: title,
        			icon: icon,
        			content: new sap.m.Text({text: message}),
        			beginButton: new sap.m.Button({
        				text: App.getTran("close"),
        				press: function() {
        					dialog.close();
        					if (callback)
        						callback();
        					
        				}
        			})
        		}).addStyleClass("oMsgDialog");
        		dialog.open();
        },
    	showDeleteDialog: function(state, title, text, handleRemove, cancel) {
    		var oDialog = new sap.m.Dialog({
    			state: state,
    			title: title,
    			content: [new sap.m.Text({
    				text: text
    			})],
    			buttons: [new sap.m.Button({
    				text: App.getTran("yes"),
    				press: function() {
    					if (handleRemove)
    						handleRemove(oDialog);
    				}
    			}), new sap.m.Button({
    				text: App.getTran("cancel"),
    				press: function() {
    					oDialog.close();
    					if (cancel)
    						cancel(oDialog);
    				}
    			})]
    		}).addStyleClass("oDialogContent");
    		
    		oDialog.open();	
    	},
     	calculateLineNumbers: function() {
     		var model = App.getModel("materials");
 			var items = model.getProperty("/");
 			
 			if (!items.length)
 				return;
 			
 			for (var i = 0; i < items.length; i++) {
 				var item = items[i];
 				item.line = (parseInt(i) === 0 ? "10" : parseInt(i) === 1 ? "20" : parseInt(i) + 1 + "0");
 			}
 			model.refresh(true);
     	},
     	getMovementReasons: function(movementType, obj) {
			var self = this;
			var movementReasons = App.getModel("movementReasons");
			App.sync.getMovementReasons(movementType).done(function(response) {
				if (!obj.movementReasonNeeded) {
					response.results.unshift({
						ValueCode: "",
						ValueName: ""
					});
				}
				movementReasons.setData(response.results);
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				});
			});
		},
		validateDate: function(oEvent) {
			var source = oEvent.getSource();
			if (!source.getDateValue()) {
				source.setValueState("Error");
				source.setValueStateText(App.getTran("dateMissing"));
				source.focus();
			} else {
				source.setValueState("None");
			}
		},
		getDestLocations: function() {
			var self = this;
			var plants = {};
			App.sync.getDestLocations().done(function(response) {
				for (var i in response.results) {
					var dest = response.results[i];
					var it = $.extend({}, dest);
					if (!plants[dest.Plant]) {
						plants[dest.Plant] = dest;
						plants[dest.Plant].storlocs = [];
						plants[dest.Plant].storlocs.push(it);
					} else {
						plants[dest.Plant].storlocs.push(it);
					}
				}
				App.setModel(new JSONModel(plants), "destLocations");
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				});
			});
		},
		initBarcodeScanning: function(callback) {
			if(navigator && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
				navigator.mediaDevices.getUserMedia({video:true}).then(function(stream) {
					App.getModel("params").setProperty("/barcodeScanEnabled", true);
					if (callback) callback();
				}).catch(function(err) {
					console.log("error getting mediadevice", err);
				});
			}
    	}
    });
});