sap.ui.define([
	'com/upm/pw/z_wh_postgi/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	'com/upm/pw/z_wh_postgi/include/formatter',
	'sap/m/Dialog',
	'sap/m/MessageBox'
], function(BaseController, JSONModel, Formatter, Dialog, MessageBox) {
	'use strict';

	return BaseController.extend('com.upm.pw.z_wh_postgi.controller.App', {
		formatter: Formatter,
		onInit: function() {
			App.gi = this;
			this.view = this.getView();
		},
		back: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			// Navigate back to FLP home
			oCrossAppNavigator.toExternal({
				target : {shellHash: "#Shell-home"}
			});
		},
		onExit: function() {
			console.log("clearing interval")
			if (this.extendingSession)
				clearInterval(this.extendingSession)
		},
		startExtendingSession: function() {
        	this.extendingSession = setInterval(App.sync.checkHostReachableASync, 300000); //refresh last server ping every 5 minutes
        },
		/*
		* Refresh item count
		* Refresh order data
		* Calculate material line numbers 0010,0020 etc..
		* Remove table selections
		*/
		refreshModels: function() {
			this.refreshItemsCount();
			App.getModel("materials").refresh(true);
			App.getModel("order").refresh(true);
			this.calculateLineNumbers();
			this.getView().byId("oTbl").removeSelections();
		},
		/*
		* When changing movement type and we have materials user is prompted
		* and if yes material data is resetted otherwise fallback to previous movement type and no data changed
		* Get movement reasons for movement type (movement reasons is shown for needed mvtypes)
		* if transfer posting then get destination plants/storage locations
		*/
		movementTypeSelect: function(oEvent) {
			var self = this;
			var params = App.getModel("params");
			var materialModel = App.getModel("materials");
			var items = materialModel.getProperty("/");
			var movementTypes = (App.getModel("movementTypes") ? App.getModel("movementTypes").getProperty("/") : []);
			var selectedItem =  oEvent.getParameter("selectedItem").getBindingContext("movementTypes");
			var selectedObj = selectedItem.getObject();
			params.setProperty("/movTypeAssigment", selectedObj.assignment);
			params.setProperty("/moveReasonNeeded", selectedObj.movementReasonNeeded);
			params.setProperty("/showMoveReason", selectedObj.movementReasonShow);
			if (items.length > 0) {
				this.showDeleteDialog("Warning", App.getTran("warning"), App.getTran("materialRemoveWarning"), function(dialog) {
					self.resetData(false);
					dialog.close();
				}, function(dialog) {
					dialog.close();
					var prevMov = params.getProperty("/prevMovType");
					params.setProperty("/movementType", prevMov);
					var mvType = movementTypes.find(function(mv){
						return mv.mvtype == prevMov;
					});
					params.setProperty("/movTypeAssigment", mvType.assignment);
					params.setProperty("/moveReasonNeeded", mvType.movementReasonNeeded);
					params.setProperty("/showMoveReason", mvType.movementReasonShow);
				});
			} else {
				this.resetData(false);
			}
			this.getMovementReasons(selectedObj.mvtype, selectedObj);
			if (selectedObj.assignment == "T" || selectedObj.assignment == 'M') {
				this.getDestLocations();
			}
		},
		/*
		* get movement reasons when reverse check box is checked
		*
		*/
		reverseSelect: function(oEvent) {
			var selected = oEvent.getParameter("selected");
			var movementTypeSelect = this.getView().byId("movementType");
			var obj = movementTypeSelect.getSelectedItem().getBindingContext("movementTypes").getObject();
			this.getMovementReasons(selected ? obj.mvtypeNext : obj.mvtype, obj);
		},
		getCostCenterDialog: function() {
			if (!this.costCenterFragment) {
                this.costCenterFragment = sap.ui.xmlfragment("com.upm.pw.z_wh_postgi.fragments.costCenters", this);
                this.getView().addDependent(this.costCenterFragment);
            }
            return this.costCenterFragment;	
		},
		/*
		*Show cost centers
		*
		*/
		showCostCenters: function(oEvent) {
			var dialog = this.getCostCenterDialog();
			dialog.open();
			if (dialog.getBinding("items"))
				dialog.getBinding("items").filter([]);
		},
		costCenterSelect: function(oEvent) {
			var params = App.getModel("params");
			var selectedItem =  oEvent.getParameter("selectedItem").getBindingContext("costCenters");
			var selectedObj = selectedItem.getObject();
			params.setProperty("/costCenter", selectedObj.Ltext);
			params.setProperty("/costCenterNumber", selectedObj.Costcenter);
			this.view.byId("costCenter").setValueState("None");
			params.refresh(true);
		},
		costCenterSearch: function(oEvent) {
			var self = this;
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Costcenter", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("Ltext", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		getVendorDialog: function(oEvent) {
			if (!this.vendorDialog){
				this.vendorDialog = sap.ui.xmlfragment("com.upm.pw.z_wh_postgi.fragments.vendors", this);
				this.getView().addDependent(this.vendorDialog);
			}
			return this.vendorDialog;
		},
		showVendors: function(oEvent) {
			var dialog = this.getVendorDialog();
			dialog._searchField.setPlaceholder(App.getTran("searchByVendorName"));
			dialog.open();
			App.getModel("vendors").setData([]);
		},
		vendorSelect: function(oEvent) {
			var params = App.getModel("params");
			var selectedVendor = oEvent.getParameter("selectedItem");
			var obj = selectedVendor.getBindingContext("vendors").getObject();
			params.setProperty("/vendor", obj.Mcod1);
			params.setProperty("/vendorId", obj.Lifnr);
			this.view.byId("vendor").setValueState("None");
		},
		/*
		* Search vendors by name (selectDialog)
		*
		*/
		vendorSearch: function(oEvent) {
			var self = this;
			var model = App.getModel("vendors");
			var value = oEvent.getParameter("value");
			if (value.length == 0)
				return;
			
			if (value.length > 25) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("longValue"));
				return;
			}
			value = value.toUpperCase();
			//different path is * is used in search
			/*var star = value.indexOf("*") > -1;
			if (star)
				value = value.replace("*", "");*/
			App.sync.getVendors(value).done(function(response) {
				model.setData(response.results);
				model.refresh(true);
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
					
				});
			});
		},
		/*
		* Search order
		* few validations and prompt dialog shown if materials exist and search for new order
		*
		*/
		searchOrder: function(oEvent) {
			var self = this;
			var value = oEvent.getParameter("query");
			var input = oEvent.getSource();
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			var valid = false;
			if (value.length == 0)
				return false;
			
			var pann = /^[0-9+]*$/;
			if (!pann.test(value) || value.length > 12) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("valueError"));
				input.setValue("");
				jQuery.sap.delayedCall(500, this, function() {input.focus(); });
				return;
			}
			function search() {
				App.sync.getOrder(value).done(function(response) {
					self.handleOrder(response);
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						input.setValue("");
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					});
				});
			}
			
			if (materials.length > 0) {
				this.showDeleteDialog("Warning", 
					App.getTran("warning"),
					App.getTran("materialsWillRemove"),
					function(dialog) {
						dialog.close();
						valid = true;
						search();
					},
					function(dialog) {
						dialog.close();
					}
				);
			} else {
				valid = true;
			}
			
			if (valid) {
				search();
			}
		},
		/*
		* parse order search data
		* for every item in order we need to get the material data using getMaterial OData call
		* every material item is sent to getMaterial OData call separately
		*/
		handleOrder: function(data) {
			var self = this;
			var view = this.getView();
			var items = data.NavGiHeaderToItem.results;
			var params = App.getModel('params');
			var orderModel = App.getModel("order");
			var materialModel = App.getModel("materials");
			var ids = [];
			
			for (var i in items) {
				var item = items[i];
				item.Quantity = parseInt(item.Quantity);
				ids.push(item.Material);
			}

			var send = function() {
				if (!ids.length) return;
				
				var len = 1;
				var materialId = ids.slice(0, len)[0];
				ids.splice(0, len);
				
				App.sync.getMaterial(materialId).done(function(response) {
					var index = items.findIndex(function(item, i) {
						return item.Material == response.Matnr;	
					});
					if (index > -1) {
						var obj = items[index];
						obj.storlocs = response.NavMaterialToSloc.results;
						obj.units = response.NavMaterialToUom.results;
						obj.Uom = (obj.units.length > 0 ? obj.units[0].Unitlangu : "");
						obj.valTypes = response.NavMaterialToValType.results.filter(function(oIt) {
							return oIt.Plant == obj.Plant;
						});
						obj.ValType = (obj.ValType ? obj.ValType : obj.valTypes.length > 0 ? obj.valTypes[0].ValType : "");
					}
					if (ids.length > 0) {
						send();
					} else {
						orderModel.setData(data);
						materialModel.setData(items);
						var storlocModel = App.getModel("stglocs");
						var storlocs = storlocModel.getData();
						var selectedPlant = items[0].Plant;
						var selectedStorLoc = items[0].StgeLoc;
						if (selectedPlant && selectedStorLoc) {
							var plantStorLocs = storlocs.filter(function(item) {
								return item.Storloc == selectedStorLoc;
							});
							params.setProperty('/plant', selectedPlant);
							params.setProperty("/stgloc", plantStorLocs[0] ? plantStorLocs[0].Storloc : "");
							params.setProperty("/stglocText", plantStorLocs[0] ? plantStorLocs[0].StoreLocDesc : "");
						}
						
						self.refreshModels();
					}
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						
					});
				});
			};
			if (ids.length > 0) {
				send();
			} else {
				orderModel.setData(data);
				materialModel.setData([]);
			}
			self.refreshModels();
		},
		/*
		* Refresh item count in table toolbar
		*
		*/
		refreshItemsCount: function() {
			var view = this.getView();
			var itemsCountTitle = view.byId("itemCount");
			var items = App.getModel("materials").getProperty("/");
			var table = view.byId("oTbl");
			var itemsSelected = table.getSelectedItems();
			if (itemsSelected.length > 0) {
				itemsCountTitle.setText(App.getTran("itemsCount", [itemsSelected.length, items.length]));
			} else {
				itemsCountTitle.setText(App.getTran("itemsCount", [items.length, items.length]));
			}
		},
		/*
		* Search for material
		*
		*/
		materialSearch: function(oEvent) {
			var self = this;
			var view = this.getView();
			var params = App.getModel("params");
			var materialModel = App.getModel("materials");
			var orderModel = App.getModel("order");
			var materialItems = materialModel.getProperty("/");
			var matDocSearchEnabled = (params.getProperty("/movTypeAssigment") == "V" || false);
			var moveTypeOrder = (params.getProperty("/movTypeAssigment") == "O" || false);
			var movetypeTransfer = (params.getProperty("/movTypeAssigment") == "T" || params.getProperty("/movTypeAssigment") == "M" || false);
			
			var value = oEvent.getParameter("query");
			var input = oEvent.getSource();
			if (value.length == 0)
				return;
			
			var pann = /^[0-9+]*$/;
			if (!pann.test(value) || value.length > 18) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("valueError"), function() {
					input.setValue("");
					jQuery.sap.delayedCall(500, self, function() {input.focus(); });
				});
				return;
			}
			if (moveTypeOrder && !orderModel.getProperty("/Orderno")) {
				sap.m.MessageToast.show(App.getTran("orderNumMissing"));
				return false;
			}
				
			
			var index = materialItems.findIndex(function(item, i) {
				return item.Material == value;
			});
			/*
			* if we already have material then we increase quantity otherwise new OData call
			*
			*/
			if (index > -1) {
				var obj = materialItems[index];
				obj.Quantity = (parseInt(obj.Quantity) + 1);
				input.setValue("");
				self.refreshModels();
				jQuery.sap.delayedCall(500, self, function() {input.focus(); });
			}  else {
				App.sync.getMaterial(value).done(function(response) {
						var storlocs = [];
						var uoms = response.NavMaterialToUom.results;
						//get valuation types (excluding blank valtype)
						var valtypes = response.NavMaterialToValType.results.filter(function(oIt) {
							return oIt.Plant == params.getProperty("/plant") && oIt.ValType.length > 0;
						});
						//valuation types (including blank valtype)
						var valTypesAll = response.NavMaterialToValType.results.filter(function(oIt) {
							return oIt.Plant == params.getProperty("/plant");
						});
						//get storlocs
						for (var i in response.NavMaterialToSloc.results) {
							var storloc = response.NavMaterialToSloc.results[i];
							storlocs.push({
								Name: self.formatter.getPlant(storloc.Plant),
								Plant: storloc.Plant,
								Lgort: storloc.Storloc,
								StoreLocDesc: storloc.StoreLocDesc
							});
						}
						/*
						* Pushing material item to list is staged
						* if returning to vendor we need to select reference material document first
						* otherwise if we have valuation types we show a popup where user selects valtype
						* if only one valtype then we select the first one
						*/
						
						function pushMat(valtype, matDoc) {
							var plant = "";
							var storloc = "";
							var storlocDesc = "";
							
							if (movetypeTransfer) {
								storlocs = App.getModel("destLocations").getData();
								if (Object.keys(storlocs).length > 0) {
									var key = Object.keys(storlocs)[0];
									plant = storlocs[key].storlocs[0].Plant;
									storloc = storlocs[key].storlocs[0].Storloc;
									storlocDesc = storlocs[key].storlocs[0].StoreLocDesc;
								}
							
							}
							var itemToPush = {
								Itemno: materialItems.length + 1,
								Material: response.Matnr,
								MatlDesc: response.Maktx,
								Quantity: 1,
								Plant: (plant || ''),
								StoreLoc: (storloc || ''),
								StoreLocDesc: (storlocDesc || ''),
								storlocs: storlocs,
								Uom: (uoms.length > 0 ? uoms[0].Unitlangu : ""),
								units: uoms,
								ValType: valtype,
								valTypes: valTypesAll
							};
							if (matDoc) {
								itemToPush.MatDoc = matDoc.MatDoc;
								itemToPush.PoNumber = matDoc.PoNumber;
								itemToPush.PoItem = matDoc.PoItem;
							}
							
							materialItems.push(itemToPush);
							input.setValue("");
							self.refreshModels();
							jQuery.sap.delayedCall(500, self, function() {input.focus(); });
						}
						//final callback, if we have matdoc then we store macdoc data to item
						//otherwise we select valuation type
						function finalCallback(matDoc) {
							if (matDoc) {
								pushMat(matDoc.ValType, matDoc);
							} else {
								if (valtypes.length > 1) {
									self.showValTypeDialog(valtypes, function(selectedValType) {
										pushMat(selectedValType);
									});
								} else {
									pushMat(valtypes.length ? valtypes[0].ValType : "");
								}
							}
						}
						//matDocSeachEnabled is true when returning to vendor
						// we need to select a reference document for returning to vendor
						if (matDocSearchEnabled) {
							App.sync.getReturnMatDoc(response.Matnr).done(function(res) {
								var selectedVendor = params.getProperty("/vendorId");
								var references = [];
								//if we have vendor selected in header then we filter docs by vendor
								//otherwise we show all and depending on which mat doc we select, we also change vendor to that mat doc vendor
								if (selectedVendor) {
									references = res.results.filter(function(doc) {
										return doc.Vendor == selectedVendor;
									});
									if (!references.length) {
										self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("noReferences"), function() {
											input.setValue("");
											jQuery.sap.delayedCall(500, self, function() {input.focus(); });
										});
										return false;
									}
								} else {
									references = res.results;
								}
								// show select dialog if we have multiple mat docs otherwise select first one
								if (references.length > 1) {
									self.showMatDocSelectDialog(references, function(selectedMatDoc) {
										params.setProperty("/vendor", selectedMatDoc.VendName);
										params.setProperty("/vendorId", selectedMatDoc.Vendor);
										finalCallback(selectedMatDoc);
									}, function() {
										input.setValue("");
										jQuery.sap.delayedCall(500, self, function() {input.focus(); });
										return false;
									});
								} else {
									finalCallback(references[0]);
								}

							}).fail(function(e) {
								self.showMessageDialog('Error', e.title, "", e.message, function() {
									input.setValue("");
									jQuery.sap.delayedCall(500, self, function() {input.focus(); });
								});
							});
							
						} else {
							finalCallback(null);
						}
						
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						input.setValue("");
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					});
				});
			}
		},
		handleSearchTargetMaterial: function(oEvent) {
			var self = this;
			var input = oEvent.getSource();
			var value = input.getValue();
			if (value.length > 0) {
				App.sync.getMaterial(value).done(function(response) {
					//all good
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						input.setValue("");
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					});
				});
			}
		},
		getMatDocDialog: function() {
			if (!this.matDocFragment) {
                this.matDocFragment = sap.ui.xmlfragment("com.upm.pw.z_wh_postgi.fragments.matDocs", this);
                this.view.addDependent(this.matDocFragment);
            }
            return this.matDocFragment;	
		},
		showMatDocSelectDialog: function(matDocs, confirmCallback) {
			var selectDlg = this.getMatDocDialog();
			this.confirmCallback = confirmCallback;
			selectDlg.setModel(new JSONModel(matDocs));
			selectDlg.setModel(App.getModel("i18n"), "i18n");
			selectDlg.open();
		},
		/*
		* Little hack to remember callback {this.confirmCallback)
		*
		*/
		matDocConfirm: function(oEvent) {
			var selected = oEvent.getParameter("selectedItem").getBindingContext().getObject();
			this.confirmCallback(selected);
		},
		matDocSearch: function(oEvent) {
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("MatDoc", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("PoNumber", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		/*
		* Valuation type dialog is shown when we have more than 1 valuation type
		*
		*/
		showValTypeDialog: function(valtypes, callback) {
			var dialog = new Dialog({
				title: App.getTran("selectValType"),
				content: [],
				buttons: []
			}).addStyleClass("oDialogContent oCustomDlg");
			
			var list = new sap.m.List({
				mode: "SingleSelectMaster",
				width: "auto",
				select: function(listEvent) {
					var selected = listEvent.getParameter("listItem").getBindingContext().getObject();
					callback(selected.ValType);
					dialog.close();
				}
			}).bindAggregation("items", "/", new sap.m.StandardListItem({
				title: "{ValType}"
			}));
	
			list.setModel(new JSONModel(valtypes));
			dialog.addContent(list);
			dialog.open();	
		},
		/*
		* Deleting selected rows are done in reversal order, positions like 0,1,2..
		* but we delete them ..2,1,0 //higher number first so that we can delete many at the same time
		* otherwise position is replaced
		*
		*/
		deleteRow: function(oEvent) {
			var self = this;
			var view = self.getView();
			var table = view.byId("oTbl");
			var paths = table.getSelectedContextPaths();
			var model = App.getModel("materials");
			var items = model.getProperty("/");
			if (paths.length > 0) {
				var rowsToRemove = [];
				for (var i in paths) {
					rowsToRemove.push(paths[i].split("/")[1]);
				}
				for (var ii = rowsToRemove.length - 1; ii >= 0; ii--) {
					var index = rowsToRemove[ii];
					items.splice(index, 1);
				}
				model.refresh(true);
				table.removeSelections();
				self.refreshModels();
			}
		},
		getStgLocDialog: function() {
			if (!this.stgLocFragment) {
                this.stgLocFragment = sap.ui.xmlfragment("com.upm.pw.z_wh_postgi.fragments.stgLocs", this);
                this.getView().addDependent(this.stgLocFragment);
            }
            return this.stgLocFragment;	
		},
		/*
		* Show storage locations
		* We use same function for showing stg locations for header level and for material item level
		*
		*/
		showStorageLocations: function(oEvent) {
			var self = this;
			var params = App.getModel("params");
			var showPlantStg = params.getProperty("/showPlantStg");
			var isHeader = (oEvent.getParameter("id").indexOf("headerStg") > -1);
			var headerStorLoc = params.getProperty("/stgloc");
			var movementTypeAssignment = params.getProperty("/movTypeAssigment");
			var model = App.getModel("materials");
			var storlocs = [];
			if (isHeader) {
				storlocs = App.getModel("stglocs").getProperty("/").filter(function(stg) {
					return stg.Plant == params.getProperty("/plant");
				});
			} else {
				var item = oEvent.getSource().getBindingContext("materials").getObject();
				var storlocObj = oEvent.getSource().getBindingContext("materials").getProperty("storlocs");
				storlocs = (storlocObj[item.Plant] ? storlocObj[item.Plant].storlocs : []);
				if (movementTypeAssignment != 'M') {
					storlocs = storlocs.filter(function(stg) {
						return stg.Storloc != headerStorLoc;
					});
				}
				
			}
			
			var selectDlg = new sap.m.SelectDialog({
				title: App.getTran("selectStgLoc"),
				confirm: function(oDlgEvent) {
					var selected = oDlgEvent.getParameter("selectedItem").getBindingContext().getObject();
					if (isHeader) {
						params.setProperty("/stgloc", selected.Storloc);
						params.setProperty("/stglocText", selected.StoreLocDesc);
						self.view.byId("headerStg").setValueState("None");
					} else {
						item.StoreLoc = selected.Storloc;
						item.StoreLocDesc = selected.StoreLocDesc;
						model.refresh(true);
					}
				},
				liveChange: [self.stgLocSearch, self]
			});
			
			var	oListItem = new sap.m.StandardListItem({
				title: "{StoreLocDesc}",
				description: "{Storloc}"
			});
			selectDlg.setModel(new JSONModel(storlocs));
			selectDlg.bindAggregation("items", "/", oListItem);
			
			selectDlg.open();
			if (selectDlg.getBinding("items"))
				selectDlg.getBinding("items").filter([]);
		},
		stgLocSearch: function(oEvent) {
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Storloc", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("StoreLocDesc", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		validateQtyField: function(oEvent) {
			const input = oEvent.getSource();
        	const value = oEvent.getParameter("value");
        	var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
        	var model = App.getModel('materials');
			function setValueForItem(val) {
    			item.Quantity = val.replace(/,/, '.');
    			model.refresh(true);
    		}
    		var reg = new RegExp('^[0-9]{1,2}([,.][0-9]{1,2})?$');
    		if (!reg.test(value)) {
    			var replacedValue = value.replace(/[^0-9,.]/, '')
    			input.setValue(replacedValue)
    			setValueForItem(replacedValue)
    		} else {
    			setValueForItem(value)
    		}
		},
		/*
		* decrease quantity button in material item level
		*
		*/
		decrease: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue();
			var context = oEvent.getSource().getParent().getBindingContext("materials");
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			item.Quantity = parseInt(value) || 0;
			if (item.Quantity > 0) {
				item.Quantity--;
				model.refresh(true);
			}
		},
		/*
		* increase quantity button in material item level
		*
		*/
		increase: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue();
			var context = oEvent.getSource().getParent().getBindingContext("materials");
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			item.Quantity = parseInt(value) || 0;
			item.Quantity++;
			model.refresh(true);
		},
		/*
		* When changing header plant we need to get stg loc for that plant
		* we take the first one but can be changed by user
		*/
		headerPlantChange: function(oEvent) {
			var params = App.getModel("params");
			var storlocModel = App.getModel("stglocs");
			var storlocs = storlocModel.getData();
			var selectedPlant = oEvent.getSource().getSelectedKey();
			var plantStorLocs = storlocs.filter(function(item) {
				return item.Plant == selectedPlant;
			});
			params.setProperty("/stgloc", plantStorLocs[0] ? plantStorLocs[0].Storloc : "");
			params.setProperty("/stglocText", plantStorLocs[0] ? plantStorLocs[0].StoreLocDesc : "");
		},
		/*
		* When changing material item plant we need to filter storage locations and exclude the header stg loc
		*
		*/
		plantChange: function(oEvent) {
			var self = this;
			var params = App.getModel("params");
			var model = App.getModel("materials");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			var storlocsAvailable = item.storlocs[item.Plant];
			var storlocs = storlocsAvailable && storlocsAvailable.storlocs.length > 0 ? storlocsAvailable.storlocs : [];
			var movementTypeAssignment = params.getProperty("/movTypeAssigment");
			if (movementTypeAssignment != 'M') {
				storlocs = storlocs.filter(function(itm) {
					return itm.Storloc != params.getProperty("/stgloc");
				});
			}
			item.StoreLoc = storlocs.length > 0 ? storlocs[0].Storloc : "";
			item.StoreLocDesc = storlocs.length > 0 ? storlocs[0].StoreLocDesc : "";
			model.refresh(true);
		},
		/*
		* validate data before sending to SAP
		*
		*/
		valid: function(callback) {
			var self = this;
			var view = this.getView();
			var params = App.getModel("params");
			var orderModel = App.getModel("order");
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			var docDt = view.byId("documentDate");
			var postDt = view.byId("postingDate");
			var docHeader = view.byId("documentHeaderText");
			var orderNum = view.byId("orderNumber");
			var headerStg = view.byId("headerStg");
			var costCenter = view.byId("costCenter");
			var vendor = view.byId("vendor");
			var isMovementReasonNeeded = params.getProperty("/moveReasonNeeded");
			var movementTypeAssignment = params.getProperty("/movTypeAssigment");
			var transferMoveTypeActive = (movementTypeAssignment == "T");
			var msgToast = sap.m.MessageToast;
			//document date
			if (!docDt.getDateValue()) {
				docDt.setValueState("Error");
				docDt.setValueStateText(App.getTran("dateMissing"));
				docDt.focus();
				return false;
			}
			//posting date
			if (!postDt.getDateValue()) {
				postDt.setValueState("Error");
				postDt.setValueStateText(App.getTran("dateMissing"));
				postDt.focus();
				return false;
			}
			//materials needed
			if (!materials.length) {
				msgToast.show(App.getTran("materialsMissing"));
				return false;
			}
			//gi for order
			if (movementTypeAssignment == "O") {
				if (!orderModel.getProperty("/Orderno")) {
					msgToast.show(App.getTran("orderNumMissing"));
					orderNum.focus();
					return false;
				}
				//return to vendor
			} else if (movementTypeAssignment == "V") {
				if (!params.getProperty("/vendorId")) {
					vendor.setValueState("Error");
					vendor.focus();
					return false;
				}
				//gi for cost center / scrapping
			} else if (movementTypeAssignment == "C" || movementTypeAssignment == "S") {
				if (!params.getProperty("/costCenterNumber")) {
					costCenter.setValueState("Error");
					costCenter.focus();
					return false;
				}
			}
			
			if (materials.length > 0) {
				var matValid = false;
				var err = "";
				for (var i in materials) {
					var mat = materials[i];
					if (mat.Quantity && mat.Quantity.toString().replace(/,/, '.') > 0) {
						matValid = true;
					} else {
						matValid = false;
						err = App.getTran("checkMaterials");
						break;
					}
					if (isMovementReasonNeeded) {
						if (!mat.MoveReas) {
							matValid = false;
							err = App.getTran("checkMoveReason");
						}
					}
				}
				if (!matValid) {
					msgToast.show(err);
					return false;
				}
			} else {
				return false;
			}
			
			if (!params.getProperty("/stgloc")) {
				headerStg.setValueState("Error");
				headerStg.setValueStateText(App.getTran("stglocMissing"));
				return false;
			}
			
			docDt.setValueState("None");
			postDt.setValueState("None"); 
			headerStg.setValueState("None");
			self.showDeleteDialog(
				"Warning",
				App.getTran("warning"),
				App.getTran("postPrompt"),
				function(dialog) {
					dialog.close();
					callback();
				},
				function() {
					return false;
				}
			);
		},
		cancelGI: function(oEvent) {
			this.resetData(true);
		},
		/*
		* This is where data gets send to SAP
		*
		*/
		postGI: function(oEvent) {
			var self = this;
			var params = App.getModel("params");
			var materialModel = App.getModel("materials");
			var orderModel = App.getModel("order");
			self.valid(function() {
				var materials = materialModel.getProperty("/");
				var movementType = self.formatter.getMovementType(params.getProperty("/movementType"));
				var reversal = params.getProperty("/reverseSelected");
				var selectedPlant = params.getProperty("/plant");
				var selectedStgLoc = params.getProperty("/stgloc");
				var movementTypeAssignment = params.getProperty("/movTypeAssigment");
				var transferMoveTypeActive = (movementTypeAssignment == "T" || movementTypeAssignment == 'M'); //transferposting active
				//header info
				var dataToSend = {
					Mvttype: !reversal ? movementType.mvtype : movementType.mvtypeNext,
					Costcenter: (params.getProperty("/costCenterNumber") || ''),
					Orderno: (orderModel.getProperty("/Orderno") || ''),
					Vendor: (params.getProperty("/vendorId") || ''),
					Docdate: params.getProperty("/docDate"),
					Postdate: params.getProperty("/postDate"),
					Ordertext: params.getProperty("/docHeaderText"),
					NavGiHeaderToItem: []
				};
				//loop item data
				for (var i in materials) {
					var item = materials[i];
					dataToSend.NavGiHeaderToItem.push({
						Orderno: (dataToSend.Orderno || ''),             
						Material: item.Material,
						MatlDesc: item.MatlDesc,
						Quantity: item.Quantity.toString(),
						Plant: selectedPlant,
						DestPlant: (transferMoveTypeActive ? item.Plant : ''),
						Itemno: item.line,
						StgeLoc: selectedStgLoc,
						DestStgeLoc: (transferMoveTypeActive ? item.StoreLoc : ''),
						Unit: item.Uom,
						MoveReas: (item.MoveReas || ''),
						PoNumber: (item.PoNumber || ''),
						PoItem: (item.PoItem || ''),
						ValType: (item.ValType || ''),
						DestMaterial: (item.DestMaterial || ''),
						Reservation: (item.Reservation || ''),
						ReservationItem: (item.ReservationItem || '')
					});
				}
				
				App.sync.postGI(dataToSend).done(function(response) {
					self.showMessageDialog("Success", App.getTran("success"), "", App.getTran("giCreated", [response.MatDoc]), function() {
						self.resetData(false);
					});
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						
					});
				});
			});
		},
		/*
		* Reset view when clicking cancel button
		* Reset view when GI has been posted successfully
		* {showPrompt} determines if prompt before resetting is shown
		*/
		resetData: function(showPrompt) {
			var self = this;
			var params = App.getModel("params");
			var orderModel = App.getModel("order");
			var materialModel = App.getModel("materials");
			var plant = params.getProperty("/plant");
			var stgloc = params.getProperty("/stgloc");
			var stglocText = params.getProperty("/stglocText");
			var movementType = params.getProperty("/movementType");
			var prevMovementType = params.getProperty("/prevMovType");
			var movTypeAssigment = params.getProperty("/movTypeAssigment");
			var moveReasonNeeded = params.getProperty("/moveReasonNeeded");
			var showMoveReason = params.getProperty("/showMoveReason");
			var barcodeScanningEnabled = params.getProperty("/barcodeScanEnabled");
			
			function reset() {
				params.setData({
					"movementType": movementType,
					"prevMovType": prevMovementType,
					"movTypeAssigment": movTypeAssigment,
					"moveReasonNeeded": moveReasonNeeded,
					"showMoveReason": showMoveReason,
					"costCenter": "",
					"postDate": new Date(),
					"docDate": new Date(),
					"reverseSelected": false,
					"vendor": "",
					"vendorId": "",
					"docHeaderText": "",
					"orderNo": "",
					"showPlantStg": true,
					"plant": plant,
					"stgloc": stgloc,
					"stglocText": stglocText,
					"barcodeScanEnabled": barcodeScanningEnabled
				});
		        orderModel.setData({});
		        materialModel.setData([]);
		        self.refreshModels();
			}
			if (showPrompt) {
				self.showDeleteDialog(
					"Warning",
					App.getTran("resetData"),
					App.getTran("resetPrompt"),
					function(dialog) {
						reset();
						dialog.close();
					},
					function() {
						
					}
				)
			} else {
				reset();
			}
			
			
		},
		// scan barcode with camera in create purchase order mode, opens dialog where you can scan barcodes
		// using QuaggaJS libarary
		// https://serratus.github.io/quaggaJS/
		scanBarcode: function(oEvent) {
			var self = this;
			if (!this._oScanDialog) {
				this._oScanDialog = new sap.m.Dialog({
					title: "{i18n>scanBarcode}",
					contentWidth: "640px",
					contentHeight: "480px",
					horizontalScrolling: false,
					verticalScrolling: false,
					stretchOnPhone: true,
					content	: [new sap.ui.core.HTML({
						id: this.createId("scanContainer"),
						content: "<div />"
					}).addStyleClass("scanContainer")],
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function(oEvent) {
							this._oScanDialog.close();
						}.bind(this)
					}),
					afterOpen: function() {
						this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function() {
							// Initialisation done, start Quagga
							Quagga.start();
						}).fail(function(oError) {
							MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name),{
								onClose: function() {
									this._oScanDialog.close();
								}.bind(this)
							});
						}.bind(this));
					}.bind(this),
					afterClose: function() {
						// Dialog closed, stop Quagga
						Quagga.stop();
					}
				}).addStyleClass("cameraDialog");
				
				this.getView().addDependent(this._oScanDialog);
			}
			this._oScanDialog.open();
		},
		//this initializes quaggaJS and when it detects barcode it runs Quagga.onDetected function
		//and searches that material ID from SAP
		_initQuagga: function(oTarget) {
			var self = this;
			var oDeferred = jQuery.Deferred();
			
			Quagga.init({
				inputStream: {
					type: "LiveStream",
					target: oTarget,
					constraints: {
						width: {min: 640},
	            		height: {min: 480},
						facingMode: "environment"
					}
				},
				locator: {
					patchSize: "medium",
					halfSample: true
				},
				numOfWorkers: 4,
				frequency: 10,
				//currectly we look only for CODE128 and EAN bar codes
				decoder	: {
					readers : [{
						format: "code_128_reader",
						config: {}
					}, {
						format: "ean_reader",
						config: {}
					}]
				},
				locate: true,
				multiple: false
			}, function(error) {
				if (error) {
					oDeferred.reject(error);
				} else {
					oDeferred.resolve();
				}
			});
			
			if(!this._oQuaggaEventHandlersAttached) {
				// Attach event handlers...
	
				Quagga.onProcessed(function(result) {
					var drawingCtx = Quagga.canvas.ctx.overlay,
						drawingCanvas = Quagga.canvas.dom.overlay;
					
					if (result) {
						// The following will attempt to draw boxes around detected barcodes
						if (result.boxes) {
							drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
							result.boxes.filter(function (box) {
								return box !== result.box;
							}).forEach(function (box) {
								Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
							});
						}
						
						if (result.box) {
							Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "#00F", lineWidth: 2});
						}
						
						if (result.codeResult && result.codeResult.code) {
							Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
						}
					}
				}.bind(this));
				// barcode detected
				Quagga.onDetected(function(result) {
					App.gi.byId("matSearch").setValue(result.codeResult.code)
					this._oScanDialog.close();
					App.gi.byId("matSearch").fireSearch({query: result.codeResult.code});
					Quagga.stop();
				}.bind(this));
				// Set flag so that event handlers are only attached once...
				this._oQuaggaEventHandlersAttached = true;
			}
			
			return oDeferred.promise();
		},
		/*
		* After rendering view we refresh material item count in table toolbar
		*
		*/
		onAfterRendering: function() {
			var self = this;
			jQuery.sap.delayedCall(1000, self, function() {
				self.refreshItemsCount(); 
				var params = App.getModel("params");
				var currentMvmtType = params.getProperty("/movementType");
				params.setProperty("/prevMovType", currentMvmtType);
				self.startExtendingSession();
			});
			
			jQuery.sap.delayedCall(1500, self, function() {
				self.initBarcodeScanning(function() {
					App.getModel("params").refresh(true);
				});
			});
		}
	});
});