sap.ui.define([
    "sap/ui/core/format/DateFormat"
], function (DateFormat) {
   return {
        deliveryDate: function (value) {
            try {
                if (value) {
                    value = new Date(parseFloat(value.split("(")[1]));
                    var date = value.getDate();
                    var month = value.getMonth() + 1;
                    var year = value.getFullYear();
                    var fullDate = date + "." + month + '.' + year;
                }
                return fullDate;
            } catch (e) {
                console.log(e);
            }
        },

        getTime: function () {
            try {
                var date = new Date();
                var hour = date.getHours();
                var minutes = date.getMinutes();
                if (minutes < 10)
                    minutes = '0' + minutes;

                var time = hour + ':' + minutes;
                return time;
            } catch (e) {
                console.log(e);
            }
        },

        toShortDate: function (sDate) {
            if (sDate) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy"
                });
                return oDateFormat.format(new Date(sDate));
            }
            return sDate;
        },

        toDateTime: function (datetime) {
            if (datetime) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy HH:mm"
                });
                return oDateFormat.format(new Date(datetime));
            }
            return datetime;
        },
        parseQuantity: function(value) {
        	return value ? parseFloat(value) : value;
        },
        getPlant: function(value) {
        	var plants = App.getModel("plants") ? App.getModel("plants").getData() : [];
        	var plant = plants.find(function(item, i) {
        		return item.Plant == value;
        	});
        	return (plant ? plant.Name : "");
        },
        getLineNumber: function(line) {
        	return line ? line : "";
        },
        getMovementType: function(type) {
        	var mvmtTypes = App.getModel("movementTypes") ? App.getModel("movementTypes").getData() : [];
        	var mvmt = mvmtTypes.find(function(item, i) {
        		return item.mvtype == type;
        	});
        	return mvmt;
        },
        checkValTypeAvailability: function(items) {
        	if (!items)
        		return true;
        	return items.filter(function(item, i) {
				return item.valTypes.length > 0;
			}).length > 0;
        },
        checkValtype: function(valtypes) {
        	if (!valtypes.length)
        		return false;
        	if (valtypes.length == 1 && valtypes[0].ValType == "")
        		return false;
        	return true;
        },
        parseQty: function(qty) {
        	return parseInt(qty);
        },
        isMoveTypeO: function(assigment) {
        	return (assigment == "O" ? true : false);
        },
        isMoveTypeV: function(assigment) {
        	return (assigment == "V" ? true : false);
        },
        isMoveTypeCS: function(assigment) {
        	return (assigment == "C" || assigment == "S" ? true : false);
        },
        isMoveTypeT: function(assigment) {
        	return (assigment == "T" || assigment =='M');
        },
        isMoveTypeM: function(assigment) {
        	return (assigment == "M");
        },
        isMoveReasonNeeded: function(needed) {
        	return needed ? true : false;
        },
        getPlantVisible: function(showPlant) {
        	return showPlant ? true : false;
        },
        getMoveReasonVisible: function(showMoveReason) {
        	return showMoveReason ? true: false;
        },
        checkCameraAvailability: function(params) {
        	return (params.barcodeScanEnabled && params.createPOMode ? true : false);
        },
        getCostCenter: function(params) {
        	return (params.costCenter && params.costCenterNumber ? params.costCenter + " (" + params.costCenterNumber + ")" : "");
        }
    };
});