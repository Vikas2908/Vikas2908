/*global App:true */
sap.ui.define([
	'sap/ui/core/BusyIndicator',
	'sap/ui/model/odata/v2/ODataModel',
	'sap/m/Dialog',
	'sap/m/MessageBox',
	'sap/ui/model/Filter',
	'sap/ui/model/Sorter'
], function(BusyIndicator, ODataModel, Dialog, MessageBox, Filter, Sorter) {
	return {
		base_url: "/odata/SAP/ZWH_EQ_GI_SRV/",
		getBaseModel: function() {
			var self = this;
			if (!this.baseServiceModel) {
				this.baseServiceModel = new ODataModel(this.base_url, {
					json: true,
					useBatch: false
				});
				this.baseServiceModel.attachMetadataFailed(function(oEvent) {
					self.parseSapError(oEvent.getParameters());
				}, this);
			}
			return this.baseServiceModel;
		},
		parseSapError: function(requestError) {
			var str = "";
			if (requestError && requestError.responseText) {
				try {
					var responseText = requestError.responseText.split("message");
					if (responseText.length > 0) {
						if (responseText[1]) {
							var txtSplitted = responseText[1].split(">");
							if (txtSplitted && txtSplitted.length > 0 && txtSplitted[1]) {
								str = txtSplitted[1].split("<")[0];
							}
						}
					}
				}
				catch(e) {
					str = requestError.message;
				}
			}
			if (!str) {
				str = requestError.message;
			}
			BusyIndicator.hide();
			MessageBox.error(str);
		},
		getUserId: function() {
			return sap.ushell ? sap.ushell.Container.getUser().getId() : null;
		},
		checkHostReachableASync: function() {
			var deferred = $.Deferred();
			var xhr = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
			xhr.open("HEAD", "?rand=" + Math.floor((1 + Math.random()) * 0x10000), true);
			xhr.onload = function () {
				return (xhr.status>= 200 && xhr.status < 300 || xhr.status === 304) ? deferred.resolve(true) : deferred.reject();
			};
			xhr.onerror = function () {
			  deferred.reject();
			};
			xhr.send();
			return deferred;	
		},
		checkHostReachable: function() {
			var xhr = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
			xhr.open("HEAD", "?rand=" + Math.floor((1 + Math.random()) * 0x10000), false);

			try{
				xhr.send();
				return (xhr.status>= 200 && xhr.status < 300 || xhr.status === 304);
			}	
			catch(e) {
				return false;
			}
		},
		showMessageDialog: function(state, title, message) {
			var dialog = new Dialog({
				state: state,
				title: title,
				content: new sap.m.Text({text: message})
			}).addStyleClass("oMsgDialog");
			dialog.open();
		},
		
		_odataRead: function(model, path, filters, sorters, params) {
			App.showLoader();
			var self = this;
			var def = $.Deferred();
			model.read(path, {
				filters: (filters || []),
				sorters: (sorters || []),
				urlParameters: (params || ''),
				success: function(data) {
					App.hideLoader();
					def.resolve(data);
				},
				error: function(error) {
					App.hideLoader();
					def.reject(self._handleError(error));
				}
			});
			
			return def;
		},
		_odataCreate: function(model, path, data) {
			App.showLoader();
			var def = $.Deferred();
			var self = this;
		
			model.create(path, data, {
				context: null,
				success: function(data) {
					App.hideLoader();
					def.resolve(data);
				},
				error: function(error) {
					App.hideLoader();
					def.reject(self._handleError(error));
				},
				async:true
			});
			
			return def;
		},
		_odataUpdate: function(model, path, data) {
			App.showLoader();
			var def = $.Deferred();
			var self = this;
			
			model.update(path, data, {
				context: null,
				success: function(data) {
					App.hideLoader();
					def.resolve(data);
				},
				error: function(error) {
					App.hideLoader();
					def.reject(self._handleError(error));
				},
				async:true
			});
			
			return def;
		},
		_odataRemove: function(model, path) {
			App.showLoader();
			var def = $.Deferred();
			var self = this;
			model.remove(path, {
				success: function(data) {
					App.hideLoader();
					def.resolve(data);
				},
				error: function(error) {
					App.hideLoader();
					def.reject(self._handleError(error));
				}
			});
			
			return def;
		},

		_handleError: function(error) {
			var message = "";
			var title = App.getTran('error');

			try{
				error = (error.response && error.response.body || error.responseText || error);
				error = JSON.parse(error);
				var innerError = error.error.innererror.errordetails;
				for (var i in innerError) {
					var errorMsg = innerError[i];

					if (errorMsg.code.indexOf('/IWBEP') == -1)
						message += errorMsg.message + '\n';
				}
			}
			catch(err) {
				message = error.error ? error.error.message.value : error.message;
			}
			if (!message)
				message = error.error ? error.error.message.value : error.message;
			
			return {title: title, message: message};
		},

		_baseDataRead: function(path, filter, sorter, urlParams) {
			return this._odataRead(this.getBaseModel(), path, filter, sorter, urlParams);
		},

		_baseDataCreate: function(path, data) {
			return this._odataCreate(this.getBaseModel(), path, data);
		},
		_baseDataUpdate: function(path, data) {
			return this._odataUpdate(this.getBaseModel(), path, data);
		},
		_baseDataRemove: function(path, data) {
			return this._odataRemove(this.getBaseModel(), path, data);
		},
		getVendors: function(vendor) {
			var path = "/SearchPoByVendorNameSet";
			return this._baseDataRead(path, [new Filter('Mcod1', 'Contains', vendor)]);
		},
		getStorageLocations: function(value) {
			var path = "/StoreLocsMatnrPlantSet";
			return this._baseDataRead(path, [new Filter('PoNumber', 'EQ', value)]);
		},
		getPlantStorLocs: function(value) {
			var path = "/PlantStorLocSet";
			return this._baseDataRead(path);
		},
		getUnits: function(value) {
			var path = "/MatnrUoMSet";
			return this._baseDataRead(path, [new Filter('PoNumber', 'EQ', value)]);
		},
		getMovementTypes: function() {
			var path = "/MovementTypeSet";
			return this._baseDataRead(path);
		},
		getCostCenters: function() {
			var path = "/CostCenterSet";
			return this._baseDataRead(path);
		},
		getOrder: function(value) {
			var path = "/GiHeaderSet('" + value + "')";
			return this._baseDataRead(path, [], [], '$expand=NavGiHeaderToItem');
		},
		getMaterial: function(value) {
			var path = "/MaterialSet('" + value +"')";
			return this._baseDataRead(path, [], [], '$expand=NavMaterialToUom,NavMaterialToSloc,NavMaterialToValType');
		},
		getUserPlant: function() {
			var path = "/UserPlantSet";
			return this._baseDataRead(path);
		},
		postGI: function(data) {
			var path = "/GiHeaderSet";
			return this._baseDataCreate(path, data);
		},
		getMovementReasons: function(mvmt) {
			var path = "/ValueTextSet";
			var filters = [
				new Filter('Fieldname', 'EQ', 'MovementReason'),
				new Filter('ValueCode', 'EQ', mvmt)
			];
			return this._baseDataRead(path, filters);
		},
		getReturnMatDoc: function(value) {
			var path = "/MaterialDocumentSet";
			return this._baseDataRead(path, [new Filter('Material', 'EQ', value)]);
		},
		getDestLocations: function() {
			var path = "/DestLocationSet";
			return this._baseDataRead(path);
		}
	};
});