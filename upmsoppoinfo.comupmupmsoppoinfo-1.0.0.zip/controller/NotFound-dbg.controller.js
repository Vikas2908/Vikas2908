sap.ui.define([
	"com/upm/upmsoppoinfo/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("com.upm.upmsoppoinfo.controller.NotFound", {
		onLinkPressed: function() {
			this.getRouter().navTo("worklist");
		}

	});

});