/* global App:true */
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"com/upm/pw/z_wh_postgr/model/models",
	"com/upm/pw/z_wh_postgr/include/formatter",
	"com/upm/pw/z_wh_postgr/include/sync",
	"sap/m/Dialog"
], function(UIComponent, Device, JSONModel, models, Formatter, Sync, Dialog) {
	"use strict";

	return UIComponent.extend("com.upm.pw.z_wh_postgr.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			window.App = this;
			UIComponent.prototype.init.apply(this, arguments);
			this.predefineFunction();
		},
		predefineFunction: function() {
			var self = this;
			App.sync = Sync;
			App.formatter = Formatter;
			
			
			App.loader =  new sap.m.BusyDialog({
				text: "",
				title: "",
				showCancelButton: false
			});
			
			App.showLoader = function() {
				App.loader.open();
			};
			App.hideLoader = function() {
				App.loader.close();
			};
			App.setLanguage = function(lang) {
				
				var i18nModel = new sap.ui.model.resource.ResourceModel({
					bundleName : "com.upm.pw.z_wh_postgr.i18n.i18n",
					bundleLocale: lang
				});
				
				App.setModel(i18nModel, "i18n");
				App.getModel("i18n").refresh(true);
			};
			
			var lang = sap.ui.getCore().getConfiguration().getLanguage() ? sap.ui.getCore().getConfiguration().getLanguage() : 'en';
			
			App.setLanguage(lang);
			App.getTran = function(tran, args) {
	         	return App.getModel('i18n').getResourceBundle().getText(tran, (args ? args : ''));
	        };
	        
	        App.setModel(new JSONModel({
	        	"createPOMode": false,
	        	"deliveryNote": "",
	        	"waybill": "",
	        	"docDate": new Date(),
	        	"postDate": new Date(),
	        	"POModeVendor": "",
	        	"barcodeScanEnabled": false,
	        	"HeaderText": "",
	        	"printLabel": ""
	        }), "params");
	        
	        App.setModel(new JSONModel({}), "purchase");
	        App.setModel(new JSONModel([]), "materials");
	        App.setModel(new JSONModel({}), "units");
	        App.setModel(new JSONModel({}), "storlocs");
	        App.setModel(new JSONModel([]), "vendors");
	        App.setModel(new JSONModel([]), "vendorPOs");
	        App.sync.getUserPlant().done(function(response) {
				App.setModel(new JSONModel(response.results), "plants");
			});
	        App.sync.getStockCategories().done(function(response) {
	        	App.setModel(new JSONModel(response.results), "stockCategories");
	        }).fail(function(e) {
				App.view.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
	        /*App.sync.getValTypes().done(function(response) {
	        	response.results.unshift({"ValueCode":"", "ValueName": ""});
	        	App.setModel(new JSONModel(response.results), "valTypes");
	        }).fail(function(e) {
				App.view.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});*/
		},
		showMessageDialog: function(state, title, icon, message, callback) {
			var dialog = new Dialog({
				state: state,
				title: title,
				icon: icon,
				content: new sap.m.Text({text: message}),
				beginButton: new sap.m.Button({
					text: App.getTran("close"),
					press: function() {
						dialog.close();
						if (callback)
							callback();
						
					}
				})
			}).addStyleClass("oMsgDialog");
			dialog.open();
        },
	});
});