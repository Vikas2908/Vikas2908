sap.ui.define([
    "sap/ui/core/format/DateFormat"
], function (DateFormat) {
   return {
        deliveryDate: function (value) {
            try {
                if (value) {
                    value = new Date(parseFloat(value.split("(")[1]));
                    var date = value.getDate();
                    var month = value.getMonth() + 1;
                    var year = value.getFullYear();
                    var fullDate = date + "." + month + '.' + year;
                }
                return fullDate;
            } catch (e) {
                console.log(e);
            }
        },

        getTime: function () {
            try {
                var date = new Date();
                var hour = date.getHours();
                var minutes = date.getMinutes();
                if (minutes < 10)
                    minutes = '0' + minutes;

                var time = hour + ':' + minutes;
                return time;
            } catch (e) {
                console.log(e);
            }
        },

        toShortDate: function (sDate) {
            if (sDate) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy"
                });
                return oDateFormat.format(new Date(sDate));
            }
            return sDate;
        },

        toDateTime: function (datetime) {
            if (datetime) {
                var oDateFormat = DateFormat.getDateTimeInstance({
                    pattern: "dd.MM.yyyy HH:mm"
                });
                return oDateFormat.format(new Date(datetime));
            }
            return datetime;
        },
        toSAPDT: function (date) {
			if (date) {
				var d = ("0" + (date.getDate())).slice(-2);
				var m = ("0" + (date.getMonth() + 1)).slice(-2);
				var y = date.getFullYear();
				date = y + '-' + m + '-' + d + 'T00:00:00';
			}
			return date;
		},
        checkPicked: function(picked) {
        	return (picked && picked > 0 ? picked : 0);
        },
        getDeliveryCount: function(delivery) {
        	return App.getTran("orderCount", [0]);
        },
        checkValTypeNoCreateMode: function(type) {
        	var createMode = App.getModel("params").getProperty("/createPOMode");
        	if (createMode)
        		return false;
        	return type.length > 0;
        },
        checkValTypeCreateMode: function(types) {
        	var createMode = App.getModel("params").getProperty("/createPOMode");
        	if (!createMode)
        		return false;
	    	if (!types.length)
	    		return false;
	        if (types.length == 1 && valtypes[0].ValType == "")
	        	return false;
	        return true;
        },
        checkItemsForVal: function(items) {
        	if (!items)
        		return true;
        	var createMode = App.getModel("params").getProperty("/createPOMode");
        	return items.filter(function(item, i) {
				return createMode ? item.valTypes.length > 0 : item.ValType.length > 0;
			}).length > 0;
        },
        createModeOn: function(mode) {
        	return mode ? false : true;
        },
        createModeOff: function(mode) {
        	return mode;
        },
        getTitle: function(vendName, vendNumber, mode) {
        	return mode ? App.getTran("grForNewPo") : (vendName || '') + " " + (vendNumber || '');
        },
        pad: function(n, width, z) {
        	z = z || '0';
			n = n + '';
			return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
        },
        getLineNumber: function(line) {
        	return parseInt(line);
        },
        getPlant: function(value) {
        	var plants = App.getModel("plants") ? App.getModel("plants").getData() : [];
        	var plant = plants.find(function(item, i) {
        		return item.Plant == value;
        	});
        	return (plant ? plant.Name : "");
        },
        checkCameraAvailability: function(params) {
        	return (params.barcodeScanEnabled && params.createPOMode ? true : false);
        },
        parseQty: function(value, uom) {
        	return parseInt(value) + " " + uom;
        },
        hideIfItemOrderNumber: function(items = []) {
        	if (!items.length) return true;
        	return items.filter(function(item) {
        		return item.OrderNumber.length === 0;
        	}).length > 0;
        },
		showIfItemOrderNumber: function(items = []) {
        	if (!items.length) return false;
        	return items.filter(function(item) {
        		return item.OrderNumber.length > 0;
        	}).length > 0;
        },
        showIfItemStorbin: function(items = []) {
        	if (!items.length) return false;
        	return items.filter(function(item) {
        		return item.StorageBin.length > 0;
        	}).length > 0;
        },
		showIfItemCC: function(items = []) {
        	if (!items.length) return false;
        	return items.filter(function(item) {
        		return item.CostCenter.length > 0;
        	}).length > 0;
        },
		hideIfItemCC: function(items = []) {
        	if (!items.length) return true;
        	return items.filter(function(item) {
        		return item.CostCenter.length === 0;
        	}).length > 0;
        },
        removeLeadingZeros: function(value) {
        	return value ? value.replace(/\b0+/g, '') : '';
        }
    };
});