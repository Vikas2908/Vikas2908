sap.ui.jsview("com.upm.pw.z_wh_postgr.view.App", {
	getControllerName: function () {
		return "com.upm.pw.z_wh_postgr.controller.App";
	},
	createContent: function (oController) {
		var self = this;
		this.setDisplayBlock(true);
		this.vendorSelectDialog = this.getSelectDialog(oController);
		this.vendorPOselectDialog = this.getPOSelectDialog(oController);

		var hiddenInput = new sap.ui.core.HTML({
			content: '<input class="hidden" id="hiddenInput" type="file" name="file" accept="image/*"/>'
		});

		var oPage = new sap.m.Page({
			title: "{i18n>appTitle}",
			showHeader: false,
			content: [
				self.getTopContent(oController),
				self.getTitleToolbar(oController),
				self.getHeader(oController),
				self.getToolbar(oController),
				self.getTable(oController),
				hiddenInput
			],
			footer: self.getFooter(oController)
		});

		this.app = new sap.m.App(this.createId("app"), {
			pages: [oPage]
		}).addStyleClass("whpostgr");
		return this.app;
	},
	getTopContent: function (oController) {
		return new sap.ui.layout.HorizontalLayout({
			content: [
				new sap.ui.layout.VerticalLayout({
					//width: "120px",
					content: [new sap.m.Label({
						text: "{i18n>purchaseorder}:"
					})]
				}),
				new sap.ui.layout.VerticalLayout({
					content: [
						new sap.m.SearchField(this.createId("oSearchField"), {
							enabled: {
								path: 'params>/createPOMode',
								formatter: oController.formatter.createModeOn
							},
							search: [oController.POSearch, oController]
						}).addStyleClass("oSearchField")
					]
				}),
				new sap.m.Button({
					visible: {
						path: 'params>/createPOMode',
						formatter: oController.formatter.createModeOn
					},
					text: "{i18n>searchByVendor}",
					press: [oController.showSelectDialog, oController]
				}).addStyleClass("oMarginLeft oCustomHeight"),
				new sap.m.Button({
					type: "Accept",
					text: "{i18n>addPhoto}",
					press: [oController.addPhoto, oController]
				}).addStyleClass("oCustomHeight"),
				new sap.ui.layout.HorizontalLayout(this.createId("oPhotoContainer"), {
					content: [

					]
				}).addStyleClass("oPhotoContainer")
			]
		}).addStyleClass("oSearchContainer whiteBg");
	},
	getTitleToolbar: function (oController) {
		return new sap.m.Toolbar({
			content: [
				new sap.m.Title({
					text: {
						parts: ['purchase>/VendName', 'purchase>/Vendor', 'params>/createPOMode'],
						formatter: oController.formatter.getTitle
					}
				}).addStyleClass("oTitle")
			]
		}).addStyleClass("oCustomTlbr whiteBg");
	},
	getSelectDialog: function (oController) {
		var selectDlg = new sap.m.SelectDialog(this.createId('vendorSelectDialog'), {
			title: "{i18n>searchByVendor}",
			confirm: [oController.vendorSelect, oController],
			search: [oController.vendorSearch, oController]
		});

		this.addDependent(selectDlg);
		return selectDlg;
	},
	getPOSelectDialog: function (oController) {
		var selectDlg = new sap.m.SelectDialog(this.createId('vendorPOSelectDialog'), {
			title: "{i18n>selectPO}",
			confirm: [oController.vendorPOSelect, oController],
			liveChange: [oController.vendorPOSearch, oController]
		});
		this.addDependent(selectDlg);
		return selectDlg;
	},
	getHeader: function (oController) {
		var self = this;
		return new sap.m.HBox({
			items: [
				new sap.m.VBox({
					width: "50%",
					items: self.getHeaderLeft(oController)
				}).addStyleClass("oFirstVBox"),
				new sap.m.VBox({
					width: "50%",
					items: self.getHeaderRight(oController)
				})
			]
		}).addStyleClass("oBox whiteBg");
	},
	getHeaderLeft: function (oController) {
		return [
			//normal mode
			new sap.ui.layout.Grid({
				visible: {
					path: 'params>/createPOMode',
					formatter: oController.formatter.createModeOn
				},
				vSpacing: 0,
				hSpacing: 1,
				//defaultSpan: "XL3 L3 M6 S12",
				//defaultIndent: "XL0 L0 M0 S0",
				content: [
					new sap.m.Label({
						text: "{i18n>purchaseorder}:"
					}),
					new sap.m.Input({
						editable: false,
						width: "99%",
						value: "{purchase>/PoNumber}"
					}),
					new sap.m.Label({
						text: "{i18n>documentHeaderTxt}:"
					}),
					new sap.m.Input({
						width: "99%",
						value: "{params>/HeaderText}",
						maxLength: 25
					})
				]
			}).addStyleClass("oFirstGridOne"),
			//normal mode
			new sap.ui.layout.Grid({
				visible: {
					path: 'params>/createPOMode',
					formatter: oController.formatter.createModeOn
				},
				vSpacing: 0,
				hSpacing: 1,
				//defaultSpan: "XL3 L3 M6 S12",
				//defaultIndent: "XL0 L0 M0 S0",
				content: [
					new sap.m.Label({
						text: "{i18n>purchasingroup}:"
					}),
					new sap.m.Input({
						editable: false,
						width: "99%",
						value: "{purchase>/PurGroup}"
					}),
					new sap.m.Label({
						text: "{i18n>purchaser}:"
					}),
					new sap.m.Input({
						editable: false,
						width: "99%",
						value: "{purchase>/Eknam}"
					}),
					new sap.m.Label({
						text: "{i18n>printLabel}:"
					}),
					new sap.m.CheckBox({
						selected: {
							path: 'params>/printLabel',
							formatter: function (value) {
								return value.length > 0 ? true : false;
							}
						},
						select: [oController.handlePrintLabelSelect, oController]
					}).addStyleClass("oHeaderCBox")
				]
			}).addStyleClass("oFirstGridTwo"),
			//create PO mode
			new sap.ui.layout.Grid({
				visible: {
					path: 'params>/createPOMode',
					formatter: oController.formatter.createModeOff
				},
				vSpacing: 0,
				hSpacing: 1,
				content: [
					new sap.m.Label({
						text: "{i18n>vendor}:"
					}).addStyleClass("oCustomLbl"),
					new sap.m.Input(this.createId("oCreatePOVendor"), {
						width: "100%",
						showValueHelp: true,
						valueHelpRequest: [oController.showSelectDialog, oController]
					}),
					new sap.m.Label({
						text: "{i18n>documentHeaderTxt}:"
					}).addStyleClass("oCustomLbl"),
					new sap.m.Input({
						width: "100%",
						value: "{params>/HeaderText}"
					})
				]
			}).addStyleClass("oGridPOMode")
		];
	},
	getHeaderRight: function (oController) {
		return [
			new sap.ui.layout.Grid({
				vSpacing: 0,
				hSpacing: 1,
				//defaultSpan: "XL3 L3 M6 S12",
				//defaultIndent: "XL0 L0 M0 S0",
				content: [
					new sap.m.Label({
						text: "{i18n>deliverynote}:"
					}),
					new sap.m.Input({
						width: "99%",
						value: "{params>/deliveryNote}"
					}),
					new sap.m.Label({
						text: "{i18n>waybill}:"
					}),
					new sap.m.Input({
						width: "99%",
						value: "{params>/waybill}"
					}),
				]
			}).addStyleClass("oGridOne"),
			new sap.ui.layout.Grid({
				vSpacing: 0,
				hSpacing: 1,
				//defaultSpan: "XL3 L3 M6 S12",
				//defaultIndent: "XL0 L0 M0 S0",
				content: [
					new sap.m.Label({
						text: "{i18n>documentdate}:",
						required: true
					}),
					new sap.m.DatePicker(this.createId("oDocDt"), {
						width: "99%",
						dateValue: "{params>/docDate}",
						displayFormat: "dd.MM.yyyy",
						change: [oController.checkValidDate, oController]
					}),
					new sap.m.Label({
						text: "{i18n>postingdate}:",
						required: true
					}),
					new sap.m.DatePicker(this.createId("oPostDt"), {
						width: "99%",
						dateValue: "{params>/postDate}",
						displayFormat: "dd.MM.yyyy",
						change: [oController.checkValidDate, oController]
					})
					
				]
			}).addStyleClass("oGridTwo")
		];
	},
	getFooter: function (oController) {
		return new sap.m.Bar({
			contentLeft: [
				new sap.m.Button({
					text: "{i18n>createPO}",
					press: [oController.createPO, oController]
				})
			],
			contentRight: [
				new sap.m.Button({
					text: "{i18n>cancel}",
					type: "Reject",
					press: [oController.cancel, oController]
				}).addStyleClass("footerbutton"),
				new sap.m.Button({
					text: "{i18n>appTitle}",
					type: "Emphasized",
					press: [oController.postgr, oController]
				}).addStyleClass("footerbutton")
			]
		}).addStyleClass("footerbar");
	},
	getToolbar: function (oController) {
		return new sap.m.Toolbar({
			content: [new sap.m.Label(this.createId("itemsCount"), {
					text: "{i18n>items}"
				}),
				new sap.m.ToolbarSpacer({
					width: "50%"
				}).addStyleClass("sapMTBSpacerFlex"),
				new sap.m.Button(this.createId("cameraBtn"), {
					visible: {
						path: 'params>/',
						formatter: oController.formatter.checkCameraAvailability
					},
					icon: "sap-icon://camera",
					press: [oController.scanBarcode, oController]
				}),
				new sap.m.SearchField(this.createId("matSearch"), {
					width: "30%",
					visible: "{params>/createPOMode}",
					placeholder: "{i18n>enterMaterialId}",
					search: [oController.searchMaterial, oController]
				}),
				new sap.m.Button({
					type: "Transparent",
					icon: "sap-icon://delete",
					press: [oController.deleteRow, oController]
				})
			]
		}).addStyleClass("oTblToolbar whiteBg");
	},
	getTable: function (oController) {
		return new sap.m.Table(this.createId("oTbl"), {
			mode: "MultiSelect",
			select: [oController.tableSelect, oController],
			columns: [new sap.m.Column({
					styleClass: "customColumn",
					width: "30px",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>item}"
					}).addStyleClass("overflowFix")
				}),
				new sap.m.Column({
					width: "15%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>material}"
					})
				}),
				new sap.m.Column({
					visible: {
						path: 'params>/createPOMode',
						formatter: oController.formatter.createModeOn
					},
					width: "6%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>openquantity}"
					})
				}),
				new sap.m.Column({
					width: "15%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					hAlign: "Center",
					header: new sap.m.Label({
						text: "{i18n>deliveredquantity}"
					})
				}),
				new sap.m.Column({
					width: "8%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>unit}"
					})
				}),
				new sap.m.Column({
					width: "12%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>plant}"
					})
				}),
				new sap.m.Column({
					width: "12%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>storagelocation}"
					})
				}),
				new sap.m.Column({
					width: "12%",
					visible: {
						path: 'materials>/',
						formatter: oController.formatter.showIfItemStorbin
					},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>storagebin}"
					})
				}),
				new sap.m.Column({
					width: "6%",
					visible: {
						path: 'materials>/',
						formatter: oController.formatter.showIfItemOrderNumber
					},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>workOrder}"
					})
				}),
				new sap.m.Column({
					width: "10%",
					visible: {
						path: 'materials>/',
						formatter: oController.formatter.hideIfItemCC
					},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>stockcategory}"
					})
				}),
				new sap.m.Column({
					width: "6%",
					visible: {
						path: 'materials>/',
						formatter: oController.formatter.showIfItemCC
					},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>costcenter}"
					})
				}),
				new sap.m.Column({
					width: "6%",
					visible: {
						path: 'materials>/',
						formatter: oController.formatter.checkItemsForVal
					},
					demandPopin: true,
					minScreenWidth: "Tablet",
					header: new sap.m.Label({
						text: "{i18n>valuationType}"
					})
				}),
				new sap.m.Column({
					visible: {
						path: 'params>/createPOMode',
						formatter: oController.formatter.createModeOn
					},
					width: "6%",
					demandPopin: true,
					minScreenWidth: "Tablet",
					styleClass: "oFinalCell",
					header: new sap.m.Label({
						text: "{i18n>finaldelivery}"
					})
				})
			]
		}).addStyleClass("oTbl");
	},
	getTableTmpl: function (oController) {
		return new sap.m.ColumnListItem({
			unread: false,
			cells: [
				new sap.m.Text({
					text: {
						path: 'materials>PoItem',
						formatter: oController.formatter.getLineNumber
					}
				}),
				new sap.m.ObjectIdentifier({
					title: "{materials>MatDesc}",
					text: "{materials>Material}"
				}),
				new sap.m.Text({
					visible: {
						path: 'params>/createPOMode',
						formatter: oController.formatter.createModeOn
					},
					text: {
						parts: ['materials>OpenQtyPo', 'materials>Uom'],
						formatter: oController.formatter.parseQty
					}
				}).addStyleClass("oVerticalMdl"),
				new sap.ui.layout.HorizontalLayout({
					content: [
						new sap.m.Button({
							icon: "sap-icon://less",
							press: [oController.decrease, oController]
						}).addStyleClass("oQuantityActions"),
						new sap.m.Input({
							value: "{materials>DeliveredQuantity}",
							liveChange: [oController.validateQtyField, oController]
						}).addStyleClass("oQuantityActions"),
						new sap.m.Button({
							icon: "sap-icon://add",
							press: [oController.increase, oController]
						}).addStyleClass("oQuantityActions")
					]
				}).addStyleClass("oQuantityBox"),
				new sap.m.Select({
					selectedKey: "{materials>Uom}"
				}).bindAggregation("items", {
					path: "materials>units/",
					template: new sap.ui.core.Item({
						text: "{materials>Unitlangu}",
						key: "{materials>Unitlangu}"
					}),
					templateShareable: true
				}).addStyleClass("oSelectActions"),
				new sap.m.Select({
					selectedKey: "{materials>Plant}",
					change: [oController.plantChange, oController]
				}).bindAggregation("items", {
					path: "materials>plants/",
					template: new sap.ui.core.Item({
						text: "{materials>Name}",
						key: "{materials>Plant}"
					}),
					templateShareable: true
				}).addStyleClass("oSelectActions"),
				new sap.m.Input({
					value: "{materials>StoreLocDesc}",
					showValueHelp: true,
					valueHelpRequest: [oController.showStorageLocations, oController]
				}).addStyleClass("oInputF"),
				new sap.m.Text({
					visible: "{= ${materials>StorageBin}.length > 0 ? true : false}",
					text: "{materials>StorageBin}"
				}),
				new sap.m.Text({
					visible: "{= ${materials>OrderNumber}.length > 0 ? true : false}",
					text: {
						path: 'materials>OrderNumber',
						formatter: oController.formatter.removeLeadingZeros
					}
				}),
				new sap.m.Select({
					visible: "{= ${materials>CostCenter}.length > 0 ? false : true}",
					selectedKey: "{materials>StockCat}"
				}).bindAggregation("items", {
					path: "stockCategories>/",
					template: new sap.ui.core.Item({
						text: "{stockCategories>Dtext}",
						key: "{stockCategories>Dvalue}"
					}),
					templateShareable: true
				}).addStyleClass("oSelectActions"),
				new sap.m.Text({
					visible: "{= ${materials>CostCenter}.length > 0 ? true : false}",
					text: "{materials>CostCenter} {materials>CctrText}"
				}),
				new sap.ui.layout.HorizontalLayout({
					content: [
						new sap.m.Text({
							visible: {
								path: 'materials>ValType',
								formatter: oController.formatter.checkValTypeNoCreateMode
							},
							text: "{materials>ValType}"
						}),
						new sap.m.Select({
							visible: {
								path: 'materials>valTypes',
								formatter: oController.formatter.checkValTypeCreateMode
							},
							selectedKey: "{materials>ValType}"
						}).bindAggregation("items", {
							path: "materials>valTypes/",
							template: new sap.ui.core.Item({
								text: "{materials>ValType}",
								key: "{materials>ValType}"
							}),
							templateShareable: true
						}).addStyleClass("oSelectActions")
					]
				}),
				new sap.m.CheckBox({
					visible: {
						path: 'params>/createPOMode',
						formatter: oController.formatter.createModeOn
					},
					selected: {
						path: 'items>Elikz}',
						formatter: function (value) {
							return value.length > 0 ? true : false;
						}
					},
					select: [oController.handleFinalDelivery, oController]
				})
			]
		}).addStyleClass("oListItem");
	},
	onAfterRendering: function () {
		this.getController().prepareFunc();
	}

});