/*global App:true */
sap.ui.define([
	"com/upm/pw/z_wh_postgr/controller/BaseController",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	'sap/ui/model/json/JSONModel',
	'com/upm/pw/z_wh_postgr/include/formatter',
	'sap/m/MessageBox'
], function(BaseController, Sorter, MessageToast, JSONModel, Formatter, MessageBox) {

	return BaseController.extend("com.upm.pw.z_wh_postgr.controller.App", {
		formatter: Formatter,
		onInit: function() {
			App.view = this;
			this.view = this.getView();
			this.searchField = this.view.byId("oSearchField");
			this.table = this.view.byId("oTbl");
			//vendor select dialog
			this.oVendorSelectDialog = this.view.vendorSelectDialog;
			//PO's of selected vendor select dialog
			this.oVendorPOSelectDialog = this.view.vendorPOselectDialog;
			//store images
			this.images = [];
		},
		handleBack: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			// Navigate back to FLP home
			oCrossAppNavigator.toExternal({
				target : {shellHash: "#Shell-home"}
			});
		},
		onExit: function() {
			console.log("clearing interval")
			if (this.extendingSession)
				clearInterval(this.extendingSession)
		},
		startExtendingSession: function() {
        	this.extendingSession = setInterval(App.sync.checkHostReachableASync, 300000); //refresh last server ping every 5 minutes
        },
		//called after rendering the view
		prepareFunc: function() {
			var self = this;
			jQuery.sap.delayedCall(800, this, function() {
				self.searchField.focus();
				self.refreshItemsCount();
				self.startExtendingSession();
			});
			
		},
		/*
		* Refresh models, table data, material toolbar count
		*
		*/
		refreshModels: function() {
			var self = this;
			var purchase = App.getModel("purchase");
			var materials = App.getModel("materials");
			self.bindTableData();
			self.refreshItemsCount();
			//self.calculateLineNumbers();
			purchase.refresh(true);
			materials.refresh(true);
		},
		checkValidDate: function(oEvent) {
			if (oEvent.getSource().getDateValue()) {
				oEvent.getSource().setValueState("None");
			}
		},
		handlePrintLabelSelect: function(oEvent) {
			var selected = oEvent.getParameter("selected");
			this.getAppModel('params').setProperty('/printLabel', selected ? 'X' : '');
		},
		/*
		* Refresh material items count, shown as Items (1 of 1)
		*/
		refreshItemsCount: function() {
			var itemsCountTitle = this.view.byId("itemsCount");
			var items = App.getModel("materials").getProperty("/");
			var table = this.view.byId("oTbl");
			var itemsSelected = table.getSelectedItems();
			if (itemsSelected.length > 0) {
				itemsCountTitle.setText(App.getTran("itemsCount", [itemsSelected.length, items.length]))
			} else {
				itemsCountTitle.setText(App.getTran("itemsCount", [items.length, items.length]))
			}
		},
		//Vendor select dialog
		showSelectDialog: function() {
			var self = this;
			var selectDialog = this.oVendorSelectDialog;
			selectDialog.open();
			App.getModel("vendors").setData([]);
		},
		//bind vendor data to select list
		bindVendorSelectDialogData: function(dataType) {
			var self = this;
			var selectDialog = this.oVendorSelectDialog;
			var vendorModel = App.getModel("vendors");
		
			var	oListItem = new sap.m.StandardListItem({
				title: "{vendors>Mcod1}",
				description: "{vendors>Lifnr}"
			}).data({
				"Lifnr": "{vendors>Lifnr}"
			});
			
			selectDialog.bindAggregation("items", "vendors>/", oListItem);
			vendorModel.refresh(true);
		},
		//bind Purchase orders data for vendor
		bindVendorPOSelectDialogData: function() {
			var self = this;
			var selectDialog = this.oVendorPOSelectDialog;
			var vendorPOModel = App.getModel("vendorPOs");
			var listItem = new sap.m.StandardListItem({
				title: "{vendorPOs>PoNumber}",
				description: "{path: 'vendorPOs>DocDate', formatter: 'App.formatter.toShortDate'}"
			}).data({
				"PoNumber": "{vendorPOs>PoNumber}"
			});
			
			selectDialog.bindAggregation("items", "vendorPOs>/", listItem);
			vendorPOModel.refresh(true);
		},
		// search PO, if we have materials in list we will show a prompt dialog before making request to SAP
		POSearch: function(oEvent) {
			var self = this;
			var value = oEvent.getParameter("query");
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			var valid = false;
			if (value.length == 0)
				return;
			
			var pann = /^[0-9+]*$/;
			if (!pann.test(value) || value.length > 10) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("valueError"));
				self.searchField.setValue("");
				jQuery.sap.delayedCall(500, this, function() {self.searchField.focus();})
				return;
			}
			function search() {
				App.sync.getPO(value).done(function(response) {
					self.handlePOData(response);
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						self.searchField.setValue("");
						jQuery.sap.delayedCall(500, self, function() { self.searchField.focus(); });
					});
				});
			}
			if (materials.length > 0) {
				this.showDeleteDialog("Warning", 
					App.getTran("warning"),
					App.getTran("materialsWillRemove"),
					function(dialog) {
						dialog.close();
						valid = true;
						search();
					},
					function(dialog) {
						dialog.close();
					}
				);
			} else {
				valid = true;
			}
			
			if (valid) {
				search();
			}
			
		},
		// process the data returned from POSearch function
		handlePOData: function(PO) {
			var self = this;
			var params = App.getModel("params");
			var poModel = App.getModel("purchase");
			var materialModel = App.getModel("materials");
			var plantModel = App.getModel("plants");
			var plants = plantModel.getProperty("/");
			poModel.setData(PO);
			params.setProperty("/HeaderText", PO.HeaderText);
			var poItems = PO.NavFromGrAndPoHdrToItemDetails.results;
			var ids = [];
			//process po items and push material ids to separate array
			//we need to get material information from SAP, one by one
			for (var i in poItems) {
				var item = poItems[i];
				item.units = [];
				item.storlocs = [];
				item.valTypes = [];
				item.plants = plants;
				if (item.Material)
					ids.push(item.Material);
				else {
					if (item.Uom) {
						item.units.push({
							Unitlangu: item.Uom
						});
					}
					
				}
			}

			var send = function() {
				if (!ids.length) return;
				
				var len = 1;
				var materialId = ids.slice(0, len)[0];
				ids.splice(0, len);
				
				App.sync.getMaterial(materialId).done(function(response) {
					if (poItems.length > 0) {
						for (var ii in poItems) {
							var poItem = poItems[ii];
							// !items.units.length is used because we want to push units and storage locations to all items (even if we have duplicate materials)
							if (poItem.Material == response.Matnr && !poItem.units.length) {
								var stglocs = [];
								for (var iii in response.NavMaterialToSloc.results) {
									var storloc = response.NavMaterialToSloc.results[iii];
									if (poItem.Plant == storloc.Plant) {
										stglocs.push({
											Name: self.formatter.getPlant(storloc.Plant),
											Plant: storloc.Plant,
											Lgort: storloc.Storloc,
											StoreLocDesc: storloc.StoreLocDesc
										});
									}
									
								}
								poItem.storlocs = stglocs;
								poItem.units = response.NavMaterialToUom.results;
								//get only valuation type to selected plant
								poItem.valTypes = response.NavMaterialToValType.results.filter(function(oIt) {
									return oIt.Plant == poItem.Plant;
								});
							}
						}
					}

					if (ids.length > 0) {
						send();
					} else {
						materialModel.setData(poItems);
						self.refreshModels();
					}
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						
					});
				});
			};
			//get material item data one by one
			if (ids.length > 0) {
				send();
			} else {
				materialModel.setData(poItems);
			}
			self.refreshModels();
		},
		//selecting vendor, fetch purchase orders for that vendor
		vendorSelect: function(oEvent) {
			var self = this;
			var paramModel = App.getModel("params");
			var selectedVendor = oEvent.getParameter("selectedItem");
			var vendorName = selectedVendor.getTitle();
			var vendorId = selectedVendor.getCustomData()[0].getValue();
			// if are in create purchase mode then no need to fetch PO's
			if (paramModel.getProperty("/createPOMode")) {
				this.getView().byId("oCreatePOVendor").setValue(vendorName);
				paramModel.setProperty("/POModeVendor", vendorId);
			} else {
				var model = App.getModel("vendorPOs");
				
				App.sync.getVendorPOs(vendorId).done(function(response) {
					model.setData(response.results);
					self.showVendorPOSelectDialog();
					self.bindVendorPOSelectDialogData();
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
					
					});
				});
			}
		},
		// search vendor by name from SAP
		vendorSearch: function(oEvent) {
			var self = this;
			var model = App.getModel("vendors");
			var value = oEvent.getParameter("value");
			if (value.length == 0)
				return;
			
			if (value.length > 25) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("longValue"));
				return;
			}
			value = value.toUpperCase();
			var isNumeric = $.isNumeric(value);
			App.sync.getVendors(value, isNumeric).done(function(response) {
				model.setData(response.results);
				self.bindVendorSelectDialogData();
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
		},
		showVendorPOSelectDialog: function() {
			var self = this;
			var selectDialog = this.oVendorPOSelectDialog;
			selectDialog.open();
			if (selectDialog.getBinding("items"))
				selectDialog.getBinding("items").filter([]);
		},
		//PO selected, call handlePOData function
		vendorPOSelect: function(oEvent) {
			var self = this;
			var selectedVendorPO = oEvent.getParameter("selectedItem");
			var vendorName = selectedVendorPO.getTitle();
			var vendorPO = selectedVendorPO.getCustomData()[0].getValue();
			
			App.sync.getPO(vendorPO).done(function(response) {
				self.handlePOData(response);
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
		},
		//filter PO's
		vendorPOSearch: function(oEvent) {
			var self = this;
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("PoNumber", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		//bind material data to table
		bindTableData: function() {
			var self = this;
			var table = this.view.byId("oTbl");
			table.bindAggregation("items", {
				path: "materials>/",
				template: this.view.getTableTmpl(self)
			});
			table.removeSelections();
		},
		// handle image uploading, 5 is limit
		// selecting image puts that attachment to sap.m.Token and clicking that opens image in dialog
		addPhoto: function(oController) {
			var self = this;
			var container = this.view.byId("oPhotoContainer");
			var amount = container.getContent().length + 1;
			
			if (container.getContent().length >=5) {
				MessageToast.show(App.getTran("imageLimit"));
			} else {
				var hiddenInput = document.getElementById('hiddenInput');
				var input = $('#hiddenInput');
				input.unbind();
				input.change(function(e) {
					self.getImageDataResize(this, 480, amount, function(imageData, name, type) {
						input.replaceWith(input.val('').clone(true));
						self.images.push({
							Filedata: imageData, 
							Filename: name,
							Filetype: type
						});
						var token = new sap.m.Token({
							text: name,
							press: function() {
								var dialog = new sap.m.Dialog({
									showHeader: false,
									contentWidth: "5em",
									contentHeight: "14em",
									content: new sap.m.Image({
										src: imageData,
										width: "100%",
										height: "224px"
									}),
									beginButton: new sap.m.Button({
										text: App.getTran("close"),
										press: function() {
											dialog.close();
										}
									})
								}).addStyleClass("oImgDialog");
								dialog.open();
							},
							"delete": function(oEvent) {
								var index = self.images.findIndex(function(item, i) {
									return item.name == name;
								});
								self.images.splice(index, 1);
								oEvent.getSource().destroy();
							}
						}).data({
							"img": imageData
						});
						container.addContent(token);
					});
				});
				hiddenInput.click();
			}
		},
		validateQtyField: function(oEvent) {
			var input = oEvent.getSource();
        	var value = oEvent.getParameter("value");
        	var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
        	var model = App.getModel('materials');
			function setValueForItem(val) {
    			item.DeliveredQuantity = val.replace(/,/, '.');
    			model.refresh(true);
    		}
    		var reg = new RegExp('^[0-9]{1,2}([,.][0-9]{1,2})?$');
    		if (!reg.test(value)) {
    			var replacedValue = value.replace(/[^0-9,.]/, '');
    			input.setValue(replacedValue);
    			setValueForItem(replacedValue);
    		} else {
    			setValueForItem(value);
    		}
		},
		//increase quantity on item level
		increase: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue()
			var context = oEvent.getSource().getParent().getBindingContext("materials");
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			var paramModel = App.getModel("params");
			var createPOMode = paramModel.getProperty("/createPOMode");
			var openQty = parseInt(item.OpenQtyPo);
			var deliveredQty = (parseInt(item.DeliveredQuantity) || 0);
			if (((deliveredQty + 1) <= openQty) || createPOMode) {
				item.DeliveredQuantity = parseInt(value) || 0;
				item.DeliveredQuantity++;
				model.refresh(true);
			}
		},
		//decrease quantity on item level
		decrease: function(oEvent) {
			var model = App.getModel("materials");
			var input = oEvent.getSource().getParent().getContent()[1];
			var value = input.getValue();
			var context = oEvent.getSource().getParent().getBindingContext("materials");
			var item = oEvent.getSource().getParent().getBindingContext("materials").getObject();
			item.DeliveredQuantity = parseInt(value) || 0;
			if (item.DeliveredQuantity > 0) {
				item.DeliveredQuantity--;
				model.refresh(true);
			}
		},
		//create Purchase order clicked, remove data and initialize barcode scanning by camera
		//render table again in case columns changed
		//show vendor select dialog
		createPO: function(oEvent) {
			var self = this;
			this.showPromptDialog("None", App.getTran("confirm"), App.getTran("createNewPo"), App.getTran("yes"), App.getTran("cancel"), function() {
				self.resetData(true, false);
				self.table.rerender();
				self.showSelectDialog();
				self.initBarcodeScanning(function() {
					App.getModel("params").refresh(true);
				});
				
			}, function() {
				
			});
		},
		//reset button in footer
		cancel: function(oEvent) {
			this.resetData(false, true);
		},
		//changing plant in item level gets new storage locations, valuation types for selected plant
		plantChange: function(oEvent) {
			var self = this;
			var model = App.getModel("materials");
			var materialItems = model.getProperty("/");
			var context = oEvent.getSource().getBindingContext("materials");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			if (!item.Material) return;
			App.sync.getMaterial(item.Material).done(function(response) {
				var storlocs = [];
				for (var i in response.NavMaterialToSloc.results) {
					var storloc = response.NavMaterialToSloc.results[i];
					if (storloc.Plant == item.Plant) {
						storlocs.push({
							Name: storloc.StoreLocDesc,
							Plant: storloc.Plant,
							Lgort: storloc.Storloc,
							StoreLocDesc: storloc.StoreLocDesc
						});
					}
				}
				item.storlocs = storlocs;
				item.StoreLoc = storlocs.length > 0 ? storlocs[0].Lgort : "";
				item.StoreLocDesc = storlocs.length > 0 ? storlocs[0].StoreLocDesc : "";
				item.valTypes = response.NavMaterialToValType.results.filter(function(oIt) {
					return oIt.Plant == item.Plant;
				});
				model.refresh(true);
			}).fail(function(e) {
				self.showMessageDialog('Error', e.title, "", e.message, function() {
				
				});
			});
		},
		/*
		* PO validation before submitting
		*/
		validPO: function(callback) {
			var self = this;
			var view = this.getView();
			var paramModel = App.getModel("params");
			var createPOMode = paramModel.getProperty("/createPOMode");
			var materialModel = App.getModel("materials");
			var materials = materialModel.getProperty("/");
			var docDt = view.byId("oDocDt");
			var postDt = view.byId("oPostDt");
			var msgToast = sap.m.MessageToast;
			//document date
			if (!docDt.getDateValue()) {
				docDt.setValueState("Error");
				docDt.setValueStateText(App.getTran("dateMissing"));
				docDt.focus();
				return false;
			}
			//posting date
			if (!postDt.getDateValue()) {
				postDt.setValueState("Error");
				postDt.setValueStateText(App.getTran("dateMissing"));
				postDt.focus();
				return false;
			}
			
			if (!materials.length) {
				msgToast.show(App.getTran("materialsMissing"));
				return false;
			}
			var matValid = false;
			if (materials.length > 0) {
				var err = "";
				for (var i in materials) {
					var mat = materials[i];
					if (mat.DeliveredQuantity &&
						mat.DeliveredQuantity.toString().replace(/,/, '.') > 0 && (mat.OrderNumber || mat.CostCenter)) { 
						matValid = true;
						continue; 
					}
					if (mat.DeliveredQuantity &&
						mat.DeliveredQuantity.toString().replace(/,/, '.') > 0 &&
						mat.StoreLoc.length > 0) {
							//in normal mode we need to validate also quantities that its not bigger than open quantity
							if (!createPOMode) {
								//if (parseInt(mat.DeliveredQuantity) > parseInt(mat.OpenQtyPo)) {
								//	err = App.getTran("rowValueHigherThanOpen", [parseInt(mat.PoItem)]);
								//	matValid = false;
								//	break;
								//} else {
									matValid = true;
								//}
							} else {
								matValid = true;
							}
					} else {
						err = App.getTran("checkMaterials");
						matValid = false;
						break;
					}
				}
				if (!matValid) {
					msgToast.show(err);
					return false;
				}
			} else {
				return false;
			}
			
			docDt.setValueState("None");
			postDt.setValueState("None");
			this.showPromptDialog(
				"Warning",
				App.getTran("warning"),
				App.getTran("postPrompt"),
				App.getTran("yes"),
				App.getTran("cancel"),
				function() {
					callback();
				}, 
				function() {
					return false;
				}
			);
		},
		/*
		* post goods receipt to SAP
		*/
		postgr: function(oEvent) {
			var self = this;
			var paramModel = App.getModel("params");
			var purchaseModel = App.getModel("purchase");
			var materialModel = App.getModel("materials");
			self.validPO(function() {
				var poItems = materialModel.getProperty("/");
				//images
				var images = self.images;
				//header data
				var dataToSend = {
					Vendor: (paramModel.getProperty("/POModeVendor") || ''),
					PoNumber: (purchaseModel.getProperty("/PoNumber") || ''),
					Lfsnr: paramModel.getProperty("/deliveryNote"),
					Frbnr: paramModel.getProperty("/waybill"),
					Postdate: App.formatter.toSAPDT(paramModel.getProperty("/postDate")),
					Docdate: App.formatter.toSAPDT(paramModel.getProperty("/docDate")),
					HeaderText: (paramModel.getProperty("/HeaderText") || ''),
					PrintLabel:(paramModel.getProperty("/printLabel") || ''),
					NavFromGrAndPoHdrToItemDetails: []
				};
				//get PO items
				for (var i in poItems) {
					var item = poItems[i];
					dataToSend.NavFromGrAndPoHdrToItemDetails.push({
						Elikz: (item.Elikz || ''),
						Material: item.Material,
						MatDesc: item.MatDesc,
						OpenQtyPo: item.DeliveredQuantity.toString(),
						Plant: item.Plant,
						PoItem: item.PoItem,
						PoNumber: (item.PoNumber || ''),
						StockCat: item.StockCat,
						StoreLoc: item.StoreLoc,
						StoreLocDesc: item.StoreLocDesc,
						Uom: item.Uom,
						ValType: item.ValType,
						CostCenter: (item.CostCenter || ''),
						OrderNumber: (item.OrderNumber || ''),
						StorageBin: (item.StorageBin || '')
					});
				}
				//postgr
				App.sync.postGR(dataToSend).done(function(response) {
					//if we have images attached then we trigger image sending otherwise show success dialog
					if (!images.length) {
						self.showMessageDialog("Success", App.getTran("success"), "", App.getTran("poCreated", [response.MatDoc]), function() {
							self.resetData(false, false);
						});
					} else {
						self.sendImages(images, response);
					}
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
					
					});
				});
			});
		},
		/*
		* Image sending to SAP, one by one
		*/
		sendImages: function(images, poData) {
			var self = this;
			var send = function() {
				if (!images.length) return;
				
				var len = 1;
				var imgToSend = images.slice(0, len)[0];
				images.splice(0, len);
				var filename = imgToSend.Filename;
				imgToSend.DocYear = poData.DocYear;
				imgToSend.MatDoc = poData.MatDoc;
				imgToSend.Filedata = imgToSend.Filedata.split(",")[1];
				imgToSend.Filename = imgToSend.Filename.split(".")[0];
				imgToSend.Filetype = filename.split(".")[1];
		
				if (imgToSend.Filetype == 'jpeg')
					imgToSend.Filetype = 'jpg';
				
				App.sync.sendImage(imgToSend).done(function(response) {
					if (images.length > 0) {
						send();
					} else {
						self.showMessageDialog("Success", App.getTran("success"), "", App.getTran("poCreated", [poData.MatDoc]), function() {
							self.resetData(false, false);
						});
					}
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
					
					});
				});
			};
			if (images.length > 0)
				send();
		},
		//show storage locations select dialog
		showStorageLocations: function(oEvent) {
			var self = this;
			var model = App.getModel("materials");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			var storlocs = oEvent.getSource().getBindingContext("materials").getProperty("storlocs");
			var selectDlg = new sap.m.SelectDialog({
				title: App.getTran("selectStgLoc"),
				confirm: function(oDlgEvent) {
					var selected = oDlgEvent.getParameter("selectedItem").getBindingContext().getObject();
					item.StoreLoc = selected.Lgort;
					item.StoreLocDesc = selected.StoreLocDesc;
					model.refresh(true);
				},
				liveChange: [self.stgLocSearch, self]
			});
			
			var	oListItem = new sap.m.StandardListItem({
				title: "{StoreLocDesc}",
				description: "{Lgort}"
			}).data({
				"material": "{Lgort}"
			});
			selectDlg.setModel(new JSONModel(storlocs));
			selectDlg.bindAggregation("items", "/", oListItem);
			
			selectDlg.open();
			if (selectDlg.getBinding("items"))
				selectDlg.getBinding("items").filter([]);
		},
		//storage location search
		stgLocSearch: function(oEvent) {
			var query = oEvent.getParameter("value");
			var binding = oEvent.getSource().getBinding("items");
			binding.filter(!query ? [] : [
				new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Lgort", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("StoreLocDesc", sap.ui.model.FilterOperator.Contains, query)
					],
					false)
			]);
		},
		//final delivery checkbox on item level
		handleFinalDelivery: function(oEvent) {
			var selected = oEvent.getParameter("selected");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			item.Elikz = selected ? "X" : "";
		},
		//selecting table items updates toolbar header like Items (1 of 2)
		tableSelect: function() {
			this.refreshItemsCount();	
		},
		/*
		* validate quantity, cannot be bigger than openquantity in normal mode, where we process PO
		**/
		checkQuantity: function(oEvent) {
			var self = this;
			var params = App.getModel("params");
			var createPOMode = params.getProperty("/createPOMode");
			var item = oEvent.getSource().getBindingContext("materials").getObject();
			var input = oEvent.getSource();
			var value = oEvent.getParameter("value");
			var pann = /^[0-9+]*$/;
			if (!pann.test(value)) {
				input.setValue("");
				jQuery.sap.delayedCall(500, self, function() {input.focus(); });
				return false;
			}
			
			if (!createPOMode) {
				var openQty = parseInt(item.OpenQtyPo);
				var deliveredQty = parseInt(value);
				if (deliveredQty > openQty) {
					input.setValueState("Error");
					input.setValueStateText(App.getTran("valueHigherThanOpen"));
				} else {
					input.setValueState("None");
				}
			}
		},
		/*
		* Search materials and put them do list
		* for existing materials increase DeliveredQuantity
		*
		*/
		searchMaterial: function(oEvent) {
			var self = this;
			var view = this.getView();
			var materialModel = App.getModel("materials");
			var materialItems = materialModel.getProperty("/");
			var params = App.getModel("params");
			var createPOMode = params.getProperty("/createPOMode");
			
			var value = oEvent.getParameter("query");
			var input = oEvent.getSource();
			if (value.length == 0)
				return;
			
			var pann = /^[0-9+]*$/;
			if (!pann.test(value) || value.length > 18) {
				self.showMessageDialog("Error", App.getTran("error"), "", App.getTran("valueError"));
				input.setValue("");
				jQuery.sap.delayedCall(500, this, function() {input.focus(); });
				return;
			}
			var index = materialItems.findIndex(function(item, i) {
				return item.Material == value;
			});
			if (index > -1) {
				var obj = materialItems[index];
				obj.DeliveredQuantity = (parseInt(obj.DeliveredQuantity) + 1);
				input.setValue("");
				self.refreshModels();
				self.calculateLineNumbers();
				jQuery.sap.delayedCall(500, self, function() {input.focus(); });
			} else {
				App.sync.getMaterial(value).done(function(response) {
					if (createPOMode && response.NoPoFromGr.length > 0) {
						self.showMessageDialog('Error', App.getTran("error"), "", App.getTran("materialNotAllowed"), function() {
							input.setValue("");
							jQuery.sap.delayedCall(500, self, function() {input.focus(); });
						});
						return false;
					}
					
					var storlocs = [];
					var uoms = response.NavMaterialToUom.results;
					for (var i in response.NavMaterialToSloc.results) {
						var storloc = response.NavMaterialToSloc.results[i];
						storlocs.push({
							Name: self.formatter.getPlant(storloc.Plant),
							Plant: storloc.Plant,
							Lgort: storloc.Storloc,
							StoreLocDesc: storloc.StoreLocDesc
						});
					}
					
					var plant = storlocs.length > 0 ? storlocs[0].Plant : "";
					var valTypes = response.NavMaterialToValType.results.filter(function(oIt) {
						return oIt.Plant == plant;
					});
					materialItems.push({
						PoItem: materialItems.length + 1,
						Material: response.Matnr,
						MatDesc: response.Maktx,
						Plant: storlocs.length > 0 ? storlocs[0].Plant : "",
						StoreLoc: storlocs.length > 0 ? storlocs[0].Lgort : "",
						StoreLocDesc: storlocs.length > 0 ? storlocs[0].StoreLocDesc : "",
						StockCat: "",
						DeliveredQuantity: 1,
						StgeLoc: "",
						storlocs: storlocs,
						units: uoms,
						ValType: (createPOMode ? valTypes.length > 0 ? valTypes[0].ValType : "" : ""),
						plants: storlocs,
						valTypes: valTypes,
						UoM: uoms.length > 0 ? uoms[0].Unitlangu : '',
						OrderNumber: '',
						CostCenter: '',
						StorageBin: ''
					});
				
					input.setValue("");
					self.refreshModels();
					self.calculateLineNumbers();
					jQuery.sap.delayedCall(500, self, function() {input.focus(); });
				}).fail(function(e) {
					self.showMessageDialog('Error', e.title, "", e.message, function() {
						input.setValue("");
						jQuery.sap.delayedCall(500, self, function() {input.focus(); });
					});
				});
			}
		},
		// delete selected material rows
		deleteRow: function(oEvent) {
			var self = this;
			var paths = self.table.getSelectedContextPaths();
			var model = App.getModel("materials");
			var items = model.getProperty("/");
			if (paths.length > 0) {
				var rowsToRemove = [];
				for (var i in paths) {
					rowsToRemove.push(paths[i].split("/")[1]);
				}
				rowsToRemove.sort(function(a, b) {
					return parseInt(a) > parseInt(b) ? -1 : parseInt(b) < parseInt(a) ? 1 : 0;
				});
				for (var ii = 0; ii < rowsToRemove.length; ii++) {
					var index = rowsToRemove[ii];
					items.splice(index, 1);
				}
				model.refresh(true);
				self.table.removeSelections();
				self.refreshModels();
			}
		},
		/*
		* Reset view when clicking cancel button
		* Reset view when GR has been posted successfully
		* {poMode} determines are we creating new PO or handling existing one and UI changes depending on it
		* {showPrompt} determines if prompt before resetting is shown
		*/
		resetData: function(poMode, showPrompt) {
			var self = this;
			var paramModel = App.getModel("params");
			var poModel = App.getModel("purchase");
			var materialModel = App.getModel("materials");
			var unitModel = App.getModel("units");
			var storLocModel = App.getModel("storlocs");
			var vendorModel = App.getModel("vendors");
			var vendorPOModel = App.getModel("vendorPOs");
			var barcodeScannedEnabled = paramModel.getProperty("/barcodeScanEnabled");
			function reset() {
				paramModel.setData({
		        	"createPOMode": poMode,
		        	"deliveryNote": "",
		        	"waybill": "",
		        	"docDate": new Date(),
		        	"postDate": new Date(),
		        	"POModeVendor": "",
		        	"barcodeScanEnabled": barcodeScannedEnabled,
		        	"HeaderText": "",
		        	"printLabel": ""
		        });
		        poModel.setData({});
		        materialModel.setData([]);
		        unitModel.setData({});
		        storLocModel.setData({});
		        vendorModel.setData([]);
		        vendorPOModel.setData([]);
		        self.images = [];
		        self.view.byId("oPhotoContainer").destroyContent();
		        self.searchField.setValue("");
		        self.refreshModels();
			}
			
			if (showPrompt) {
				this.showPromptDialog(
					"Warning",
					App.getTran("resetData"),
					App.getTran("resetPrompt"),
					App.getTran("yes"),
					App.getTran("no"),
					function() {
						reset();
					}, 
					function() {
						
					}
				);
			} else {
				reset();
			}
			
		},
		// scan barcode with camera in create purchase order mode, opens dialog where you can scan barcodes
		// using QuaggaJS libarary
		// https://serratus.github.io/quaggaJS/
		scanBarcode: function(oEvent) {
			var self = this;
			if (!this._oScanDialog) {
				this._oScanDialog = new sap.m.Dialog({
					title: "{i18n>scanBarcode}",
					contentWidth: "640px",
					contentHeight: "480px",
					horizontalScrolling: false,
					verticalScrolling: false,
					stretchOnPhone: true,
					content	: [new sap.ui.core.HTML({
						id: this.createId("scanContainer"),
						content: "<div />"
					}).addStyleClass("scanContainer")],
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function(oEvent) {
							this._oScanDialog.close();
						}.bind(this)
					}),
					afterOpen: function() {
						this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function() {
							// Initialisation done, start Quagga
							Quagga.start();
						}).fail(function(oError) {
							MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name),{
								onClose: function() {
									this._oScanDialog.close();
								}.bind(this)
							});
						}.bind(this));
					}.bind(this),
					afterClose: function() {
						// Dialog closed, stop Quagga
						Quagga.stop();
					}
				}).addStyleClass("cameraDialog");
				
				this.getView().addDependent(this._oScanDialog);
			}
			this._oScanDialog.open();
		},
		//this initializes quaggaJS and when it detects barcode it runs Quagga.onDetected function
		//and searches that material ID from SAP
		_initQuagga: function(oTarget) {
			var self = this;
			var oDeferred = jQuery.Deferred();
			
			Quagga.init({
				inputStream: {
					type: "LiveStream",
					target: oTarget,
					constraints: {
						width: {min: 640},
	            		height: {min: 480},
						facingMode: "environment"
					}
				},
				locator: {
					patchSize: "medium",
					halfSample: true
				},
				numOfWorkers: 4,
				frequency: 10,
				//currectly we look only for CODE128 and EAN bar codes
				decoder	: {
					readers : [{
						format: "code_128_reader",
						config: {}
					}, {
						format: "ean_reader",
						config: {}
					}]
				},
				locate: true
			}, function(error) {
				if (error) {
					oDeferred.reject(error);
				} else {
					oDeferred.resolve();
				}
			});
			
			if(!this._oQuaggaEventHandlersAttached) {
				// Attach event handlers...
	
				Quagga.onProcessed(function(result) {
					var drawingCtx = Quagga.canvas.ctx.overlay,
						drawingCanvas = Quagga.canvas.dom.overlay;
					
					if (result) {
						// The following will attempt to draw boxes around detected barcodes
						if (result.boxes) {
							drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
							result.boxes.filter(function (box) {
								return box !== result.box;
							}).forEach(function (box) {
								Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
							});
						}
						
						if (result.box) {
							Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "#00F", lineWidth: 2});
						}
						
						if (result.codeResult && result.codeResult.code) {
							Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
						}
					}
				}.bind(this));
				// barcode detected
				Quagga.onDetected(function(result) {
					App.view.byId("matSearch").setValue(result.codeResult.code)
					this._oScanDialog.close();
					App.view.byId("matSearch").fireSearch({query: result.codeResult.code});
					Quagga.stop();
				}.bind(this));
				// Set flag so that event handlers are only attached once...
				this._oQuaggaEventHandlersAttached = true;
			}
			
			return oDeferred.promise();
		}
		
	});
});