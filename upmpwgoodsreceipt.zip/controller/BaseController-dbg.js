sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'com/upm/pw/z_wh_postgr/include/formatter',
    'sap/ui/core/BusyIndicator',
    'sap/ui/model/json/JSONModel',
    'sap/m/Dialog'
], function(Controller, Formatter, BusyIndicator, JSONModel, Dialog) {
    return Controller.extend("com.upm.pw.z_wh_postgr.controller.BaseController", {
        formatter: Formatter,
        showMessageDialog: function(state, title, icon, message, callback) {
        		var dialog = new Dialog({
        			state: state,
        			title: title,
        			icon: icon,
        			content: new sap.m.Text({text: message}),
        			beginButton: new sap.m.Button({
        				text: App.getTran("close"),
        				press: function() {
        					dialog.close();
        					if (callback)
        						callback();
        					
        				}
        			})
        		}).addStyleClass("oMsgDialog");
        		dialog.open();
        },
        showPromptDialog: function(state, title, message, beginButtonText, endButtonText, callback1, callback2) {
        		var dialog = new Dialog({
        			state: state,
        			title: title,
        			content: new sap.m.Text({text: message}),
        			beginButton: new sap.m.Button({
        				text: beginButtonText,
        				press: function() {
        					dialog.close();
        					if (callback1)
        						callback1();
        					
        				}
        			}),
        			endButton: new sap.m.Button({
        				text: endButtonText,
        				press: function() {
        					dialog.close();
        					if (callback2)
        						callback2();
        				}
        			})
        		}).addStyleClass("oMsgDialog");
        		dialog.open();
        },
    	showDeleteDialog: function(state, title, text, handleRemove, cancel) {
    		var oDialog = new sap.m.Dialog({
    			state: state,
    			title: title,
    			content: [new sap.m.Text({
    				text: text
    			})],
    			buttons: [new sap.m.Button({
    				text: App.getTran("yes"),
    				press: function() {
    					if (handleRemove)
    						handleRemove(oDialog);
    				}
    			}), new sap.m.Button({
    				text: App.getTran("no"),
    				press: function() {
    					oDialog.close();
    					if (cancel)
    						cancel(oDialog);
    				}
    			})]
    		}).addStyleClass("oDialogContent");
    		
    		oDialog.open();	
    	},
    	//resize image and get Base64 image
    	getImageDataResize: function(elem, maxSize, imgName, callback) {
			var maxSize = 1280; // maxSize is overriden here
			var quality = 0.75;

			var file = elem.files ? elem.files[0] : false;

			if (file) {
				var name = file.name;
				var splitted = name.split(".");
				name = imgName + "." + splitted[splitted.length - 1];
				var reader = new FileReader();
				reader.onloadend = function(e) {
					var image = new Image();
					image.src = reader.result;
					image.onload = function() {

						var bigRatio = 1.0;
						if (image.width > maxSize || image.height > maxSize)
							bigRatio = image.width > image.height ? maxSize / image.width : maxSize / image.height;

						var newWidth = Math.round(image.width * bigRatio);
						var newHeight = Math.round(image.height * bigRatio);
						var canvas = document.createElement('canvas');

						canvas.width = newWidth;
						canvas.height = newHeight;

						var ctx = canvas.getContext("2d");
						ctx.drawImage(this, 0, 0, newWidth, newHeight);
						var fileData = canvas.toDataURL(file.type, quality);

						if (callback) callback(fileData, name, file.type);
						delete image;
						delete canvas;
					};
				};
				reader.readAsDataURL(file);
			}
		},
		calculateLineNumbers: function() {
    		var model = this.getView().getModel("materials");
			var items = model.getProperty("/");
			
			if (!items.length)
				return;
			
			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				item.PoItem = (parseInt(i) === 0 ? "10" : parseInt(i) === 1 ? "20" : parseInt(i) + 1 + "0");
			}
			model.refresh(true);
    	},
    	initBarcodeScanning: function(callback) {
    		if(navigator && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
				navigator.mediaDevices.getUserMedia({video:true}).then(function(stream) {
					App.getModel("params").setProperty("/barcodeScanEnabled", true);
					if (callback) callback();
				}).catch(function(err) {
					console.log("error getting mediadevice", err);
				});
			}
    	},
    	getAppModel: function(model) {
    		return this.getOwnerComponent().getModel(model);
    	}

    });
});