sap.ui.define([
	'com/upm/upmrcpqualityapp/controller/CommonController',
	'com/upm/upmrcpqualityapp/model/Config'
], function(CommonController, ConfigModel) {
	return CommonController.extend('com.upm.upmrcpqualityapp.controller.Root', {

		onInit: function() {
			this.rootControl = this.byId('rootControl');
            this.getMyComponent().setModel(new ConfigModel(), 'Config')
		},

		hideMaster: function() {
			this.rootControl.setMode(sap.m.SplitAppMode.HideMode);
		},

		showMaster: function() {
			this.rootControl.setMode(sap.m.SplitAppMode.ShowHideMode);
		},

		afterNavigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'afterNavigate', {
				fromView: navigationEvent.getParameter('to').sViewName,
				toView: navigationEvent.getParameter('from').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		},

		navigate: function(navigationEvent) {
			this.getMyComponent().getEventBus().publish('app', 'navigate', {
				fromView: navigationEvent.getParameter('from').sViewName,
				toView: navigationEvent.getParameter('to').sViewName,
				directionIsBackWards: navigationEvent.getParameter('isBackToPage')
			});
		}

	});
});