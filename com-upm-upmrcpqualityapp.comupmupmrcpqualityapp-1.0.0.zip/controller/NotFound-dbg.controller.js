sap.ui.define([
	'com/upm/upmrcpqualityapp/controller/BaseController'

], function(BaseController) {
	'use strict';
	return BaseController.extend('com.upm.upmrcpqualityapp.controller.NotFound', {
		onInit: function() {}
	});
});