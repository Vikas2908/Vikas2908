sap.ui.define([
	'com/upm/upmrcpqualityapp/controller/CommonController',
	'com/upm/upmrcpqualityapp/controller/BaseController'
], function (CommonController, BaseController) {
	return CommonController.extend('com.upm.upmrcpqualityapp.controller.UsageDecision', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function () {
			BaseController.prototype.onInit.apply(this, arguments);

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'navigate', this.handleNavigate.bind(this));

			this.setModel('UsageDecisionViewModel');
		},

		routeMatched: function (navigationEvent) {
			if (navigationEvent.getParameter('name') === 'UsageDecision') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				var args = navigationEvent.getParameter('arguments');
				if (sap.ui.Device.system.phone) {
					this.getElementById('udUploadImageButton').setText('');
				}

				if (args.key === 'FromMainView') {
					this.getElementById('acceptWithoutQualCheckButton').setVisible(true);
					this.visibleButtons(false);
					this.getElementById('usageDecisionVBox').setVisible(false);
					if (sap.ui.Device.system.phone) {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITHOUT_QUALITY_CHECK_FOR_MOBILE'));
					} else {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITHOUT_QUALITY_CHECK', [args.deliveryNumber]));
					}
				} else if (args.key === 'FromQualityCheckView') {
					this.getElementById('acceptWithoutQualCheckButton').setVisible(false);
					if (sap.ui.Device.system.phone) {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK_FOR_MOBILE'));
						this.visibleButtons(false);
						this.getElementById('usageDecisionVBox').setVisible(true);
					} else {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK', [args.deliveryNumber]));
						this.visibleButtons(true);
						this.enableButtons(true);
						this.getElementById('usageDecisionVBox').setVisible(false);
					}
				} else if (args.key === 'FromBoxButtonClick') {
                    this.getElementById('acceptWithoutQualCheckButton').setVisible(false);
                    this.visibleButtons(false);
					this.getElementById('usageDecisionVBox').setVisible(false);
					if (sap.ui.Device.system.phone) {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK_FOR_MOBILE'));
					} else {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK', [args.deliveryNumber]));
					}
                } else {
					this.getElementById('acceptWithoutQualCheckButton').setVisible(false);
					if (sap.ui.Device.system.phone) {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK_FOR_MOBILE'));
						this.visibleButtons(false);
						this.getElementById('usageDecisionVBox').setVisible(true);
					} else {
						this.setTitle(this.getResourceBundleText('USAGE_DECISION_VIEW_TITLE_WITH_QUALITY_CHECK', [args.deliveryNumber]));
						this.visibleButtons(false);
						this.getElementById('usageDecisionVBox').setVisible(false);
					}
				}

				//	this.getStorageLocations(args.materialNumber, args.plant, args.deliveryNumber);
				var storageLocation = this.getModel('RcpQualityMainViewModel').getProperty('/Lgort');
				this.getBoxes(storageLocation);
			}
		},

		handleNavigate: function (channel, eventName, navigationData) {
			if (
				this.navigatedToCurrentView(navigationData.toView) &&
				this.navigatedFrom(navigationData.fromView, 'NotFound')
			) {

			}
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */

		onNavBackPress: function () {
			this.onNavBack();
		},

		onStLocationSelectionChange: function () {
			var selectedStLocation = this.getModel('RcpQualityMainViewModel').getProperty('/Lgort');
			this.getBoxes(selectedStLocation);
		},

		onBoxSelectionChange: function () {
			var storageLocation = this.getModel('RcpQualityMainViewModel').getProperty('/Lgort');
			this.getFields(storageLocation);
		},

		onAcceptPress: function () {

			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			this.enableButtons(true);
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var title = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_TITLE_TEXT', [oRcpQualityMainViewModel.Vbeln]);
				if (sap.ui.Device.system.phone) {
					title = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				}
				var message = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_MESSAGE_TEXT', [oRcpQualityMainViewModel.Lgort]);
				this.openWarningsMessagePopup('X', 'NOQ', title, message);
			}
		},

		onAcceptWithQualityCheckPress: function () {

			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			this.enableButtons(true);
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var title = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_TITLE_TEXT', [oRcpQualityMainViewModel.Vbeln]);
				if (sap.ui.Device.system.phone) {
					title = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				}
				var message = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WITH_QUALCHECK_WARNING_POPUP_MESSAGE_TEXT', [
					oRcpQualityMainViewModel.Lgort
				]);
				this.openWarningsMessagePopup('', 'A', title, message);
			}
		},

		onAcceptWithWarningPress: function () {

			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			this.enableButtons(true);
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var title = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_TITLE_TEXT', [oRcpQualityMainViewModel.Vbeln]);
				if (sap.ui.Device.system.phone) {
					title = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				}
				var message = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WITH_WARNING_POPUP_MESSAGE_TEXT', [oRcpQualityMainViewModel.Lgort]);
				this.openWarningsMessagePopup('X', 'AW', title, message);
			}
		},

		onRefusePress: function () {

			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			this.enableButtons(false);
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var title = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_TITLE_TEXT', [oRcpQualityMainViewModel.Vbeln]);
				if (sap.ui.Device.system.phone) {
					title = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				}
				var message = this.getResourceBundleText('USAGE_DECISION_REFUSE_POPUP_MESSAGE_TEXT', [oRcpQualityMainViewModel.Lgort]);
				this.openWarningsMessagePopup('X', 'R', title, message);
			}
		},

		onPartlyRefusePress: function () {

			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			this.enableButtons(true);
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var title = this.getResourceBundleText('USAGE_DECISION_ACCEPT_WARNING_POPUP_TITLE_TEXT', [oRcpQualityMainViewModel.Vbeln]);
				if (sap.ui.Device.system.phone) {
					title = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				}
				var message = this.getResourceBundleText('USAGE_DECISION_PARTLY_REFUSE_POPUP_MESSAGE_TEXT', [oRcpQualityMainViewModel.Lgort]);
				this.openWarningsMessagePopup('X', 'PR', title, message);
			}
		},

		onUDUploadImagePress: function () {
			this.openUploadImageDialog();
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		setTitle: function (title) {
			this.getElementById('usageDecisionPage').setTitle(title);
		},

		getStorageLocations: function (material, plant, deliveryNumber) {
			this.setAppBusyMode();
			this.getModel('SelectViewModel').setProperty('/StorageLocations', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetStorLoc', {
                        urlParameters: {
                            inMatnr: '\'' + material + '\'',
                            inPlant: '\'' + plant + '\'',
                            inDlvNo: '\'' + deliveryNumber + '\''
                        }
                    })
				.done(function (oData) {
					if (oData && oData.length > 0) {
						this.getModel('SelectViewModel').setProperty('/StorageLocations', oData);
						this.getModel('SelectViewModel').setProperty('/Lgort', oData[0].Lgort);
						this.getBoxes(oData[0].Lgort);
					}
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			//.always(this.setAppNotBusyMode.bind(this));
		},

		getBoxes: function (storageLocation) {
			this.setAppBusyMode();
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			this.getModel('SelectViewModel').setProperty('/Boxes', []);
			//FETR0050038 INC2135491_NQA: Box is filled in few cases incorrectly 
			this.getModel('SelectViewModel').setProperty('/Zzbox', '');
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetBoxValue', {
                        urlParameters: {
                            inLgort: '\'' + storageLocation + '\'',
                            inInspLot: '\'' + oRcpQualityMainViewModel.Prueflos + '\'',
                            inPlant: '\'' + oRcpQualityMainViewModel.Werks + '\''
                        }
                    })
				.done(function (oData) {
					if (oData && oData.length > 0) {
						this.getModel('SelectViewModel').setProperty('/Boxes', oData);
						this.getModel('SelectViewModel').setProperty('/Zzbox', oData[0].Zzbox);
						var that = this;
						oData.forEach(function (item) {
							if (item.Sel === 'X')
								that.getModel('SelectViewModel').setProperty('/Zzbox', item.Zzbox);
						});
						this.getFields(storageLocation);
					}
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			//.always(this.setAppNotBusyMode.bind(this));
		},

		getFields: function (storageLocation) {
			this.setAppBusyMode();
			var selectedBox = this.getView().byId("idBoxDropDown").getSelectedItem(),
				selectedBoxItem;
			if (selectedBox === null)
				selectedBoxItem = '';
			else
				selectedBoxItem = selectedBox.getText();

			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			this.getModel('SelectViewModel').setProperty('/Fields', []);
			//FETR0050038 INC2135491_NQA: Box is filled in few cases incorrectly 
			this.getModel('SelectViewModel').setProperty('/Zzfield', '');

			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetFieldValue', {
                        urlParameters: {
                            inLgort: '\'' + storageLocation + '\'',
                            inPlant: '\'' + oRcpQualityMainViewModel.Werks + '\'',
                            inInspLot: '\'' + oRcpQualityMainViewModel.Prueflos + '\'',
                            inBox: '\'' + selectedBoxItem + '\''
                        }
                    })
				.done(function (oData) {
					if (oData && oData.length > 0) {
						this.getModel('SelectViewModel').setProperty('/Fields', oData);
						this.getModel('SelectViewModel').setProperty('/Zzfield', oData[0].Zzfield);

						var that = this;
						oData.forEach(function (item) {
							if (item.Sel === 'X')
								that.getModel('SelectViewModel').setProperty('/Zzfield', item.Zzfield);
						});

					}
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			//.always(this.setAppNotBusyMode.bind(this));
		},

		getChangeDelivery: function () {
			this.setAppBusyMode();
			//	var selectedStLocation = this.getModel('SelectViewModel').getProperty('/Lgort') || '';
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel');
			var items = oRcpQualityMainViewModel.getData();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetChangeDelivery', {
                        urlParameters: {
                            inDlvNo: '\'' + items.Vbeln + '\'',
                            inLgort: '\'' + items.Lgort + '\''
                        }
                    })
				.done(function (oData) {
					if (oData.Message) {
						oRcpQualityMainViewModel.setProperty('/ChangeDeliveryMessage', oData.Message);
					}
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			/*.always(this.setAppNotBusyMode.bind(this));*/
		},

		getUpdateBoxValue: function (insplot, savebuttonPressedFromUsageDecision) {
			this.setAppBusyMode();
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel');
			var selectedBox = this.getModel('SelectViewModel').getProperty('/Zzbox') || '';
			var selectedField = this.getModel('SelectViewModel').getProperty('/Zzfield') || '';
			//	var inspLotData = this.getModel('QualityCheckViewModel').getData();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'UpdBoxValue', {
                        urlParameters: {
                            inInspLot: '\'' + insplot + '\'',
                            inBox: '\'' + selectedBox + '\'',
                            inZzfield: '\'' + selectedField + '\''
                        }
                    })
				.done(function (oData) {
					if (oData.Message) {
						oRcpQualityMainViewModel.setProperty('/UpdatedBoxValueMessage', oData.Message);
					}
					if (savebuttonPressedFromUsageDecision) {
						// this.navTo('RcpQualityMain', {}, false);
                        this.onNavBack();
					}
					this.setAppNotBusyMode();
					//this.navTo('RcpQualityMain', {}, false);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			/*.always(this.setAppNotBusyMode.bind(this));*/
		},

		createSaveObj: function () {
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			var saveObject = {};
			saveObject.Insplot = inspLotData.Prueflos || '';
			return saveObject;
		},

		postRcpConfirmation: function (saveObj) {
			this.setAppBusyMode();
			this.oDataUtil.create('ZRCP_QUALITY_INSPECTION_SRV', 'RcpConfirmationSet', saveObj)
				.done(function (oData) {
					if (oData) {
						//	this.navTo('RcpQualityMain', {}, false);
						this.showSuccessMessagePopup(saveObj.AcceptNoQual, saveObj.Insplot);
					}
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			/*.always(this.setAppNotBusyMode.bind(this));*/
		},

		visibleButtons: function (show) {
            this.getElementById('usageDecisionVBox').setVisible(show);
			this.getElementById('acceptWithQualCheckButton').setVisible(show);
			this.getElementById('acceptWithoutWarningButton').setVisible(show);
			this.getElementById('refuseButton').setVisible(show);
			this.getElementById('partlyRefuseButton').setVisible(show);
		},

		showSuccessMessagePopup: function (qualityCheck, inspLot) {
			// var that = this;
			var title = this.getResourceBundleText('COMMON_SUCCESS_TITLE');
			var successMessage = '';
			if (qualityCheck) {
				successMessage = this.getResourceBundleText('VISUAL_CHECK_SUCCESS_MESSAGE', [inspLot]);
			} else {
				successMessage = this.getResourceBundleText('USAGE_DECISION_SAVE_SUCCESS_MESSAGE', [inspLot]);
			}
			//	var message = this.getResourceBundleText('USAGE_DECISION_SAVE_SUCCESS_MESSAGE', [inspLot]);
			var okText = this.getResourceBundleText('OK_LABEL');
			var that = this;
			var messageBoxParameters = {
				type: 'Success',
				title: title,
				message: successMessage,
				actions: [okText],
				onClose: function (oAction) {
						if (oAction === "Ok" || oAction === "OK") {
							that.enableButtons(false);
							// that.navTo('RcpQualityMain', {}, false);
                            that.onNavBack();
						}
					}
					//	onClose: this.onNavBackPress.bind(this)
			};

			that.showMessageBox(messageBoxParameters);
		},

		openWarningsMessagePopup: function (print, type, title, message) {
			var saveText = this.getResourceBundleText('SAVE_BUTTON_TEXT');
			var cancelText = this.getResourceBundleText('CANCEL_BUTTON_LABEL');
			var messageBoxParameters = {
				type: 'Warning',
				title: title,
				message: message,
				actions: [saveText, cancelText],
				onClose: this.handleWarningMessagePopup.bind(this, print, type)
			};

			this.showMessageBox(messageBoxParameters);
		},

		handleWarningMessagePopup: function (print, type, action) {
			//here goes call of all services after saving
			var saveText = this.getResourceBundleText('SAVE_BUTTON_TEXT');
			var cancelText = this.getResourceBundleText('CANCEL_BUTTON_LABEL');
			this.enableButtons(false);
			var saveObj = this.createSaveObj();
			if (action === saveText) {
				//saveObj.AcceptNoQual = 'X';

				if (type === 'NOQ') {
					saveObj.AcceptNoQual = 'X';
				} else if (type === 'A') {
					saveObj.Print = print;
					saveObj.Accept = 'X';
				} else if (type === 'AW') {
					saveObj.Print = print;
					saveObj.AcceptWarning = 'X';
				} else if (type === 'R') {
					saveObj.Print = print;
					saveObj.Refused = 'X';
				} else if (type === 'PR') {
					saveObj.Print = print;
					saveObj.PartRefused = 'X';
				}

				if (saveObj) {
					this.getChangeDelivery();
					this.getUpdateBoxValue(saveObj.Insplot);
					this.postRcpConfirmation(saveObj);
				}
			} else if (action === cancelText) {
				this.enableButtons(false);
			}
		},
		onSavePress: function () {
			var selectedBoxValue = this.getView().byId("idBoxDropDown").getSelectedItem().getText();
			var savebuttonPressedFromUsageDecision = true;
			if (selectedBoxValue === "")
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('USERDECISION_EMPTY_BOX_ERROR_MESSAGE'));
			else {
				var inspLotData = this.getModel('RcpQualityMainViewModel').getData();
				var Insplot = inspLotData.Prueflos || '';
				this.getUpdateBoxValue(Insplot, savebuttonPressedFromUsageDecision);
			}
		},
		enableButtons: function (enable) {
			/*if(enable){
				sap.ui.core.BusyIndicator.show();
			}else{
				sap.ui.core.BusyIndicator.hide();
			}*/
			this.getElementById('acceptWithQualCheckButton').setEnabled(enable);
			this.getElementById('acceptWithoutWarningButton').setEnabled(enable);
			this.getElementById('refuseButton').setEnabled(enable);
			this.getElementById('partlyRefuseButton').setEnabled(enable);
		}
	});
});