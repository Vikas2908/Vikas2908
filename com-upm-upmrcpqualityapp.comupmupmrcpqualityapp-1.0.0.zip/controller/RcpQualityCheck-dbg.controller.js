sap.ui.define([
	'com/upm/upmrcpqualityapp/controller/CommonController',
	'com/upm/upmrcpqualityapp/controller/BaseController',
	'com/upm/upmrcpqualityapp/util/formatter'
], function (CommonController, BaseController, formatterUtil) {
	return CommonController.extend('com.upm.upmrcpqualityapp.controller.RcpQualityCheck', {

		/* =========================================================== */
		/* View & Life Cycle		                                   */
		/* =========================================================== */

		onInit: function () {
			BaseController.prototype.onInit.apply(this, arguments);

			this.getMyComponent()
				.getEventBus()
				.subscribe('app', 'navigate', this.handleNavigate.bind(this));
		},

		onAfterRendering: function () {
			// this.handleBrowserEvent(this.getElementById('visualTable'), true);
			// this.handleBrowserEvent(this.getElementById('gravametricksTable'), false);
		},

		routeMatched: function (navigationEvent) {
			if (navigationEvent.getParameter('name') === 'RcpQualityCheck') {
				BaseController.prototype.routeMatched.apply(this, arguments);
				var object = this.getModel('RcpQualityMainViewModel').getData();
				if (sap.ui.Device.system.phone) {
					this.getElementById('qualityCheckPage').setTitle(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_TITLE_FOR_MOBILE_DEVICE', [
						object.Vbeln
					]));
					this.getElementById('qcUploadImageButton').setText('');
				}
				this.getElementById('usageDecisionButton').setVisible(false);
				this.getElementById('iconTabBarId').setSelectedKey('visualIconTabFilterKey');
				this.getViewData();
			}
		},

		handleNavigate: function (channel, eventName, navigationData) {
			if (
				this.navigatedToCurrentView(navigationData.toView) &&
				this.navigatedFrom(navigationData.fromView, 'NotFound')
			) {

			}
			/*	var oTable = this.getElementById('txtFieldsTable');
				this.setSortValues(oTable);*/
		},

		handleBrowserEvent: function (table, isVisualTable) {
			// var that = this;
			// if (table) {
			// 	table.attachBrowserEvent('keyup', function (event) {
			// 		var visual = $('#' + event.target.id + '').parent().parent()[0].className.split(' ');
			// 		//	var visual = $('#' + event.target.id + '').parent()[0].className.split(' ');
			// 		if (visual[0] !== 'enterTable' && visual[0] !== 'enterTable2') {
			// 			visual = $('#' + event.target.id + '').parent()[0].className.split(' ');
			// 		}
			// 		switch (event.keyCode) {
			// 		case jQuery.sap.KeyCodes.ARROW_UP:
			// 		case jQuery.sap.KeyCodes.ARROW_DOWN:
			// 			that.simulateEnterKey();
			// 			if (isVisualTable && visual[0] === 'enterTable') {
			// 				that.focusToNextInput(event.keyCode);
			// 			} else if (isVisualTable && visual[0] === 'enterTable2') {
			// 				that.focusToNextInput2(event.keyCode);
			// 			} else {
			// 				that.focusToNextInput3(event.keyCode);
			// 			}
			// 			break;
			// 		case jQuery.sap.KeyCodes.ENTER:
			// 			//that.focusToNextInput();
			// 			break;
			// 		default:
			// 			break;
			// 		}
			// 	});
			// }
		},

		simulateEnterKey: function () {
			var e = $.Event('keypress');
			e.which = 13;
			e.keyCode = 13;
			$(this).trigger(e);
		},

		/* =========================================================== */
		/* Event handlers		                                	   */
		/* =========================================================== */
		onCheckBoxSelect: function (oEvent) {
			this.setCheckboxSelection(oEvent);
		},

		onNavBackPress: function () {
			this.onNavBack();
		},

		onCountrySelectionChange: function () {
			var selectedCountry = this.getModel('SelectViewModel').getProperty('/Country');
			this.getCities(selectedCountry);
		},

		onCitySelectionChange: function () {},

		onUsageDesionPress: function () {
			var object = this.getModel('RcpQualityMainViewModel').getData();
			this.navTo('UsageDecision', {
				deliveryNumber: object.Vbeln,
				materialNumber: object.Matnr || '',
				plant: object.Werks || '',
				key: 'FromQualityCheckView'
			}, true);
		},

		onQCUploadImagePress: function () {
			this.openUploadImageDialog();
		},

		onSavePress: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var oModel = this.getModel('VisualViewModel').getData();
			if (parseFloat(oModel.VisualTotal) !== 0 && parseFloat(oModel.VisualTotal) !== 100) {
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_VISUAL_CHECK_SUMTOTAL'));
				this.getElementById('iconTabBarId').setSelectedKey('visualIconTabFilterKey');
			} else {
				this.openConfirmationMessagePopup(oRcpQualityMainViewModel.Vbeln);
			}
		},

		onIconTabBarSelect: function (oEvent) {
			var selectedKey = oEvent.getParameter('key');
			var oModel = this.getModel('VisualViewModel').getData();
			if (selectedKey === 'gravametricksIconTabFilterKey' || selectedKey === 'textsIconTabFilterKey' || selectedKey ===
				'additionalDataTabFilterKey') {
				if (oModel && parseFloat(oModel.VisualTotal) !== 0 && parseFloat(oModel.VisualTotal) !== 100) {
					this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_VISUAL_CHECK_SUMTOTAL'));
					this.getElementById('iconTabBarId').setSelectedKey('visualIconTabFilterKey');
				}
			}
		},

		onVisualChanged: function () {
			var that = this;
			this.getModel('VisualViewModel').updateBindings();
			var oModel = this.getModel('VisualViewModel').getData();
			var total = 0;
			var difference = 0;
			oModel.VisualItems.forEach(function (result) {

				if (result.Input10 !== '' && result.Header !== 'X') {
					total += parseFloat(result.Input10.replace(',', '.'));
					if (total > 100) {
						that.openErrorMessagePopupWithoutEvent(that.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_VISUAL_CHECK_SUMTOTAL'));
						total -= parseFloat(result.Input10.replace(',', '.'));
						result.Input10 = '';
					}
				} else {
					result.Input10 = '';
				}
			});
			oModel.VisualTotal = total.toFixed(2).replace('.', ',');
			oModel.VisualDifference = (100 - total).toFixed(2).replace('.', ',');

			this.calculateSubTotal(oModel.VisualItems);

			this.checkInputValidation(oModel, 'input10');

			this.getModel('VisualViewModel').updateBindings();
		},

		onSupplierChanged: function () {
			this.getModel('VisualViewModel').updateBindings();
			var oModel = this.getModel('VisualViewModel').getData();

			this.calculateSubTotal(oModel.VisualItems);

			this.checkInputValidation(oModel, 'input30');

			this.getModel('VisualViewModel').updateBindings();
		},

		onGravimetricChange: function () {
			this.getModel('VisualViewModel').updateBindings();
			var oModel = this.getModel('VisualViewModel').getData();
			var total = 0;
			var totalGrPercentage = 0;
			var input20Total = 0;
			oModel.VisualItems.forEach(function (result) {
				if (result.Input20 !== '' && result.Header !== 'X') {
					total += parseFloat(result.Input20.replace(',', '.'));
					input20Total = total.toString();
					totalGrPercentage = formatterUtil.toPercent(input20Total.replace('.', ','), total);
				} else {
					result.Input20 = '';
				}
			});
			oModel.totalGr = total;
			oModel.GrSumTotal = input20Total.replace('.', ',');
			oModel.TotalGrPercentage = totalGrPercentage;

			this.calculateSubTotal(oModel.VisualItems);

			this.checkInputValidation(oModel, 'input20');

			this.getModel('VisualViewModel').updateBindings();
		},

		onAvgValChange: function (oEvent) {
			var oAdditionalDataModel = this.getModel('AdditionalDataModel');
			var path = oEvent.getSource().oPropagatedProperties.oBindingContexts.AdditionalDataModel.sPath + '/OriginalInput';

			var avgValue = oEvent.getParameter('value');
			avgValue = avgValue.replace(',', '.');
			avgValue = parseFloat(avgValue);
			if (avgValue !== 0) {
				avgValue = avgValue.toFixed(2).replace('.', ',');
			}
			oAdditionalDataModel.setProperty(path, avgValue.toString());
		},

		/* =========================================================== */
		/* Internal methods				                          	   */
		/* =========================================================== */

		getViewData: function () {
			this.createInspLot();
			/*	this.getDlvChecks();
				this.getTxtFields();
				this.getAddData();
				this.getCities('');*/
			this.getCountries();
		},

		setCheckboxSelection: function (oEvent) {
			var oTextFieldsViewModel = this.getModel('TextFieldsViewModel');
			var path = oEvent.getSource().oPropagatedProperties.oBindingContexts.TextFieldsViewModel.sPath + '/Activated';
			var selected = oEvent.getParameter('selected');
			if (selected) {
				oTextFieldsViewModel.setProperty(path, 'X');
			} else {
				oTextFieldsViewModel.setProperty(path, '');
			}
		},

		checkInputValidation: function (oModel, visualInput) {
			// 20, 80 || 20, 90 || 20, 80, 90 - Input
			var matricsValidationFlag = true;
			var xInspoper = true;
			for (var i = 0; i < oModel.VisualItems.length; i++) {
				var inspoper = oModel.VisualItems[i].Inspoper;
				var input = 0;
				if (visualInput === 'input10') {
					input = oModel.VisualItems[i].Input10 ? parseFloat(oModel.VisualItems[i].Input10.replace(',', '.')) : 0;
				} else if (visualInput === 'input20') {
					input = oModel.VisualItems[i].Input20 ? parseFloat(oModel.VisualItems[i].Input20.replace(',', '.')) : 0;
				} else if (visualInput === 'input30') {
					input = oModel.VisualItems[i].Input30 ? parseFloat(oModel.VisualItems[i].Input30.replace(',', '.')) : 0;
				}

				if (inspoper === '0020') {
					if (input === 0) {
						xInspoper = false;
					} else if (input !== 0) {
						matricsValidationFlag = true;
						xInspoper = true;
					}
				}

				if (xInspoper && (inspoper === '0080' || inspoper === '0090') && input !== 0) {
					matricsValidationFlag = false;
				}
			}

			if (!matricsValidationFlag) {
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_MATRIC_CHECK_ERROR_MESSAGE'));
			} else {
				//this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_MATRIC_CHECK_SUMTOTAL'));
			}
		},

		createNavChecksSaveObject: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			var itemsValid = true;
			var navChecksSaveObject = {};
			navChecksSaveObject.Vbeln = oRcpQualityMainViewModel.Vbeln;
			navChecksSaveObject.Iwerk = '';
			navChecksSaveObject.Ernam = '';
			navChecksSaveObject.Matnr = '';
			navChecksSaveObject.Werks = '';
			navChecksSaveObject.Erzet = '';
			navChecksSaveObject.Erdat = '';
			navChecksSaveObject.Lifnr = '';
			navChecksSaveObject.Lname = '';
			navChecksSaveObject.Origin = '';
			navChecksSaveObject.Oname = '';
			navChecksSaveObject.Inco1 = '';
			navChecksSaveObject.Inco2 = '';
			navChecksSaveObject.Arktx = '';
			navChecksSaveObject.Tknota = '';
			navChecksSaveObject.Tort2a = '';
			navChecksSaveObject.Land1a = '';
			navChecksSaveObject.Traid = '';
			navChecksSaveObject.Signi = '';
			navChecksSaveObject.Prueflos = inspLotData.Prueflos;
			navChecksSaveObject.Checks = 'C';

			var oModel = this.getModel('VisualViewModel').getData();
			var totalGr = 0;
			totalGr = oModel.totalGr;
			var visualTotal = 0;
			visualTotal = oModel.VisualTotal ? parseFloat(oModel.VisualTotal.replace(',', '.')) : 0;

			var visualItems = this.getModel('VisualViewModel').getProperty('/VisualItems');
			var items = [];
			$.map(visualItems, function (item) {
				var mean20 = item.Input20 ? formatterUtil.toPercent(item.Input20.replace(',', '.'), totalGr) : '';
				items.push({
					Insplot: item.Insplot,
					Inspoper: item.Inspoper,
					Input10: item.Input10 ? item.Input10.replace(',', '.') : '',
					Input30: item.Input30 ? item.Input30.replace(',', '.') : '',
					Header: item.Header,
					TxtOper: item.TxtOper,
					Input20: item.Input20 ? item.Input20.replace(',', '.') : '',
					//	Mean20 : mean20 ? mean20.replace(',', '.' ) : ''
					Mean20: mean20 || ''
				});
			});
			navChecksSaveObject.InspNavChecks = items;

			//	if(totalGr > 100 || totalGr < 100){
			/*if(totalGr !== 100){	
				itemsValid = false;
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_MATRIC_CHECK_SUMTOTAL'));
			} */

			//	if(visualTotal > 100 ||visualTotal < 100) {
			if (visualTotal !== 0 && visualTotal !== 100) {
				itemsValid = false;
				this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_VISUAL_CHECK_SUMTOTAL'));
			}

			if (itemsValid) {
				return navChecksSaveObject;
			}
		},

		createLongTextSaveObject: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			var txtLongSaveObject = {};
			txtLongSaveObject.Vbeln = oRcpQualityMainViewModel.Vbeln;
			txtLongSaveObject.Iwerk = '';
			txtLongSaveObject.Ernam = '';
			txtLongSaveObject.Matnr = '';
			txtLongSaveObject.Werks = '';
			txtLongSaveObject.Erzet = '';
			txtLongSaveObject.Erdat = '';
			txtLongSaveObject.Lifnr = '';
			txtLongSaveObject.Lname = '';
			txtLongSaveObject.Origin = '';
			txtLongSaveObject.Oname = '';
			txtLongSaveObject.Inco1 = '';
			txtLongSaveObject.Inco2 = '';
			txtLongSaveObject.Arktx = '';
			txtLongSaveObject.Tknota = '';
			txtLongSaveObject.Tort2a = '';
			txtLongSaveObject.Land1a = '';
			txtLongSaveObject.Traid = '';
			txtLongSaveObject.Signi = '';
			txtLongSaveObject.Prueflos = inspLotData.Prueflos;
			txtLongSaveObject.Checks = 'L';

			var txtlongItem = this.getModel('LongTextModel').getProperty('/LongTextData');
			var txtLongItemArray = [];
			$.map(txtlongItem, function (item) {
				txtLongItemArray.push({
					LongText: item.LongText,
					InspLotNumber: item.InspLotNumber
				});
			});
			txtLongSaveObject.InspNavLongText = txtLongItemArray;
			return txtLongSaveObject;
		},

		createTextFieldsSaveObject: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			var txtFieldsSaveObject = {};
			txtFieldsSaveObject.Vbeln = oRcpQualityMainViewModel.Vbeln;
			txtFieldsSaveObject.Iwerk = '';
			txtFieldsSaveObject.Ernam = '';
			txtFieldsSaveObject.Matnr = '';
			txtFieldsSaveObject.Werks = '';
			txtFieldsSaveObject.Erzet = '';
			txtFieldsSaveObject.Erdat = '';
			txtFieldsSaveObject.Lifnr = '';
			txtFieldsSaveObject.Lname = '';
			txtFieldsSaveObject.Origin = '';
			txtFieldsSaveObject.Oname = '';
			txtFieldsSaveObject.Inco1 = '';
			txtFieldsSaveObject.Inco2 = '';
			txtFieldsSaveObject.Arktx = '';
			txtFieldsSaveObject.Tknota = '';
			txtFieldsSaveObject.Tort2a = '';
			txtFieldsSaveObject.Land1a = '';
			txtFieldsSaveObject.Traid = '';
			txtFieldsSaveObject.Signi = '';
			txtFieldsSaveObject.Prueflos = inspLotData.Prueflos;
			txtFieldsSaveObject.Checks = 'T';

			var txtFieldsItems = this.getModel('TextFieldsViewModel').getProperty('/TextFields');
			var txtFieldsItemsArray = [];
			$.map(txtFieldsItems, function (item) {
				txtFieldsItemsArray.push({
					Activated: item.Activated,
					ComNo: item.ComNo,
					CommentTxt: item.CommentTxt,
					GroupNo: item.GroupNo,
					GroupTxt: item.GroupTxt,
					Insplot: item.Insplot
				});
			});
			txtFieldsSaveObject.InspNavTextFields = txtFieldsItemsArray;
			return txtFieldsSaveObject;
		},

		createAddDataSaveObject: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			var addDataSaveObject = {};
			addDataSaveObject.Vbeln = oRcpQualityMainViewModel.Vbeln;
			addDataSaveObject.Iwerk = '';
			addDataSaveObject.Ernam = '';
			addDataSaveObject.Matnr = '';
			addDataSaveObject.Werks = '';
			addDataSaveObject.Erzet = '';
			addDataSaveObject.Erdat = '';
			addDataSaveObject.Lifnr = '';
			addDataSaveObject.Lname = '';
			addDataSaveObject.Origin = '';
			addDataSaveObject.Oname = '';
			addDataSaveObject.Inco1 = '';
			addDataSaveObject.Inco2 = '';
			addDataSaveObject.Arktx = '';
			addDataSaveObject.Tknota = '';
			addDataSaveObject.Tort2a = '';
			addDataSaveObject.Land1a = '';
			addDataSaveObject.Traid = '';
			addDataSaveObject.Signi = '';
			addDataSaveObject.Prueflos = inspLotData.Prueflos;
			addDataSaveObject.Checks = 'A';

			var addDataItems = this.getModel('AdditionalDataModel').getProperty('/AdditionalData');
			var addDataItemsArray = [];
			$.map(addDataItems, function (item) {
				addDataItemsArray.push({
					CharDescr: item.CharDescr,
					CharType: item.CharType,
					ConfirmNo: item.ConfirmNo,
					EndDate: item.EndDate,
					EndTime: item.EndTime,
					IdiSubsys: item.IdiSubsys,
					Inspchar: item.Inspchar,
					Inspector: item.Inspector,
					Insplot: item.Insplot,
					Inspoper: item.Inspoper,
					MeanValue: item.MeanValue,
					OriginalInput: item.OriginalInput ? item.OriginalInput.replace(',', '.') : '',
					Plant: item.Plant,
					PlntWorkc: item.PlntWorkc,
					StartDate: item.StartDate,
					StartTime: item.StartTime,
					Status: item.Status,
					TxtOper: item.TxtOper,
					TxtWorkc: item.TxtWorkc,
					Workcenter: item.Workcenter
				});
			});
			addDataSaveObject.InspNavAddData = addDataItemsArray;
			return addDataSaveObject;
		},

		postRcpqDelvDetails: function (postObject, lastCheck) {
			this.setAppBusyMode();
			return this.oDataUtil.create('ZRCP_QUALITY_INSPECTION_SRV', 'RcpqDelvDetailsSet', postObject)
				.done(function (oData) {
					if (lastCheck) {
						//	this.getUsageDecision(oData.Prueflos);
						this.handlePostSuccessPopup(oData.Prueflos);
						this.setAppNotBusyMode();
					}
				}.bind(this))
				.fail(this.openErrorMessagePopup.bind(this));
			/*.always(this.setAppNotBusyMode.bind(this));*/
		},

		getUsageDecision: function (inInspLot) {
			this.setAppBusyMode();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetUsageDecision', {
                urlParameters: {
                    inInspLot: '\'' + inInspLot + '\''
                }
            })
				.done(function (oData) {
					if (oData.Message) {
						this.getElementById('usageDecisionButton').setVisible(false);
					} else {
						this.getElementById('usageDecisionButton').setVisible(true);
						this.getElementById('usageDecisionButton').setEnabled(false);
					}
					console.log(oData.Message);
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			/*.always(this.setAppNotBusyMode.bind(this));*/
		},

		getChangeShipment: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var deliveryNumber = oRcpQualityMainViewModel.Vbeln;
			var selectedCity = this.getElementById('citySelect').getSelectedKey();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetChangeShipment', {
                        urlParameters: {
                            inDlvNo: '\'' + deliveryNumber + '\'',
                            inKnota: '\'' + selectedCity + '\''
                        }
                    })
				.done(function (oData) {
					console.log(oData);
				}.bind(this))
				.fail(function (oEvent) {
					//	this.openErrorMessagePopup(oEvent);
				}.bind(this));
		},

		openConfirmationMessagePopup: function (delNumber) {
			var closeText = this.getResourceBundleText('NO_BUTTON_LABEL');
			var saveText = this.getResourceBundleText('YES_BUTTON_LABEL');
			var dialogTitle = this.getResourceBundleText('CONFIRM_TITLE_TEXT', [delNumber]);
			var confirmMessage = this.getResourceBundleText('CONFIRM_MESSAGE_TEXT');
			if (sap.ui.Device.system.phone) {
				dialogTitle = this.getResourceBundleText('CONFIRM_TITLE_TEXT_FOR_MOBILE_DEVICE');
				confirmMessage = this.getResourceBundleText('CONFIRM_MESSAGE_TEXT_FOR_MOBILE_DEVICE', [delNumber]);
			}
			var messageBoxParameters = {
				type: 'Warning',
				title: dialogTitle,
				message: confirmMessage,
				actions: [saveText, closeText],
				onClose: this.handleCloseConfirmationPopup.bind(this)

			};
			this.showMessageBox(messageBoxParameters);
		},

		handleCloseConfirmationPopup: function (action) {
			var saveText = this.getResourceBundleText('YES_BUTTON_LABEL');
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			//	var selectedIconBarKey = this.getElementById('iconTabBarId').getSelectedKey();
			if (action === saveText) {
				var txtFieldsSaveObject = this.createTextFieldsSaveObject();
				var addDataSaveObject = this.createAddDataSaveObject();
				var navChecksSaveObject = this.createNavChecksSaveObject();
				var longTextsSaveObject = this.createLongTextSaveObject();
				this.getElementById('idSaveButton').setEnabled(false);
				$.when(
						this.handleNavChecksSaveObject(navChecksSaveObject, false),
						this.getUsageDecision(inspLotData.Prueflos)
					)
					.always(function () {
						this.handleNavChecksSaveObject(txtFieldsSaveObject, false)
							.always(function () {
								this.handleNavChecksSaveObject(addDataSaveObject, false); // FETR0047220 : INC1960361 : Call are separeted for backend at a time both call was going
								//	this.getChangeShipment();
							}.bind(this))
							.always(function () {
								//	this.handleNavChecksSaveObject(addDataSaveObject, true);
								this.handleNavChecksSaveObject(longTextsSaveObject, true); // FETR0047220 : INC1960361 : Call are separeted for backend at a time both call was going
								this.getChangeShipment(); //// FETR0047220 : INC1960361 : Call are separeted for backend at a time both call was going  
							}.bind(this))
					}.bind(this))
			}
		},

		handleNavChecksSaveObject: function (saveObject, isLastCheck) {
			var deferred = $.Deferred();
			if (saveObject) {
				this.postRcpqDelvDetails(saveObject, isLastCheck).always(function () {
					deferred.resolve();
				});
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},

		handlePostSuccessPopup: function (inspectionLot) {
			var that = this;
			that.showSuccessPopup(that.getResourceBundleText('VISUAL_CHECK_SUCCESS_MESSAGE', [inspectionLot]));
			that.getElementById('iconTabBarId').setSelectedKey('visualIconTabFilterKey');
			//	this.showSuccessPopup(this.getResourceBundleText('TEXTFIELDS_SUCCESS_MESSAGE', [inspectionLot]));
			//	this.showSuccessPopup(this.getResourceBundleText('ADDITIONALDATA_SUCCESS_MESSAGE', [inspectionLot]));
		},

		showSuccessPopup: function (message) {
			var that = this;
			var messageBoxParameters = {
				type: 'Success',
				title: that.getResourceBundleText('COMMON_SUCCESS_TITLE'),
				message: message,
				onClose: function (oAction) {
					if (oAction === "Ok" || oAction === "OK") {
						that.getElementById('usageDecisionButton').setEnabled(true);
						that.getElementById('idSaveButton').setEnabled(true);
					} else if (oAction === "Close" || oAction === "CANCEL" || oAction === "Cancel" || oAction === "CLOSE") {
						that.getElementById('usageDecisionButton').setVisible(false);
						that.getElementById('idSaveButton').setEnabled(true);
					}
				}
			};
			that.showMessageBox(messageBoxParameters);
		},

		onResendPress: function () {
			/*	/RcpqEmailSend?inInspLot=’ 010001010592’ */

			this.setAppBusyMode();
			/*var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inInspLot = oRcpQualityMainViewModel.Prueflos;*/
			var inspLotData = this.getModel('QualityCheckViewModel').getData();
			//	this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetLongText?inInspLot=\'' + inspLotData.Prueflos + '\'')
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'RcpqEmailSend', {
                urlParameters: {
                    inInspLot: '\'' + inspLotData.Prueflos + '\''
                }
            })
				.done(function (oData) {
					//	console.log("send email");
					this.setAppNotBusyMode();
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
					this.setAppNotBusyMode();
				}.bind(this));
			//.always(this.setAppNotBusyMode.bind(this));

		},

		onTextChange: function (oEvent) {
			/*	var result = /^[0-9]{1,2}[.,]\d{1-2}$/.test(value);///^\d*\.?\d*$/.test(value); 
				if(result){
					return value;
				}else{
					return "";
				}*/
			var oInputVal = oEvent.getSource();

			var val = oInputVal.getValue(),
				comaIndex = val.indexOf(","),
				dotIndex = val.indexOf("."),
				diff = comaIndex - dotIndex;

			if (comaIndex !== -1 && dotIndex !== -1) {

				if (comaIndex < dotIndex)
					val = val.split(",")[0] + "," + val.split(",")[1].split(".")[0];
				else
					val = val.split(".")[0] + "." + val.split(".")[1].split(",")[0];
				oInputVal.setValue(val);
			}

			if (val.split(",").length > 2) {
				val = val.split(",")[0] + "," + val.split(",")[1];
				oInputVal.setValue(val);
			}
			if (val.split(".").length > 2) {
				val = val.split(".")[0] + "." + val.split(".")[1];
				oInputVal.setValue(val);
			}

			if (diff === -1) {
				val = val.split(",")[0] + ",";
				oInputVal.setValue(val);

			}
			var tempValue = val.replace(",", ".");
			var isCommaPresent = val.indexOf(",") > -1;
			var isDotPresent = val.indexOf(".") > -1;
			var notNumber = isNaN(tempValue);
			var splitValues = ["", ""];
			if (notNumber) {
				var replaceSpecialChar = val.toString().replace(/[^0-9\.\,]/g, "");
				oInputVal.setValue(replaceSpecialChar);
			} else if ((tempValue.split(".")[0] > 999999 || (tempValue.split(".")[1] !== undefined && String(tempValue.split(".")[1]).length >
					3))) {
				if (tempValue.split(".")[0] > 999999) {
					splitValues[0] = tempValue.split(".")[0].substr(0, 6);
				} else {
					splitValues[0] = tempValue.split(".")[0];
				}
				if (tempValue.split(".")[1] !== undefined) {
					splitValues[1] = tempValue.split(".")[1].substr(0, 3);
				}
				if (isCommaPresent) {
					tempValue = splitValues[0] + "," + splitValues[1];
				} else if (isDotPresent) {
					tempValue = splitValues[0] + "." + splitValues[1];
				} else {
					tempValue = splitValues[0];
				}

				oInputVal.setValue(tempValue);
			}
		},
		onLongTextChange: function (oEvent) {

		}
	});
});