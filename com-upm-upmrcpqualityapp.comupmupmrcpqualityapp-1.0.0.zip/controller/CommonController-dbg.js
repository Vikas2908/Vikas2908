sap.ui.define([
	'com/upm/upmrcpqualityapp/controller/BaseController',
	'com/upm/upmrcpqualityapp/util/formatter'
], function (BaseController, formatterUtil) {
	return BaseController.extend('com.upm.upmrcpqualityapp.controller.CommonController', {
		setSortValues: function (oTable) {
			var oBinding = oTable.getBinding('items');

			this.sorterUtil.sort(oBinding, [{
				propertyName: 'CommentTxt',
				desc: false
			}], 'GroupTxt');
		},

		createInspLot: function () {
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var oVisualViewModel = this.getModel('VisualViewModel');
			oVisualViewModel.setProperty('/VisualItems', []);
			this.getModel('TextFieldsViewModel').setProperty('/TextFields', []);
			this.getModel('AdditionalDataModel').setProperty('/AdditionalData', []);
			this.getModel('LongTextModel').setProperty('/LongTextData', []);
			var deliveryNumber = oRcpQualityMainViewModel.Vbeln;
			this.setAppBusyMode();
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'CreateInspLot', {
                urlParameters: {
                    inDlvNo: '\'' + deliveryNumber + '\''
                }
            })
				.done(function (oData) {
					this.handleCreateInspLotSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		handleCreateInspLotSuccess: function (oData) {
			if (oData) {
				this.getModel('QualityCheckViewModel').setData(oData);
				this.getDlvChecks(oData.Prueflos);
				this.getTxtFields(oData.Prueflos);
				this.getAddData(oData.Prueflos);
				this.getLongTextData(oData.Prueflos);
			}
		},

		getDlvChecks: function (inInspLot) {
			this.setAppBusyMode();
			/*	var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var inInspLot = oRcpQualityMainViewModel.Prueflos;*/
			var oVisualViewModel = this.getModel('VisualViewModel');
			oVisualViewModel.setProperty('/VisualItems', []);
			oVisualViewModel.setProperty('/totalGr', 0);
			oVisualViewModel.setProperty('/VisualTotal', 0);
			oVisualViewModel.setProperty('/VisualDifference', 100);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetDlvChecks', {
                urlParameters: {
                    inInspLot:  '\'' + inInspLot + '\''
                }
            })
				.done(function (oData) {
					this.handleGetDlvChecksSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.setAppNotBusyMode();
					this.openErrorMessagePopup(oEvent);
				}.bind(this));
		},

		handleGetDlvChecksSuccess: function (oData) {
			var oVisualViewModel = this.getModel('VisualViewModel');
			$.when(
				oVisualViewModel.setProperty('/totalGr', '0'),
				this.calculateTotal(oData),
				this.calculateGravimetricTotal(oData),
				this.calculateSubTotal(oData)
			).done(function () {
				this.setAppNotBusyMode();
			}.bind(this));
		},

		calculateTotal: function (oData) {
			var total = 0;
			var difference = 100;
			var oVisualViewModel = this.getModel('VisualViewModel');
			if (oData) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].Input10) {
						//    oData[i].Input10 = formatterUtil.NumberDecimalFormatter(oData[i].Input10);
						//    oData[i].Input10 = parseFloat(oData[i].Input10);
						total += parseFloat(oData[i].Input10);
					}
					/* if (oData[i].Input20) {
					   oData[i].Input20 = formatterUtil.NumberDecimalFormatter(parseFloat(oData[i].Input20));
					 }
					 if (oData[i].Input30) {
					   oData[i].Input30 = formatterUtil.NumberDecimalFormatter(parseFloat(oData[i].Input30));
					 }*/
				}
			}

			oVisualViewModel.setProperty('/VisualTotal', total.toString());
			oVisualViewModel.setProperty('/VisualDifference', difference - total);
		},

		calculateGravimetricTotal: function (oData) {
			var total = 0;
			var totalGrPercentage = 0;
			var input20Total = '0.00';
			var oVisualViewModel = this.getModel('VisualViewModel');
			if (oData) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].Input20) {
						total += parseFloat(oData[i].Input20);
						input20Total = total.toString();
						totalGrPercentage = formatterUtil.toPercent(input20Total.replace('.', ','), total);
					}
				}
			}

			oVisualViewModel.setProperty('/totalGr', total.toString());
			oVisualViewModel.setProperty('/GrSumTotal', input20Total.replace('.', ','));
			oVisualViewModel.setProperty('/TotalGrPercentage', totalGrPercentage);
		},

		calculateSubTotal: function (oData) {
			var sub_Input10 = 0;
			var sub_Input20 = 0;
			var sub_Input30 = 0;
			var oVisualViewModel = this.getModel('VisualViewModel');
			if (oData) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].Header !== 'X') {
						if (oData[i].Input10) {
							sub_Input10 += parseFloat(oData[i].Input10.replace(',', '.'));
						}
						if (oData[i].Input20) {
							sub_Input20 += parseFloat(oData[i].Input20.replace(',', '.'));
							/*if(sub_Input20 > 100) {
						    	this.openErrorMessagePopupWithoutEvent(this.getResourceBundleText('RCP_QUALITY_CHECK_VIEW_MATRIC_CHECK_SUMTOTAL'));
						    	oData[i].Input20 = '';
						    	break;
						   } 
					       oVisualViewModel.setProperty('/totalGr', sub_Input20);*/
						}
						if (oData[i].Input30) {
							sub_Input30 += parseFloat(oData[i].Input30.replace(',', '.'));
						}
					} else {
						oData[i].Input10 = sub_Input10.toString();
						oData[i].Input20 = sub_Input20.toString();
						oData[i].Input30 = sub_Input30.toString();
						sub_Input10 = 0;
						sub_Input20 = 0;
						sub_Input30 = 0;
					}
				}
				//----for ZeroFormat
				for (var i = 0; i < oData.length; i++) {

					if (parseFloat(oData[i].Input10.replace(',', '.')) === 0) {
						oData[i].Input10 = '';
					} else {
						if (oData[i].Input10) {
							oData[i].Input10 = parseFloat(oData[i].Input10.replace(',', '.')).toFixed(2);
							oData[i].Input10 = oData[i].Input10.toString().replace('.', ',');
						}
					}
					if (parseFloat(oData[i].Input30.replace(',', '.')) === 0) {
						oData[i].Input30 = '';
					} else {
						if (oData[i].Input30) {
							oData[i].Input30 = parseFloat(oData[i].Input30.replace(',', '.')).toFixed(2);
							oData[i].Input30 = oData[i].Input30.toString().replace('.', ',');
						}
					}
					if (parseFloat(oData[i].Input20.replace(',', '.')) === 0) {
						oData[i].Input20 = '';
					} else {
						if (oData[i].Input20) {
							oData[i].Input20 = parseFloat(oData[i].Input20.replace(',', '.')).toFixed(2);
							oData[i].Input20 = oData[i].Input20.toString().replace('.', ',');
						}
					}
				}

				oVisualViewModel.setProperty('/VisualItems', oData);
			}
		},

		getTxtFields: function (inInspLot) {
			this.setAppBusyMode();
			/*var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inInspLot = oRcpQualityMainViewModel.Prueflos;*/
			this.getModel('TextFieldsViewModel').setProperty('/TextFields', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetTextFields', {
                urlParameters: {
                    inInspLot:  '\'' + inInspLot + '\''
                }
            })
				.done(function (oData) {
					this.handleGetTxtFieldsSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		handleGetTxtFieldsSuccess: function (oData) {
			if (oData && oData.length > 0) {
				this.getModel('TextFieldsViewModel').setProperty('/TextFields', oData);
			}
		},

		getAddData: function (inInspLot) {
			this.setAppBusyMode();
			/*var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inInspLot = oRcpQualityMainViewModel.Prueflos;*/
			this.getModel('AdditionalDataModel').setProperty('/AdditionalData', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetAddData', {
                urlParameters: {
                    inInspLot: '\'' + inInspLot + '\''
                }
            })
				.done(function (oData) {
					this.handleGetAddDataSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		handleGetAddDataSuccess: function (oData) {
			if (oData && oData.length > 0) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].OriginalInput) {
						oData[i].OriginalInput = oData[i].OriginalInput.replace('.', ',');
					}
				}
				this.getModel('AdditionalDataModel').setProperty('/AdditionalData', oData);
			}
		},
		getLongTextData: function (inInspLot) {
			this.setAppBusyMode();
			/*var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var inInspLot = oRcpQualityMainViewModel.Prueflos;*/
			this.getModel('LongTextModel').setProperty('/LongTextData', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetLongText', {
                urlParameters: {
                    inInspLot: '\'' + inInspLot + '\''
                }
            })
				.done(function (oData) {
					this.handleGetLongTextDataSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},
		handleGetLongTextDataSuccess: function (oData) {
			if (oData.InspLotNumber !== 0) {
				//var LongTextVar = $(oData.LongText).replace('\n','</br>');
				var textData = [{
					"InspLotNumber": oData.InspLotNumber,
					"LongText": String(oData.LongText).replace(/\\n/gi, String.fromCharCode(13, 10)) //oData.LongText
				}];
				this.getModel('LongTextModel').setProperty('/LongTextData', textData);
			}
		},

		getCountries: function () {
			this.setAppBusyMode();
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			this.getModel('SelectViewModel').setProperty('/Countries', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetLoadPoints', {
                        urlParameters: {
                            inLifnr: '\'' + oRcpQualityMainViewModel.Lifnr + '\'',
                            inCity: '\'\'',
                            inKnota: '\'' + oRcpQualityMainViewModel.Knota + '\'',
                            inCountry: '\'\''
                        }
                    })
				.done(function (oData) {
					this.handleGetCountriesSuccess(oData);
				}.bind(this))
				.fail(function (oEvent) {
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		handleGetCountriesSuccess: function (oData) {
			if (oData && oData.length > 0) {
				this.getModel('SelectViewModel').setProperty('/Countries', oData);
				this.getModel('SelectViewModel').setProperty('/Country', oData[0].Country);
				this.getCities(oData[0].Country);
			} else {
				this.getCities('');
				this.getModel('SelectViewModel').setProperty('/Countries', []);
				this.getModel('SelectViewModel').setProperty('/Country', "");
				this.getModel('SelectViewModel').setProperty('/Cities', []);
				this.getModel('SelectViewModel').setProperty('/Knote', "");
			}
		},

		getCities: function (selectedCountry) {
			this.setAppBusyMode();
			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			this.getModel('SelectViewModel').setProperty('/Cities', []);
			this.oDataUtil.read('ZRCP_QUALITY_INSPECTION_SRV', 'GetLoadPoints', {
                        urlParameters: {
                            inLifnr: '\'' + oRcpQualityMainViewModel.Lifnr + '\'',
                            inCity: '\'X\'',
                            inKnota: '\'' + oRcpQualityMainViewModel.Knota + '\'',
                            inCountry: '\'' + selectedCountry + '\''
                        }
                    })
				.done(function (oData) {
					if (oData && oData.length > 0) {
						this.getModel('SelectViewModel').setProperty('/Cities', oData);
						this.getModel('SelectViewModel').setProperty('/Knote', oData[0].Knote);
					} else {
						this.getModel('SelectViewModel').setProperty('/Cities', []);
						this.getModel('SelectViewModel').setProperty('/Knote', '');
					}
				}.bind(this))
				.fail(function (oEvent) {
					this.getModel('SelectViewModel').setProperty('/Cities', []);
					this.getModel('SelectViewModel').setProperty('/Knote', '');
					this.openErrorMessagePopup(oEvent);
				}.bind(this))
				.always(this.setAppNotBusyMode.bind(this));
		},

		openUploadImageDialog: function () {
			if (!this.uploadImageDialog) {
				this.uploadImageDialog = sap.ui.xmlfragment('uploadImageDialog', 'com.upm.upmrcpqualityapp.view.fragment.UploadImageDialog', this);
				this.getView().addDependent(this.uploadImageDialog);
			}
			this.uploadImageDialog.open();
		},

		onUploadImageDialogClosePress: function () {
			this.uploadImageDialog.close();
			this.getModel('ViewModel').setProperty('/Attachments', []);
		},

		onAfterSearchDialogClose: function () {
			this.getFragmentElementById('uploadImageDialog', 'uploadCollections').destroy(true);
			this.getFragmentElementById('uploadImageDialog', 'uploadCollectionsItem').destroy(true);
			this.uploadImageDialog.destroy(true);
			this.uploadImageDialog = null;
		},

		onCapture: function () {
			this.cordovaCameraUtil.handleCaptureImage(this.onSuccess, this.onFail);
		},

		onSelect: function () {
			this.cordovaCameraUtil.handleSelectImage(this.onSuccess, this.onFail);
		},

		onSuccess: function (imageURI) {
			var imageId = sap.ui.core.Fragment.byId('uploadImageDialog', 'imageId');
			imageId.setSrc("data:image/png;base64," + imageURI);
			sap.ui.core.Fragment.byId('uploadImageDialog', 'uploadImageButton').setVisible(true);
		},

		onFail: function (message) {
			sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.Error, 'Error');
		},

		onUpload: function () {
			console.log('cordova.version: ' + cordova.version);
			var imageData = sap.ui.core.Fragment.byId('uploadImageDialog', 'imageId').getSrc();

			var base64Marker = 'data:image/png;base64,';
			var base64Index = imageData.indexOf(base64Marker) + base64Marker.length;
			var base64EncodedData = imageData.substring(base64Index);
			var blob = this.cordovaCameraUtil.b64toBlob(base64EncodedData, 'image/png');

			var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
			var deliveryNumber = oRcpQualityMainViewModel.Vbeln;
			// var oDataModel = new sap.ui.model.odata.ODataModel(this.oDataUtil.getServiceUrl('ZRCP_QUALITY_INSPECTION_SRV'), true);
			// var sSecurityToken = oDataModel.getSecurityToken();
			var sSecurityToken = this.oDataUtil.getSecurityToken('ZRCP_QUALITY_INSPECTION_SRV');

			var currentDate = new Date();
			currentDate.setHours(currentDate.getHours());
			currentDate.setMinutes(currentDate.getMinutes());
			currentDate.setSeconds(currentDate.getSeconds());
            var fileName = this.formatterUtil.formateDateAndTimeForAttachment(currentDate) + '.png';
            var baseUrl = jQuery.sap.getModulePath('com.upm.upmrcpqualityapp');

			var xhr = new XMLHttpRequest();
			xhr.open('POST', baseUrl + '/GWaaS/odata/SAP/ZRCP_QUALITY_INSPECTION_SRV;v=1/RcpqGosAttachmentSet', true);
			xhr.setRequestHeader('slug', deliveryNumber + '/' + fileName);
			xhr.setRequestHeader('Content-Type', 'image/png');
			xhr.setRequestHeader('Accept', 'application/json');
			xhr.setRequestHeader('X-CSRF-Token', sSecurityToken);

			xhr.upload.onprogress = function (e) {
				if (e.lengthComputable) {
					var percentComplete = (e.loaded / e.total) * 100;
					console.log(percentComplete + '% uploaded');
				}
			};

			xhr.onerror = function () {
				console.log('Error');
			};

			xhr.onload = function (oData) {
				if (xhr.status === 201) {
					var successMessage = this.getResourceBundleText('DATA_UPLOAD_SUCCESS');
					sap.m.MessageBox.show(successMessage, sap.m.MessageBox.Icon.Info, 'Success');
					console.log(oData.srcElement.response);
					//	this.onUploadImageDialogClosePress();
					sap.ui.core.Fragment.byId('uploadImageDialog', 'uploadImageButton').setVisible(false);
					var imageId = sap.ui.core.Fragment.byId('uploadImageDialog', 'imageId');
					imageId.setSrc('');
				} else {
					//					var errorMessage = this.getResourceBundleText('DATA_UPLOAD_ERROR');
					sap.m.MessageBox.show(xhr.status + ' ' + xhr.statusText, sap.m.MessageBox.Icon.Error, 'Error');
				}
			}.bind(this);

			xhr.send(blob);
		},

		onUploadCollectionChange: function (oEvent) {
			if (oEvent) {
                oEvent.getSource().setUploadUrl(sap.ui.require.toUrl('com/upm/upmrcpqualityapp') + '/GWaaS/odata/SAP/ZRCP_QUALITY_INSPECTION_SRV;v=1/RcpqGosAttachmentSet')
				var oRcpQualityMainViewModel = this.getModel('RcpQualityMainViewModel').getData();
				var deliveryNumber = oRcpQualityMainViewModel.Vbeln;
				// var oDataModel = new sap.ui.model.odata.ODataModel(this.oDataUtil.getServiceUrl('ZRCP_QUALITY_INSPECTION_SRV'), true);
				// var sSecurityToken = oDataModel.getSecurityToken();
                var sSecurityToken = this.oDataUtil.getSecurityToken('ZRCP_QUALITY_INSPECTION_SRV');
				var oUploadCollection = oEvent.getSource();

				var fileName = oEvent.getParameter('files')[0].name;
				if (sap.ui.Device.system.phone) {
					var fileType = fileName.split('.');
					//	var date = oEvent.getParameter('files')[0].lastModifiedDate;
					var currentDate = new Date();
					currentDate.setHours(currentDate.getHours());
					currentDate.setMinutes(currentDate.getMinutes());
					currentDate.setSeconds(currentDate.getSeconds());

					fileName = formatterUtil.formateDateAndTimeForAttachment(currentDate);
					fileName = fileName + '.' + fileType[1];
				}

				var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
					name: 'slug',
					value: deliveryNumber + '/' + fileName
				});
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'X-CSRF-Token',
					value: sSecurityToken
				}));
				oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
				oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
					name: 'Accept',
					value: 'application/json'
				}));
			}
		},

		onUploadComplete: function (oEvent) {
			var oViewModel = this.getModel('ViewModel');
			var oRawResponse = oEvent.getParameter('files')[0].responseRaw;
			var fileName = oEvent.getParameter('files')[0].fileName;
			// var status = oEvent.getParameter('files')[0].status;
            var oResponse = {};
            try {
                var oResponse = JSON.parse(oRawResponse);
            } catch(oError) {
                console.log(oError);
            }
            var attachments = oViewModel.getProperty('/Attachments') || [];
            if (oResponse.error) {
                var errorMessage = this.getResourceBundleText('DATA_UPLOAD_ERROR', oResponse.error.message.value);
                sap.m.MessageBox.show(errorMessage, sap.m.MessageBox.Icon.Error, 'Error');
            } else if (oResponse && oResponse.d) {
                var message = this.getResourceBundleText('DATA_UPLOAD_SUCCESS');
                sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.Info, 'Success');
                if (sap.ui.Device.system.phone) {
                    var fileType = fileName.split('.');
                    var currentDate = new Date();
                    currentDate.setHours(currentDate.getHours());
                    currentDate.setMinutes(currentDate.getMinutes());
                    currentDate.setSeconds(currentDate.getSeconds());
                    fileName = formatterUtil.formateDateAndTimeForAttachment(currentDate);
                    fileName = fileName + '.' + fileType[1];
                    oResponse.d.fileName = fileName;
                } else {
                    oResponse.d.fileName = fileName;
                }
                attachments.push(oResponse.d);
                oViewModel.setProperty('/Attachments', attachments);
            } else {
                var unhandledErrorMessage = this.getResourceBundleText('DATA_UPLOAD_ERROR');
                sap.m.MessageBox.show(unhandledErrorMessage, sap.m.MessageBox.Icon.Error, 'Error');
            }
		},

		formatDlvDetailsInputFields: function (value1, value2, value3) {
			var itemArray = [];
			if (value1) {
				itemArray.push(value1);
			}
			if (value2) {
				itemArray.push(value2);
			}
			if (value3) {
				itemArray.push(value3);
			}
			var result = itemArray.join(' / ');
			return result;
		},

		/* ========================================= */
		/* 				Focus handling				 */
		/* ========================================= */

		focusToScanfield: function (index) {
			var $canfocus = $('.enterTable input');
			$targetControl = $canfocus.eq(index);
			if ($targetControl) {
				$targetControl.control()[0].focus();
			}
		},

		focusToNextInput: function (keyCode) {
            // THIS CAUSES INFINITE WHILE LOOP
			// var $canfocus = $('.enterTable input');
			// var index = $canfocus.index(document.activeElement);
			// var focusableFound = false;
			// while (!focusableFound && index < $canfocus.length) {
			// 	if (keyCode === 40) {
			// 		index++;
			// 	} else {
			// 		index = index - 1;
			// 	}
			// 	var $curControl = $canfocus.eq(index);
			// 	if ($curControl.control() && $curControl.control()[0] && $curControl.control()[0].getEnabled()) {
			// 		focusableFound = true;
			// 		$curControl.control()[0].focus();
			// 	}
			// }
		},

		focusToNextInput2: function (keyCode) {
            // THIS CAUSES INFINITE WHILE LOOP
			// var $canfocus = $('.enterTable2 input');
			// var index = $canfocus.index(document.activeElement);
			// var focusableFound = false;
			// while (!focusableFound && index < $canfocus.length) {
			// 	if (keyCode === 40) {
			// 		index++;
			// 	} else {
			// 		index = index - 1;
			// 	}
			// 	var $curControl = $canfocus.eq(index);
			// 	if ($curControl.control() && $curControl.control()[0] && $curControl.control()[0].getEnabled()) {
			// 		focusableFound = true;
			// 		$curControl.control()[0].focus();
			// 	}
			// }
		},

		focusToNextInput3: function (keyCode) {
            // THIS CAUSES INFINITE WHILE LOOP
			// var $canfocus = $('.enterTable3 input');
			// var index = $canfocus.index(document.activeElement);
			// var focusableFound = false;
			// while (!focusableFound && index < $canfocus.length) {
			// 	if (keyCode === 40) {
			// 		index++;
			// 	} else {
			// 		index = index - 1;
			// 	}
			// 	var $curControl = $canfocus.eq(index);
			// 	if ($curControl.control() && $curControl.control()[0] && $curControl.control()[0].getEnabled()) {
			// 		focusableFound = true;
			// 		$curControl.control()[0].focus();
			// 	}
			// }
		}
	});
});