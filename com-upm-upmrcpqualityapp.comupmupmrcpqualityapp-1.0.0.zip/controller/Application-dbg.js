sap.ui.define([
	'sap/ui/base/Object',
	'sap/ui/model/resource/ResourceModel',
	'com/upm/upmrcpqualityapp/model/models'
], function(Object, ResourceModel, models) {
	'use strict';

	return Object.extend('com.upm.upmrcpqualityapp.controller.Application', {

		constructor: function(component) {
			this.component = component;
		},

		init: function() {
			// jQuery.sap.includeStyleSheet(
			// 	jQuery.sap.getModulePath('com.upm.upmrcpqualityapp') + '/css/styles.css'
			// );

			this.component.setModel(
				new ResourceModel({
					bundleUrl: [
						jQuery.sap.getModulePath('com.upm.upmrcpqualityapp'),
						this.component.getMetadata().getConfig().resourceBundle
					].join('/')
				}), 'i18n');


			this.component.setModel(models.createDeviceModel(), 'Device');
			this.component.setModel(models.createGlobalPropertiesModel(), 'GlobalPropertiesModel');

			this.initializeRouter();

			this.component.attachParseError(this.showElementError);
			this.component.attachValidationError(this.showElementError);
			this.component.attachValidationSuccess(this.hideElementError);
		},

		initializeRouter: function() {
			var router = this.component.getRouter();

			router.attachBypassed(this.onBypassed.bind(this), this);

			router.initialize();
		},

		onBypassed: function() {

		},

		showElementError: function(oEvent) {
			var element = oEvent.getParameter('element');
			element.setValueState ?
				element.setValueState(sap.ui.core.ValueState.Error) :
				element.addStyleClass('selectError');
		},

		hideElementError: function(oEvent) {
			var element = oEvent.getParameter('element');
			element.setValueState ?
				element.setValueState(sap.ui.core.ValueState.None) :
				element.removeStyleClass('selectError');
		},

		getNavigationIntent: function() {
			var urlParser = sap.ushell.Container.getService('URLParsing');
			return urlParser.parseShellHash(urlParser.getHash(window.location.href)).action;
		}
	});
});