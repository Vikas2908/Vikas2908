sap.ui.define([
	'sap/ui/model/json/JSONModel'
], function(JSONModel) {
	'use strict';

	return JSONModel.extend('com.upm.upmrcpqualityapp.model.DemoModel', {
		constructor: function() {
			JSONModel.call(this, {});
			this.setInitialData();
			this._setUpdateBindings();
			return this;
		},

        _setUpdateBindings: function() {
            var binding = new sap.ui.model.json.JSONPropertyBinding(this, '/keyboardModeEdit', new sap.ui.model.Context(this, '/keyboardModeEdit'));
            // Change keyboardModeEdit back to Edit, if it changes
			binding.attachChange(function() {
				this.setProperty('/keyboardModeEdit', 'Edit');
			}.bind(this));
        },

		setInitialData: function() {
			this.setData({
				keyboardModeEdit: 'Edit'
			});
		}
	});
});