sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device'
], function(JSONModel, Device) {
	'use strict';

	return {
		createDeviceModel: function(additionalProperties) {
			var oDeviceModel = new JSONModel(
				$.extend({
					isTouch: Device.support.touch,
					isNoTouch: !Device.support.touch,
					isTablet : Device.system.tablet,
		            isNoTablet : !Device.system.tablet,
					isPhone: Device.system.phone,
					isNoPhone: !Device.system.phone,
                    isCordova: window.cordova ? true : false,
                    isNoCordova: window.cordova ? false : true
				}, additionalProperties)
			);
			oDeviceModel.setDefaultBindingMode('OneWay');
			return oDeviceModel;
		},

		createGlobalPropertiesModel: function(additionalProperties) {
			var oGlobalProperitesModel = new JSONModel(
				$.extend({

				}, additionalProperties)
			);
			return oGlobalProperitesModel;
		}
	};
});