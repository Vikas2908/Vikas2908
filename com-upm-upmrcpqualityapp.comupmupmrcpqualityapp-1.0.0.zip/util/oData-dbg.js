// oDataUtil
sap.ui.define([],
	function() {
		'use strict';
        var baseUrl = jQuery.sap.getModulePath('com.upm.upmrcpqualityapp');
        var models = {};

		return {
			// Define services here
			services: {
				'ZRCP_QUALITY_INSPECTION_SRV': baseUrl + '/GWaaS/odata/SAP/ZRCP_QUALITY_INSPECTION_SRV;v=1'
			},

			getServiceUrl: function(serviceName) {
				var service = this.services[serviceName];
				if (!service) {
					throw new Error('Service: ' + service + ' not found');
				}
				return service;
			},

            getOdataModel: function(modelName) {
				if (!models[modelName]) {
					models[modelName] = new sap.ui.model.odata.v2.ODataModel(this.getServiceUrl(modelName), {
						useBatch: false
					});
				}
				return models[modelName];
			},

			getSecurityToken: function(modelName) {
				var securityToken;
				this.getOdataModel(modelName).refreshSecurityToken(function() {
					securityToken = this.getOdataModel(modelName).getSecurityToken();
				}.bind(this), function() {});
				return securityToken;
			},

			handleResultsObjects: function(oData) {
				oData = oData['results'] ? oData['results'] : oData;
				return typeof oData === 'object' && oData !== null && !Array.isArray(oData) ?
					this.removeResultFromObject(oData) :
					oData;
			},

			removeResultFromObject: function(oData) {
				Object.keys(oData).map(function(key) {
					oData[key] = oData[key] !== null && typeof oData[key] === 'object' && oData[key] && oData[key]['results'] ?
						oData[key]['results'] :
						oData[key];
					if (Array.isArray(oData[key])) {
						oData[key] = oData[key].map(this.removeResultFromObject.bind(this));
					}
				}.bind(this));

				return oData;
			},

            checkPathToService: function(sPath) {
                if (sPath.indexOf('/') !== 0) {
                    sPath = '/' + sPath;
                }
                return sPath;
            },

			/**
			 * Reads data from back end
			 * @param {string} sService - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object=} filters - filter parameters
			 * @param {object=} sorters - sorter parameters
			 * @param {string=} urlParameters - additional url parameters
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end or error event
			 */
			read: function(serviceName, pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

				var oDataModel = this.getOdataModel(serviceName).attachMetadataFailed(function(oError) {
					deferred.reject(oError);
				}.bind(this));;
                // new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
                pathToService = this.checkPathToService(pathToService);
				oDataModel.read(pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					filters: oParameters && oParameters.filters ? oParameters.filters : null,
					sorters: oParameters && oParameters.sorters ? oParameters.sorters : null,
					urlParameters: oParameters && oParameters.urlParameters ? oParameters.urlParameters : null,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Removes data from back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end or error event
			 */
			remove: function(serviceName, pathToService, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

                var oDataModel = this.getOdataModel(serviceName);
				// var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
                pathToService = this.checkPathToService(pathToService);
				oDataModel.remove(pathToService, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Posts data to back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToPost - data to be posted to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			create: function(serviceName, pathToService, dataToPost, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

                var oDataModel = this.getOdataModel(serviceName);
				// var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
                pathToService = this.checkPathToService(pathToService);
				oDataModel.create(pathToService, dataToPost, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			},

			/**
			 * Updates data to back end
			 * @param {string} serviceName - part of the uri, before path to service
			 * @param {string} pathToService - path to the service
			 * @param {object} dataToUpdate - data to be updated to back end
			 * @param {boolean=} async - make call async
			 * @returns {object} data from back end
			 */
			update: function(serviceName, pathToService, dataToUpdate, oParameters) {
				var deferred = $.Deferred();

				oParameters = oParameters || {};

                var oDataModel = this.getOdataModel(serviceName);
				// var oDataModel = new sap.ui.model.odata.ODataModel(this.getServiceUrl(serviceName), true);
                pathToService = this.checkPathToService(pathToService);
				oDataModel.update(pathToService, dataToUpdate, {
					async: oParameters && oParameters.hasOwnProperty('async') ? oParameters.async : true,
					success: function(oData) {
						deferred.resolve(this.handleResultsObjects(oData));
					}.bind(this),
					error: function(errEvt) {
						deferred.reject(errEvt);
					}
				});

				return deferred.promise();
			}
		};
	});